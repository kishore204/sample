/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("flm.fiori.utils.utilities");
function getErrorMessage(messageString,header){if(messageString==""||messageString==null||messageString==undefined){return null}else if(header==""||header==null||header==undefined){return null}if(header["Content-Type"].indexOf("xml")>-1){var xmlDoc=$.parseXML(messageString);var xmlArr=$(xmlDoc);var xmlMessage=xmlArr.find("message");var message=xmlMessage[0].textContent;return message}else{var msgObj=eval("("+messageString+")");var message=msgObj.error.message.value;return message}}
;
function getErrorJson(messageString){var msgObj=eval("("+messageString+")");var message=msgObj.error.message.value;return message}
;
function dateFormatter(d){if(d==null){d=new Date()}var y=d.getFullYear();var m=null;var a=null;if((d.getMonth()+1)<10){m="0"+(d.getMonth()+1)}else{m=d.getMonth()+1}if((d.getDate())<10){a="0"+(d.getDate())}else{a=d.getDate()}return y.toString().concat(m,a)}
;
