/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("flm.fiori.utils.utilities");
 
// function for extracting the error from the error string
function getErrorMessage(messageString, header){
	if(messageString == "" || messageString == null || messageString == undefined){
		return null;
	}else if(header == "" || header == null || header == undefined){
		return null;
	}
	if(header["Content-Type"].indexOf("xml") >-1){
		var xmlDoc = $.parseXML( messageString );
		var  xmlArr = $( xmlDoc );
		var  xmlMessage = xmlArr.find( "message" );
		var message = xmlMessage[0].textContent;
		return message;
	}else{
		var msgObj = eval("(" + messageString + ")");
		var message = msgObj.error.message.value;
		return message;
	}
};

function getErrorJson(messageString){
	var msgObj = eval("(" + messageString + ")");
	var message = msgObj.error.message.value;
	return message;
};

// Date Formatter

function dateFormatter(oDate) {
	
	if (oDate == null) {
		oDate = new Date();
	}
	var year = oDate.getFullYear();
	var month = null;
	var date = null;
	if ((oDate.getMonth() + 1) < 10) {
		month = "0" + (oDate.getMonth() + 1);
	} else {
		month = oDate.getMonth() + 1;
	}
	if ((oDate.getDate()) < 10) {
		date = "0" + (oDate.getDate());
	} else {
		date = oDate.getDate();
	}

	return year.toString().concat(month, date);

};