/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("flm.fiori.utils.dynamicUIAssist");

function createDynamicUI(p, c, v, f, d) {
	var a = [];
	var t = p;
	var g = null;
	for (var i = 0; i < t.length; i++) {
		if (t[i] != undefined && t[i] != null) {
			if (v.byId(t[i].ID) == undefined) {
				if (g != t[i].GROUP && t[i].GROUP != "") {
					createGroup(t[i].GROUP_TITLE, c, v, f);
					g = t[i].GROUP
				}
				a.push({
					"id": t[i].ID,
					"type": t[i].TYPE,
				});
				if (d) {
					t[i].DISABLED = true
				}
				switch (t[i].TYPE) {
					case "IP":
						hbox = createInputField(t[i], c, v, f);
						if (t[i].CURR_ID != null && t[i].CURR_ID != undefined && t[i].CURR_ID != "") {
							var k = null;
							for (var j = 0; j < p.length; j++) {
								if (p[j].ID == t[i].CURR_ID) {
									k = j
								}
							}
							if (k != null) {
								if (t[i].DISABLED) {
									p[k].DISABLED = true
								}
								p[k].LABEL = "Currency";
								createInputField(p[k], c, v, f, hbox)
							}
						}
						break;
					case "F4":
						createInputField(t[i], c, v, f);
						break;
					case "DP":
						createDatePicker(t[i], c, v, f);
						break;
					case "TP":
						createDatePicker(t[i], c, v, f);
						break;
					case "CB":
						createSwitch(t[i], c, v, f);
						break
				}
			}
		}
	}
	return a
}

function createInputField(p, c, v, f, h) {
	var a = null;
	var l = null;
	var n = null;
	if (p.ID != null && p.ID != undefined && p.ID != "") {
		a = new sap.m.Input(p.ID, {
			liveChange: c.onChangeFileAttribute
		})
	};
	if (p.VALUE != null && p.VALUE != undefined && p.VALUE != "") {
		if (p.CURR_ID != null && p.CURR_ID != undefined && p.CURR_ID != "") {
			a.setValue(p.VALUE.trim())
		} else {
			a.setValue(p.VALUE)
		}
	};
	if (p.MAXLENGTH != null && p.MAXLENGTH != undefined && p.MAXLENGTH != "") {
		a.setMaxLength(parseInt(p.MAXLENGTH))
	};
	if (p.TYPE == "F4" || p.TYPE == "CU") {
		a.setShowValueHelp(true);
		a.attachValueHelpRequest(c.handleF4Help)
	};
	if (p.CURR_ID != null && p.CURR_ID != undefined && p.CURR_ID != "") {
		a.setType(sap.m.InputType.Number);
		n = new sap.m.HBox()
	};
	if (p.LABEL != null && p.LABEL != undefined && p.LABEL != "") {
		l = new sap.m.Label({
			text: p.LABEL,
			tooltip: p.LABEL
		});
		a.setName(p.LABEL);
		if (p.MANDATORY == true) {
			l.setRequired(true)
		}
		l.setLabelFor(a);
		v.byId(f).addContent(l)
	};
	if (p.DISABLED == true) {
		a.setEditable(false)
	}
	if (h == undefined) {
		if (n == null) {
			v.byId(f).addContent(a)
		} else {
			n.addItem(a);
			v.byId(f).addContent(n)
		}
	} else {
		h.addItem(a)
	}
	return n
};

function createDatePicker(p, c, v, f, s) {
	var a = null;
	var l = null;
	var n = new sap.m.HBox({
		alignItems: "Center"
	});
	if (p.ID != null && p.ID != undefined && p.ID != "") {
		a = new sap.m.DateTimeInput(p.ID, {
			change: c.onChangeDateTimeInDynamicUI
		});
		var b = new sap.ui.core.Icon({
			id: p.ID + "Clear",
			src: "sap-icon://sys-cancel",
			size: "1rem",
			tooltip: sap.ui.getCore().getModel("i18n").getObject("CLEAR"),
			press: function() {
				a.setValue("");
				b.setVisible(false);
				c.saveFlag = true
			},
		});
		if (p.TYPE == "DP") {
			a.setType("Date");
			a.setDisplayFormat("dd/MM/yyyy")
		} else if (p.TYPE == "TP") {
			a.setValueFormat("HH:mm");
			a.setDisplayFormat("HH:mm");
			a.setType("Time")
		};
		if (p.VALUE != null && p.VALUE != undefined && p.VALUE != "" && p.VALUE != "00000000") {
			if (p.TYPE == "DP") {
				a.setValue(p.VALUE)
			} else if (p.TYPE == "TP") {
				a.setValue(p.VALUE.substr(0, 4))
			}
		};
		if (p.DISABLED == true) {
			a.setEditable(false)
		};
		if (p.LABEL != null && p.LABEL != undefined && p.LABEL != "") {
			l = new sap.m.Label({
				text: p.LABEL,
				tooltip: p.LABEL
			});
			a.setName(p.LABEL);
			if (p.MANDATORY == true) {
				l.setRequired(true)
			};
			l.setLabelFor(a);
			v.byId(f).addContent(l)
		};
		n.addItem(a);
		n.addItem(b);
		if (a.getValue() == "" || !a.getEditable()) {
			sap.ui.getCore().byId(p.ID + "Clear").setVisible(false)
		}
		v.byId(f).addContent(n)
	}
}

function createSwitch(p, c, v, f) {
	var a = null;
	var l = null;
	if (p.ID != null && p.ID != undefined) {
		a = new sap.m.Switch(p.ID, {
			customTextOn: sap.ui.getCore().getModel("i18n").getObject("YES"),
			customTextOff: sap.ui.getCore().getModel("i18n").getObject("NO"),
			change: c.onChangeFileAttribute
		})
	};
	if (p.VALUE == "X") {
		a.setState(true)
	};
	if (p.DISABLED == true) {
		a.setEnabled(false)
	};
	if (p.INVISIBLE == true) {
		a.setVisible(false)
	};
	if (p.LABEL != null && p.LABEL != undefined) {
		l = new sap.m.Label({
			text: p.LABEL,
			tooltip: p.LABEL
		});
		a.setName(p.LABEL);
		if (p.MANDATORY == true) {
			l.setRequired(true)
		};
		l.setLabelFor(a);
		v.byId(f).addContent(l)
	};
	v.byId(f).addContent(a)
};

function createGroup(g, c, v, f) {
	if (g != null && g != undefined) {
		// v.byId(f).addContent(new sap.ui.core.Title({
		// 	text: g,
		// 	emphasized: false,
		// 	level: "H5"
		// }))
	}
};

function getF4Array(f) {
	var s = "!!";
	var a = ",,";
	var b = f.split(s);
	var c = new Array();
	for (var i = 0; i < b.length; i++) {
		tempArr = null;
		tempArr = b[i].split(a);
		c[i] = {};
		if (tempArr[0] != undefined) c[i].ResulltCol1 = tempArr[0];
		if (tempArr[1] != undefined) c[i].ResultCol2 = tempArr[1]
	}
	return c
}

function getDateArray(v) {
	var s = "!!";
	var a = ",";
	var f = v.split(s);
	var b = new Array();
	for (var i = 0; i < f.length; i++) {
		tempDateArr = null;
		tempDateArr = f[i].split(a);
		b[i] = {};
		if (tempDateArr[0] != undefined) b[i].ResulltCol1 = tempDateArr[0];
		if (tempDateArr[1] != undefined) b[i].ResultCol2 = tempDateArr[1];
		if (tempDateArr[2] != undefined) b[i].ResulltCol3 = tempDateArr[2]
	}
	return b
}