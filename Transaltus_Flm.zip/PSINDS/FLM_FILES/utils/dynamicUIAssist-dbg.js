/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("flm.fiori.utils.dynamicUIAssist");

function createDynamicUI(params, oController, oView, formId, disabledMode) {

 var dynUIAssistArr = []; // contains objects with id and type as
        // attributes..
 var tParams = params;
 var group = null; // Create elements and assign them to the view for
 for (var i = 0; i < tParams.length; i++) {
  if (tParams[i] != undefined && tParams[i] != null) {
   if (oView.byId(tParams[i].ID) == undefined) {
    if (group != tParams[i].GROUP && tParams[i].GROUP != "") {
     createGroup(tParams[i].GROUP_TITLE, oController, oView,
       formId);
     group = tParams[i].GROUP;
    }

    dynUIAssistArr.push({
     "id" : tParams[i].ID,
     "type" : tParams[i].TYPE,
    });
    if (disabledMode) {
     tParams[i].DISABLED = true;
    }

    switch (tParams[i].TYPE) {

    case "IP":
     hbox = createInputField(tParams[i], oController, oView,
       formId);
     if (tParams[i].CURR_ID != null
       && tParams[i].CURR_ID != undefined
       && tParams[i].CURR_ID != "") {
      var k = null;
      for (var j = 0; j < params.length; j++) {
       if (params[j].ID == tParams[i].CURR_ID) {
        k = j;
       }
      }
      if (k != null) {
       if(tParams[i].DISABLED){
        params[k].DISABLED = true;
       }
       params[k].LABEL="Currency";
       createInputField(params[k], oController, oView,
         formId, hbox);
      }
     }
     break;
    case "F4":
     createInputField(tParams[i], oController, oView, formId);
     break;
    case "DP": 
     createDatePicker(tParams[i], oController, oView, formId);
     break;
    case "TP":
     createDatePicker(tParams[i], oController, oView, formId);
     break;
    case "CB":
     createSwitch(tParams[i], oController, oView, formId);
     break;
//    default:
//     createInputField(tParams[i], oController, oView, formId);
//     break;
    }
   }
   ;
  }
  ;
 }

 return dynUIAssistArr;
}

function createInputField(param, oController, oView, formId, hbox) {
 var control = null;
 var label = null;
 var newhbox = null;
 if (param.ID != null && param.ID != undefined && param.ID != "") {
  control = new sap.m.Input(param.ID, {
   liveChange: oController.onChangeFileAttribute
  // width : "30rem"
  });
 }
 ;
 if (param.VALUE != null && param.VALUE != undefined && param.VALUE != "") {

  if (param.CURR_ID != null && param.CURR_ID != undefined
    && param.CURR_ID != "") {
   control.setValue( param.VALUE.trim());
  } else {
   control.setValue(param.VALUE);
  }
 }
 ;
 if (param.MAXLENGTH != null && param.MAXLENGTH != undefined
   && param.MAXLENGTH != "") {
  control.setMaxLength(parseInt(param.MAXLENGTH));
 }
 ;
 if (param.TYPE == "F4" || param.TYPE == "CU" ) {
  control.setShowValueHelp(true);
  control.attachValueHelpRequest(oController.handleF4Help);
 }
 ;
 if (param.CURR_ID != null && param.CURR_ID != undefined
   && param.CURR_ID != "") {
  control.setType(sap.m.InputType.Number);
  newhbox = new sap.m.HBox();
 }
 ;
 if (param.LABEL != null && param.LABEL != undefined && param.LABEL != "") {
  label = new sap.m.Label({
   text : param.LABEL,
   tooltip: param.LABEL
  });
  control.setName(param.LABEL);
  if (param.MANDATORY == true) {
   label.setRequired(true);
  }
  label.setLabelFor(control);
  oView.byId(formId).addContent(label);
 }
 ;

 if (param.DISABLED == true) {
  control.setEditable(false);
 }
 if (hbox == undefined) {
  if (newhbox == null) {
   oView.byId(formId).addContent(control);
  } else {
   newhbox.addItem(control);
   oView.byId(formId).addContent(newhbox);
  }
 } else {
  hbox.addItem(control);
 }
 return newhbox;
};

function createDatePicker(param, oController, oView, formId, saveFlag) {

 var control = null; 
 var label = null;
 //Date and ClearDate Icon to be kept in HBox 
 var newhbox = new sap.m.HBox({alignItems: "Center"}); 
 if (param.ID != null && param.ID != undefined && param.ID != "") { 
  control = new sap.m.DateTimeInput(param.ID,{
   change: oController.onChangeDateTimeInDynamicUI
  });
  var clearDateTime = new sap.ui.core.Icon(
    { id: param.ID + "Clear",
     src : "sap-icon://sys-cancel", 
     size : "1rem",
     tooltip : sap.ui.getCore().getModel("i18n").getObject("CLEAR"),
     press : function() {
         control.setValue("");
//         control.setDateValue("");
         clearDateTime.setVisible(false);
         oController.saveFlag = true;
       },
    });
  if (param.TYPE == "DP") {
   control.setType("Date");
   control.setDisplayFormat("dd/MM/yyyy");
//   control.setValueFormat("YYYYMMDD");
  } else if (param.TYPE == "TP") {
//   param.VALUE = param.VALUE;//.substr(0, 4);
   control.setValueFormat("HH:mm");
   control.setDisplayFormat("HH:mm");
   control.setType("Time");
  }
  ;
  // control.setDisplayFormat(); // control.setValueFormat(); } ;
  if (param.VALUE != null && param.VALUE != undefined
    && param.VALUE != "" && param.VALUE !="00000000") {

   if (param.TYPE == "DP") {
    control.setValue(param.VALUE);
   } else if (param.TYPE == "TP") {
    control.setValue(param.VALUE.substr(0, 4));
   }

  }
  ;
  if (param.DISABLED == true) {
   control.setEditable(false);
  }
  ;

  if (param.LABEL != null && param.LABEL != undefined
    && param.LABEL != "") {
   label = new sap.m.Label({
    text : param.LABEL,
    tooltip: param.LABEL
   });
   control.setName(param.LABEL);
   if (param.MANDATORY == true) {
    label.setRequired(true);
   }
   ;
   label.setLabelFor(control);
   oView.byId(formId).addContent(label);
  }
  ;
  newhbox.addItem(control);
  newhbox.addItem(clearDateTime);
  if(control.getValue()=="" || !control.getEditable()){
   sap.ui.getCore().byId(param.ID+"Clear").setVisible(false);
  }
//  oView.byId(formId).addContent(control);
  oView.byId(formId).addContent(newhbox);
 }
 ;
}

function createSwitch(param, oController, oView, formId) {
 var control = null;
 var label = null;
 if (param.ID != null && param.ID != undefined) {
  control = new sap.m.Switch(param.ID, {
   customTextOn : sap.ui.getCore().getModel("i18n").getObject("YES"),
   customTextOff : sap.ui.getCore().getModel("i18n").getObject("NO"),
   change: oController.onChangeFileAttribute
  });
 }
 ;
 if (param.VALUE == "X") {
  control.setState(true);
 }
 ;
 if (param.DISABLED == true) {

  control.setEnabled(false);
 }
 ;
 if (param.INVISIBLE == true) {
  control.setVisible(false);
 }
 ;

 if (param.LABEL != null && param.LABEL != undefined) {
  label = new sap.m.Label({
   text : param.LABEL,
   tooltip: param.LABEL
  });
  control.setName(param.LABEL);
  if (param.MANDATORY == true) {
   label.setRequired(true);
  }
  ;
  label.setLabelFor(control);
  oView.byId(formId).addContent(label);
 }
 ;
 oView.byId(formId).addContent(control);
};

function createGroup(groupName, oController, oView, formId) {
 if (groupName != null && groupName != undefined) {
  oView.byId(formId).addContent(new sap.ui.core.Title({
   text : groupName,
   emphasized : false,
   level : "H5"
  }));
 }
 ;
};

function getF4Array(f4string) {
 var sep1 = "!!";
 var sep2 = ",,";
 var f4arr = f4string.split(sep1);
 var f4Array = new Array();
 for (var i = 0; i < f4arr.length; i++) {
  tempArr = null;
  tempArr = f4arr[i].split(sep2);
  f4Array[i] = {};
  if (tempArr[0] != undefined)
   f4Array[i].ResulltCol1 = tempArr[0];
  if (tempArr[1] != undefined)
   f4Array[i].ResultCol2 = tempArr[1];
 }
 return f4Array;
}

function getDateArray(val) {
 var sep1 = "!!";
 var sep2 = ",";
 var f4arr = val.split(sep1);
 var f4Array = new Array();
 for (var i = 0; i < f4arr.length; i++) {
  tempDateArr = null;
  tempDateArr = f4arr[i].split(sep2);
  f4Array[i] = {};
  if (tempDateArr[0] != undefined)
   f4Array[i].ResulltCol1 = tempDateArr[0];
  if (tempDateArr[1] != undefined)
   f4Array[i].ResultCol2 = tempDateArr[1];
  if (tempDateArr[2] != undefined)
   f4Array[i].ResulltCol3 = tempDateArr[2];
 }
 return f4Array;
}