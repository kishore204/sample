/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("flm.fiori.utils.formatter");
jQuery.sap.require("sap.m.Label");

flm.fiori.utils.formatter = {
  trackState :  function (sValue) {
    try {
      
      if (sValue == true) {
        return true;
      } else if (sValue == false) {
        return false;
      } else {
        return "Error";
      }
    } catch (err) {
      return "None";
    }
  },
  
  privateColor : function(val){
	  try {
	      
	      if (val == true) {
	        return "true";
	      } else if (val == false) {
	        return "false";
	      } else {
	        return "Error";
	      }
	    } catch (err) {
	      return "None";
	    };
  },
  
  designationValueVisibility : function(val){
	  
	if(val == ""){
		return false;
	}
		else{
			return true;
		}	 
  },
  
  substitutionDetailsVisibility : function(val){
	  
	  if(val == ""){
			return false;
		}
			else{
				return true;
			} 
  },
  
  enabledStatus: function(val1,val2){
      if (val1 == "CABINET"|| val1 == "ASSISTANT" || val1=="DOCUMENT" || val1=="DOCDAAK" || val2=="" || val1=="SEARCH" || val1=="CABINDAAK" || val1=="SEARCHDAAK") {
		return false;
	} else {
		return true;
	}

},

noteColumVisibility : function(val){
	 if (val == "TRACKDAAK") {
			return false;
		} else {
			return true;
		}
},

enabledStatusNoting: function(val1){
    if (val1 == "CABINET" || val1=="DOCUMENT") {
		return false;
	} else {
		return true;
	}

},

enableLinkStatus: function(val){
	if (val == "CABINET"
		|| val == "ASSISTANT" || val=="DOCUMENT" || val == "SEARCHFILE") {
	return false;
}
},
editNoteEnabledState : function(val){
	if (val == "CABINET"
		|| val == "ASSISTANT" || val=="DOCUMENT") {
	return false;
	}
},

  
  editorValue : function(val){
 try {
	      
	      if (val == undefined) {
	        return "";
	      } else {
	    	  return val;
	      }
	    } catch (err) {
	      return "None";
	    }
  },
  
  editorHTMLValue : function(val){
	  try {
	 	      
	 	      if (val == undefined || val == null || val == "") {
	 	        return "<h1></h1>";
	 	      } else {
	 	    	  return val;
	 	      }
	 	    } catch (err) {
	 	      return "None";
	 	    }
	   },
  
  documentRow1: function(name,createdon){

	 /* var str1 = "Uploaded By - "+name;*/
	  var str1 = sap.ui.getCore().getModel("i18n").getObject("UPLOADED_BY")+ " - " + name;
		if (createdon != 0) {
			/*str1 += " ; Uploaded On - "+createdon;*/
			str1 += " ; "+ sap.ui.getCore().getModel("i18n").getObject("UPLOADED_ON") + " - " +createdon;
		}
		return str1;
  },
	 /*  documentRow1: function(name,createdon){
		   		var str = new sap.m.Label({
		   			text: "Uploaded By"
		   		});
		   		var str2 = new sap.m.Label({
		   			text: "; Uploaded On "
		   		});
			  var str1 = str + name;
				if (createdon != 0) {
					str1 += str2 + createdon;
				}
				return str1;
		  },*/
		  
  documentRow2: function(flagIsAttachment,flagIsFile,flagIsDaak,flagIsObject,flagIsReport,FileSize,filetitle,filename){

	  var str2="";
	  if (flagIsAttachment) {
			str2 = /*"Attachment Name - "+filetitle+*/sap.ui.getCore().getModel("i18n").getObject("DOCUMENTTYPE") + " - "+filename;
		} 
		else if(flagIsObject){
			str2 = sap.ui.getCore().getModel("i18n").getObject("OBJECTTYPE") + " - "+filename;
		}
		else if(flagIsReport){
			str2 = sap.ui.getCore().getModel("i18n").getObject("REPORT_TYPE") + " - "+filetitle+" ; "+ sap.ui.getCore().getModel("i18n").getObject("DOCUMENTTYPE") + " - "+filename;
		}
		else if(flagIsDaak){
			str2 = sap.ui.getCore().getModel("i18n").getObject("SUBJECT") + " - "+filetitle+" ; "+ sap.ui.getCore().getModel("i18n").getObject("DOCUMENTTYPE") + " - "+filename;
		}
		else {
			str2 = sap.ui.getCore().getModel("i18n").getObject("SUBJECT") + " - "+filetitle+" ; "+ sap.ui.getCore().getModel("i18n").getObject("DOCUMENTTYPE") + " - "+filename;
		}

//		if (FileSize != 0) {
//			str2 += " ; Attachment Size - "+FileSize+"KB";
//		}
		return str2;
  },
  
  tooltipText : function(val){
	  if(val==true){
		  return sap.ui.getCore().getModel("i18n").getObject("ON");
	  }else{
		  return sap.ui.getCore().getModel("i18n").getObject("OFF");
	  }
	  
  },
  treeTableIcon: function(val1, val2){
	  if(val2=='X'){
		  return "";
	  }
	  else if(val2 != "" && val2 !=undefined){
		  return "sap-icon://company-view";
	  }
	  else if(val1=="X"){
		  return "sap-icon://employee-approvals";
	  }
	  else if(val1=="I"){
		  return "sap-icon://employee-lookup";
	  }
	  else{
		  return "sap-icon://customer";
	  }
  },
  
  treeTableIconColor: function(val,val1,val2){
	  if(val=="X"){
		  if(val1 != ""){
			  return "#193E19";
		  }
		  else if(val2 !=""){
			  return "#2E8AE6";
		  }
		  else{
		  return "#33CC33";
	  }
	  }
	  else if(val=="I"){
		  return "#F0AB00";
	  }
	  else{
		  return "#999999";
	  }
  },
  
  treeTableFlowIcon: function(val){
	  
	  if(val=="S"){
		  return "sap-icon://pull-down";
	  }
	  else {
		  return "sap-icon://share-2";
	  }
  },
    
  formatDate: function(inDate){
	  
	  if(inDate != null && inDate != ""){
		  var date1 = [];
		  date1 = inDate.split(".");
		  date = date1[2]+date1[1]+date1[0];
//		  numbers = inDate.match(/\d+/g); 
//		  date = new Date(numbers[2], numbers[1]-1, numbers[0]);
//		  return date;
		  
		  return date;
	  }
	  
  },
  
  numberFormatter : function(inNumber){
	  if(inNumber != null && inNumber != ""){
		  var sNumberType = sap.ui.core.format.NumberFormat.getInstance({
				minIntegerDigits: 1,
				maxIntegerDigits: 15,
				minFractionDigits: 0,
				maxFractionDigits: 3,
				groupingEnabled: true,
				groupingSeparator: ",",
				decimalSeparator: ".",
				plusSign: "+",
				minusSign: "-",
				isInteger: false
			});
		  var outNumber = sNumberType.format(inNumber);
		  return outNumber;
	  }else{
		  //do error handling
	  }
	  
  }  ,
  
  selectEnabledStatus: function(value){
      if (value=="Sequence" || value=="Parallel") {
		return false;
	} else {
		return true;
	}
},

notingidDisplay : function(id, flag, name, creator, date){
	if(flag){
		 newId = id.replace('P','');
		newId = newId.replace(/^0+/, '00');
		var displayId="P";
		displayId= displayId.concat(newId);
		var headerValue =  displayId  + " " +name+ " "+ creator+ " " + date;
		return headerValue;
	}else{
		var displayId = id.replace(/^0+/, '00');
		var headerValue = displayId  + " " +name+ " "+ creator+ " " + date;
		return headerValue;
	}
},

valueHelpVisibility : function(val){
	if(val == ""){
		return false;
	}else{
		return true;
	}
},

trackSubState : function(val,endDate){
	
	var dat = endDate.split(".");
    //var ndate = Date(dat[2],dat[1],dat[0],"23","59","59");
	var ndate = new Date(dat[2], dat[1]-1, dat[0],"23","59","59");
/*	if(d.getMonth()<10){
		d=d.getFullYear()+"0"+(d.getMonth()+1)+d.getDate();
	}else{
		d=d.getFullYear()+(d.getMonth()+1)+d.getDate();
	}
	endDate=endDate.replace(/\./g, "");
	endDate=endDate.substr(4,4)+endDate.substr(2,2)+endDate.substr(0,2);*/
    var d=new Date();
	if(val=="Active" && (ndate>=d)){
		return true;
	}
	else{
		return false;
	}
},

trackSubEnable : function(endDate){
	var d=new Date();
	var dat = endDate.split(".");
    var ndate = new Date(dat[2],dat[1]-1,dat[0],"23","59","59");
	/*if(d.getMonth()<10){
		d=d.getFullYear()+"0"+(d.getMonth()+1)+d.getDate();
	}else{
		d=d.getFullYear()+(d.getMonth()+1)+d.getDate();
	}
	endDate=endDate.replace(/\./g, "");
	endDate=endDate.substr(4,4)+endDate.substr(2,2)+endDate.substr(0,2);*/
    if(ndate>=d){
		return true;
	}
	else{
		return false;
	}
},

linkEnabled : function(val){
	if(val=="X"){
		return false;
	}else{
		return true;
	}
},

linkEmphasized : function(val){
	if(val=="X"){
		return true;
	}else{
		return false;
	}
},

lockSelect : function(val){
	if(val=="Sequence" || val=="Parallel"){
		return false;
	}else{
		return true;
	}
},

privateNoteVisibility : function(val){
	if(!val || val=="" || val=="<a/>"){
		return false;
	}else{
		return true;
	}
},

/*addPrefixLineBreak : function(val,flag){
	if(flag && val && val.substring(val.length-5,val.length-1)!="<br/>"){
		val+="<br/>";
	}
return decodeURIComponent(val);
},*/
};
