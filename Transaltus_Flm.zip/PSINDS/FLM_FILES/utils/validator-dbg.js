/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("flm.fiori.utils.validator");

function validateInput(oController, validationControls) {
	for(var i=0;i<validationControls.length;i++){
		if(validationControls[i].getMetadata()._sClassName=="sap.m.Select"){
			var selectValue=validationControls[i].getSelectedItem().getText();
			if(selectValue=="" && (selectValue!="GRPN" && selectValue!="CNRN" && selectValue!="CNRY" && selectValue!="GRPY" && selectValue!="NRYN" && selectValue!="NRYD"))
			{
				if (validationControls[i].getName() =="" || validationControls[i].getName()==null ){
					sap.m.MessageToast.show(oController.getView().getModel("i18n").getObject("MESSAGE_61") + oController.getView().getModel("i18n").getObject("FILE_NO"));
				}else{
					sap.m.MessageToast.show(oController.getView().getModel("i18n").getObject("MESSAGE_61") + validationControls[i].getName());
				}
			return validationControls[i];
			}
		}
		
		else if(validationControls[i].getMetadata()._sClassName=="sap.m.Switch"){
			
		}
		
		else{
		if(validationControls[i].getValue()=="" && (validationControls[i].getName()!="GRPN" && validationControls[i].getName()!="CNRN" && 
				validationControls[i].getName()!="CNRY" && validationControls[i].getName()!="GRPY" && validationControls[i].getName()!="NRYN" && validationControls[i].getName()!="NRYD"))
		{
			if (validationControls[i].getName() =="" || validationControls[i].getName()==null ){
				sap.m.MessageToast.show(oController.getView().getModel("i18n").getObject("MESSAGE_61") + oController.getView().getModel("i18n").getObject("FILE_NO"));
			}else{
					sap.m.MessageToast.show(oController.getView().getModel("i18n").getObject("MESSAGE_62") + validationControls[i].getName());
			}
		return validationControls[i];
		}
		}
		
	}
	return false;
};

function destroyDialogs(oController){
	
	if(oController.versionDialog != undefined){

	    oController.versionDialog.destroy();

	    oController.versionDialog=undefined;

	}
	
	if(oController.oMoveToCabinet != undefined){

	    oController.oMoveToCabinet.destroy();

	    oController.oMoveToCabinet=undefined;

	}

	if(oController.oVersion != undefined){
	sap.ui.getCore().byId("idCli").destroy();
		oController.oVersion.destroyContent();
	    oController.oVersion.destroy();

	    oController.oVersion=undefined;

	}

	if(oController.attachmentDialog != undefined){

	    oController.attachmentDialog.destroy();

	    oController.attachmentDialog=undefined;

	}if(oController.fileDialog != undefined){

	    oController.fileDialog.destroy();

	    oController.fileDialog=undefined;

	}if(oController._uploadActionSheet != undefined){

	    oController._uploadActionSheet.destroyButtons();
	   
	}
	if(oController._sendActionSheet != undefined){

	    oController._sendActionSheet.destroyButtons();
	}
	if(oController.searchPopup != undefined){
		/*sap.ui.getCore().byId("idHeaderContainer").destroyItems();
		sap.ui.getCore().byId("idSearchTable").destroyItems();
		sap.ui.getCore().byId("idVboxToolbar").destroyContent();
		sap.ui.getCore().byId("searchBox").destroy();*/
//		sap.ui.getCore().byId("idSearchTable").destroyItems();
//		sap.ui.getCore().byId("idSearchTable").destroy();
//		sap.ui.getCore().byId("idVboxToolbar").destroy();
//		sap.ui.getCore().byId("idHeaderContainer").destroyItems();
//		sap.ui.getCore().byId("idHeaderContainer").destroy();
//		sap.ui.getCore().byId("searchBox").destroyItems();
//		sap.ui.getCore().byId("searchBox").destroy();
		oController.searchPopup.destroyContent();
		oController.searchPopup.destroy();
	    oController.searchPopup=undefined;
}
	if(oController.oSequenceSend != undefined){
		oController.oSequenceSend.destroy();
		oController.oSequenceSend = undefined;
	}
	
	if(oController._oFullScreenDialog1 != undefined){
		oController._oFullScreenDialog1.destroy();
		oController._oFullScreenDialog1 = undefined;
	}
	if(oController._docTypeSelectDialog != undefined){
		oController._docTypeSelectDialog.destroy();
		oController._docTypeSelectDialog = undefined;
	}
	
	if(oController._printActionSheet != undefined){
		oController._printActionSheet.destroy();
		oController._printActionSheet = undefined;
	}
	if(oController.getView().byId("dynamicAttrForm").getContent()!=null)
	{oController.getView().byId("dynamicAttrForm").destroyContent();
	}
	if(oController.shareAttrDialog != undefined){
		oController.shareAttrDialog.destroy();
		oController.shareAttrDialog = undefined;
	}
	if(oController._workflowActionSheet != undefined){
		oController._workflowActionSheet.destroy();
		oController._workflowActionSheet = undefined;
	}
	if(oController.oCreateWorkflow != undefined){
		oController.oCreateWorkflow.destroy();
		oController.oCreateWorkflow = undefined;
	}
	
	if(oController._valueHelpDialog != undefined){
		oController._valueHelpDialog.destroy();
		oController._valueHelpDialog = undefined;
	}
}



