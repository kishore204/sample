/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.declare("flm.fiori.Configuration");jQuery.sap.require("sap.ca.scfld.md.ConfigurationBase");jQuery.sap.require("sap.ca.scfld.md.app.Application");var serviceUrl="/sap/opu/odata/PSINDS/FILES_SRV_SRV";
//sap.ui.richtexteditor.TinyMCELicense = "sap.only";
sap.ca.scfld.md.ConfigurationBase.extend("flm.fiori.Configuration",{oServiceParams:{serviceList:[{name:"Files",masterCollection:"/FILE_INTRAY_ES?$filter=IntrayType eq 'IN'",serviceUrl:"/sap/opu/odata/PSINDS/FILES_SRV_SRV",isDefault:true,mockedDataSource:"/flm.fiori/model/metadata.xml"}]},getServiceParams:function(){return this.oServiceParams},getAppConfig:function(){return this.oAppConfig},getServiceList:function(){return this.oServiceParams.serviceList},getMasterKeyAttributes:function(){return["Id"]}});
