/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
// define a root UIComponent which exposes the main view
jQuery.sap.declare("flm.fiori.Component");
jQuery.sap.require("flm.fiori.Configuration");
jQuery.sap.require("sap.ca.scfld.md.ComponentBase");
// debugger
// sap.ui.richtexteditor.TinyMCELicense = "sap.only";
// change made while git training PLEASE REMOVE
// extent of sap.ca.scfld.md.ComponentBase
sap.ca.scfld.md.ComponentBase.extend("flm.fiori.Component", {
	metadata : sap.ca.scfld.md.ComponentBase.createMetaData("FS", {
		"name" : "File Lifecycle Management",
		"version" : "1.3.0-SNAPSHOT",
		"library" : "flm.fiori",
		"includes" : [ "css/style.css" ],
		dependencies : {
			"libs" : [ "sap.m", "sap.me", "sap.ui.table",
					"sap.ui.richtexteditor" ],
			"components" : [],
		},
		config : {
			fullWidth : true,
		},
		viewPath : "flm.fiori.view",
		fullScreenPageRoutes : {
			// fill the routes to your full screen pages in here.
			"fullscreen" : {
				"pattern" : "",
				"view" : "S1"
			},
			"subscreen" : {
				"pattern" : "subscreen/{caseguid}/{fileid}/{wiId}",
				"view" : "S2"
			},

			"myscreen" : {
				"pattern" : "myscreen",
				"view" : "S3"
			},
			"searchscreen" : {
				"pattern" : "searchscreen",
				"view" : "S4"
			},
			"docscreen" : {
				"pattern" : "docscreen",
				"view" : "S5"
			},
			"daakscreen" : {
				"pattern" : "daakscreen",
				"view" : "S6"
			},
			"daakdocscreen" : {
				"pattern" : "daakdocscreen/{caseguid}",
				"view" : "S6"
			},
			"mailscreen" : {
				"pattern" : "mailscreen",
				"view" : "S7"
			},
			"daaksearchscreen" : {
				"pattern" : "daaksearchscreen",
				"view" : "S8"
			}

		},
	// customizing: {
	// "sap.ui.controllerExtensions": {
	// "flm.fiori.view.S2": {
	// controllerName: "flm.fiori.view.S2customCtrl"
	// }
	// },
	//
	// },

	}),

	/**
	 * Initialize the application
	 * 
	 * @returns {sap.ui.core.Control} the content
	 */
	createContent : function() {
		var oViewData = {
			component : this
		};
		return sap.ui.view({
			viewName : "flm.fiori.Main",
			type : sap.ui.core.mvc.ViewType.XML,
			viewData : oViewData
		});
	}
});
