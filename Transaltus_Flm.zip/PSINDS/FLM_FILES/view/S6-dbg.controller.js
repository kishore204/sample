/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("flm.fiori.utils.dynamicUIAssist");
jQuery.sap.require("sap.m.TablePersoController");
jQuery.sap.require("flm.fiori.utils.inboxPersonalDialog");
jQuery.sap.require("flm.fiori.utils.dynamicUIAssist");
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require("sap.ui.thirdparty.sinon");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("flm.fiori.utils.utilities");
jQuery.sap.require("flm.fiori.utils.formatter");
jQuery.sap.require("flm.fiori.utils.validator");
jQuery.sap.require("flm.fiori.utils.BASE64Util");

var oControllerS6 = null;
var daaktype = null;

sap.ca.scfld.md.controller.BaseFullscreenController
              .extend(
                           "flm.fiori.view.S6",
                           {
                            data : {
                                   priority : null,
                                   fileNumber : null,
                                   dynamic : null,
                                   notes : null,
                                   folders : null,
                                   documents : null,
                                   buttons : null,
                                   privateNote : null,
                                   basic : null,
                                   attachments : [],
                            },
                            caseguid : "",
                            fileid : "",
                            filenumber : null,
                            wiId : "",
                            gCounter : null,
                            digitalsign : null,
                            createSignFlag : false,
                            dynUIAssistArr : null,
                            fromTab : null,
                            oStdDialog : null,
                            navBackArrS6 : [],
//                            _formFragments : {},
                            initFlag: true,
//                            _fragments : {},
                            _valueHelpDialog : undefined,
                            oCreateWorkflow : undefined,
                            workflowAdminAuthorization : false,
                            seeMoreOpen : null,
                            globalModel : {},
                            inputId : {},
                            response : {},
                            globalCounter : {},
                            flatObj :[],
                            flagLocation : {},
                            createFileResponse : {},
                            updateWorkflowFlag : false,
                            newWorkflowFlag : false,
                            saveFlag : false,
                            rightTreeData : null,
                            leftTreeNodes : null,
                            navFlagDaak : false,
                            fromSameDaak : false,
                            docGuid : null,
                            docFileid : null,
                            docWiid : null,
                            S2flag : false,
                            addPrefixLineBreak : true,
                            numberDateObjDaak : null,
                            
                           
                            onInit : function(oEvent) {
                             /**
                                    * Called when a controller is instantiated and its View controls (if available) are already created.
                                    * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
                                    */
                             sap.ui.richtexteditor.TinyMCELicense = "sap.only";
                                 serviceUrl = this.getView().getModel().sServiceUrl;
                                  if(sap.ui.getCore().getModel("i18n") == undefined){
                                                            sap.ui.getCore().setModel(this.getView().getModel("i18n"),"i18n");
                                                     }
                                       
                                       var oModel = new sap.ui.model.json.JSONModel();
                                       oModel.setData(this.data);
                                       this.getView().setModel(oModel,"createdaak");
                                       
                                       this.getView().addEventDelegate({

                                           onBeforeShow : jQuery.proxy(function(evt) {

                                                  this.onBeforeShow(evt);

                                           }, this)

                                    });
                                       oControllerS6 = this;
                                       this.getView().byId("idDaakNumberHboxMain")
                                                     .addStyleClass("filetype");
                                       this.oRouter
                                       .attachRouteMatched(
                                                     function(oEvent) {

                                                      if (oEvent.getParameter("name") == "daakscreen") {
                                                              if(oControllerS1.tabType == "createdaak"){
                                                                  this.getView().byId("idDaakType").setValue(sap.ui.getCore().getModel("passdaak").getData()[1].toUpperCase());
                                                                  this.daaktype = sap.ui.getCore().getModel("passdaak").getData()[0];
                                                              }
                                                                  else if(oControllerS1.caseguid!=undefined || oControllerS1.caseguid!=null ){
                                                                   if(oControllerS1.tabType == "document"){
                                                                       this.caseguid = oControllerS6.caseguid;
                                                                       this.fileid = oControllerS6.fileid;
                                                                       this.wiId = oControllerS6.wiId;
                                                                       if (this.fromSameDaak) {
                                                                           oControllerS6.onBeforeShow({
                                                                                               "from" : oControllerS6.getView()
                                                                                        });
                                                                       }
                                                                      }else{
                                                                    this.caseguid = oControllerS1.caseguid;
                                                                    this.fileid = oControllerS1.fileid;
                                                                    this.wiId = oControllerS1.wiId;
                                                                      }
                                                                   }
                                                                  
                                                           }
                                                      else if (oEvent.getParameter("name") == "fullscreen") { 
                                                            this.getView().byId("idDaakNumberHbox").destroyItems();
                                                                  this.getView().byId("dynamicAttrForm").destroyContent();
                                                           }
                                                      else if (oEvent.getParameter("name") == "daakdocscreen" || oEvent.getParameter("name") == "daakscreen") {
                                                       this.caseguid = oEvent.getParameter("arguments").caseguid;//oEvent.getSource().getBindingContext("createdaak").getObject().CaseGuid;//docGuid;
                                                       this.fileid = oEvent.getParameter("arguments").fileid;//oEvent.getSource().getBindingContext("createdaak").getObject().FileID;//docFileid;
                                                       this.wiId = oEvent.getParameter("arguments").wiId;//oEvent.getSource().getBindingContext("createdaak").getObject().Wiid;
                                                       if (this.fromSameDaak) {
                                                                   oControllerS6.onBeforeShow({
                                                                                       "from" : oControllerS6.getView()
                                                                                });
                                                               }
                                                           }

                                                     }, this);
                                       this.i18 = this.getView().getModel("i18n");
                                       
                                       /*Hook for changes in initial load*/
                                       if(this.customInitializeDaakData){
                                           this.customInitializeDaakData(this);
                                    }
                                       
                                       /*code for fixing rte bug */
                                        if (sap.ui.version.indexOf("1.20.") == 0) {
                                              jQuery.sap.require("sap.ui.richtexteditor.RichTextEditor");
                                              sap.ui.richtexteditor.RichTextEditor.prototype.exitTinyMCE = function(){
                                                this.bExiting = true;
                                                if (window.tinymce) {
                                                 tinymce.execCommand('mceRemoveControl', false, this.textAreaId);
                                                }
                                                sap.ui.getCore().getEventBus().unsubscribe("sap.ui",
                                                    "__preserveContent", this._tinyMCEPreserveHandler);
                                                sap.ui.getCore().getEventBus().unsubscribe("sap.ui",
                                                    "__beforePopupClose", this._tinyMCEPreserveHandler);
                                              };
                                            }
                               },


                         /* called in onInit() function to set the properties of UI elements based on Tab type */
                           onBeforeShow : function(oEvent) {
                            
                            this.oSource = oEvent.from;
                              this.navFlagDaak = false;
                               this.initFlag = true;
                               this.updateWorkflowFlag = false;
                               this.gCounter = 0;
                               this.fromDocSearch = false;
                               this.getView().byId("createDaak").setBusy(false);
                               oControllerS6.getView().byId("daakNotingEditor").setValue("");
                               this.byId("daakWftree").setSelectedIndex(-1);
                this.byId("idDaakDeleteButton").setEnabled(false);
                this.byId("idDaakAddNewWorkflowButton").setEnabled(false);
//                               this.fromTab = "CREATEDAAK";
                             //var daakTabId = null;
                               if (this.fromSameDaak) {
              if (this.navBackArrS6.length == 0) {
               switch (this.fromTab) {
               case "INTRAYDAAK":
                oControllerS1.tabType = "file";
                break;
               case "DRAFTDAAK":
                oControllerS1.tabType = "draft";
                break;
               case "SUBSTDAAK":
                oControllerS1.tabType = "substitute";
                break;
               case "CABINDAAK":
                oControllerS1.tabType = "cabinet";
                break;
               case "TRACKDAAK":
                oControllerS1.tabType = "track";
                break;
               case "CREATEDAAK":
                oControllerS1.tabType = "createdaak";
                break;
               }
               this.fromSameDaak = false;
              } else {
               oControllerS1.tabType = "document";
              }
             }
             if (this.oSource.sId != "__page0") {
              if (this.oSource.getControllerName() == "flm.fiori.view.S1") {
               tabId = oEvent.from.byId("TAB_CONTAINER")
                 .getSelectedKey();
               this.fromFileSearch = false;
              }else if (this.oSource.getControllerName() == "flm.fiori.view.S2") {

               tabId = "document";
               this.S3flag = true;
               oControllerS1.tabType="document";
               this.fromTab = "INTRAY";
              } else if (this.oSource.getControllerName() == "flm.fiori.view.S4") {

               tabId = "search";
               this.fromFileSearch = true;
               this.fromTab = "SEARCH";
              }else if (this.oSource.getControllerName() == "flm.fiori.view.S5") {

               tabId = "document";
               this.fromDocSearch = true;
               oControllerS1.tabType="document";
               oControllerS6.caseguid = guid;
               oControllerS6.fileid = fileID;
               this.fromTab = "SEARCHDOC";
              }
               else if (this.oSource.getControllerName() == "flm.fiori.view.S3") {

               tabId = "document";
               this.S3flag = true;
               this.fromTab = "CREATE";
              } else if (this.oSource.getControllerName() == "flm.fiori.view.S8") {
               oControllerS1.tabType = "search";
               tabId = "daakSearch";
               this.fromFileSearch = true;
               this.fromTab = "SEARCHDAAK";
              }
             }
                               if(oControllerS1.tabType =="file"){
                                   this.fromTab = "INTRAYDAAK";
                                   this.setInitialModels(this);
                                   this.getView().byId("idDaakNumberHboxMain").setVisible(false);
                                   this.getView().byId("idLabelDaakNumber").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setValue(oControllerS6.data.basic.FileNumber);
                                   this.getView().byId("idTrackDaakLabel").setVisible(
                                                 true);
                                   this.getView().byId("idTrackDaakSwitch").setVisible(
                                                 true);
                                   this.getView().byId("idConfidentialDaakLabel").setVisible(
                                           true);
                                   this.getView().byId("idConfidentialDaakSwitch").setVisible(
                                           true);
                                   this.getView().byId("daakEmptyNotingPanel").setVisible(false);
                                   this.getView().byId("daakNotingPanel").setVisible(true);
                                   this.getView().byId("daakNoteDocPanel").setVisible(true);
                                   this.getView().byId("idTrackDaakSwitch").setState(oControllerS6.data.basic.Track);
                                   this.getView().byId("idTrackDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Track));
                                   this.getView().byId("idConfidentialDaakSwitch").setState(oControllerS6.data.basic.Conf);
                                   this.getView().byId("idConfidentialDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Conf));
                                   this.getView().byId("idTrackDaakSwitch").setEnabled(oControllerS6.data.basic.TrackEdit);
                                   this.getView().byId("idConfidentialDaakSwitch").setEnabled(oControllerS6.data.basic.ConfEdit);
                                   this.getView().byId("idDaakCreatedOn").setValue(oControllerS6.data.basic.CreateTime);
                                   this.getView().byId("idDaakCreatedBy").setValue(oControllerS6.data.basic.CreatedByID);
                                   this.getView().byId("idDaakStatus").setValue(oControllerS6.data.basic.Status);
                                   this.getView().byId("idDaakStatus").setVisible(true);
                                   this.getView().byId("idResponddate").setVisible(true);
                                   this.getView().byId("idRespondByLabel").setVisible(true); 
                                   if(oControllerS1.respondBy == "  --"){
                                    this.getView().byId("idResponddate").setEditable(true);
                                       this.getView().byId("idResponddate").setValue("");
                                     
                                   }else{
                                    var date=new Date();
                                       date.setFullYear(oControllerS1.respondBy.substr(6,4));
                                       date.setMonth(oControllerS1.respondBy.substr(3,2)-1);
                                       date.setDate(oControllerS1.respondBy.substr(0,2));
                                   this.getView().byId("idResponddate").setEditable(false);
                                   this.getView().byId("idResponddate").setDateValue(date);
                                   }
                                   this.getView().byId("deleteDate").setVisible(false);
                                   this.getView().byId("idDaakType").setValue(oControllerS6.data.basic.ShortText.toUpperCase());
                                   this.getView().byId("idLabelDaakActivity").setVisible(true);
                                   this.getView().byId("idInputDaakActivity").setVisible(true);
                                   this.getView().byId("idInputDaakActivity").setValue(oControllerS6.data.basic.Actdc);
                                   try{
                                   this.getView().byId("idDaakShortText").setValue(decodeURIComponent(oControllerS6.data.basic.CaseTitle));
                                   }catch(err){
                                    this.getView().byId("idDaakShortText").setValue(oControllerS6.data.basic.CaseTitle);
                                   }
                                   this.getView().byId("idDaakShortText").setEditable(false);
                                   this.getView().byId("idWorkflowBox").setVisible(true);
                                   oControllerS6.getView().byId("idDaakButtonSend").setEnabled(true);
                                   oControllerS6.getView().byId("idDaakButtonClose").setEnabled(true);
                                   this.getView().byId("attachDocAction").setVisible(true);
                                 
                               }
                             else if(oControllerS1.tabType=="draft"){
                                   this.daaktype="";
                                   this.fromTab = "DRAFTDAAK";
                                   this.setInitialModels(this);
                                   this.getView().byId("idDaakNumberHboxMain").setVisible(false);
                                   this.getView().byId("idLabelDaakNumber").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setValue(oControllerS6.data.basic.FileNumber);
                                   this.getView().byId("idTrackDaakLabel").setVisible(
                                                 true);
                                   this.getView().byId("idTrackDaakSwitch").setVisible(
                                                 true);
                                   this.getView().byId("idConfidentialDaakLabel").setVisible(
                                           true);
                                   this.getView().byId("idConfidentialDaakSwitch").setVisible(
                                           true);
                                   this.getView().byId("idResponddate").setVisible(false);
                                   this.getView().byId("idRespondByLabel").setVisible(false);  
                                   this.getView().byId("deleteDate").setVisible(false);
                                   this.getView().byId("daakEmptyNotingPanel").setVisible(false);
                                   this.getView().byId("daakNotingPanel").setVisible(true);
                                   this.getView().byId("daakNoteDocPanel").setVisible(true);
                                   this.getView().byId("idTrackDaakSwitch").setState(oControllerS6.data.basic.Track);
                                   this.getView().byId("idTrackDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Track));
                                   this.getView().byId("idConfidentialDaakSwitch").setState(oControllerS6.data.basic.Conf);
                                   this.getView().byId("idConfidentialDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Conf));
                                   this.getView().byId("idTrackDaakSwitch").setEnabled(oControllerS6.data.basic.TrackEdit);
                                   this.getView().byId("idConfidentialDaakSwitch").setEnabled(oControllerS6.data.basic.ConfEdit);
                                   this.getView().byId("idDaakCreatedOn").setValue(oControllerS6.data.basic.CreateTime);
                                   this.getView().byId("idDaakCreatedBy").setValue(oControllerS6.data.basic.CreatedByID);
                                   this.getView().byId("idDaakType").setValue(oControllerS6.data.basic.ShortText.toUpperCase());
                                   this.getView().byId("idLabelDaakActivity").setVisible(false);
                                   this.getView().byId("idInputDaakActivity").setVisible(false);
                                   this.getView().byId("idDaakStatus").setVisible(false);
                                   try{
                                   this.getView().byId("idDaakShortText").setValue(decodeURIComponent(oControllerS6.data.basic.CaseTitle));
                                   }catch(err){
                                    this.getView().byId("idDaakShortText").setValue(oControllerS6.data.basic.CaseTitle);
                                   }
                                   this.getView().byId("idDaakShortText").setEditable(true);
                                   oControllerS6.getView().byId("idDaakAddNewWorkflowButton").setEnabled(true);
                                   oControllerS6.getView().byId("idDaakButtonSend").setEnabled(true);
                                   oControllerS6.getView().byId("idDaakButtonClose").setEnabled(true);
                                   this.getView().byId("idWorkflowBox").setVisible(true);
                                   this.getView().byId("attachDocAction").setVisible(true);
                                 }
                               else if(oControllerS1.tabType=="substitute"){
                                   this.daaktype="";
                                   this.fromTab = "SUBSTDAAK";
                                   this.setInitialModels(this);
                                   this.getView().byId("idLabelDaakNumber").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setValue(oControllerS6.data.basic.FileNumber);
                                   this.getView().byId("idTrackDaakLabel").setVisible(
                                                 true);
                                   this.getView().byId("idTrackDaakSwitch").setVisible(
                                                 true);
                                   this.getView().byId("daakEmptyNotingPanel").setVisible(false);
                                   this.getView().byId("daakNotingPanel").setVisible(true);
                                   this.getView().byId("daakNoteDocPanel").setVisible(true);
                                   this.getView().byId("idTrackDaakSwitch").setState(oControllerS6.data.basic.Track);
                                   this.getView().byId("idTrackDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Track));
                                   this.getView().byId("idConfidentialDaakSwitch").setState(oControllerS6.data.basic.Conf);
                                   this.getView().byId("idConfidentialDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Conf));
                                   this.getView().byId("idTrackDaakSwitch").setEnabled(oControllerS6.data.basic.TrackEdit);
                                   this.getView().byId("idConfidentialDaakSwitch").setEnabled(oControllerS6.data.basic.ConfEdit);
                                   this.getView().byId("idDaakCreatedOn").setValue(oControllerS6.data.basic.CreateTime);
                                   this.getView().byId("idDaakCreatedBy").setValue(oControllerS6.data.basic.CreatedByID);
                                   this.getView().byId("idDaakStatus").setValue(oControllerS6.data.basic.Status);
                                   this.getView().byId("idDaakStatus").setVisible(true);
                                   
                                   try{
                                   this.getView().byId("idDaakShortText").setValue(decodeURIComponent(oControllerS6.data.basic.CaseTitle));
                                   }catch(err){
                                    this.getView().byId("idDaakShortText").setValue(oControllerS6.data.basic.CaseTitle);
                                   }
                                   this.getView().byId("idDaakShortText").setEditable(false);
                                   this.getView().byId("idResponddate").setVisible(true);
                                   this.getView().byId("idRespondByLabel").setVisible(true); 
                                   if(oControllerS1.respondBy == "  --"){
                                    this.getView().byId("idResponddate").setEditable(true);
                                       this.getView().byId("idResponddate").setValue("");
                                    
                                   }else{
                                    var date=new Date();
                                       date.setFullYear(oControllerS1.respondBy.substr(6,4));
                                       date.setMonth(oControllerS1.respondBy.substr(3,2)-1);
                                       date.setDate(oControllerS1.respondBy.substr(0,2));
                                   this.getView().byId("idResponddate").setEditable(false);
                                   this.getView().byId("idResponddate").setDateValue(date);
                                   }
                                   this.getView().byId("deleteDate").setVisible(false);
                                   oControllerS6.getView().byId("idDaakButtonSend").setEnabled(true);
                                   oControllerS6.getView().byId("idDaakButtonClose").setEnabled(true);
                                   this.getView().byId("idWorkflowBox").setVisible(true);
                                   this.getView().byId("attachDocAction").setVisible(true);
                                 }
                               else if(oControllerS1.tabType=="cabinet"){
                                   this.daaktype="";
                                   this.fromTab = "CABINDAAK";
                                   this.setInitialModels(this);
                                   this.getView().byId("idDaakNumberHboxMain").setVisible(false);
                                   oControllerS6.getView().byId("idResponddate").setEditable(false);
                                   this.getView().byId("idResponddate").setVisible(true);
                                   this.getView().byId("idRespondByLabel").setVisible(true); 
                                   this.getView().byId("deleteDate").setVisible(false);
                                   this.getView().byId("idLabelDaakNumber").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setValue(oControllerS6.data.basic.FileNumber);
                                   this.getView().byId("idTrackDaakLabel").setVisible(
                                                 true);
                                   this.getView().byId("idTrackDaakSwitch").setVisible(
                                                 true);
                                   this.getView().byId("daakEmptyNotingPanel").setVisible(true);
                                   this.getView().byId("daakNotingPanel").setVisible(false);
                                   this.getView().byId("daakNoteDocPanel").setVisible(true);
                                   this.getView().byId("idTrackDaakSwitch").setState(oControllerS6.data.basic.Track);
                                   this.getView().byId("idTrackDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Track));
                                   this.getView().byId("idConfidentialDaakSwitch").setState(oControllerS6.data.basic.Conf);
                                   this.getView().byId("idConfidentialDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Conf));
                                   this.getView().byId("idTrackDaakSwitch").setEnabled(oControllerS6.data.basic.TrackEdit);
                                   this.getView().byId("idConfidentialDaakSwitch").setEnabled(oControllerS6.data.basic.ConfEdit);
                                   this.getView().byId("idDaakCreatedOn").setValue(oControllerS6.data.basic.CreateTime);
                                   this.getView().byId("idDaakCreatedBy").setValue(oControllerS6.data.basic.CreatedByID);
                                   this.getView().byId("idDaakType").setValue(oControllerS6.data.basic.ShortText.toUpperCase());
                                   this.getView().byId("idDaakStatus").setValue(oControllerS6.data.basic.Status);
                                   this.getView().byId("idDaakStatus").setVisible(true);
                                   try{
                                   this.getView().byId("idDaakShortText").setValue(decodeURIComponent(oControllerS6.data.basic.CaseTitle));
                                   }catch(err){
                                    this.getView().byId("idDaakShortText").setValue(oControllerS6.data.basic.CaseTitle);
                                   }
                                   this.getView().byId("idDaakShortText").setEditable(false);
                                   this.getView().byId("idWorkflowBox").setVisible(false);
                                   oControllerS6.getView().byId("idDaakButtonSend").setEnabled(false);
                                   oControllerS6.getView().byId("idDaakButtonClose").setEnabled(false);
                                   this.getView().byId("attachDocAction").setVisible(false);
                                 }
                               else if(oControllerS1.tabType=="track"){
                                   this.daaktype="";
                                   this.fromTab = "TRACKDAAK";
                                   this.setInitialModels(this);
                                   this.getView().byId("idDaakNumberHboxMain").setVisible(false);
                                   oControllerS6.getView().byId("idResponddate").setEditable(false);
                                   this.getView().byId("idResponddate").setVisible(false);
                                   this.getView().byId("idRespondByLabel").setVisible(false);
                                   this.getView().byId("deleteDate").setVisible(false);
                                   this.getView().byId("idLabelDaakNumber").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setValue(oControllerS6.data.basic.FileNumber);
                                   this.getView().byId("idTrackDaakLabel").setVisible(
                                                 true);
                                   this.getView().byId("idTrackDaakSwitch").setVisible(
                                                 true);
                                   this.getView().byId("daakEmptyNotingPanel").setVisible(false);
                                   this.getView().byId("daakNotingPanel").setVisible(false);
                                   this.getView().byId("daakNoteDocPanel").setVisible(false);
                                   this.getView().byId("idTrackDaakSwitch").setState(oControllerS6.data.basic.Track);
                                   this.getView().byId("idTrackDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Track));
                                   this.getView().byId("idConfidentialDaakSwitch").setState(oControllerS6.data.basic.Conf);
                                   this.getView().byId("idConfidentialDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Conf));
                                   this.getView().byId("idTrackDaakSwitch").setEnabled(true);
                                   this.getView().byId("idConfidentialDaakSwitch").setEnabled(false);
                                   this.getView().byId("idDaakCreatedBy").setValue(oControllerS6.data.basic.CreatedByID);
                                   this.getView().byId("idDaakCreatedOn").setValue(oControllerS6.data.basic.CreateTime);
                                   this.getView().byId("idDaakType").setValue(oControllerS6.data.basic.ShortText.toUpperCase());
                                   this.getView().byId("idDaakStatus").setValue(oControllerS6.data.basic.Status);
                                   this.getView().byId("idDaakStatus").setVisible(true);
                                   
                                   try{
                                   this.getView().byId("idDaakShortText").setValue(decodeURIComponent(oControllerS6.data.basic.CaseTitle));
                                   }catch(err){
                                    this.getView().byId("idDaakShortText").setValue(oControllerS6.data.basic.CaseTitle);
                                   }
                                   this.getView().byId("idDaakShortText").setEditable(false);
                                   oControllerS6.getView().byId("idDaakAddNewWorkflowButton").setEnabled(true);
                                   oControllerS6.getView().byId("idDaakButtonSend").setEnabled(true);
                                   oControllerS6.getView().byId("idDaakButtonClose").setEnabled(true);
                                   this.getView().byId("idWorkflowBox").setVisible(false);
                                   this.getView().byId("attachDocAction").setVisible(false);
                                 }
                               else if(oControllerS1.tabType =="document"){
                                  this.daaktype="";
                                     this.fromTab = "DOCDAAK";
                                     this.setInitialModels(this);
                                     this.byId("daakWftree").setSelectionMode("None");
                                     this.getView().byId("idDaakNumberHboxMain").setVisible(false);
                                     this.getView().byId("idResponddate").setVisible(true);
                                     this.getView().byId("idRespondByLabel").setVisible(true); 
                                     this.getView().byId("deleteDate").setVisible(false);
                                     this.getView().byId("idLabelDaakNumber").setVisible(
                                                   true);
                                     this.getView().byId("idInputDaakNumber2").setVisible(
                                                   true);
                                     this.getView().byId("idInputDaakNumber2").setValue(oControllerS6.data.basic.FileNumber);
                                     this.getView().byId("idTrackDaakLabel").setVisible(
                                                   true);
                                     this.getView().byId("idTrackDaakSwitch").setVisible(
                                                   true);
                                     this.getView().byId("idConfidentialDaakLabel").setVisible(
                                             true);
                                     this.getView().byId("idConfidentialDaakSwitch").setVisible(
                                             true);
                                     this.getView().byId("daakEmptyNotingPanel").setVisible(true);
                                     this.getView().byId("daakEmptyEditor").setVisible(false);
                                     this.getView().byId("daakNotingPanel").setVisible(false);
                                     this.getView().byId("daakNoteDocPanel").setVisible(true);
                                     this.getView().byId("idTrackDaakSwitch").setState(oControllerS6.data.basic.Track);
                                     this.getView().byId("idTrackDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Track));
                                     this.getView().byId("idConfidentialDaakSwitch").setState(oControllerS6.data.basic.Conf);
                                     this.getView().byId("idConfidentialDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Conf));
                                     this.getView().byId("idTrackDaakSwitch").setEnabled(false);
                                     this.getView().byId("idConfidentialDaakSwitch").setEnabled(false);
                                     this.getView().byId("idDaakCreatedOn").setValue(oControllerS6.data.basic.CreateTime);
                                     this.getView().byId("idDaakCreatedBy").setValue(oControllerS6.data.basic.CreatedByID);
                                     this.getView().byId("idDaakStatus").setValue(oControllerS6.data.basic.Status);
                                     this.getView().byId("idDaakStatus").setVisible(true);
                                     if(oControllerS6.data.basic.PlanEndDate == ""){
                                         this.getView().byId("idResponddate").setValue("");
                                     }else{
                                        var date=new Date();
                                         date.setFullYear(oControllerS6.data.basic.PlanEndDate.substr(6,4));
                                         date.setMonth(oControllerS6.data.basic.PlanEndDate.substr(3,2)-1);
                                         date.setDate(oControllerS6.data.basic.PlanEndDate.substr(0,2));
                                         this.getView().byId("idResponddate").setDateValue(date);
                                     }
                                     this.getView().byId("idResponddate").setEditable(false);
                                     this.getView().byId("idDaakType").setValue(oControllerS6.data.basic.ShortText.toUpperCase());
                                     this.getView().byId("idLabelDaakActivity").setVisible(true);
                                     this.getView().byId("idInputDaakActivity").setVisible(true);
                                     this.getView().byId("idInputDaakActivity").setValue(oControllerS6.data.basic.Actdc);
                                     try{
                                     this.getView().byId("idDaakShortText").setValue(decodeURIComponent(oControllerS6.data.basic.CaseTitle));
                                     }catch(err){
                                      this.getView().byId("idDaakShortText").setValue(oControllerS6.data.basic.CaseTitle);
                                     }
                                     this.getView().byId("idDaakShortText").setEditable(false);
                                     oControllerS6.getView().byId("idDaakAddNewWorkflowButton").setEnabled(false);
                                     oControllerS6.getView().byId("idDaakButtonSend").setVisible(false);
                                     oControllerS6.getView().byId("idDaakButtonClose").setVisible(false);
                                     oControllerS6.getView().byId("daakAttachFileAction").setVisible(false);
                                     oControllerS6.getView().byId("idDaakButtonSave").setVisible(false);
                                     this.getView().byId("attachDocAction").setVisible(false);
                                     this.getView().byId("idWorkflowBox").setVisible(false);
                                   }
                               else if(oControllerS1.tabType =="createdaak"){                             
                               this.caseguid = "";
                               this.fileid = "";
                               this.fromTab = "CREATEDAAK";
                               this.setInitialModels(this);
                               //this.flatObj=[];
                               if(!this.initFlag){
                                this.getView().byId("createDaak").setBusy(true);
                                return;
                               }
                               this.createDaakNo();
                               this.getView().byId("idDaakNumberHboxMain").setVisible(true);
                               this.getView().byId("idResponddate").setEditable(true);
                               this.getView().byId("idResponddate").setValue("");
                               this.getView().byId("idLabelDaakNumber").setVisible(
                                             false);
                               this.getView().byId("idInputDaakNumber2").setVisible(
                                             false);
                               this.getView().byId("idInputDaakNumber2").setValue("");
                               this.getView().byId("idDaakShortText").setValue("");
                               
                               this.getView().byId("idTrackDaakLabel").setVisible(
                                             false);
                               this.getView().byId("idTrackDaakSwitch").setVisible(
                                             false);
                               this.getView().byId("idTrackDaakSwitch").setTooltip(this.getView().getModel("i18n").getObject("OFF"));
                               this.getView().byId("idConfidentialDaakSwitch").setVisible(
                                       false);
                               this.getView().byId("idConfidentialDaakLabel").setVisible(
                                       false);
                               this.getView().byId("idLabelDaakActivity").setVisible(false);
                               this.getView().byId("idInputDaakActivity").setVisible(false);
                               this.getView().byId("daakNotingPanel").setVisible(false);
                               this.getView().byId("idDaakShortText").setEditable(true);
                               this.getView().byId("daakNoteDocPanel").setVisible(true);
                               oControllerS6.getView().byId("idDaakButtonSend").setEnabled(false);
                               oControllerS6.getView().byId("idDaakButtonClose").setEnabled(false);
                               this.getView().byId("daakEmptyNotingPanel").setVisible(true);
                               oControllerS6.getView().byId("idDaakAddNewWorkflowButton").setEnabled(false);
                               this.getView().byId("attachDocAction").setVisible(true);
                               this.getView().byId("idDaakStatus").setVisible(false);
                               this.getView().byId("idWorkflowBox").setVisible(true);
                               this.getView().byId("idResponddate").setVisible(false);
                               this.getView().byId("idRespondByLabel").setVisible(false); 
                               this.getView().byId("deleteDate").setVisible(false);
                               }
                               else{
                                this.fromTab = "SEARCHDAAK";
                                   this.setInitialModels(this);
                                   this.getView().byId("idDaakNumberHboxMain").setVisible(false);
                                   this.getView().byId("idLabelDaakNumber").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setVisible(
                                                 true);
                                   this.getView().byId("idInputDaakNumber2").setValue(oControllerS6.data.basic.FileNumber);
                                   this.getView().byId("idTrackDaakLabel").setVisible(
                                                 true);
                                   this.getView().byId("idTrackDaakSwitch").setVisible(
                                                 true);
                                   this.getView().byId("idConfidentialDaakLabel").setVisible(
                                           true);
                                   this.getView().byId("idConfidentialDaakSwitch").setVisible(
                                           true);
                                   this.getView().byId("daakEmptyNotingPanel").setVisible(true);
                                   this.getView().byId("daakNotingPanel").setVisible(false);
                                   this.getView().byId("daakNoteDocPanel").setVisible(true);
                                   this.getView().byId("idTrackDaakSwitch").setState(oControllerS6.data.basic.Track);
                                   this.getView().byId("idTrackDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Track));
                                   this.getView().byId("idConfidentialDaakSwitch").setState(oControllerS6.data.basic.Conf);
                                   this.getView().byId("idConfidentialDaakSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS6.data.basic.Conf));
                                   this.getView().byId("idTrackDaakSwitch").setEnabled(oControllerS6.data.basic.TrackEdit);
                                   this.getView().byId("idConfidentialDaakSwitch").setEnabled(oControllerS6.data.basic.ConfEdit);
                                   this.getView().byId("idDaakCreatedOn").setValue(oControllerS6.data.basic.CreateTime);
                                   this.getView().byId("idDaakCreatedBy").setValue(oControllerS6.data.basic.CreatedByID);
                                   this.getView().byId("idDaakStatus").setValue(oControllerS6.data.basic.Status);
                                   this.getView().byId("idDaakStatus").setVisible(true);
                                   this.getView().byId("idResponddate").setEditable(false);
                                   this.getView().byId("idDaakType").setValue(oControllerS6.data.basic.ShortText.toUpperCase());
                                   this.getView().byId("idLabelDaakActivity").setVisible(true);
                                   this.getView().byId("idInputDaakActivity").setVisible(true);
                                   this.getView().byId("idInputDaakActivity").setValue(oControllerS6.data.basic.Actdc);
                                   try{
                                   this.getView().byId("idDaakShortText").setValue(decodeURIComponent(oControllerS6.data.basic.CaseTitle));
                                   }catch(err){
                                    this.getView().byId("idDaakShortText").setValue(oControllerS6.data.basic.CaseTitle);
                                   }
                                   this.getView().byId("idDaakShortText").setEditable(false);
                                   oControllerS6.getView().byId("idDaakButtonSend").setEnabled(true);
                                   oControllerS6.getView().byId("idDaakButtonClose").setEnabled(true);
                                   this.getView().byId("attachDocAction").setVisible(false);
                                   this.getView().byId("idWorkflowBox").setVisible(false);
                                   this.getView().byId("idResponddate").setVisible(true);
                                   this.getView().byId("idRespondByLabel").setVisible(true); 
                                   this.getView().byId("deleteDate").setVisible(false);
                               }
                              
                           /*Document tree creation starts */    
                               this.getView().byId("idDaakAttachmentsList").bindAggregation(
                                       "items",
                                       "createdaak>/attachments",
                                       function(a, b) {
                                              var listItem = new sap.m.CustomListItem({});

                                              // LIST ATTRIBUTES STARTS
                                              var oIcon = new sap.ui.core.Icon(
                                                            {
                                                                   src : "sap-icon://create",
                                                                   size : "1rem"
                                                            });
                                              var fbox = new sap.m.FlexBox({
                                                     width : "100%"
                                              });
                                              var fbox1 = new sap.m.FlexBox({
                                                     alignItems : "Start",
                                                     justifyContent : "Start",
                                                     width : "5%"
                                              });
                                              var fbox2 = new sap.m.FlexBox({
                                                     alignItems : "Start",
                                                     justifyContent : "Start",
                                                     width : "80%"
                                              });
                                              var fbox3 = new sap.m.FlexBox({
                                                     alignItems : "Start",
                                                     justifyContent : "End",
                                                     width : "15%"
                                              });
                                              var vbox = new sap.m.VBox({});
                                              vbox
                                                            .addItem(new sap.m.Link(
                                                                          {
                                                                                 text : "{createdaak>DocumentName}",
                                                                                 press : oControllerS6.onLinkPress
                                                                          }).addStyleClass("docLink"));
                                              vbox
                                                            .addItem(new sap.m.Text(
                                                                          {
                                                                                 "text" : {
                                                                                        "parts" : [
                                                                                                     'createdaak>CreatedByName',
                                                                                                     'createdaak>CreatedOn' ],

                                                                                        "formatter" : flm.fiori.utils.formatter.documentRow1
                                                                                 }
                                                                          // str1
                                                                          }).addStyleClass("docDetails"));
                                              vbox
                                                            .addItem(new sap.m.Text(
                                                                          {
                                                                                 text : {
                                                                                        "parts" : [
                                                                                                     'createdaak>IsAttachment',
                                                                                                     'createdaak>IsFile',
                                                                                                     'createdaak>IsDaak',
                                                                                                     'createdaak>IsObject',
                                                                                                     'createdaak>IsReport',
                                                                                                     'createdaak>FileSizeDescr',
                                                                                                     'createdaak>FileTitle',
                                                                                                     'createdaak>FileName' ],

                                                                                        "formatter" : flm.fiori.utils.formatter.documentRow2
                                                                                 }
                                                                          // str2
                                                                          }).addStyleClass("docDetails"));
                                              fbox1.addItem(oIcon);
                                              fbox2.addItem(vbox);
                                              var hbox = new sap.m.HBox({});
                                              hbox
                                                            .addItem(new sap.m.Link(
                                                                          {
                                                                                 visible : "{createdaak>NotingEnabledRef}",
                                                                                 text : oControllerS6.getView().getModel("i18n").getObject("ADD_TO_NOTING"),
                                                                                 press : oControllerS6.addHyperlinkClick,
                                                                                 target : "_self",
                                                                                 enabled : flm.fiori.utils.formatter.enabledStatus(oControllerS6.fromTab)
                                                                          }).addStyleClass("docLink"));
                                             
                                              hbox
                                                            .addItem(new sap.ui.core.HTML(
                                                                          {
                                                                                 visible : "{createdaak>NotingEnabledRef}",
                                                                                 content : "<span>&nbsp&nbsp&nbsp&nbsp;</span>"
                                                                          }).addStyleClass("docLink"));
                                              hbox
                                                            .addItem(new sap.m.Link(
                                                                          {
                                                                                 visible : "{createdaak>IsAttachment}",
                                                                                 text : oControllerS6.getView().getModel("i18n").getObject("ATTACH_NEW_VERSION"),
                                                                                 press : oControllerS6.attachNewVersion,
                                                                                 enabled : flm.fiori.utils.formatter.enabledStatus(oControllerS6.fromTab)
                                                                          }).addStyleClass("docLink"));
                                              vbox.addItem(hbox);
                                           var deleteIconVisibility;
           if (oControllerS6.fromTab == "DOCDAAK" || oControllerS6.fromTab == "SEARCHDAAK") {
            deleteIconVisibility = flm.fiori.utils.formatter.enabledStatus(oControllerS6.fromTab);
           } else {
            deleteIconVisibility = "{createdaak>DeleteEnabledRef}";
           }
                                              
                                              fbox3
                                                            .addItem(new sap.ui.core.Icon(
                                                                          {
                                                                                 visible : deleteIconVisibility,
                                                                                 src : "sap-icon://delete",
                                                                                 size : "1rem",
                                                                                 tooltip : oControllerS6.getView().getModel("i18n").getObject("DELETEATTACHMENT"),
                                                                                 //press : oControllerS3.deleteAttachment,
                                                                                 press : oControllerS6.confirmDelete,
                                                                          })
                                                                          .addStyleClass("panelButton"));
                                              fbox.addItem(fbox1);
                                              fbox.addItem(fbox2);
                                              fbox.addItem(fbox3);
                                              listItem.addContent(fbox);
                                              return listItem;
                                              });
                               

                               /*Document tree creation Ends */   
                               
                                    this.oTreeTable = this.getView().byId("daakWftree");
                                    if(oControllerS1.tabType!="document"){
                                    this.oTreeTable.setSelectionMode("Multi");
                                    }
                                    if(this.oTreeTable.getColumns().length>0){
                                     this.oTreeTable.destroyColumns();
                                    }
                                    if(this.fromTab=="CREATEDAAK" || this.fromTab=="DRAFTDAAK"){
                                    var oLink = new sap.m.Link({
                                           text : "{workflow>Fullname}",
                                           press : oControllerS6.openBusinessCard,
                                           enabled : {
                                               "parts" : [ 'workflow>isSpecial'],
                                               "formatter" : flm.fiori.utils.formatter.linkEnabled
                                           },
                                           emphasized : {
                                               "parts" : [ 'workflow>isSpecial'],
                                               "formatter" : flm.fiori.utils.formatter.linkEmphasized
                                           },
                                    });
                                    var oSpace1 = new sap.ui.core.HTML({
                                           content : "<span>&nbsp;&nbsp;</span>"
                                    });
                                    var oSpace2 = new sap.ui.core.HTML({
                                           content : "<span>&nbsp;&nbsp;</span>"
                                    });
                                    var oIcon1 = new sap.ui.core.Icon(
                                                  {
                                                         size : "1rem",
                                                         src : {
                                                                "parts" : [ 'workflow>Nodetype' ],
                                                                "formatter" : flm.fiori.utils.formatter.treeTableFlowIcon
                                                         },
                                                         color : "#5C85FF"
                                                  });
                                    
                                    var oIcon2 = new sap.ui.core.Icon(
                                                  {
                                                         size : "1rem",
                                                         src : {
                                                             "parts" : [ 'workflow>Pospast' , 'workflow>isSpecial'],
                                                             "formatter" : flm.fiori.utils.formatter.treeTableIcon
                                                         },
                                                         color : {
                                                             "parts" : [ 'workflow>Pospast' , 'workflow>isSpecial'],
                                                             "formatter" : flm.fiori.utils.formatter.treeTableIconColor
                                                         }
                                                  });
                                    
                                    this.oLayout = new sap.ui.layout.HorizontalLayout(
                                                  {
                                                         content : [ oIcon1,oSpace1,oIcon2,oSpace2,oLink ]
                                                  });
                                    
                                    this.noteLayout = new sap.ui.layout.HorizontalLayout(
                                            {
                                                content : [ pubText,oLine1,oIcon3,priText ]
                                         });

                  this.oTreeTable.addColumn(new sap.ui.table.Column({
                   label : this.getView().getModel("i18n").getObject("PROCESSORS"),
                   template : this.oLayout,
                   width : "15rem"
                  }));
                  this.oTreeTable.addColumn(new sap.ui.table.Column({
                   label : this.getView().getModel("i18n").getObject("ACTIVITY"),
                   template : "workflow>Actdc",
                   width : "12rem"
                  }));
                  this.oTreeTable.addColumn(new sap.ui.table.Column({
                   label : this.getView().getModel("i18n").getObject("START_DATE"),
                   template : "workflow>Creadate",
                   width : "10rem"
                  }));
                  this.oTreeTable.addColumn(new sap.ui.table.Column({
                   label : this.getView().getModel("i18n").getObject("END_DATE"),
                   template : "workflow>Enddate",
                   width : "10rem"
                  }));
                  this.oTreeTable.addColumn(new sap.ui.table.Column({
                   label : this.getView().getModel("i18n").getObject("STATUS"),
                   template : "workflow>Statustext",
                   width : "10rem"
                  }));

                                    }else{
                                         var oLink = new sap.m.Link({
                                            text : "{Fullname}",
                                            press : oControllerS6.openBusinessCard,
                                            enabled : {
                                                "parts" : [ 'isSpecial'],
                                                "formatter" : flm.fiori.utils.formatter.linkEnabled
                                            },
                                            emphasized : {
                                                "parts" : [ 'isSpecial'],
                                                "formatter" : flm.fiori.utils.formatter.linkEmphasized
                                            },
                                     });
                                     var oSpace1 = new sap.ui.core.HTML({
                                            content : "<span>&nbsp;&nbsp;</span>"
                                     });
                                     var oSpace2 = new sap.ui.core.HTML({
                                            content : "<span>&nbsp;&nbsp;</span>"
                                     });
                                     var oIcon1 = new sap.ui.core.Icon(
                                                   {
                                                          size : "1rem",
                                                          src : {
                                                                 "parts" : [ 'Nodetype' ],
                                                                 "formatter" : flm.fiori.utils.formatter.treeTableFlowIcon
                                                          },
                                                          color : "#5C85FF"
                                                   });
                                     
                                     var oIcon2 = new sap.ui.core.Icon(
                                                   {
                                                          size : "1rem",
                                                          src : {
                                                              "parts" : [ 'Pospast' , 'isSpecial'],
                                                              "formatter" : flm.fiori.utils.formatter.treeTableIcon
                                                       },
                                                       color : {
                                                           "parts" : [ 'Pospast','SubstRsn','AdminRsn' ],
                                                           "formatter" : flm.fiori.utils.formatter.treeTableIconColor
                                                       }
                                                   });
                                     
                                     this.oLayout = new sap.ui.layout.HorizontalLayout({
                                                          content : [ oIcon1,oSpace1,oIcon2,oSpace2,oLink ]
                                                   });

                                     var pubText = new sap.ui.core.HTML({
                                         content : "{shortPrefix1}" 
                                     });
                                     
                                     var oLine1 = new sap.ui.core.HTML({
                                         content : "<HR/>"
                                     });
                                     
                                     var oIcon3 = new sap.ui.core.Icon(
                                             {
                                                 size : "1rem",
                                                 src : "sap-icon://private",
                                                 color : "#009de0",
//                                                 styleClass : "noteLayoutIcon1"
                                             }).addStyleClass("notePrivIcon");
                                     var privateHead = new sap.ui.core.Icon(
                                             {
                                                 size : "1rem",
                                                 src : "sap-icon://private",
                                                 color : "#5C85FF",
                                             });//.addStyleClass("noteLayoutIcon1");
                                     var priText = new sap.ui.core.HTML({
                                         content : "<span>"+"{shortPrefix2}"+"</span>",
                                     });
                                   /*  var h1 = new sap.ui.layout.HorizontalLayout({
                                      content : priText
                                     }).addStyleClass("h11");*/

                                     var seeMoreLink1 = new sap.m.Link({
                                      text : oControllerS6.getView().getModel("i18n").getObject("READ_MORE"),
                                      emphasized : true,
                                      press: oControllerS6.onSeeMorePress1
                                     }).addStyleClass("linkStyle");
                                     var seeMoreLink2 = new sap.m.Link({
                                      text : oControllerS6.getView().getModel("i18n").getObject("READ_MORE"),
                                      emphasized : true,
                                      press: oControllerS6.onSeeMorePress2
                                     }).addStyleClass("linkStyle");
                                     var scPublic = new sap.m.ScrollContainer({
                                     content : [pubText,seeMoreLink1] 
                                     });
                                     var scPrivate = new sap.m.ScrollContainer({
                                      content: [priText,seeMoreLink2,oIcon3]
                                     });
                                   /* var h2 = new sap.ui.layout.HorizontalLayout({
                                      content : seeMoreLink2
                                     }).addStyleClass("h12");*/
                                     this.publicLayout = new sap.ui.layout.HorizontalLayout(
                                             {
//                                                 content : [ pubText,seeMoreLink1 ],
                                                 content : [scPublic],
                                                 visible : 
                                                 {
                                                     "parts" : ['Prefix1'],
                                                     "formatter" : flm.fiori.utils.formatter.privateNoteVisibility
                                                 },
                                             });
                                     
                                     this.privateLayout = new sap.ui.layout.HorizontalLayout(
                                             {
//                                                 content : [ privateHead,priText,seeMoreLink2 ],
                                                 content : [scPrivate],
                                                 visible : 
                                                 {
                                                     "parts" : ['Prefix2'],
                                                     "formatter" : flm.fiori.utils.formatter.privateNoteVisibility
                                                 },
                                             });
                                     this.noteLayout = new sap.ui.layout.VerticalLayout(
                                             {
                                                 content : [ this.publicLayout,this.privateLayout ]
                                                //  content : [ this.publicLayout ]
                                          });

                                                     this.oTreeTable.addColumn(new sap.ui.table.Column({
                                                            label : this.getView().getModel("i18n").getObject("PROCESSORS"),
                                                            template : this.oLayout,
                                                            width : "20%"
                                                     }));
                                                     this.oTreeTable.addColumn(new sap.ui.table.Column({
                                                            label : this.getView().getModel("i18n").getObject("ACTIVITY"),
                                                            template : "Actdc",
                                                            width : "7.5%"
                                                     }));
                                                     this.oTreeTable.addColumn(new sap.ui.table.Column({
                                                            label : this.getView().getModel("i18n").getObject("START_DATE"),
                                                            template : "Creadate",
                                                            width : "10%"
                                                     }));
                                                     this.oTreeTable.addColumn(new sap.ui.table.Column({
                                                            label : this.getView().getModel("i18n").getObject("END_DATE"),
                                                            template : "Enddate",
                                                            width : "10%"
                                                     }));
                                                     this.oTreeTable.addColumn(new sap.ui.table.Column({
                                                            label : this.getView().getModel("i18n").getObject("STATUS"),
                                                            template : "Statustext",
                                                            width : "7.5%"
                                                     }));
                                                     this.oTreeTable.addColumn(new sap.ui.table.Column({
                                    label : this.getView().getModel("i18n").getObject("NOTE"),
                                    template : this.noteLayout,
                                    width : "45%",
                                    visible : flm.fiori.utils.formatter.noteColumVisibility(oControllerS6.fromTab)
                                   }));
                                                    
                                    }
                                   
                                    // load workflow here
                                    if(this.fromTab=="CREATEDAAK" || this.fromTab=="DRAFTDAAK"){
                                         oControllerS6.loadTreeTable();
                                    }else{ // the workflow is loaded into global model for intray
                                         if (this.data.workflow == null) {
                                                              // load the service and set the model
                                                              oWorkflowModel = new sap.ui.model.json.JSONModel();
                                                              oWorkflowModel
                                                                           .attachRequestCompleted(
                                                                                         this,
                                                                                         function(oEvent) {
                                                                                                
                                                                                                oWorkflowModel
                                                                                                              .detachRequestCompleted();
                                                                                                oControllerS6.data.workflow = oWorkflowModel.oData.d.results;
                                                                                                oControllerS6.getView()
                                                                                                              .getModel("createdaak")
                                                                                                              .checkUpdate();
                                                                                                oControllerS6
                                                                                                              .initializeWorkflow(oControllerS6);
                                                                                                oControllerS6.getView()
                                                                                                              .getModel("createdaak")
                                                                                                              .checkUpdate();
                                                                                         }, this);
                                                              
                                                                     oWorkflowModel
                                                                     .loadData(
                                                                                  serviceUrl
                                                                                                + "/FILE_PROUTE_ES?$filter=CaseGuid eq '"
                                                                                                + this.caseguid + + "' and TabType eq '"+this.fromTab+"' and WitemId eq '"+this.wiId+"' and ISDAAK eq true",
                                                                                  null, true);
                                                              
                                                       }else{
                                                        oControllerS6.reloadWorkflow(oControllerS6);
                                                        oControllerS6.customBusyDialogClose();
                                                       }
                                                }      


                                    // List Model for documents
                                    oListModel = [];
                                    
                             },
                             /*
         * Generic Code for
         * opening fragments
         */
              openDialog : function(sType) {

               if (!this[sType]) {
                this[sType] = sap.ui.xmlfragment("flm.fiori.view."
                  + sType, this // associate
                // controller
                // with
                // the
          // fragment
                );
                this.getView().addDependent(this[sType]);
               }
               this[sType].open();
              },
              /*
         * Generic Code for
         * closing fragments
         */
              closeDialog : function(sType) {
               if (!this[sType]) {
                this[sType] = sap.ui.xmlfragment("flm.fiori.view."
                  + sType, this // associate
                // controller
                // with
                // the
          // fragment
                );
                this.getView().addDependent(this[sType]);
               }
               this[sType].close();

              },
                            
                         /*Setting initial models*/
                             // /////////////////////////////////////////////////////
                             setInitialModels : function(controller) {
                                    
                                    oModel = controller.getView().getModel();
                                                         
                                  if(oControllerS6.fromTab=="CREATEDAAK"){
                                  oBatchOp = oModel
                                                .createBatchOperation(
                                                              "/FILE_BUTTONS_ES(GUID='',TABTYPE='"+this.fromTab+"',FILEID='',FILETYPE='',WIID='',ISDAAK=true)",'GET');
                                  }else{
                                   oBatchOp = oModel
                                      .createBatchOperation(
                                                    "/FILE_BUTTONS_ES(GUID='"+this.caseguid+"',TABTYPE='"+this.fromTab+"',FILEID='',FILETYPE='',WIID='"+this.wiId+"',ISDAAK=true)",'GET'); 
                                  }
                                  oModel.addBatchReadOperations([ oBatchOp ]);

                                    oBatchOp = oModel
                                                  .createBatchOperation(
                                                                "/FILE_F4_ES?$filter=CaseGuid+eq+'"
                                                                                    + this.caseguid
                                                                                    + "'+and+OtherF4+eq+true+and+ID+eq+'WC'",
                                                                'GET');
                                    oModel.addBatchReadOperations([ oBatchOp ]);
                                    
                                    if(oControllerS6.fromTab=="CREATEDAAK"){
                                    oBatchOp = oModel.createBatchOperation(
                                                  "/FILE_NUMBER_ES?$filter=DAAKTYPE+eq+'" + this.daaktype + "'+and+ISDAAK+eq+true", 'GET');
                                    oModel.addBatchReadOperations([ oBatchOp ]);
                                    }
                                    
                                    oBatchOp = oModel
                                    .createBatchOperation("/FILE_ATTR_ES?$filter=GUID+eq+'"
                                                                      + this.caseguid
                                                                      + "'+and+FILETYPE+eq+''+and+TABTYPE+eq+'"+this.fromTab+"'+and+ISDAAK+eq+true", 'GET');
                                    oModel.addBatchReadOperations([ oBatchOp ]);
                                   
                                    //basic attributes
                                    oBatchOp = oModel.createBatchOperation(
                                                                "/FILE_BASIC_ES(CaseGuid='" + this.caseguid
                                                                             + "',TabType='" + this.fromTab
                                                                             + "',FileType='',ExtKey='"
                                                                             + this.fileid + "',Wiid='"+this.wiId+"',ISDAAK=true)", 'GET');
                                    oModel.addBatchReadOperations([ oBatchOp ]);
                                                                        
                                   if(oControllerS6.fromTab=="CREATEDAAK" || oControllerS6.fromTab=="DRAFTDAAK"){
                                    this.wiId = "";
                                   }
                                    //documents
                                   
                                    oBatchOp = oModel
                                                               .createBatchOperation(
                                                                            "/FILE_DOCUM_ES?$filter=Guid+eq+'"
                                                                                          + this.caseguid
                                                                                          + "'+and+TabType+eq+'"+this.fromTab+"'+and+Wiid+eq+'"+this.wiId+"'+and+FileID+eq+'"
                                                                                          + this.fileid + "'",
                                                                            'GET');
                                    oModel.addBatchReadOperations([ oBatchOp ]);
                                    
                                    
                                    //notings
                                    oBatchOp = oModel.createBatchOperation(
                                                                      "/FILE_NOTING_ES?$filter=TabType+eq+'"
                                                                                    + this.fromTab
                                                                                    + "'+and+CaseGuid+eq+'"
                                                                                    + this.caseguid
                                                                                    + "'+and+Wiid+eq+'"+this.wiId+"'+and+Wfinfo+eq+''", 'GET');
                                    oModel.addBatchReadOperations([ oBatchOp ]);
                                         
                                    oModel.submitBatch(
                                                  function(oResponse, oData) {
                                                     var i = 0;
                                                         
                                                         if(oResponse.__batchResponses[i].message==undefined){
                                                          controller.data.buttons = oResponse.__batchResponses[i].data;
                                                          }
                                                             else{
                                                              sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                            oResponse.__batchResponses[i].response.headers));
                                                            oControllerS6.initFlag=false;
                                                              return;
                                                             }
                                                              i++;
                                                               
                                                               if(oResponse.__batchResponses[i].message==undefined){
                                                                controller.data.privateNote = oResponse.__batchResponses[i].data.results;
                                                                }
                                                                   else{
                                                                    sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                    oResponse.__batchResponses[i].response.headers));
                                                                    oControllerS6.initFlag=false;
                                                                    return;
                                                                   }
                                                                i++;
                                                               
                                                                if(oControllerS6.fromTab=="CREATEDAAK"){
                                                                if(oResponse.__batchResponses[i].message==undefined){
                                                                 controller.data.fileNumber = oResponse.__batchResponses[i].data.results;
//                                                                 oControllerS6.getView().byId("idDaakCreatedBy").setValue(controller.data.fileNumber[0].UNAME);
                                                                var d = new Date();
                                                                var time = d.toTimeString().substr(0, 8);
                                                                var today = d.toDateString();
                                                                // fetching value from view 1
                                                                oControllerS6.getView().byId("idDaakCreatedOn").setValue(today + " , "+ time);
                                                                 if(controller.data.fileNumber.length==0){
                                                                  sap.m.MessageBox.alert(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_55"));
                                                                 oControllerS6.initFlag=false;
                                                                     return;
                                                                 }
                                                                 }
                                                                    else{
                                                                     sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                     oResponse.__batchResponses[i].response.headers));
                                                                    oControllerS6.initFlag=false;
                                                                     return;
                                                                     }
                                                                i++;
                                                                }
                                                                
                                                                if(oResponse.__batchResponses[i].message==undefined){
                                                                 controller.data.dynamic = oResponse.__batchResponses[i].data.results;
                                                                 }
                                                                    else{
                                                                     sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                     oResponse.__batchResponses[i].response.headers));
                                                                    oControllerS6.initFlag=false;
                                                                     return;
                                                                     }
                                                                i++;
                                                                
                                                                if(oResponse.__batchResponses[i].message==undefined){
                                                                 controller.data.basic = oResponse.__batchResponses[i].data;
                                                                    }
                                                                    else{
                                                                     sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                     oResponse.__batchResponses[i].response.headers));
                                                                    oControllerS6.initFlag=false;
                                                                     return;
                                                                     }
                                                                i++;
                                                                
                                                                if(oResponse.__batchResponses[i].message==undefined){
                                                                 controller.data.attachments = oResponse.__batchResponses[i].data.results;}
                                                                    else{
                                                                     sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                     oResponse.__batchResponses[i].response.headers));
                                                                    oControllerS6.initFlag=false;
                                                                     return;
                                                                     }
                                                                i++;
                                                                
                                                                if(oResponse.__batchResponses[i].message==undefined){
                                                                 if (oResponse.__batchResponses[i].data.results.length == 0) {
                                                                 oControllerS6.getView()
                  .byId(
                    "daakNotingEditor")
                  .setValue(
                    "");
                                                                 
                controller.data.notes = oResponse.__batchResponses[i].data.results;
                 for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                  try{
                   oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                                                   }catch(err){
                                                    oResponse.__batchResponses[i].data.results[j].actNote = oResponse.__batchResponses[i].data.results[j].NotingString;
                                                   }

                 }
                                                                 }
                                                                 else if (oResponse.__batchResponses[i].data.results.length > 0) {
                                                                 if (oResponse.__batchResponses[i].data.results[oResponse.__batchResponses[i].data.results.length - 1].ANotingString != "") {

                     var assistNoting = oResponse.__batchResponses[i].data.results[oResponse.__batchResponses[i].data.results.length - 1].ANotingString;
                     oControllerS6.getView()
                       .byId(
                         "daakNotingEditor")
                       .setValue(
                         assistNoting);
                      oResponse.__batchResponses[i].data.results
                  .splice(
                    oResponse.__batchResponses[i].data.results.length - 1,
                    1);
                                                                 controller.data.notes = oResponse.__batchResponses[i].data.results;
                                                                  for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                   try{
                                                                    oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                                                     }catch(err){
                                                      oResponse.__batchResponses[i].data.results[j].actNote = oResponse.__batchResponses[i].data.results[j].NotingString;
                                                     }
                     }
                                                                 }
                                                                else {
                                                                 oControllerS6.getView()
                       .byId(
                         "daakNotingEditor")
                       .setValue(
                         "");
                     controller.data.notes = oResponse.__batchResponses[i].data.results;
                      for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                        try{
                        oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                                                            }catch(err){
                                                             oResponse.__batchResponses[i].data.results[j].actNote = oResponse.__batchResponses[i].data.results[j].NotingString;
                                                            }
                                                            }
                    }
                                                                         }
                                                                }
                                                                    else{
                                                                     sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                     oResponse.__batchResponses[i].response.headers));
                                                                    oControllerS6.initFlag=false;
                                                                     return;
                                                                     }
                                                                mparams = controller.data.dynamic; 
                                                                controller.getView().byId("dynamicAttrForm").destroyContent();
                                                                controller.dynUIAssistArr = createDynamicUI(mparams, controller,
                                                                             controller.getView(), "dynamicAttrForm",
                                                                             false);
                                                                controller.getView().getModel("createdaak").checkUpdate();
                                                                controller.createFileResponse = controller.data.fileNumber;
                                                                
                                                  }, function(oResponse) {
                                                         
                                                  }, false);

                             },
                             
                             onChangeFileAttribute : function(oEvent) {
                                 oControllerS6.saveFlag = true;
                                    },
                                    
                                    onChangeDateAttribute : function(oEvent) {
                                     this.getView().byId("deleteDate").setVisible(true);
                                     oControllerS6.saveFlag = true;
                                        },

                                    /* Handling f4 help */
                                        handleF4Help : function(oEvent) {
                                           
                                           for ( var i = 0; i < mparams.length; i++) {
                                                  if (mparams[i].ID == oEvent.getSource().getId()) {

                                                         if (!oControllerS6._oDynamicF4Dialog) {
                                                                oControllerS6._oDynamicF4Dialog = sap.ui
                                                                             .xmlfragment(
                                                                                           "flm.fiori.view.dynamicF4popup",
                                                                                           oControllerS6);

                                                         }

                                                         var oF4Model = null;
                                                         oF4Texts = new sap.ui.model.json.JSONModel();
                                                         var f4text = {
                                                                title : mparams[i].F4_TITLE,
                                                                id : mparams[i].ID
                                                         };
                                                         oF4Texts.setData(f4text);
                                                         oControllerS6._oDynamicF4Dialog.setModel(
                                                                       oF4Texts, "dyntext");
                                                         if (mparams[i].F4HELP_VALUES != null
                                                                       && mparams[i].F4HELP_VALUES != undefined
                                                                       && mparams[i].F4HELP_VALUES != "") {
                                                                f4array = getF4Array(mparams[i].F4HELP_VALUES);
                                                                oF4Model = new sap.ui.model.json.JSONModel();
                                                                oF4Model.setData(f4array);
                                                         } else {
                                                                oF4Model = new sap.ui.model.odata.ODataModel(
                                                                             serviceUrl
                                                                                           + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                           + this.caseguid
                                                                                           + "' and ID eq '"
                                                                                           + mparams[i].ID
                                                                                           + "' and FileID eq '"
                                                                                           + this.fileid + "'");
                                                         }
                                                         oControllerS6._oDynamicF4Dialog
                                                                       .setModel(oF4Model);
                                                  }
                                           }
                                           oControllerS6._oDynamicF4Dialog.open();
                                    },
                                    
                                    /*Changing dynamic attributes date time value*/
                                    
                                    onChangeDateTimeInDynamicUI : function(oEvent) {
                                     oControllerS6.saveFlag = true;
                      if(oEvent.getSource().getValue()!="" && oEvent.getSource().getEditable()){
                      sap.ui.getCore().byId(oEvent.getSource().getId()+"Clear").setVisible(true);
                      }else{
                      sap.ui.getCore().byId(oEvent.getSource().getId()+"Clear").setVisible(false);
                      }  

                     },     

                     /*Search in value help popup */
                            _handleF4HelpSearch1 : function(evt) {

                         var sValue = evt.getParameter("value");
                         var oFilter = new sap.ui.model.Filter("ResulltCol1",
                           sap.ui.model.FilterOperator.Contains, sValue);
                         var oFilter1 = new sap.ui.model.Filter("ResultCol2",
                           sap.ui.model.FilterOperator.Contains, sValue);
                         var oFilter2 = new sap.ui.model.Filter("ResultCol3",
                         sap.ui.model.FilterOperator.Contains, sValue);
                       evt.getSource().getBinding("items").filter(
                         new sap.ui.model.Filter([ oFilter,oFilter1, oFilter2 ],
                             "OR"));
                        },

                        /*Select value from value help F4 pop-up*/
                         _handleF4HelpClose1 : function(evt) {
                                          
                                          var oSelectedItem = evt.getParameter("selectedItem");
                                          var id = evt.getSource().getModel("dyntext").getData().id;
                                          var oInput;
                                          if (oSelectedItem) {// when called from FRAGMENT
                                                 if (sap.ui.getCore().byId(id) != undefined) {
                                                        oInput = sap.ui.getCore().byId(
                                                                      evt.getSource().getModel("dyntext")
                                                                                   .getData().id);

                                                 } else {// when called from VIEW
                                                        oInput = this.getView().byId(
                                                                      evt.getSource().getModel("dyntext")
                                                                                   .getData().id);
                                                 }
                                                 ;
                                                 // get the id and
                                                 // place it here
                                                 if (id == "idUsername" || id=="processorInput" || id=="userValueInput" || id=="daakProcessorInput") {
                                                  if(oSelectedItem.getBindingContext().getObject().ResultCol3.substr(0,2) == "US"){
                                                        oInput.setValue(oSelectedItem.getBindingContext().getObject().ResultCol2
                                                                     + " " + oSelectedItem.getBindingContext().getObject().ResulltCol1);
                                                   
                                                 }else{
                                                  oInput.setValue(oSelectedItem.getBindingContext().getObject().ResulltCol1);
                                                 }
                                                 oInput.setName(oSelectedItem
                                                              .getBindingContext()
                                                              .getObject().ResultCol3);  
                                                 } else if (id == "idOrgUnit") {

                                                        oInput.setValue(oSelectedItem.getBindingContext().getObject().ResultCol2);
                                                        var oTable = sap.ui.getCore().byId("leftTree");
                                                        var oModel = new sap.ui.model.json.JSONModel();
                                                        oModel.attachRequestCompleted(oControllerS6,function(oEvent){
                                                         if(oEvent.mParameters.errorobject){
                                                       oModel.detachRequestCompleted();
                                                             sap.m.MessageBox.alert(getErrorJson(oEvent.mParameters.errorobject.responseText));
                          return;
                                                      }
                                                        },oControllerS6);
                                                        oModel.loadData(serviceUrl
                                                                      + "/ORGU_MEM_ETSet?$filter=OobjId eq '"
                                                                      + oSelectedItem.getBindingContext()
                                                                                   .getObject().ResultCol3 + "' and LevelDesc eq '1'",
                                                                      null, false);
                                                        var result = [{
                                                                      "Stext" : oSelectedItem.getBindingContext().getObject().ResultCol2 ,
                                                                      "Text" : oSelectedItem.getBindingContext().getObject().ResulltCol1,
                                                                      "Objid" : oSelectedItem.getBindingContext().getObject().ResultCol3.substr(2),
                                                                      "Otype" : oSelectedItem.getBindingContext().getObject().ResultCol3.substr(0,2),
                                                                      "ImageSrc" : "sap-icon://org-chart",
                                                                      "LevelDesc" : "1",
                                                                      nodes: [],
                                                               }];
                                                        
                                                        result=result.concat(oModel.oData.d.results);
                                                        oControllerS6.leftTreeNodes=result;
                                      ///////////////////
                                                        var obj = {
                                                                "nodes" : [],
                                                                "Label" : oControllerS6.getView().getModel("i18n").getObject("SEQUENCE")
                                                         };
                                                         for ( var i = 0; i < result.length; ++i) {
                                                                result[i].__metadata = null;
                                                                var levels = result[i].LevelDesc.split("_");

                                                                for ( var k = 0; k < levels.length; ++k) {
                                                                       levels[k] = parseInt(levels[k]) - 1;
                                                                }

                                                                var tempObj = obj;

                                                                for ( var j = 0; j < levels.length - 2; ++j) {
                                                                       tempObj = tempObj.nodes[levels[j]];
                                                                }

                                                                if (tempObj.nodes[levels[j]] == undefined) {
                                                                       result[i].nodes = [];
                                                                       tempObj.nodes[levels[j]] = result[i];
                                                                       continue;
                                                                }

                                                                result[i].nodes = [];
                                                                tempObj.nodes[levels[j]].nodes.push(result[i]);
                                                         }

                                                         oModel.setData(obj);
                                                        //////////////////

//                                                        oModel.setData(result);

                                                        oTable.setModel(oModel); // set model to
                                                                                                        // Table*/
                                                        
                                                        oTable.bindRows("/");
//                                                        for(var i=0;i<result.length;i++){
//                                                         oTable.expand(i);
//                                                        }
                                                        sap.ui.getCore().byId("idOrgUnitClear").setVisible(true);
                                                 }else if (id == "idFactoryCalendar") {
                                                   oInput
                                                      .setName(oSelectedItem
                                                                    .getBindingContext()
                                                                    .getObject().ResultCol3);

                                                   oInput
                                                      .setValue(oSelectedItem
                                                                    .getBindingContext()
                                                                    .getObject().ResulltCol1);
                                                     sap.ui.getCore().byId("idFactoryCalendarClear").setVisible(true);
                                                 }
                                                 else {
                                                        oInput
                                                                                   .setName(oSelectedItem
                                                                                                 .getBindingContext()
                                                                                                 .getObject().ResultCol3);

                                                                      oInput
                                                                                   .setValue(oSelectedItem
                                                                                                 .getBindingContext()
                                                                                                 .getObject().ResulltCol1);
                                                                      oControllerS6.onChangeFileAttribute();
//                                                        oInput
//                                                                      .setValue(oSelectedItem
//                                                                                   .getBindingContext()
//                                                                                   .getObject().ResultCol3);
                                                 }
                                          }
                                          evt.getSource().getBinding("items").filter([]);
//                                          this._oDynamicF4Dialog.getModel().destroy();
//                                          this._oDynamicF4Dialog.getModel("dyntext").destroy();
                                   },
                             
                             /*Noting expanded editor*/
                             
                             notingExpandActionPressed : function(oEvent) {

                                 if (!oControllerS6._oFullScreenDialog1) {
                                  oControllerS6._oFullScreenDialog1 = sap.ui
                                                      .xmlfragment(
                                                                   "flm.fiori.view.notingFullView",
                                                                   oControllerS6);
                                 }
                                
                                 oControllerS6._oFullScreenDialog1.getContent()[0]
                                               .setValue(oControllerS6.getView().byId("daakNotingEditor")
                                                            .getValue());
                                 oControllerS6._oFullScreenDialog1.open();
                          },

                          notingFullScreenCloseButton : function(oEvent) {
                                 this.getView().byId("daakNotingEditor")
                                               .setValue(
                                                 oControllerS6._oFullScreenDialog1
                                                                          .getContent()[0].getValue());
                                 oControllerS6._oFullScreenDialog1.close();
                                 // oControllerS2._oFullScreenDialog1.destroy();
                          },

                          notingFullScreenCancelButton : function(oEvent) {
                                 sap.ui.getCore().byId("notingFullEditor")
                                               .setValue(
                                                             this.getView().byId("daakNotingEditor")
                                                                          .getValue());
                                 oControllerS6._oFullScreenDialog1.close();
                                 // oControllerS2._oFullScreenDialog1.destroy();
                          },
                          
                          /* Posting New Noting */
                          onNewNotingPostActionPressed : function(evt) {
                                               // notingEditFlag = false;
                                               if(!this.wiId){
                                                this.wiId="";
                                               }
                                               if (oControllerS6.getView().byId("daakNotingEditor")
                                                             .getValue() == "") {
                                                      sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_24"));
                                                      return;
                                               }
//                                               var SignedTxt = "";
                                              
                                               var newNoting = this.getView().byId("daakNotingEditor")
                                                             .getValue();// oEvent.getSource().getBindingContext().getObject();
                                               var remarkTo = "";
                                               var bPrivate;
                                               if (this.getView().byId("daakReceiverTypeNoting")
                                                             .getSelectedItem().getText() == "") {
                                                      bPrivate = "0002";
                                               } else {
                                                      if (this.getView().byId("daakProcessorInput").getValue() == '') {
                                                             sap.m.MessageBox
                                                                          .alert(this.getView().getModel("i18n").getObject("MESSAGE_23"));
                                                             return;
                                                      } else {
                                                             bPrivate = "0004";
                                                             remarkTo = this.getView().byId("daakProcessorInput")
                                                                          .getName();
                                                      }
                                               }
                                               var newNotingData = {
                                                      TabType : this.fromTab,
                                                      Textid : bPrivate,
                                                      Wiid : this.wiId,
                                                      CaseGuid : oControllerS6.caseguid,
                                                      NotingString : encodeURIComponent(newNoting),
                                                     // SNotingString : "",
                                                      PAgent : remarkTo
                                               };
                                               this.customBusyDialogOpen();
                                        var ocrModel = this.getView().getModel();
                                               ocrModel
                                                             .create(
                                                                          "/FILE_NOTING_ES",
                                                                          newNotingData,
                                                                          {
                                                                                 success : function(oResponse) {
                                                                                        
                                                                                        var notingListModel = oControllerS6.getView().byId(
                                                                                                                    "daakNotingList")
                                                                                                      .getModel("createdaak").oData.notes;
                                                                                        if (notingListModel == null) {
                                                                                               notingListModel = [ oResponse ];
                                                                                               try{
                                                                                                oResponse.actNote = decodeURIComponent(oResponse.NotingString);
                                                                              }catch(err){
                                                                               oResponse.actNote = oResponse.NotingString;
                                                                              }
                                                                                               
                                                                              oControllerS6.data.notes = notingListModel;
                                                                                               oControllerS6.getView()
                                                                                                             .getModel("createdaak")
                                                                                                             .checkUpdate();
                                                                                        } else {
                                                                                               notingListModel.splice(0, 0,
                                                                                                             oResponse);
                                                                                               //oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                                                                                               try{
                                                                                                oResponse.actNote = decodeURIComponent(oResponse.NotingString);
                                                                              }catch(err){
                                                                               oResponse.actNote = oResponse.NotingString;
                                                                              } 
                                                                              oControllerS6.getView()
                                                                                                             .getModel("createdaak")
                                                                                                             .refresh();
                                                                                        }
                                                                                        oControllerS6.customBusyDialogClose();                                                  
                                                                                 },
                                                                                 error : function(oResponse) {
                                                  sap.m.MessageBox.alert(getErrorJson(oResponse.response.body));
                                                  oControllerS6.customBusyDialogClose();
                                                 },
                                                                                  async : false
                                                                          });
                                               this.getView().byId("daakNotingEditor").setValue("");

                                               this.getView().byId("daakProcessorInput").setValue("");
                                               oControllerS6.getView().byId("daakReceiverTypeNoting")
                                                             .setSelectedKey("SPACE");
                                        },
                                        
                                        // ///Notings Edit

                                        editNotingPressed : function(oEvent) {
                                               // notingEditFlag = true;
                                               this.getView().byId("daakNotingCreateAction").setVisible(false);
                                               this.getView().byId("daakNotingEditAction").setVisible(true);
                                               oControllerS6.getView().byId("daakNotingEditor").rerender();
                                               var clickedNote = oEvent.getSource().getParent()
                                                             .getParent().getParent().getParent()
                                                             .getParent().getBindingContext("createdaak")
                                                             .getObject();
                                               if (!clickedNote.NoteFlag) {
                                                oControllerS6.getView().byId("daakProcessorInput")
                                                                   .setEnabled(false);
                                                oControllerS6.getView().byId("daakReceiverTypeNoting")
                                                                   .setSelectedKey("SPACE");
                                                oControllerS6.getView().byId("daakReceiverTypeNoting")
                                                                   .setEnabled(false);
                                               } else {
                                                oControllerS6.getView().byId("daakProcessorInput")
                                                                   .setEnabled(true);
                                                oControllerS6.getView().byId("daakReceiverTypeNoting")
                                                                   .setEnabled(true);
                                               }
                                               var tempModel = new sap.ui.model.json.JSONModel();
                                               tempModel.setData(oEvent.getSource().getParent()
                                                             .getParent().getItems()[0].getBindingContext(
                                                             "createdaak").getObject());
                                               this.getView().byId("daakNotingEditor")
                                                             .setModel(tempModel);
                                               this.getView().byId("daakNotingEditor").setValue(
                                                             oEvent.getSource().getParent().getParent()
                                                                          .getItems()[0].getContent());
                                               sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_59"));
                                        },
                                        // ///Notings Edit ends

                                        // //For new noting clear data
                                        notingNewActionPressed : function(oEvent) {
                                               this.getView().byId("daakNotingEditAction").setVisible(false);
                                               this.getView().byId("daakNotingCreateAction").setVisible(true);
                                               this.getView().byId("daakProcessorInput").setEnabled(true);
                                               this.getView().byId("daakReceiverTypeNoting").setEnabled(
                                                             true);
                                               this.getView().byId("daakNotingEditor").setValue("");
                                               this.getView().byId("daakProcessorInput").setValue("");
                                               this.getView().byId("daakReceiverTypeNoting")
                                                             .setSelectedKey("SPACE");

                                        },
                                        
                                        // For Edited Notings
                                        onEditNotingActionPressed : function(evt) { 
                                        if (oControllerS6.getView().byId("daakNotingEditor")
                                                      .getValue() == "") {
                                               sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_24"));
                                               return;
                                        }
//                                        var SignedTxt = "";
                                              
                                        
                                        if (this.getView().byId("daakNotingEditor").getModel()
                                                      .getData().Notingid != undefined) {
                                               if (this.getView().byId("daakNotingEditor").getModel()
                                                             .getData().NoteFlag) {
                                                      if (oControllerS6.getView().byId("daakProcessorInput")
                                                                   .getValue() == "") {
                                                            sap.m.MessageBox
                                                                          .alert(this.getView().getModel("i18n").getObject("MESSAGE_22"));
                                                             return;
                                                      }
                                               }
                                               var remarkTo = "";
                                               var bPrivate;
                                               if (this.getView().byId("daakReceiverTypeNoting")
                                                             .getSelectedItem().getText() == ""
                                                             || !this.getView().byId(
                                                                          "daakReceiverTypeNoting").getEnabled()) {
                                                      bPrivate = "0002";
                                               } else {

                                                      if (this.getView().byId("daakProcessorInput").getValue() == ''
                                                                   || !this.getView().byId("daakProcessorInput")
                                                                                 .getEnabled()) {
                                                             sap.m.MessageBox
                                                                          .alert(this.getView().getModel("i18n").getObject("MESSAGE_23"));
                                                             return;
                                                      } else {
                                                             bPrivate = "0004";
                                                             remarkTo = this.getView().byId("daakProcessorInput")
                                                                          .getName();
                                                      }

                                               }

                                               var editedContent = {
                                                      TabType : oControllerS6.fromTab,
                                                      Textid : bPrivate,
                                                      //Wiid : oControllerS3.wiId,
                                                      CaseGuid : oControllerS6.caseguid,
                                                      NotingString : encodeURIComponent(oControllerS6.getView().byId(
                                                                   "daakNotingEditor").getValue()),
                                                     // SNotingString : SignedTxt,
                                                      PAgent : remarkTo,
                                                      Notingid : oControllerS6.getView().byId(
                                                                    "daakNotingEditor").getModel().getData().Notingid
                                               };
                                               var updateModel = this.getView().getModel();
                                               // create batch operation
                                               // updateModel.clearBatch();
                                               var batchOp = updateModel.createBatchOperation(
                                                             "/FILE_NOTING_ES(Notingid='"
                                                                          + oControllerS6.getView().byId(
                                                                                        "daakNotingEditor").getModel()
                                                                                        .getData().Notingid + "')",
                                                             'PUT', editedContent);
                                               // add batch operation
                                               updateModel.addBatchChangeOperations([ batchOp ]);
                                               var batchOp = updateModel.createBatchOperation(
                                                             "/FILE_NOTING_ES(Notingid='"
                                                                          + oControllerS6.getView().byId(
                                                                                        "daakNotingEditor").getModel()
                                                                                        .getData().Notingid + "')",
                                                             "GET");
                                               // add batch operation
                                               updateModel.addBatchReadOperations([ batchOp ]);

                                               oControllerS6.customBusyDialogOpen("");
                                               // finally submit batch for both basic and dynamic
                                               // attributes
                                               updateModel
                                                             .submitBatch(
                                                                          function(oResponse, oData) {
                                                                                 
                                                                                 var notingList = oControllerS6
                                                                                               .getView().byId(
                                                                                                             "daakNotingList")
                                                                                               .getModel("createdaak")
                                                                                               .getData().notes;
                                                                                 if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {

                                                                                 for (var i = 0; i < notingList.length; i++) {
                                                                                        if (notingList[i].Notingid == oResponse.__batchResponses[1].data.Notingid) {
                                                                                         try{
                                                                                          notingList[i].actNote= decodeURIComponent(oResponse.__batchResponses[1].data.NotingString);
                                                                           }catch(err){
                                                                            notingList[i].actNote= oResponse.__batchResponses[1].data.NotingString;
                                                                           }
                                                                                               
                                                                                               notingList[i].Createdate = oResponse.__batchResponses[1].data.Createdate;
                                                                                               notingList[i].Rmrkto = oResponse.__batchResponses[1].data.Rmrkto;
                                                                                               oControllerS6.getView()
                                                                                                             .byId(
                                                                                                                           "daakNotingList")
                                                                                                             .getModel(
                                                                                                                          "createdaak")
                                                                                                             .checkUpdate();
                                                                                               break;
                                                                                        }
                                                                                 }
                                                                                 }
                                                                                        else{
                                                      sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                                        oResponse.__batchResponses[i].response.headers));
                                                      return;
                                                     }
                                                                                 
                                                                                 oControllerS6.customBusyDialogClose();
                                                                          }, function(oResponse) {
                                                                                 
                                                                          }, true);

                                               this.getView().byId("daakNotingEditor").setValue("");

                                               this.getView().byId("daakProcessorInput").setValue("");
                                               this.getView().byId("daakNotingEditor").getModel()
                                                             .destroy();
                                        }
                                        this.getView().byId("daakNotingEditAction").setVisible(false);
                                        this.getView().byId("daakNotingCreateAction").setVisible(true);

                                        // Enable the reciever type and name field
                                        this.getView().byId("daakProcessorInput").setEnabled(true);
                                        this.getView().byId("daakReceiverTypeNoting").setEnabled(
                                                      true);
                                        oControllerS6.getView().byId("daakReceiverTypeNoting")
                                                      .setSelectedKey("SPACE");
                                 }, 
                                 
                                 /*open dialog for private note processor details*/
                                 subDetailsPressed : function(oEvent){
                   if (!this.privateDetailOpen) {
                    this.privateDetailOpen = sap.ui.xmlfragment(
                      "flm.fiori.view.privateDetails", this);
                   }
                   var detailsModel = new sap.ui.model.json.JSONModel();
                   detailsModel.setData(oEvent.getSource()
                     .getBindingContext("createdaak").getObject());
                   this.privateDetailOpen.setModel(detailsModel);
                   this.privateDetailOpen.bindElement("/");
                   this.privateDetailOpen.openBy(oEvent.getSource());
                  },
                                 
                  /*Generic function for busyDialog open */
                                 customBusyDialogOpen : function(busyText) {
                                     if (!this._dialog) {

                                            this._dialog = sap.ui.xmlfragment(
                                                         "flm.fiori.view.busyDialog", this);
                                            this.getView().addDependent(this._dialog);
                                     }
                                     if (busyText != null) {
                                            this._dialog.setText(busyText);
                                     } else {
                                            this._dialog.setText("");
                                     }

                                     this._dialog.open();
                              },

                              /*Generic function for busyDialog close */
                              customBusyDialogClose : function() {
                                     this._dialog.close();
                              },
                              
                              /* Functions for the DOCUMENTS panel starts */
                              onLinkPress : function(oEvent) {
                                  
                                 oControllerS6.customBusyDialogOpen();
                                  var temp = oEvent.getSource().getParent().getParent()
                                                       .getParent().getParent().getBindingContext(
                                                                    "createdaak");
                                  oControllerS6.documentId = oEvent.getSource().getModel(
                                                       "createdaak").getObject(temp.getPath());

                                  var isAttachment = null;
                                  
                                  isAttachment = oControllerS6.documentId.IsAttachment;

                                  if (isAttachment) {
                                   //Check for versions
                                   oModel = new sap.ui.model.json.JSONModel();
                                      // if(oControllerS3.documentId<gResponse.length){
                                      oModel.loadData(serviceUrl
                                                    + "/FILE_DOC_FI?param_1='AV'&param_2='"
                                                    +  oControllerS6.caseguid
                                                    + "'&param_3='"
                                                    +  oControllerS6.fileid
                                                    + "'&param_4='"
                                                    + encodeURIComponent(oControllerS6.documentId.DocumentName)
                                                    + "'&param_5=''", null, false);
                                      
                                      if(oModel.getData().d.results[0].msg_type=='E'){
                                       sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                                     oControllerS6.customBusyDialogClose();
                                       return;
                                      }
                                         if (oModel.oData.d.results.length > 1) {
                                                if(!oControllerS6.oVersion){
                                                 oControllerS6.oVersion = sap.ui.xmlfragment(
                                                              "flm.fiori.view.attachmentVersion",
                                                              oControllerS6);
                                                }
                                                oControllerS6.oVersion.open();
                                                sap.ui.getCore().byId("idButtonAddLink")
                                                              .setVisible(false);
                                                sap.ui.getCore().byId("idCli")
                                                              .setType("Active");
                                                var oTable = sap.ui.getCore().byId(
                                                              "idVersionsTable");
                                                oTable.setModel(oModel, "versionModelDetail");
                                         }
                                         else {
                                                              if (oEvent.getSource().getBindingContext(
                                                                     "createdaak").getObject().IsAttachment) {
                                                              var v = 1;
                                                              
                                                              oModel = new sap.ui.model.json.JSONModel();
                                                              // success
                                                              oModel
                                                                           .attachRequestCompleted(
                                                                                         this,
                                                                                         function(oEvent) {
                                                                                                oModel
                                                                                                              .detachRequestCompleted();
                                                                                                if (oModel.getData().d.results[0].msg_type != "E") {
                                                                                                       if (oModel
                                                                                                                     .getData().d.results[0].Url != "") {
                                                                                                              window
                                                                                                                           .open(oModel
                                                                                                                                         .getData().d.results[0].Url);
                                                                                                       }
                                                                                                } else {
                                                                                                       sap.m.MessageBox
                                                                                                                     .alert(oModel
                                                                                                                                  .getData().d.results[0].msg_text);
                                                                                                }
                                                                                                
                                                                                                oControllerS6.customBusyDialogClose();

                                                                                         }, this);
                                                              // Failure
                                                              oModel.attachRequestFailed(this, function(
                                                                           oEvent) {
                                                                    
                                                               oControllerS6.customBusyDialogClose();
                                                                     oModel.detachRequestCompleted();
                                                                    oModel.detachRequestFailed();
                                                              }, this);
                                                              oModel
                                                                           .loadData(
                                                                                         serviceUrl
                                                                                                       + "/FILE_DOC_FI?param_1='AU'&param_2='"
                                                                                                       + v
                                                                                                       + "'&param_3='"
                                                                                                       + oControllerS6.documentId.AttachmentLoioID
                                                                                                       + "'&param_4='"
                                                                                                       + oControllerS6.documentId.DocumentClass
                                                                                                       + "'&param_5=''",
                                                                                         null, true);
                                                       }
                                                }
                                         oControllerS6.customBusyDialogClose();
                                  }  else if (oControllerS6.documentId.IsDaak) {
                                                    
                                                    //oControllerS3.fromSamePath = true;
                                             if (oEvent.getSource().getBindingContext("createdaak")
                                                                               .getObject().CaseGuid != oControllerS6.caseguid) {

                                                                          oControllerS6.navBackArrS6.push({
                                                                                      caseguid : oControllerS6.caseguid,
                                                                                      fileid : oControllerS6.fileid,
                                                                                      wiId : oControllerS6.wiId,
                                                                                      fromTab : oControllerS6.fromTab,
                                                                               });
                                                                          oControllerS6.fromSameDaak = true;
                                                                          oControllerS6.fromTab = "DOCDAAK";
//                                                                               oControllerS1.tabType = "draft";
                                                                               oControllerS6.getView().byId("dynamicAttrForm").destroyContent();
                                                                               docGuid = oEvent.getSource().getBindingContext("createdaak").getObject().CaseGuid;
                                                                               docFileid = oEvent.getSource().getBindingContext("createdaak").getObject().FileID;
                                                                               docWiid = "0" ;
//                                                                               oControllerS6.oRouter.navTo("daakdocscreen");
                                                                               oControllerS6.oRouter.navTo("daakdocscreen", {
                                                                                   caseguid : oEvent.getSource().getBindingContext("createdaak").getObject().CaseGuid
                                                                            });
                                                                               oControllerS6.customBusyDialogClose();
                                                                  }

                                                           }else if(oControllerS6.documentId.IsIpi){
                                                 oModel = new sap.ui.model.json.JSONModel();
                                                    // success
                                                    oModel
                                                                 .attachRequestCompleted(
                                                                               this,
                                                                               function(oEvent) {
                                                                                      oModel.detachRequestCompleted();
                                                                                      if (oModel.getData().d.results[0].msg_type != "E") {
                                                                                             if (oModel
                                                                                                           .getData().d.results[0].Url != "") {
                                                                                                    window
                                                                                                                 .open(oModel
                                                                                                                               .getData().d.results[0].Url);
                                                                                             }
                                                                                      } else {
                                                                                             sap.m.MessageBox
                                                                                                           .alert(oModel
                                                                                                                        .getData().d.results[0].msg_text);
                                                                                      }
                                                                                      
                                                                                      oControllerS6.customBusyDialogClose();

                                                                               }, this);
                                                    // Failure
                                                    oModel.attachRequestFailed(this, function(
                                                                 oEvent) {
                                                          
                                                     this.customBusyDialogClose();
                                                           oModel.detachRequestCompleted();
                                                          oModel.detachRequestFailed();
                                                    }, this);
                                                    oModel
                                                                 .loadData(
                                                                               serviceUrl
                                                                                              + "/FILE_DOC_FI?param_1='DU'&param_2='"
                                                         + encodeURIComponent(oControllerS6.documentId.DocumentName)
                                                       + "'&param_3=''&param_4=''&param_5=''",
                                                                               null, true);
                                                }else {

                                                       oModel = new sap.ui.model.json.JSONModel();
                                                       // success
                                                       oModel
                                                                    .attachRequestCompleted(
                                                                                  this,
                                                                                  function(oEvent) {
                                                                                         oModel.detachRequestCompleted();
                                                                                         if (oModel.getData().d.results[0].msg_type != "E") {
                                                                                                if (oModel.getData().d.results[0].Url != "") {
                                                                                                       window
                                                                                                                     .open(oModel
                                                                                                                                  .getData().d.results[0].Url);
                                                                                                }
                                                                                         } else {
                                                                                                sap.m.MessageBox
                                                                                                              .alert(oModel
                                                                                                                           .getData().d.results[0].msg_text);
                                                                                         }
                                                                                         
                                                                                         this.customBusyDialogClose();

                                                                                   }, this);
                                                       
                                                       if (oControllerS6.documentId.IsObject) {

                                      oModel.loadData(serviceUrl
                                        + "/FILE_DOC_FI?param_1='OB'&param_2='"
                                        + oControllerS6.documentId.BorID
                                        + "'&param_3='"
                                        + oControllerS6.documentId.ElementType
                                        + "'&param_4='"
                                        + oControllerS6.documentId.BorType
                                        + "'&param_5=''", null, true);
                                      oControllerS6.customBusyDialogClose();
                                     } else if (oControllerS6.documentId.IsReport) {

                                      oModel.loadData(
                                          serviceUrl
                                            + "/FILE_DOC_FI?param_1='OR'&param_2='"
                                            + oControllerS6.documentId.Variant
                                            + "'&param_3='"
                                            + oControllerS6.documentId.ElementType
                                            + "'&param_4=''&param_5=''",
                                          null, true);
                                      oControllerS6.customBusyDialogClose();
                                     }
                                                }
                           },
                           
                           addHyperlinkClick : function(oEvent) {

                               var flag='N';
                               if(oEvent.getSource().getTarget()=="_self"){
                                      flag='N';
                               }else{
                                      flag='D';
                               }
                                
                                 oControllerS6.customBusyDialogOpen();
                                 oControllerS6.documentId = oEvent.getSource()
                                                .getParent().getParent().getParent()
                                                .getParent().getBindingContext("createdaak");
                                 oControllerS6.documentId.getModel().oData.attachments.flag=flag; //to check whether noting or description
                                  oModel = new sap.ui.model.json.JSONModel();
                                  
                                  
                                  if(oControllerS6.documentId.getObject().IsAttachment){
                                  // if(oControllerS3.documentId<gResponse.length){
                                  oModel.loadData(serviceUrl
                                                + "/FILE_DOC_FI?param_1='AV'&param_2='"
                                                + oControllerS6.caseguid
                                                + "'&param_3='"
                                                + oControllerS6.fileid
                                                + "'&param_4='"
                                                + encodeURIComponent(oControllerS6.documentId
                                                              .getProperty("DocumentName"))
                                                + "'&param_5=''", null, false);
                                  if(oModel.getData().d.results[0].msg_type=='E'){
                                   sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                                oControllerS6.customBusyDialogClose();
                                   return;
                                  }
                                  if (oModel.oData.d.results.length > 1) {
                                      if(!oControllerS6.oVersion){
                                       oControllerS6.oVersion = sap.ui.xmlfragment(
                                                                        "flm.fiori.view.attachmentVersion",
                                                                        oControllerS6);
//                                                               oModel.oData.d.results.flag=flag; //to check whether to add in noting or description
                                                          }
                                      oControllerS6.oVersion.open();
                                          sap.ui.getCore().byId("idButtonAddLink")
                                                        .setVisible(true);
                                          sap.ui.getCore().byId("idCli").setType("Inactive");
                                          var oTable = sap.ui.getCore().byId(
                                                        "idVersionsTable");
                                          oTable.setModel(oModel, "versionModelDetail");
                                   } else {
                                    oControllerS6.attachHyperlink(oEvent);
                                   } 
                                  }else{
                                   oControllerS6.attachHyperlink(oEvent);
                                  }
//                                  oControllerS3.customBusyDialogClose();
                           },
                              
                           attachHyperlink : function(oEvent) {
                               
                               var flag='N';
                               oControllerS6.customBusyDialogOpen();
                               var hyperText = null;
                               oModel = new sap.ui.model.json.JSONModel();
                               var v = 1;
                                               oModel = new sap.ui.model.json.JSONModel();
                                               var temp = true;
                                               
                                               try {
                                                      var temp2 = oEvent.getSource().getParent()
                                                                   .getCells();
                                               } catch (err) {
                                                      temp = false;
                                               }
                               
                            // success
                                               oModel.attachRequestCompleted(this, function(oEvent) {
                                                   
                                                   if(oModel.getData().d.results[0].msg_type=='E'){
                                                    sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                                                    oControllerS6.customBusyDialogClose();
                                                    return;
                                                   }
                                                   hyperText =  oControllerS6.documentId.getProperty("DocumentName");
                                                   if( oControllerS6.documentId.getModel().oData.attachments.flag=='N'){
                                                          var e =  this.getView().byId("daakNotingEditor");
                                                   }else {
                                                          var e =  this.getView().byId("descrEditor");
                                                          this.saveFlag=true;
                                                   }
                                                   
                                                   var link=oModel.oData.d.results[0].Url;
                                                   link=link.split('?');
                                                   if(link[0].indexOf("ContentServer.dll")!=-1){
                                                    if(link[1]){
                                                           link[1]=link[1].replace(/\(/g,"%28");
                                                           link[1]=link[1].replace(/\)/g,"%29");
                                                           link=link[0]+"?"+link[1];
                                                           }
                                                           else{
                                                            link=link[0];
                                                           }
                                                   }
                                                   else if(link[0].indexOf("sap/bc/gui/sap/its")!=-1){
                                                    if(link[1]){
                                                           link[1]=link[1].replace(/\=/g,"%3D");
                                                           link[1]=link[1].replace(/\=/g,"%3D");
                                                           link=link[0]+"?"+link[1];
                                                           }
                                                           else{
                                                            link=link[0];
                                                           } 
                                                   }
                                                   e.setValue(e.getValue() +" "+ "<p><a href='"
                                                                + link
                                                                + "' target='_blank'>" + hyperText + "</a></p>");
                                                   sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_85"));
                                                   oModel.detachRequestCompleted();
                                                   oControllerS6.customBusyDialogClose();

                                            }, this);

                                               oControllerS6.customBusyDialogOpen();
                                        if (temp) {
                                               v = oEvent.getSource().getParent().getCells()[0]
                                                             .getText();
                                               oModel.loadData(serviceUrl
                                                             + "/FILE_DOC_FI?param_1='AU'&param_2='" + v
                                                             + "'&param_3='"
                                                             +  oControllerS6.documentId.getProperty("AttachmentLoioID")
                                                             + "'&param_4='"
                                                             +  oControllerS6.documentId.getProperty("DocumentClass")
                                                             + "'&param_5=''", null, true);
                                               
                                        } else {
                                               if (oEvent.getSource().getBindingContext("createdaak")
                                                             .getObject().IsAttachment) {
                                                      oModel
                                                                   .loadData(
                                                                                 serviceUrl
                                                                                               + "/FILE_DOC_FI?param_1='AU'&param_2='"
                                                                                               + v
                                                                                               + "'&param_3='"
                                                                                               +  oControllerS6.documentId.getProperty("AttachmentLoioID")
                                                                                               + "'&param_4='"
                                                                                               +  oControllerS6.documentId.getProperty("DocumentClass")
                                                                                               + "'&param_5=''", null,
                                                                                 true);
                                                      
                                               } else if ( this.documentId.getObject().IsObject) {

                                                      oModel.loadData(serviceUrl
                                                                   + "/FILE_DOC_FI?param_1='OB'&param_2='"
                                                                   +  oControllerS6.documentId.getProperty("BorID")
                                                                   + "'&param_3='"
                                                                   +  oControllerS6.documentId.getProperty("ElementType")
                                                                   + "'&param_4='"
                                                                   +  oControllerS6.documentId.getProperty("BorType")
                                                                   + "'&param_5=''", null, true);
                                                      
                                               } else if ( this.documentId.getObject().IsReport) {

                                                      oModel
                                                                   .loadData(
                                                                                 serviceUrl
                                                                                               + "/FILE_DOC_FI?param_1='OR'&param_2='"
                                                                                               +  oControllerS6.documentId.getProperty("Variant")
                                                                                               + "'&param_3='"
                                                                                               +  oControllerS6.documentId.getProperty("ElementType")
                                                                                               + "'&param_4=''&param_5=''",
                                                                                 null, true);
                                                      
                                               }else if ( this.documentId.getObject().IsIpi) {

                                                   oModel
                                                                .loadData(
                                                                  serviceUrl
                              + "/FILE_DOC_FI?param_1='DU'&param_2='"
                              + encodeURIComponent(oControllerS6.documentId.getProperty("DocumentName"))
                              + "'&param_3=''&param_4=''&param_5=''",
                            null, true);
                                                   
                                            }
                                        }
                               
                        },
                        
                        /* Attach New Version */
                        attachNewVersion : function(oEvent) {
                            
                            if(!oControllerS6.versionDialog){
                            oControllerS6.versionDialog = sap.ui.xmlfragment(
                                          "flm.fiori.view.newVersion", oControllerS6);
                            }
                            sap.ui.getCore().byId("idFileUploaderNV").setValue("");
          sap.ui.getCore().byId("idKey1NV").setValue("");
          sap.ui.getCore().byId("idKey2NV").setValue("");
          sap.ui.getCore().byId("idKey3NV").setValue("");
          sap.ui.getCore().byId("idKey4NV").setValue("");
          sap.ui.getCore().byId("idKey5NV").setValue("");
                            oControllerS6.documentId = oEvent.getSource()
                                          .getParent().getParent().getParent()
                                          .getParent().getBindingContext("createdaak");

                            oModel = new sap.ui.model.json.JSONModel();
                            oModel.attachRequestCompleted(this, function(oEvent) {
           oModel.detachRequestCompleted();
           if(oModel.getData().d.results[0].msg_type=='E'){
                                sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                                oControllerS6.customBusyDialogClose();
                                return;
                               }
           var keys = oModel.oData.d.results[0];
           sap.ui.getCore().byId("idKey1NV").setValue(
             keys.Keyword1);
           sap.ui.getCore().byId("idKey2NV").setValue(
             keys.Keyword2);
           sap.ui.getCore().byId("idKey3NV").setValue(
             keys.Keyword3);
           sap.ui.getCore().byId("idKey4NV").setValue(
             keys.Keyword4);
           sap.ui.getCore().byId("idKey5NV").setValue(
             keys.Keyword5);
           oControllerS6.customBusyDialogClose();
           oControllerS6.versionDialog.open();

          }, oControllerS6);

          // if(oControllerS2.documentId<gResponse.length){
          oControllerS6.customBusyDialogOpen();
           oModel.loadData(serviceUrl
                                  + "/FILE_DOC_FI?param_1='NV'&param_2='"
                                  + oControllerS6.caseguid
                                  + "'&param_3='"
                                 + encodeURIComponent(oControllerS6.documentId
                                                .getProperty("DocumentName"))
                                  + "'&param_4=''&param_5=''", null, true);


                     },
                     
                     onNVOkButton : function(oEvent) {
                         oControllerS6.customBusyDialogOpen();
                                            oControllerS6.versionDialog.close();
                              var i = 0;
                              var doc_num, doc_type, doc_class, doc_guid;
                              doc_num = oControllerS6.documentId
                                            .getProperty("DocumentName");
                              doc_type = oControllerS6.documentId
                                            .getProperty("DocumentType");
                              doc_class = oControllerS6.documentId
                                            .getProperty("DocumentClass");
                              doc_guid = oControllerS6.documentId
                                            .getProperty("AttachmentLoioID");
                              var oFUploader = sap.ui.getCore().byId(
                                            "idFileUploaderNV");
                              if (oFUploader.getValue() == "") {
                                                   sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_36"));
                                                   return;
                                                   } 
//                              oFUploader.setUploadUrl("proxy/https/ldcixka.wdf.sap.corp:44318/sap/bc/doc_upload");
                             oFUploader.setUploadUrl("/sap/bc/doc_upload");
                              var par_id = ""; // PARENTKEY
                              var wf_id = oControllerS6.wiId; // WIID
                              var key_1 = sap.ui.getCore().byId("idKey1NV")
                                            .getValue();
                              var key_2 = sap.ui.getCore().byId("idKey2NV")
                                            .getValue();
                              var key_3 = sap.ui.getCore().byId("idKey3NV")
                                            .getValue();
                              var key_4 = sap.ui.getCore().byId("idKey4NV")
                                            .getValue();
                              var key_5 = sap.ui.getCore().byId("idKey5NV")
                                            .getValue();
                              var sInfo = '[{"CASE_GUID":"' + oControllerS6.caseguid
                                            + '","PAR_ID":"' + par_id + '","WF_ID":"'
                                            + wf_id + '","DOC_CLASS":"' + doc_class
                                           + '","DOC_GUID":"' + doc_guid + '","DOC_NUM":"'
                                            + doc_num + '","DOC_TYPE":"' + doc_type
                                            + '","KEY_1":"' + key_1 + '","KEY_2":"' + key_2
                                            + '","KEY_3":"' + key_3 + '","KEY_4":"' + key_4
                                            + '","KEY_5":"' + key_5 + '","ISDAAK":"X"}]';

                              oFUploader.setAdditionalData(sInfo);
                              oFUploader.attachUploadComplete(oControllerS6,
                                                          function(oEvent) {
                                                                 oControllerS6.customBusyDialogClose();
                                                          }, oControllerS6);
                              oFUploader.upload();
                       },
                       
                       
                       /*Download attachment*/
                       downloadAttachment : function(oEvent) {

                           oControllerS6.customBusyDialogOpen();
                           var version = 1;
         oModel = new sap.ui.model.json.JSONModel();
         version = oEvent.getSource().getCells()[0].getText();
          oModel.loadData(serviceUrl
            + "/FILE_DOC_FI?param_1='AU'&param_2='" + version
            + "'&param_3='"
            + oControllerS6.documentId.AttachmentLoioID
            + "'&param_4='"
            + oControllerS6.documentId.DocumentClass
            + "'&param_5=''", null, false);
          if(oModel.getData().d.results[0].msg_type=='E'){
           sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
           oControllerS6.customBusyDialogClose();
           return;
           }

         var url = oModel.oData.d.results[0].Url;

         window.open(url);// window.open(url);
         oControllerS6.customBusyDialogClose();
                  
                    },
                       
                     confirmDelete : function(evt) {

         var oItem = evt.getSource();
         if (oItem.getBindingContext("createdaak").getObject().DeleteEnabledRef
           && oItem.getBindingContext("createdaak")
             .getObject().NotingEnabledRef) {
          sap.m.MessageBox
            .confirm(
              oControllerS6.getView().getModel("i18n").getObject("MESSAGE_32"),
              function(response) {
               if (response == "OK") {
                oControllerS6
                  .deleteAttachment(
                    evt, oItem);
               } else {
                return;
               }
              });
         } else {

          sap.m.MessageBox.confirm(
            oControllerS6.getView().getModel("i18n").getObject("MESSAGE_33"),
            function(response) {
             if (response == "OK") {
              oControllerS6.deleteAttachment(evt,
                oItem);
             } else {
              return;
             }
            });
          // oControllerS3.deleteAttachment(evt,oItem);
         }
        },

         uploadActionsOpen : function(oEvent) {
          if (oControllerS6.caseguid == "") {
                             sap.m.MessageToast.show(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_79"));
                      } else {
                             var oButton = oEvent.getSource();
                             //oControllerS6.uploadNode = this.getParent();
                             if (!oControllerS6._uploadActionSheet || oControllerS6._uploadActionSheet.getButtons().length == 0){
                                    oControllerS6._uploadActionSheet = sap.ui
                                                  .xmlfragment(
                                                               "flm.fiori.view.uploadButton",
                                                               oControllerS6);
                                    oControllerS6.getView().addDependent(
                                                  oControllerS6._uploadActionSheet);
                                    if (oControllerS6.data.buttons.ISATTACHMENT == false) {
                                           sap.ui.getCore().byId("attachmentAction")
                                                        .setVisible(false);
                                    }
                                    if (oControllerS6.data.buttons.ISIPI == false) {
                                           sap.ui.getCore().byId("ipiAction")
                                                        .setVisible(false);
                                    }
                                    if (oControllerS6.data.buttons.ISFILE == false) {
                                           sap.ui.getCore().byId("fileAction")
                                                        .setVisible(false);
                                    }
                                    if (oControllerS6.data.buttons.ISOBJECT == false) {
                                           sap.ui.getCore().byId("objectAction")
                                                        .setVisible(false);
                                    }
                                    if (oControllerS6.data.buttons.ISREPORT == false) {
                                           sap.ui.getCore().byId("reportAction")
                                                        .setVisible(false);
                                    }
                             }
                             jQuery.sap.delayedCall(0, this, function() {
                                   oControllerS6._uploadActionSheet
                                                  .openBy(oButton);
                             });
                      }
              },
              
              /*Uploading the document*/
              attachmentButtonPressed : function(oEvent) {
                  oControllerS6.isAttachment = true;
                  oControllerS6.isFile = false;
                  oControllerS6.isReport = false;
                  oControllerS6.isObject = false;
                  oControllerS6.isIPI = false;
                  oControllerS6.isDaak = false;
                  //this.attachmentDialog = null;
                  if(!oControllerS6.attachmentDialog){
                  oControllerS6.attachmentDialog = sap.ui.xmlfragment(
                                "flm.fiori.view.attachment", oControllerS6);
                  }
                 sap.ui.getCore().byId("idDocNumber").setValue("");
     sap.ui.getCore().byId("idFileUpload").setValue("");
     sap.ui.getCore().byId("idKey1").setValue("");
     sap.ui.getCore().byId("idKey2").setValue("");
     sap.ui.getCore().byId("idKey3").setValue("");
     sap.ui.getCore().byId("idKey4").setValue("");
     sap.ui.getCore().byId("idKey5").setValue("");
                  var docType = sap.ui.getCore().byId("idDocumentType");
                  var ddModel = new sap.ui.model.json.JSONModel();
                  ddModel
                                .loadData(serviceUrl
                                              + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                  + this.caseguid
                                                                  + "' and OtherF4 eq true and ID eq 'DT'");
                  docType.setModel(ddModel);

                  oControllerS6.attachmentDialog.open();
           },
           
           onOkButton : function(oEvent) {
               
               var oAttachmentList=oControllerS6.getView().getModel("createdaak").oData.attachments;
               
               var i = 0, doc_num, flag = false;
               if (oControllerS6.isFile) {
                      doc_num = sap.ui.getCore().byId("idFileNumber");
               } else if (oControllerS6.isAttachment) {
                      doc_num = sap.ui.getCore().byId("idDocNumber");
               }else if (oControllerS6.isDaak) {
                      doc_num = sap.ui.getCore().byId("idDaakNumber");
               }
               
               for (i = 0; i < oAttachmentList.length; i++) {
                      if (doc_num.getValue() == oAttachmentList[i].DocumentName) {
                             sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_35"));
                             flag = true;
                             break;
                      }
                      // }
               }

               if (oControllerS6.isAttachment && !flag) {
                      var doc_num = sap.ui.getCore().byId("idDocNumber")
                                    .getValue();
                      var doc_type = sap.ui.getCore().byId(
                                    "idDocumentType").getSelectedItem()
                                    .getKey();
                      var oFUploader = sap.ui.getCore().byId(
                                    "idFileUpload");
//                      oFUploader.setUploadUrl("proxy/https/ldcixka.wdf.sap.corp:44318/sap/bc/doc_upload");
                      oFUploader.setUploadUrl("/sap/bc/doc_upload");
                      if (doc_num.match(/\s/g)){
        sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_72"));
        return;
       }
                     if (oFUploader.getValue() == "" || doc_num == ""
                                    || doc_type == "") {
                             sap.m.MessageToast
                                           .show(this.getView().getModel("i18n").getObject("MESSAGE_36"));
                      }else if (doc_num.length > 60) {
       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_37"));
     return;
                      }else {
                             var wf_id = oControllerS6.wiId; // WIID
                             var key_1 = sap.ui.getCore().byId("idKey1")
                                           .getValue();
                             var key_2 = sap.ui.getCore().byId("idKey2")
                                           .getValue();
                             var key_3 = sap.ui.getCore().byId("idKey3")
                                           .getValue();
                             var key_4 = sap.ui.getCore().byId("idKey4")
                                           .getValue();
                             var key_5 = sap.ui.getCore().byId("idKey5")
                                           .getValue();
                             var sInfo = '[{"CASE_GUID":"'
                                           + oControllerS6.caseguid
                                           + '","PAR_ID":"","WF_ID":"' + wf_id
                                           + '","DOC_NUM":"' + doc_num
                                           + '","DOC_TYPE":"' + doc_type
                                           + '","KEY_1":"' + key_1 + '","KEY_2":"'
                                           + key_2 + '","KEY_3":"' + key_3
                                           + '","KEY_4":"' + key_4 + '","KEY_5":"'
                                           + key_5 + '",,"ISDAAK":"X"}]';

                             oFUploader.setAdditionalData(sInfo);
                             oControllerS6.customBusyDialogOpen();
        oFUploader.attachUploadComplete(oControllerS6,
          function(oEvent) {
           oControllerS6
             .customBusyDialogClose();
          }, oControllerS6);
                             oFUploader.upload();
                      }
               } else if (oControllerS6.isDaak && !flag) {
                   var today = new Date();
                   var file_name = sap.ui.getCore().byId(
                                 "idDaakNumber").getValue();
                   if (file_name == "") {
                    sap.m.MessageBox
       .alert(this.getView().getModel("i18n").getObject("MESSAGE_36"));
                    return;
                   }if (this.getView().byId("idInputDaakNumber2").getValue() == file_name) {
       sap.m.MessageBox
       .alert(this.getView().getModel("i18n").getObject("MESSAGE_44"));
     return;
    } else {
                          
                          oModel = new sap.ui.model.json.JSONModel();
                          oModel.attachRequestCompleted(
          oEvent,
          function(oEvt) {
           oModel
             .detachRequestCompleted();
                          var fileUploadResponse = oModel.oData.d.results[0];
                          if (fileUploadResponse.msg_type != "E") {
                                 var doc_num = file_name;

                                 var vData = {
                                                   "CaseGuid" : fileUploadResponse.CaseGuid,
                                                                   "Wiid" : oControllerS6.wiId,
                                                                   "FileID" : fileUploadResponse.FileID,
                                                                   "DocumentName" : decodeURIComponent(doc_num),
                                                                   "DocumentType" : "FIL",
                                                                   "FileName" : "Daak",
                                                                   "CreatedByName" : fileUploadResponse.CreatedByName,
                                                                   "CreatedOn" : fileUploadResponse.CreatedOn/*today
                                                                                 .toLocaleDateString().replace(
                                                                                               "/", ".").replace("/",
                                                                                               ".")
                                                                                 + " "
                                                                                 + today.toTimeString().substr(
                                                                                               0, 8)*/,
                                                                   "FileTitle" : fileUploadResponse.FileTitle,//decodeURIComponent(fileUploadResponse.FileTitle),
                                                                   "FileSizeDescr" : fileUploadResponse.FileSize,
                                                                   "DocumentClass" : fileUploadResponse.DocClass,
                                                                   "AttachmentLoioID" : fileUploadResponse.DocGuid,
                                                                   "ParentKey" : ""/*oControllerS3.uploadNode
                                                                                 .getBindingContext("global")
                                                                                 .getProperty("RowKey")*/,
                                                                   "IsAttachment" : oControllerS6.isAttachment,
                                                                   "IsFile" : oControllerS6.isFile,
                                                                   "IsObject" : oControllerS6.isObject,
                                                                   "IsIpi" : oControllerS6.isIpi,
                                                                   "IsReport" : oControllerS6.isReport,
                                                                   "IsDaak" : oControllerS6.isDaak,
                                                                   "DeleteEnabledRef" : true,
                                                                   "NotingEnabledRef" : false,
                                 };

                                 oControllerS6.getView().getModel("createdaak").oData.attachments.push(vData);
                                 oControllerS6
          .getView()
          .getModel(
            "createdaak")
          .checkUpdate();
                                 sap.m.MessageToast
                                              .show(this.getView().getModel("i18n").getObject("MESSAGE_38"));
                                 sap.ui.getCore().byId("idDaakDialog").close();
                                 } else {
                                 sap.m.MessageBox
                                              .alert(fileUploadResponse.msg_text);
                          }
                          oControllerS6
        .customBusyDialogClose();
                          
                   }, oControllerS6);
                          oControllerS6.customBusyDialogOpen();
        oModel.loadData(serviceUrl
          + "/FILE_DOC_FI?param_1='AD'&param_2='"
          + oControllerS6.caseguid
          + "'&param_3='"
          + encodeURIComponent(file_name)
          + "'&param_4='"+oControllerS6.wiId+"'&param_5=''",
          null, true);
   }
            }
        },
        
        onUploadComplete : function(oEvent) {
            
            var today = new Date();
            var sResponse = oEvent.getParameter("response");
            var resToken = sResponse.split(',');
            var fileAttr = new Array();
            var nameVal, statusMsg = "", statusIcon = null;
            for ( var i = 0; i < resToken.length; ++i) {
                   nameVal = resToken[i].split('::');
                   fileAttr[nameVal[0]] = nameVal[1];
            }
            if (fileAttr["Status"] == "Successful") {
                   var doc_num = sap.ui.getCore().byId("idDocNumber")
                                 .getValue();
                   var doc_type = sap.ui.getCore().byId(
                                 "idDocumentType").getSelectedItem();
                   var vData = {
                          "DocumentName" : doc_num,
                          "DocumentType" : doc_type.getKey(),
                          "FileName" : doc_type.getText(),
                          "CreatedByName" : fileAttr["UploadedBy"],
                          "CreatedOn" : fileAttr["CreatedOn"]/*today.toLocaleDateString()
                                        .replace("/", ".").replace("/", ".")
                                        + " "
                                        + today.toTimeString().substr(0, 8)*/,
                          "FileTitle" : fileAttr["AttachmentName"],
                          "FileSizeDescr" : fileAttr["FileSize"],
                          "DocumentClass" : fileAttr["DocClass"],
                          "AttachmentLoioID" : fileAttr["DocGuid"],
                         "ParentKey" : ""/*oControllerS3.uploadNode
                                        .getBindingContext("global").getProperty(
                                                     "RowKey")*/,
                          "IsAttachment" : oControllerS6.isAttachment,
                          "IsFile" : oControllerS6.isFile,
                          "IsObject" : oControllerS6.isObject,
                          "IsIpi" : oControllerS6.isIpi,
                          "IsDaak" : oControllerS6.isDaak,
                          "IsReport" : oControllerS6.isReport,
                          "DeleteEnabledRef" : true,
                          "NotingEnabledRef" : true,
                   };
                   oControllerS6.getView().getModel("createdaak").oData.attachments.push(vData);
//                   oControllerS3.getView().getModel("global").oData.push(vData);
                   oControllerS6.getView().getModel("createdaak").refresh();
                   sap.m.MessageToast
                                 .show(this.getView().getModel("i18n").getObject("MESSAGE_38"));
                   sap.ui.getCore().byId("idAttachmentDialog").close();

            } else {
                   sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_39"));
            }
            oControllerS6.customBusyDialogClose();
     },
     
           fileButtonPressed : function(oEvent) {
                  oControllerS6.isAttachment = false;
                  oControllerS6.isFile = true;
                  oControllerS6.isReport = false;
                  oControllerS6.isObject = false;
                  oControllerS6.isIPI = false;
                  oControllerS6.isDaak = false;
                 // this.fileDialog = null;
                  if(! oControllerS6.fileDialog){
                   oControllerS6.fileDialog = sap.ui.xmlfragment(
                                "flm.fiori.view.file",  oControllerS6);
                  }
                  sap.ui.getCore().byId("idFileNumber").setValue("");
                  oControllerS6.fileDialog.open();
           },

           attachNewVersion : function(oEvent) {
                 
                  if(! oControllerS6.versionDialog){
                  oControllerS6.versionDialog = sap.ui.xmlfragment(
                                "flm.fiori.view.newVersion", oControllerS6);
                  }
                  sap.ui.getCore().byId("idFileUploaderNV").setValue("");
     sap.ui.getCore().byId("idKey1NV").setValue("");
     sap.ui.getCore().byId("idKey2NV").setValue("");
     sap.ui.getCore().byId("idKey3NV").setValue("");
     sap.ui.getCore().byId("idKey4NV").setValue("");
     sap.ui.getCore().byId("idKey5NV").setValue("");
                  oControllerS6.documentId = oEvent.getSource()
                                .getParent().getParent().getParent()
                                .getParent().getBindingContext("createdaak");

                  oModel = new sap.ui.model.json.JSONModel();
                  oModel.attachRequestCompleted(this, function(oEvent) {
      oModel.detachRequestCompleted();
      if(oModel.getData().d.results[0].msg_type=='E'){
                      sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                      oControllerS6.customBusyDialogClose();
                      return;
                     }
      var keys = oModel.oData.d.results[0];
      sap.ui.getCore().byId("idKey1NV").setValue(
        keys.Keyword1);
      sap.ui.getCore().byId("idKey2NV").setValue(
        keys.Keyword2);
      sap.ui.getCore().byId("idKey3NV").setValue(
        keys.Keyword3);
      sap.ui.getCore().byId("idKey4NV").setValue(
        keys.Keyword4);
      sap.ui.getCore().byId("idKey5NV").setValue(
        keys.Keyword5);
      oControllerS6.customBusyDialogClose();
      oControllerS6.versionDialog.open();

     }, oControllerS6);

     // if(oControllerS2.documentId<gResponse.length){
     oControllerS6.customBusyDialogOpen();
      oModel.loadData(serviceUrl
                        + "/FILE_DOC_FI?param_1='NV'&param_2='"
                        + oControllerS6.caseguid
                        + "'&param_3='"
                       + encodeURIComponent(oControllerS6.documentId
                                      .getProperty("DocumentName"))
                        + "'&param_4=''&param_5=''", null, true);

            },
              
              /*Save initial daak attributes*/
              saveButtonEventDaak : function(oEvent){
               oControllerS6.saveDaakActionPressed();
              },
              
              saveDaakActionPressed : function(val) {
                  
                  /*
                  * Pushing input controls into an array for validation
                  * starts
                  */
            if(val == undefined){
             val = '';
            }
               var daakNumberString="";
               var validationControls = new Array();
               var hboxContent = this.getView().byId(
                             "idDaakNumberHbox");
               for ( var i = 0; i < hboxContent.getItems().length; i += 2) {
                      validationControls.push(hboxContent.getItems()[i]
                                    .getItems()[2]);
                      if(hboxContent.getItems()[i]
                      .getItems()[2].getType()=="Default"){
                       daakNumberString+=hboxContent.getItems()[i]
                      .getItems()[2].getSelectedItem().getText();
                      }else{
                       daakNumberString+=hboxContent.getItems()[i]
                          .getItems()[2].getValue()+"/";
                      }
               }
               //check for file number length
               if(daakNumberString.length>100){
                   sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_17"));
                   return;
               }
               
//               validationControls.push(this.getView().byId("idResponddate"));
               validationControls.push(this.getView().byId("idDaakShortText"));
            /*   var dynamicAttrForm = oControllerS6.getView().byId(
                             "dynamicAttrForm");*/
               for ( var i = 0; i < mparams.length; i++) {
                      if (mparams[i].MANDATORY == true) {
                             validationControls.push(sap.ui.getCore().byId(
                                           mparams[i].ID));
                      }
                      if(mparams[i].CURR_ID!=""){
                       if(sap.ui.getCore().byId(mparams[i].ID).getValue()!="" && sap.ui.getCore().byId(mparams[i].ID).getValue()!="0.000"){ 
                        
                       validationControls.push(sap.ui.getCore().byId(
                                  mparams[i].CURR_ID));
                       }
                      }
               }
               var f = validateInput(oControllerS6, validationControls);
               if (f) {
                      f.focus(true);
                      return;// Break
               } else {
                      // Continue
               }
               
               oControllerS6.customBusyDialogOpen();
                  //Check if file is new or update
                  if(oControllerS6.caseguid!=""){
                  oControllerS6.updateFile();
                  
                  }
                  else{
                  
                  /*
                  * Pushing input controls into an array for validation
                  * ends
                  */
                  
                  // Saving Data starts
                  var oModel = new sap.ui.model.odata.ODataModel(
                                serviceUrl);
                  oModel.setUseBatch(true);
                  
               // read file number
                  
                  for ( var i = 0; i < oControllerS6.createFileResponse.length - 1; i++) {
                         var tempObj = {};
                         tempObj.NAME = oControllerS6.createFileResponse[i].NAME;
                         if (oControllerS6.createFileResponse[i].DDVALUES != "") {
                                tempObj.VALUE = sap.ui.getCore().byId(
                                              "FID00" + i).getSelectedItem().getKey();
                         } else if (tempObj.NAME == "SEPR") {
                                tempObj.VALUE = sap.ui.getCore().byId(
                                              "FID00" + i).getText();
                         } else {
                                tempObj.VALUE = sap.ui.getCore().byId(
                                              "FID00" + i).getValue();
                         }
                         // obj.push(tempObj);
                         // create batch operation
                         var batchOp = oModel.createBatchOperation(
                                       "/FILE_NUMBER_ES", 'POST', tempObj);

                         // add batch operation
                         oModel.addBatchChangeOperations([ batchOp ]);

                  }

                  // read basic attr
                  var obj = {};
                  obj.PlanEndDate = oControllerS6.getView().byId("idResponddate").getValue();
                  obj.CaseTitle = oControllerS6.getView().byId("idDaakShortText").getValue();
                  obj.ShortText = sap.ui.getCore().getModel("passdaak").getData()[1];
//                  obj.ISDAAK = true;
                  // create batch operation
                  var batchOp = oModel.createBatchOperation(
                                "/FILE_BASIC_ES", 'POST', obj);

                  // add batch operation
                  oModel.addBatchChangeOperations([ batchOp ]);
//                  this.dynUIAssistArr=this.getView().getModel("global").oData.dynamic;
                  // read dynamic attributes
                  for ( var i = 0; i < this.dynUIAssistArr.length; ++i) {
                         var value = "";
                         switch (this.dynUIAssistArr[i].type) {
                         case "IP":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getValue();
                                break;
                         case "F4":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getValue();
                                break;
                         case "DP":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getDateValue();
                                if(value != null){
                                 value = dateFormatter(value);
                                }else{
                                 value = "";
                                }
                                break;
                         case "TP":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getValue();
                                break;
                         case "CB":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getState();
                                if(value){
                                   value='X';
                                }else{
                                   value="";
                                }
                                break;
                         case "CU":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getValue();
                                break;
                         }

                         // create batch operation
                         var batchOp = oModel.createBatchOperation(
                                       "/FILE_ATTR_ES", 'POST', {
                                              "ID" : this.dynUIAssistArr[i].id,
                                              "TYPE" : this.dynUIAssistArr[i].type,
                                              "VALUE" : value,
                                              "GUID" : oControllerS6.caseguid
                                       });

                         // add batch operation
                         oModel.addBatchChangeOperations([ batchOp ]);

                  }
                 

                  // create batch operation
                  var batchOp = oModel.createBatchOperation(
                                "/FILE_ATTR_ES", 'POST', {
                                       "ID" : 'EOT',
                                       "FILETYPE" : oControllerS6.daaktype,// end of transfer
                                       "GUID" : oControllerS6.caseguid,
                                       "VALUE" : val,
                                       "ISDAAK" : true
                                });

                  // add batch operation
                  oModel.addBatchChangeOperations([ batchOp ]);

                  
                  // finally submit batch for both basic and dynamic
                  // attributes
                  oModel.submitBatch(
                                              function(oResponse, oData) {
                                              
                                               if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {
                                                var resObj = oResponse.__batchResponses[oResponse.__batchResponses.length - 1].__changeResponses[0];
                                                           oControllerS6.filenumber = resObj.data.FILENUMBER;
                                                           oControllerS6.fileid = resObj.data.FILEID;
                                                           oControllerS6.caseguid = resObj.data.GUID;
                                                           oControllerS6.digitalsign = resObj.DIGSIGNREQ;
                                                           // Fetching response for save
                                                           oControllerS6.getView().byId("idDaakNumberHboxMain").setVisible(false);
                                                           oControllerS6.getView().byId("idLabelDaakNumber").setVisible(true);
                                                           oControllerS6.getView().byId("idInputDaakNumber2").setVisible(true);
                                                           oControllerS6.getView().byId("idInputDaakNumber2").setValue(oControllerS6.filenumber);
                                                           oControllerS6.getView().byId("idTrackDaakLabel").setVisible(true);
                                                           oControllerS6.getView().byId("idTrackDaakSwitch").setVisible(true);
                                                           oControllerS6.getView().byId("idConfidentialDaakLabel").setVisible(true);
                                                           oControllerS6.getView().byId("idConfidentialDaakSwitch").setVisible(true);
                                                           oControllerS6.getView().byId("idDaakButtonSend").setEnabled(true);
                                                           oControllerS6.getView().byId("idDaakButtonClose").setEnabled(true);
                                                        // Validations
                                              /*Notings set to editable*/            
                                                           oControllerS6.getView().byId("daakEmptyNotingPanel").setVisible(false);
                                                           oControllerS6.getView().byId("daakNotingPanel").setVisible(true);
                                                           oControllerS6.getView().byId("idDaakAddNewWorkflowButton").setEnabled(true);
//                                                           oControllerS3.getView().byId("printAction").setVisible(true);
                                                           oControllerS6.fromTab="DRAFTDAAK";
                                                          // oControllerS3.getView().byId("idChangeWorkflowButton").setEnabled(true);
                                                           //oControllerS3.getView().byId("shareDraftAction").setEnabled(true);
                                                           oControllerS6.saveFlag=false;
                                                           oControllerS6.customBusyDialogClose();
                                                           sap.m.MessageToast
                                                           .show(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_81"));
                                                            
                                                    } else if(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf("<severity>warning</severity>") != -1 || oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf('"severity":"warning"') != -1){

                                                     sap.m.MessageBox.confirm(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                         oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers),
                                                      function(response) {
                            if (response == "OK") {
                             oControllerS6.customBusyDialogOpen();
                             //valueEOT = 'X';
                             oControllerS6.saveButtonPressed('X');
                            }
                            else{
                             oControllerS6.customBusyDialogClose();
                            }
                                                          });
                                                      }else {
                                                       
//                                                           sap.m.MessageToast
//                                                                         .show(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message);
                                                     sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                       oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers));
                                                           oControllerS6.customBusyDialogClose();
                                                           return;
                                                    }
                                              }, function(oResponse) {
                                               
                                               oControllerS6.customBusyDialogClose();
                                                    
                                              });

                  // Saving Data ends

                  }
                  
           },
           
           /*Update the file once it is created or saved*/
           
           updateFile : function(eotValue){
               // var eotValue = '';
             if(eotValue == undefined){
              eotValue = '';
             }
                var oModel = new sap.ui.model.odata.ODataModel(
                        serviceUrl);
                oModel.setUseBatch(true);
                var result = oControllerS6.flatObj;
                // read basic attr
                  var obj = {};
                  obj.PlanEndDate = oControllerS6.getView().byId("idResponddate").getValue();
                  obj.CaseTitle = oControllerS6.getView().byId(
                                "idDaakShortText").getValue();
                  obj.CaseGuid = oControllerS6.caseguid;
                  obj.Wiid = oControllerS6.wiId;
                  // create batch operation
                  var batchOp = oModel.createBatchOperation(
                                                 "/FILE_BASIC_ES(ExtKey='',CaseGuid='" + oControllerS6.caseguid
                                                              + "',FileType='',TabType='"
                                                              + oControllerS6.fromTab + "',Wiid='',ISDAAK=true)", 'PUT',
                                                 obj);

                  // add batch operation
                  oModel.addBatchChangeOperations([ batchOp ]);
                  // read dynamic attributes
                  for ( var i = 0; i < this.dynUIAssistArr.length; ++i) {
                         var value = "";
                         switch (this.dynUIAssistArr[i].type) {
                         case "IP":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getValue();
                                break;
                         case "F4":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getValue();
                                break;
                         case "DP":
                             value = sap.ui.getCore().byId(
                                     this.dynUIAssistArr[i].id).getDateValue();
                                if(value != null){
                                 value = dateFormatter(value);
                                }else{
                                 value = "";
                                }
                                break;
                         case "TP":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getValue();
                                break;
                         case "CB":
                                var t = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getState();
                                if(t){
                                   value='X';
                                }else{
                                   value="";
                                }
                                break;
                         case "CU":
                                value = sap.ui.getCore().byId(
                                              this.dynUIAssistArr[i].id).getValue();
                                break;
                         }

                         // create batch operation
                         var batchOp = oModel.createBatchOperation(
                                       "/FILE_ATTR_ES(ID='"
                                                       + this.dynUIAssistArr[i].id
                                                       + "',TABTYPE='" + oControllerS6.fromTab
                                                       + "')", 'PUT', {
                                              "ID" : this.dynUIAssistArr[i].id,
                                              "TYPE" : this.dynUIAssistArr[i].type,
                                              "VALUE" : value,
                                              "GUID" : oControllerS6.caseguid
                                       });

                         // add batch operation
                         oModel.addBatchChangeOperations([ batchOp ]);

                  }
                  
               // create batch operation EOT
                  var batchOp = oModel.createBatchOperation(
                                "/FILE_ATTR_ES(ID='" + "-1" /* this.dynUIAssistArr[i].id */
                                                 + "',TABTYPE='" + oControllerS6.fromTab
                                                 + "')", 'PUT', {
                                       "ID" : 'EOT',
                                       "FILETYPE" : '',// end of transfer
                                       "GUID" : oControllerS6.caseguid,
                                       "VALUE" : eotValue,
                                       "ISDAAK" : true
                                });

                  // add batch operation
                  oModel.addBatchChangeOperations([ batchOp ]);
                 
                
                  // finally submit batch for both basic
     // and dynamic
                  // attributes
                  oModel
                                .submitBatch(
                                              function(oResponse, oData) {
                                              
                                               if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {
                                                 var resObj = oResponse.__batchResponses[oResponse.__batchResponses.length - 1].__changeResponses[0]; // Response
                                                           sap.m.MessageToast
                                                                         .show(oControllerS6.getView().getModel("i18n").getObject("DAAKSAVESUCCESS"));
                                                           oControllerS6.saveFlag=false;
                                                           oControllerS6.updateWorkflowFlag=false;
                                                    } else if(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf("<severity>warning</severity>") != -1 || oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf('"severity":"warning"') != -1){
                                                     sap.m.MessageBox.confirm(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                       oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers),
                                                    function(response) {
                          if (response == "OK") {
                           oControllerS6.customBusyDialogOpen();
                           //eotValue = 'X';
                           oControllerS6.updateFile('X');

                          }
                                                        });
                                                    }
                        else {
                                                           sap.m.MessageBox
                                                                         .alert(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                                        oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers));
//return;
                                                    }
                                                    oControllerS6.customBusyDialogClose();
                                              }, function(oResponse) {
                                               oControllerS6.customBusyDialogClose();
                                              });

                  // Saving Data ends

                  },
                  
                /*Workflow starts */
                  /*Workflow starts */
                  onAddNewWorkflow : function(oEvent) {
                   if(this.fromTab == "CREATEDAAK" || this.fromTab == "DRAFTDAAK"){
                      oControllerS6.updateWorkflowFlag=false;
                        oControllerS6.newWorkflowFlag=true;
                        if(oControllerS6.oCreateWorkflow==undefined){
                            oControllerS6.oCreateWorkflow = sap.ui.xmlfragment(
                                          "flm.fiori.view.createWorkflow", oControllerS6);
                                                                      
                            var oTable = sap.ui.getCore().byId("leftTree");
                            oTable.setRowHeight(50);
                            var oText = new sap.m.Text({
                             text : "{Text}"
                            });
                            
                            var oSpace1 = new sap.ui.core.HTML({
                                content : "<span>&nbsp;&nbsp;</span>"
                            });
                            
                            var oIcon = new sap.ui.core.Icon({
                             src : "{ImageSrc}",
                             color : "#009DE0",
                             press : oControllerS6.loadRemainingTree,
                            });
                            
                            var oSpace = new sap.ui.core.HTML({
                                content : "<span>&nbsp;&nbsp;</span>"
                            });
                            
                            var oIcon1 = new sap.ui.core.Icon({
                             src : "{Level}",
                             press : oControllerS6.loadRemainingTree,
                            });
                            this.oLayout = new sap.ui.layout.HorizontalLayout(
                                    {
                                           content : [oIcon1,oSpace,oIcon,oSpace1,oText ]
                                    });
                            
                            oTable.addColumn(new sap.ui.table.Column({
                                   label : oControllerS6.getView().getModel("i18n").getObject("HIERARCHY"),
                                   template : this.oLayout,
                                   name : "Otype" + "Objid",
                                   sortProperty : ""
                            }));
                            oTable.addColumn(new sap.ui.table.Column({
                                   label : oControllerS6.getView().getModel("i18n").getObject("OBJECT_NAME"),
                                   template : "Stext",
                                   sortProperty : ""
                            }));
                            var oModel = new sap.ui.model.json.JSONModel();
                            oModel
                                          .loadData(
                                                        serviceUrl
                                                                     + "/ORGU_MEM_ETSet?$filter=OobjId eq ''",
                                                        null, false);
                            
                            var result = oModel.oData.d.results;
                            
                            oModel.setData(result);

                            oTable.setModel(oModel); // set model to Table*/
                            
                            oTable.bindRows("/");
                            oTable.setExpandFirstLevel(true);
                            
                            var oTable = sap.ui.getCore().byId("rightTree");
                            var ActivityDDModel = new sap.ui.model.json.JSONModel();
                            ActivityDDModel
                                          .loadData(serviceUrl
                                                        + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                               + this.caseguid
                                                                               + "' and ID eq 'TY' and OtherF4 eq true");
                           var ActivityDD = new sap.m.Select({
                                   value : "Select",
                                   selectedKey : "{Activity}",
                                   items : {
                                          path : "keys>/d/results",
                                          template : new sap.ui.core.Item({
                                                 key : "{keys>ResultCol3}",
                                                 text : "{keys>ResulltCol1}",
                                                 tooltip: "{keys>ResulltCol1}"
                                          }),
                                   },
                                   visible : {
                                   "parts" : [ 'Type' ],
                                          "formatter" : flm.fiori.utils.formatter.lockSelect
                                        }
                            });
                            ActivityDD.setModel(ActivityDDModel,"keys");
                            var processingDays = new sap.m.Input({
                                   type : "Text",
                                   placeholder : "0",
                                   value : "{Days}",
                                   visible : {
                                   "parts" : [ 'Type' ],
                                        "formatter" : flm.fiori.utils.formatter.lockSelect
                                    }
                            });
                            var d = new Date();
                            var t = "";
                            var processingDate = new sap.m.DateTimeInput({
//                             type : "Date", 
                             valueFormat : "yyyyMMdd",
                             displayFormat : "dd/MM/yyyy",
                             value : "{PosidLed}",
                             visible : {
                               "parts" : [ 'Type' ],
                                    "formatter" : flm.fiori.utils.formatter.lockSelect
                                }
                            });
                            
                            oTable.addColumn(new sap.ui.table.Column({
                                   label : oControllerS6.getView().getModel("i18n").getObject("APPROVER_LEVEL"),
                                   template : "Text",
                                   sortProperty : ""
                            }));
                            oTable.addColumn(new sap.ui.table.Column({
                                   label : oControllerS6.getView().getModel("i18n").getObject("APPROVER_NAME"),
                                   template : "Stext",
                                   sortProperty : ""
                            }));
                            oTable.addColumn(new sap.ui.table.Column({
                                   label : oControllerS6.getView().getModel("i18n").getObject("ACTIVITY"),
                                   template : ActivityDD,
                                   sortProperty : "",
                                   visible : {"parts" : [ 'Type' ],
                                          "formatter" : flm.fiori.utils.formatter.lockSelect}
                            }));
                            oTable.addColumn(new sap.ui.table.Column({
                                label : oControllerS6.getView().getModel("i18n").getObject("PROCESSING_DATE"),
                                template : processingDate,
                                sortProperty : "",
                                visible : {"parts" : [ 'Type' ],
                                    "formatter" : flm.fiori.utils.formatter.lockSelect}
                            }));
                            oTable.addColumn(new sap.ui.table.Column({
                                   label : oControllerS6.getView().getModel("i18n").getObject("PROCESSING_TIME"),
                                   template : processingDays,
                                   sortProperty : "",
                                   visible : {"parts" : [ 'Type' ],
                                       "formatter" : flm.fiori.utils.formatter.lockSelect}
                            }));
                            
                          //retaining existing workflow in right tree
                            var oTable=sap.ui.getCore().byId("rightTree");
                            oControllerS6.flatObj=new Array();
                           oControllerS6.globalCounter = 0;
                           var treeData=oControllerS6.getView().byId("daakWftree").getModel("workflow").getData();
                           var oModel = new sap.ui.model.json.JSONModel();
                           if(oEvent.getSource().getId()=="addInSequence"){
                            var d = new Date();
                            oModel.setData({
                                   "results" : [ {
                                          "Type" : "Sequence",
                                          "Text" : "Sequence",
                                          "Activity" : "SPACE",
                                          "nodes" : [],
                                          "PosidLed" : ""
                                   } ]
                            });
                           }else if(oEvent.getSource().getId()=="addInParallel"){
                          oModel.setData({
                                  "results" : [ {
                                         "Type" : "Parallel",
                                         "Text" : "Parallel",
                                         "Activity" : "SPACE",
                                         "nodes" : [],
                                         "PosidLed" : ""
                                  } ]
                           });
                           }
                            oTable.setModel(oModel); // set model to
              // Table*/
                            oTable.setSelectedIndex(0);
                            oTable.bindRows("/results");
                            oTable.setExpandFirstLevel(true);
                            oTable.expand(0);
                                  
                           }else{
                             sap.ui.getCore().byId("idFactoryCalendar").setValue("");
                             sap.ui.getCore().byId("idOrgUnit").setValue("");
                             sap.ui.getCore().byId("leftTree").getModel().destroy();
                              
                           //retaining existing workflow in right tree
                               var oTable=sap.ui.getCore().byId("rightTree");
                               oControllerS6.flatObj=new Array();
                              oControllerS6.globalCounter = 0;
                              var treeData=oControllerS6.getView().byId("daakWftree").getModel("workflow").getData();
                              var oModel = new sap.ui.model.json.JSONModel();
                            if(oEvent.getSource().getId()=="addInSequence"){
                                 oModel.setData({
                                        "results" : [ {
                                               "Type" : "Sequence",
                                               "Text" : "Sequence",
                                               "Activity" : "SPACE",
                                               "nodes" : []
                                        } ]
                                 });
                                }else if(oEvent.getSource().getId()=="addInParallel"){
                               oModel.setData({
                                       "results" : [ {
                                              "Type" : "Parallel",
                                              "Text" : "Parallel",
                                              "Activity" : "SPACE",
                                              "nodes" : []
                                       } ]
                                });
                             }
                               oTable.setModel(oModel); // set model to
               // Table*/
                               oTable.setSelectedIndex(0);
                               oTable.bindRows("/results");
                               oTable.setExpandFirstLevel(true);
                            }
                       
                       
                       //Set Activity and dueDays disabled for Sequence Node
                       
                       //Set Activity and dueDays disabled for Sequence Node ends
                      oControllerS6.oCreateWorkflow.open();
                      for(var i=0;i<sap.ui.getCore().byId("rightTree").getModel().getData().results.length;i++){
                          if(sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Sequence" || sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Parallel"){
                           sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[1].setVisible(false);
                           sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[2].setVisible(false);
                          }
                      }
                      }else{
                       if (oControllerS6.oSequenceSend == undefined) {
         oControllerS6.oSequenceSend = sap.ui.xmlfragment(
           "flm.fiori.view.sendTo", oControllerS6);

         var select1 = sap.ui.getCore().byId("idSelect1");
         var select1Model = new sap.ui.model.json.JSONModel({});
         select1Model
           .loadData(serviceUrl
             + "/FILE_F4_ES?$filter=CaseGuid eq '"
               + this.caseguid
               + "' and OtherF4 eq true and ID eq 'WC'");
         select1.setModel(select1Model, "processorType");
         var select2 = sap.ui.getCore().byId("idSelect2");
         var select2Model = new sap.ui.model.json.JSONModel({});
         select2Model
           .loadData(serviceUrl
             + "/FILE_F4_ES?$filter=CaseGuid eq '"
               + this.caseguid
               + "' and OtherF4 eq true and ID eq 'TY'");
         select2.setModel(select2Model, "activity");
        }
                       var currNode = oControllerS6.byId("daakWftree").getContextByIndex(
         oControllerS6.byId("daakWftree").getSelectedIndex())
         .getObject();
                          sap.ui.getCore().byId("idLabelSelectType").setVisible(true);
                          sap.ui.getCore().byId("idSequenceRadioButton").setVisible(true);
//                          sap.ui.getCore().byId("idParallelRadioButton").setVisible(true);
         // modify UI of popup depending upon the scenario
         var currNode = oControllerS6.byId("daakWftree").getContextByIndex(
           oControllerS6.byId("daakWftree").getSelectedIndex())
           .getObject();

         if(oControllerS6.workflowAdminAuthorization){
        oControllerS6.resetWorkflowPopup(oControllerS6);
        if(currNode.Creadate!=""){
         sap.ui.getCore().byId("idParallelRadioButton").setVisible(false);
        }else{
         sap.ui.getCore().byId("idParallelRadioButton").setVisible(true);
        }
       }else if(currNode.IsDelete){
          oControllerS6.resetWorkflowPopup(oControllerS6,"PAR");
         }else{
          oControllerS6.resetWorkflowPopup(oControllerS6,"SEQ");
         }

        oControllerS6.oSequenceSend.open();
                      }
               },
               
            resetWorkflowPopup: function(controller, mode){
    //clearing the input fields
    sap.ui.getCore().byId("idSelect1").setSelectedKey("SPACE");
    sap.ui.getCore().byId("idSelect2").setSelectedKey("SPACE");
    sap.ui.getCore().byId("idUsername").setValue("");
    sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
    sap.ui.getCore().byId("idInputDays").setValue("");
    // Condition to check wether parallel is enabled or not. Correspondingly changing UI
    if(controller.workflowParallelEnabled){
     // clearing the model
     var oTable = sap.ui.getCore().byId("idProcessorsTable");
     if(oTable.getModel("dummy")){
      oTable.getModel("dummy").destroy();
     }
     var oModel = new sap.ui.model.json.JSONModel({
      "data" : []
     });
     oTable.setModel(oModel, "dummy");
     if(mode == null){    //normal reset
      sap.ui.getCore().byId("idSequenceRadioButton").setVisible(true);
      sap.ui.getCore().byId("idParallelRadioButton").setVisible(true);
      sap.ui.getCore().byId("idSequenceRadioButton").setEnabled(true);
      sap.ui.getCore().byId("idParallelRadioButton").setEnabled(true);
      sap.ui.getCore().byId("idSequenceRadioButton").setSelected(true);
      sap.ui.getCore().byId("idParallelRadioButton").setSelected(false);
      controller.onSeqSelect();
     }else if(mode == "SEQ"){  //reset and set it for seq alone
      sap.ui.getCore().byId("idSequenceRadioButton").setVisible(true);
      sap.ui.getCore().byId("idParallelRadioButton").setVisible(true);
      sap.ui.getCore().byId("idSequenceRadioButton").setEnabled(true);
      sap.ui.getCore().byId("idParallelRadioButton").setEnabled(false);
      sap.ui.getCore().byId("idParallelRadioButton").setSelected(false);
      sap.ui.getCore().byId("idSequenceRadioButton").setSelected(true);
      controller.onSeqSelect();
     }else if(mode == "PAR"){  //reset and set it for parallel alone
      sap.ui.getCore().byId("idSequenceRadioButton").setVisible(true);
      sap.ui.getCore().byId("idParallelRadioButton").setVisible(true);
      sap.ui.getCore().byId("idSequenceRadioButton").setEnabled(false);
      sap.ui.getCore().byId("idParallelRadioButton").setEnabled(true);
      sap.ui.getCore().byId("idSequenceRadioButton").setSelected(false);
      sap.ui.getCore().byId("idParallelRadioButton").setSelected(true);
      controller.onParSelect();
     }
    }else{
     sap.ui.getCore().byId("idSequenceRadioButton").setVisible(true);
     sap.ui.getCore().byId("idParallelRadioButton").setVisible(false);
     sap.ui.getCore().byId("idSequenceRadioButton").setSelected(true);
     sap.ui.getCore().byId("idParallelRadioButton").setSelected(false);
     controller.onSeqSelect();
    }
   },

   onParSelect : function(oEvent) {
    sap.ui.getCore().byId("idButtonAdd").setVisible(true);
    sap.ui.getCore().byId("idProcessorsTable").setVisible(
      true);
   },

   onSeqSelect : function(oEvent) {
    sap.ui.getCore().byId("idButtonAdd").setVisible(false);
    sap.ui.getCore().byId("idProcessorsTable").setVisible(
      false);
   },
               
               addSequenceCreateWorkflow : function(oEvent, newObj, sourceFlag) {
                
                if(sap.ui.getCore().byId("rightTree").getSelectedIndex()<0){
                 alert(this.getView().getModel("i18n").getObject("MESSAGE_58"));
                       return;
                }
                
               if (!newObj) {
                     var leftTree = sap.ui.getCore().byId("leftTree");
                     leftTree.rerender();
                     var leftIndices = leftTree.getSelectedIndices();
                     var leftObject = new Array();
                     for(var i=0;i<leftIndices.length;i++){
                     leftObject[i] = {};
                     leftObject[i].Type="";
                     leftObject[i].Text = ""; //leftTree.getContextByIndex(
//                                   leftIndex).getObject().Text;
                     leftObject[i].Stext = leftTree.getContextByIndex(
                                   leftIndices[i]).getObject().Stext;
                     leftObject[i].Nodetype = "S";
                     if(leftTree.getContextByIndex(
                       leftIndices[i]).getObject().Otype.length==1){
                      leftTree.getContextByIndex(
                        leftIndices[i]).getObject().Otype+=' ';
                     }
                     leftObject[i].Agent = leftTree.getContextByIndex(
                       leftIndices[i]).getObject().Otype
                                   + leftTree.getContextByIndex(leftIndices[i])
                                                 .getObject().Objid;
                     leftTree.isParallel = "";
                     leftTree.CaseGuid = "1";
                     leftObject[i].Statustext=this.getView().getModel("i18n").getObject("NOTYETSTARTED");
                     leftObject[i].PosidLed="";
                     leftObject[i].nodes = [];
                     }
              }

                   else if (newObj && sourceFlag=="sendTo") {
                          var leftObject = newObj;
                          leftObject.Type="";
                          leftObject.Text="";//newObj.processor;
                          leftObject.Stext = newObj.Fullname;
                          leftObject.Nodetype="S";
                          leftObject.Agent=newObj.Agent;
                          leftObject.Statustext=this.getView().getModel("i18n").getObject("NOTYETSTARTED");
                          leftObject.key=newObj.Activity;
                         leftObject.nodes = [];
                   }
                   else if (newObj && sourceFlag=="mainWf") {
                       var leftObject = newObj;
                       leftObject.Type="";
                       leftObject.Nodetype="S";
                       leftObject.Statustext=this.getView().getModel("i18n").getObject("NOTYETSTARTED");
                       leftObject.PosidLed="";
                       leftObject.Stext = newObj.Fullname;
                       leftObject.key=newObj.Activity;
                       leftObject.nodes = [];
                }
                   var rightTree = sap.ui.getCore().byId("rightTree");

                   // get selected index of leftTree

                   // get selected index of rightTree
                   var rightIndex = rightTree.getSelectedIndex();

                   
                   // case 1 - right tree is empty or nothing is selected
                   if (rightIndex == -1) {
                          // append to the end of the treetable
                          var data = rightTree.getModel().oData.results;

                          data[0].nodes.push(leftObject);

                          rightTree.getModel().checkUpdate();
                          
                          rightTree.rerender();
                          for(var i=0;i<sap.ui.getCore().byId("rightTree").getModel().getData().results.length;i++){   
                           if(sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Sequence" || sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Parallel"){
                               sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[2].setEnabled(false);
                               sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[3].setEnabled(false);
                              }
                          }
                          return;
                   }

                // get right tree selected Object
                   var rightObject = rightTree.getContextByIndex(
                                 rightIndex).getObject(); // .getRows()[rightIndex].getBindingContext().getObject();

                   // case 2 - normal node
                   // figure out the parent node so that you can append
                   var data = rightTree.getModel().oData.results;
                   var path = rightTree.getContextByIndex(rightIndex)
                                 .getPath().substr(9).split("/");
                   var obj = data;
                   for ( var i = 0; i < path.length - 3; ++i) {
                          obj = obj[path[i]];
                   }

                   // if parent is sequence
                   if(leftObject.length==undefined){
                   var tempObj = leftObject;
                   leftObject = new Array();
                   leftObject[0] = tempObj;
                   }
                   for(var j=leftObject.length-1;j>=0;j--){
                   if (obj[path[i]].Type == "Sequence") {
                       leftObject[j].Nodetype = "S";   
                    obj[path[i]].nodes.splice(
                                        parseInt(path[i + 2]) + 1, 0, leftObject[j]);
                   } else if (obj[path[i]].Type == "Parallel") { // if
                        leftObject[j].Nodetype = "P";                                                       // parent
                        obj[path[i]].nodes.splice(
                                parseInt(path[i + 2]) + 1, 0, leftObject[j]); 
                   } // node is parallel
                        else if (obj[path[i]].type == undefined) {
                          obj[path[i]].nodes[0].nodes.splice(
                                        parseInt(path[i + 2]), 0, leftObject[j]);
                   }
                   }
                   rightTree.getModel().checkUpdate();
                   rightTree.rerender();
                   return;

            },

            addParallelCreateWorkflow : function(oEvent) {
                   
                   var leftTree = sap.ui.getCore().byId("leftTree");
                   var rightTree = sap.ui.getCore().byId("rightTree");

                   // rerender trees
                   leftTree.rerender();
                   rightTree.rerender();

                   // get selected index of leftTree
                   var leftIndex = leftTree.getSelectedIndex();

                   if (leftIndex == -1) {
                          alert(this.getView().getModel("i18n").getObject("MESSAGE_16"));
                          return;
                   }

                   // get selected index of rightTree
                   var rightIndex = rightTree.getSelectedIndex();

                   // get left tree selected object
                  var leftObject = {};
                   leftObject.Text = leftTree.getContextByIndex(leftIndex)
                                 .getObject().Text;
                   leftObject.Stext = leftTree
                                 .getContextByIndex(leftIndex).getObject().Stext;
                   leftObject.Nodetype = "P";
                   if(leftTree.getContextByIndex(
                           leftIndex).getObject().Otype.length==1){
                    leftTree.getContextByIndex(
                               leftIndex).getObject().Otype+=' ';
                   }
                   leftObject.Agent = leftTree
                                 .getContextByIndex(leftIndex).getObject().Otype
                                 + leftTree.getContextByIndex(leftIndex)
                                               .getObject().Objid;
                   leftTree.isParallel = true;
                   leftTree.CaseGuid = "1";
                   leftObject.Statustext=this.getView().getModel("i18n").getObject("NOTYETSTARTED");
                   leftObject.PosidLed="";
                   leftObject.nodes = [];

                   // case 1 - right tree is empty or nothing is selected
                   if (rightIndex == -1) {
                          // alert saying that - choose a person/agent to add
                          // in parallel
                          return;
                   }

                   // get right tree selected object
                   var rightObject = rightTree.getContextByIndex(
                                 rightIndex).getObject(); // .getRows()[rightIndex].getBindingContext().getObject();

                   // case 2 - non parallel node (normal node)
                   if (rightObject.Type != "Parallel") {
                          // figure out the parent node so that you can remove
                          // selected item
                          var data = rightTree.getModel().oData.results;
                          var path = rightTree.getContextByIndex(rightIndex)
                                        .getPath().substr(9).split("/");
                          var obj = data;
                          for ( var i = 0; i < path.length - 3; ++i) {
                                 obj = obj[path[i]];
                          }

                          if (obj[path[i]].Type == "Sequence") {

                                 // remove the selected item from the list and
                                 // add new node instead - i.e., assign type as
                                 // parallel
                                 var oldObject = obj[path[i]].nodes.splice(
                                               path[i + 2], 1, {
                                                     "Text" : "Parallel",
                                                     "Type" : "Parallel",
                                                     "nodes" : []
                                               });

                                obj[path[i]].nodes[path[i + 2]].nodes = [
                                               oldObject[0], leftObject ];
                          } else if (obj[path[i]].Type == "Parallel") {

                                 obj[path[i]].nodes.push(leftObject);
                          }

                          rightTree.getModel().checkUpdate();

                          rightTree.rerender();

                          // add new node instead - assign type as parallel
                          // add deleted item inside the parallel node
                          // add the selected item inside the parallel node
                          return;
                   }

                   // case 3 - parallel node
                   if (rightObject.Type == "Parallel") {
                          // alert saying that - choose a person/agent to add
                          // in parallel
                          return;
                   }

            },
            onChangeWorkflowSelect : function(oEvent) {
               if(sap.ui.getCore().byId("rightTree").getSelectedIndex()<0){
                alert(this.getView().getModel("i18n").getObject("MESSAGE_58"));
                      return;
               }
                oControllerS6.updateWorkflowFlag=true;
                oControllerS6.newWorkflowFlag=false;
                     if (!oControllerS6.oSequenceSend) {
                      oControllerS6.oSequenceSend = sap.ui.xmlfragment(
                                          "flm.fiori.view.sendTo", oControllerS6);
                     }
                     sap.ui.getCore().byId("idUsername").setValue("");
               sap.ui.getCore().byId("idUsername").setName("");
               sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
               sap.ui.getCore().byId("idInputDays").setValue("");
               sap.ui.getCore().byId("idSelect2").setSelectedKey();
         sap.ui.getCore().byId("idSendToDialog").setContentWidth("100%");

                     sap.ui.getCore().byId("idLabelSelectType").setVisible(false);
                     sap.ui.getCore().byId("idSequenceRadioButton").setVisible(false);
                     sap.ui.getCore().byId("idParallelRadioButton").setVisible(false);
//                     sap.ui.getCore().byId("idDatePickerSendTo").setVisible(false);                                       
//                     sap.ui.getCore().byId("idInputDays").setVisible(false);
                     // if(oEvent.getSource().getId()=="__xmlview3--idChangeWorkflowButton"){
                     oControllerS6.flagLocation = "fromChangeWorkflow";
                     if (oEvent.getSource().getId() == "idAddProcessorButton") {
                            oControllerS6.flagLocation = "fromAddNewWorkflow";
                     }
                     var oTable = sap.ui.getCore().byId("idProcessorsTable");
                                   var oModel = new sap.ui.model.json.JSONModel({
                                          "data" : []
                                   });
                                   oTable.setModel(oModel, "dummy");
                     var select1 = sap.ui.getCore().byId("idSelect1");
                     var select1Model = new sap.ui.model.json.JSONModel({});
                     select1.setSelectedKey("SPACE");
                     select1Model
                                   .loadData(serviceUrl
                                                 + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                     + this.caseguid
                                                                     + "' and OtherF4 eq true and ID eq 'WC'",null,false);
                     select1.setModel(select1Model,"processorType");
                     
                     var select2 = sap.ui.getCore().byId("idSelect2");
                     var select2Model = new sap.ui.model.json.JSONModel({});
                     select2Model
                                   .loadData(serviceUrl
                                                 + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                     + this.caseguid
                                                                     + "' and OtherF4 eq true and ID eq 'TY'",null,false);
                     select2.setModel(select2Model,"activity");
                     if (oControllerS6._oDynamicF4Dialog) {
                      oControllerS6._oDynamicF4Dialog.getModel().destroy();
                     }
                     
//                     sap.ui.getCore().byId("idParallelRadioButton")
//                                   .setVisible(false);
                     this.oSequenceSend.open();
                     
              },

               onSendToDialogCloseButton : function(oEvent) {
                      
                sap.ui.getCore().byId("idUsername").setValue("");
                   sap.ui.getCore().byId("idSelect1").setSelectedKey("SPACE");
                   sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
                   sap.ui.getCore().byId("idInputDays").setValue("");
     if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
      oEvent.getSource().getParent().close();
     } else {
      oEvent.getSource().getParent().getParent().close();
     }
               },
               onWorkflowDialogCloseButton : function(oEvent){
                oControllerS6.oCreateWorkflow.close(); 
               },
               
               getParent : function(parNode,levels){
                var j = 0; 
                if(levels.length==1){
                 return oControllerS6.byId("daakWftree").getModel().oData;
                }else{
                while(j<=levels.length-2){
           parNode=parNode.nodes[parseInt(levels[j]-1)];
           j++;
          } 
                }
                return parNode;
               },
               
               checkWiid : function(){
                var retArr = new Array();
                var treeData = oControllerS6.byId("daakWftree").getModel().oData;
                for(var i=0;i<oControllerS6.flatTreeTableData.length;i++){
                 var currNode = oControllerS6.flatTreeTableData[i];
                 retArr[0] = currNode;
                 retArr[2]='';
                 if(currNode.PosidWiid==oControllerS6.wiId){
//                  var j=0;
                  var parNode = treeData;
                  var levels = currNode.Label.split("_");
               parNode = oControllerS6.getParent(parNode,levels);                  
                  if(currNode.Nodetype=="S" && parNode.nodes.length>parseInt(levels[levels.length-1]) && parNode.isSpecial!='X'){
                   retArr[1] = parNode.nodes[parseInt(levels[levels.length-1])];
                   if(parNode.nodes[parseInt(levels[levels.length-1])].isSpecial=='X'){
                    retArr[2]='X';
                   }else{
                    retArr[2]='';
                   }
                   return retArr;
                  }else if(currNode.Nodetype!="S" && currNode.nodes.length>0 && parNode.isSpecial!='X'){
                   retArr[1] = currNode.nodes[0];
                   return retArr;
                  }else{
//                   parNode = oControllerS6.getParent(parNode,levels,j);
//                   grandParLevels = grandParNode.Label.split("_");
                   while(parNode!==treeData){
                    levels = parNode.Label.split("_");
                    if(parNode.isSpecial=='X'){
                     parNode = oControllerS6.getParent(treeData,levels);
                     retArr[2]='X';
                    }else if(parNode.nodes.length>parseInt(levels[levels.length-1])){
                     retArr[1] = parNode.nodes[parseInt(levels[levels.length-1])];
                     return retArr;
                    }else{
                     parNode = oControllerS6.getParent(treeData,levels);
                     retArr[2]='';
                    }
                   }
                   if(parNode.nodes[parseInt(levels[levels.length-1])]){
                   retArr[1] = parNode.nodes[parseInt(levels[levels.length-1])];
                   }else{
                   retArr[1] = parNode.nodes[parseInt(levels[levels.length-1])+1];   
                   }
                            return retArr;
                  }
                 }
                }
               },
               
               addResponseNode : function(oEvent){
                var hrchyData = oControllerS6.byId("daakWftree").getModel().oData;
                var returnArr = oControllerS6.checkWiid(hrchyData,hrchyData.nodes,"",0);
                var currNode = returnArr[0];
                var prevNode = returnArr[1];
                if(!prevNode){
                 return;
                }
//                var pos = returnArr[3];
                var nodeType = 'S';
                if(returnArr[2]=='X'){
                 nodeType = 'P';
                }else{
                 nodeType='S';
                }
                var obj = {
                 "isParallel" : "",
                            "Actdc" : currNode.Actdc,
                            "Activity" : currNode.Activity,
                            "Agent" :currNode.Agent,
                            "Nodetype" : nodeType,
                            "op" : "INTRAY",
                            "CaseGuid" : oControllerS6.caseguid,
                            "Fullname" : currNode.Stext,
                            "PosidLed" : currNode.PosidLed,
                            "DueDays" : currNode.DueDays,                                                         
                            "Parentid" : prevNode.Posid,
                            "WitemId" : "",
                         };
                
                var oWfModel = oControllerS6.getView().getModel();
                oWfModel
      .create(
        "/FILE_PROUTE_ES",
        obj,
        {
         success : function(oResponse) {
          oControllerS6.customBusyDialogClose();
          // Reloading the workflow
          // and closing the busy
          // indicator
        },
         error : function(oResponse) {

          // through the error and
          // close the busy indicator
          oControllerS6
            .customBusyDialogClose();
          sap.m.MessageBox.alert(oControllerS6.getView()
            .getModel("i18n").getObject("MESSAGE_68"));
         },
         async : true,
        });
//     oControllerS6.loadTreeTable();
               },
               
               onCreateWorkflowOkPress : function(oEvent) {
                oControllerS6.customBusyDialogOpen();
                   /* New Addition */
                var wftree = oControllerS6.getView().byId("daakWftree");
                var parentId="";
                var selectedNodeType = "";
                if(wftree.getModel("workflow").oData.nodes.length == 0){
                 wftree.setSelectedIndex(-1);
                }
                if(wftree.getModel("workflow").oData.nodes.length != 0 && wftree.getSelectedIndex()==-1){
                 parentId="0000";
                }
                if(wftree.getSelectedIndex()!=-1){
                selectedNodeType = wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().Nodetype;
                }
//                   oControllerS6.updateWorkflowFlag=true;
                   var result = sap.ui.getCore().byId("rightTree") 
                                 .getModel().oData.results; 
                   oControllerS6.rightTreeData=result;
                   oControllerS6.flatObj = new Array();
                   oControllerS6.globalCounter = 0;
                   for ( var i = 0; i < result[0].nodes.length; i++) {
                          oControllerS6.convertToFlatForCreateWorkflow(
                                        result[0].nodes, i, (i+1),"S","createWF");
                   }
                   if(oControllerS6.flatObj.length==0){
                    sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_87"));
                    return;
                   }
//                   var oModel = new sap.ui.model.json.JSONModel();
                   var oModel = new sap.ui.model.odata.ODataModel(
                           serviceUrl);
                   var obj = {
                           "nodes" : [],
                           "Label" : "Sequence"
                    };
//                    var oTreeTable = oControllerS6.getView().byId("wftree");
//                   oControllerS6.flatObj=oControllerS6.flatObj.reverse();
                    result=oControllerS6.flatObj;
                    //If Single Parallel Node is added, convert it to Sequence
                   
                    if(wftree.getSelectedIndex()==-1 && wftree.getModel("workflow").oData.nodes.length==0){
                     //Enter Only one Among date and DAys
                     for(var i=0;i<oControllerS6.flatObj.length;i++){
                     if(oControllerS6.flatObj[i].PosidLed!="" && oControllerS6.flatObj[i].Days!=""){
                         sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_88"));
                         oControllerS6.customBusyDialogClose();
                         return;
                        }
                     }
                     for(var i=0;i<oControllerS6.flatObj.length;i++){
                            var op="";
                            if(i==oControllerS6.flatObj.length-1){
                                   op='INTRAY';
                            }
                        if(oControllerS6.flatObj[i].Days == undefined || oControllerS6.flatObj[i].Days == ""){
                         oControllerS6.flatObj[i].Days = 0;
                        }
                            
                    oModel.setUseBatch(true);
                    // create batch operation
                    var batchOp = oModel.createBatchOperation(
                                  "/FILE_PROUTE_ES", 'POST',
                                                {
                                                      "isParallel" : oControllerS6.flatObj[i].isParallel,
                                                      "Nodetype" : oControllerS6.flatObj[i].Nodetype,
                                                      "Actdc" : oControllerS6.flatObj[i].Actdc,
                                                      "Activity" : oControllerS6.flatObj[i].Activity,
                                                      "CaseGuid" : oControllerS6.caseguid,
                                                      "OrgObj" : oControllerS6.flatObj[i].OrgObj,
                                                      "WitemId" : '',
                                                      "Agent" :oControllerS6.flatObj[i].Agent, 
                                                      "op" : op,
//                                                      "Stext" : oControllerS6.flatObj[i].Stext,
                                                      "DueDays" : oControllerS6.flatObj[i].Days,
                                                      "PosidLed" : oControllerS6.flatObj[i].PosidLed,
                                                });
                    
                    
                    // add batch operation
                    oModel.addBatchChangeOperations([ batchOp ]);
                     }
                     
                     oModel
                        .submitBatch(
                                      function(oResponse, oData) {
                                       
                                       if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {
                                         var resObj = oResponse.__batchResponses[oResponse.__batchResponses.length - 1].__changeResponses[0]; // Response
//                                                   sap.m.MessageToast
//                                                                 .show(oControllerS6.getView().getModel("i18n").getObject("SAVESUCCESS"));
                                        oControllerS6.loadTreeTable();
                                        wftree.expand(wftree.getSelectedIndex());
                                                   oControllerS6.saveFlag=false;
                                                   oControllerS6.updateWorkflowFlag=false;
                                            } else if(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf("<severity>warning</severity>") != -1 || oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf('"severity":"warning"') != -1){
                                             sap.m.MessageBox.confirm(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                               oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers),
                                            function(response) {
                  if (response == "OK") {
                   oControllerS6.customBusyDialogOpen();
                   //eotValue = 'X';
                   oControllerS6.updateFile('X');

                  }
                                                });
                                            }
                else {
                                                   sap.m.MessageBox
                                                                 .alert(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                                oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers));
//return;
                                            }
                                            oControllerS6.customBusyDialogClose();
                                      }, function(oResponse) {
                                       oControllerS6.customBusyDialogClose();
                                      },true); 
                     
                    
                    }
                    else{
                     var parentId="0000",isSpecial=null;
                     if(wftree.getSelectedIndex()!=-1){
                      parentId = wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().Posid;
                      if(wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().isSpecial=="X"){
                       isSpecial='X';
                      }
                        }
                     //Enter only one Among DAte and days
                    for(var i=0;i<oControllerS6.flatObj.length;i++){
                    if(oControllerS6.flatObj[i].PosidLed!="" && oControllerS6.flatObj[i].Days!=""){
                     
                    sap.ui.getCore().byId("rightTree").getRows()[i+1].getCells()[3].setValue("");
                     sap.ui.getCore().byId("rightTree").getRows()[i+1].getCells()[4].setValue("");
                    sap.ui.getCore().byId("rightTree").getRows()[i+1].getCells()[3].focus(true);
                       sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_89"));
                       sap.ui.getCore().byId("rightTree").rerender();
                       oControllerS6.customBusyDialogClose();
                       return;
                      }
                    }
//                     for(var i=0;i<oControllerS6.flatObj.length;i++){
                     for(var i=oControllerS6.flatObj.length-1;i>=0;i--){
                      
                            var op="";
//                            if(i==oControllerS6.flatObj.length-1){
                            if(i==0){
                                   op="INTRAY";
                            }
                            if(oControllerS6.flatObj[i].Nodetype=="P"){
                             oControllerS6.flatObj[i].isParallel='X';
                            }
                            // To add in sequence after the parallel block (Nodetype='P' and isParallel='')
//                            if(wftree.getSelectedIndex()!=-1){
                            if( isSpecial && oControllerS6.flatObj[i].Nodetype=="S"){
                             oControllerS6.flatObj[i].Nodetype="P";
                             oControllerS6.flatObj[i].isParallel="";
                            }
//                            }
                        if(sap.ui.getCore().byId("rightTree").getModel().getData().results[0].Type=="Sequence"){   
                     var obj = {
                          "isParallel" : oControllerS6.flatObj[i].isParallel,
                                      "Actdc" : oControllerS6.flatObj[i].Actdc,
                                      "Activity" : oControllerS6.flatObj[i].Activity,
                                      "Agent" :oControllerS6.flatObj[i].Agent,
                                      "Nodetype" : oControllerS6.flatObj[i].Nodetype,
                                      "op" : "INTRAY",
//                                      "CaseGuid" : oControllerS6.caseguid,
//                                      "OrgObj" : oControllerS6.flatObj[i].OrgObj,
//                                      "WitemId" : '',
                                      "CaseGuid" : oControllerS6.caseguid,
                                      "Fullname" : oControllerS6.flatObj[i].Stext,
                                      "PosidLed" : "",
                                      "DueDays" : 0,                                                         
                                      "Parentid" : parentId,
                                      "WitemId" : "",
                                       };
                     
                     var oWfModel = oControllerS6.getView().getModel();
      oWfModel
        .create(
          "/FILE_PROUTE_ES",
          obj,
          {
           success : function(oResponse) {
            oControllerS6.customBusyDialogClose();
            // Reloading the workflow
            // and closing the busy
            // indicator
//            oControllerS6
//              .loadTreeTable();
//            wftree.expand(wftree.getSelectedIndex());

           },
           error : function(oResponse) {

            // through the error and
            // close the busy indicator
            oControllerS6
              .customBusyDialogClose();
            sap.m.MessageBox.alert(oControllerS6.getView()
              .getModel("i18n").getObject("MESSAGE_68"));
           },
           async : true,
          });
       oControllerS6.loadTreeTable();
//       oControllerS6.customBusyDialogClose();
                     }
                     else if(sap.ui.getCore().byId("rightTree").getModel().getData().results[0].Type=="Parallel"){
                      var oModel = oControllerS6.getView().getModel();
                      oModel.setUseBatch(true);
       var isParallel = "X";
       var nodeType = "P";
                      var batchOp = oModel
       .createBatchOperation(
         "/FILE_PROUTE_ES",
         'POST',
         {
          "isParallel" : isParallel,
          "Nodetype" : nodeType,
          "Actdc" : oControllerS6.flatObj[i].Actdc,
          "Activity" : oControllerS6.flatObj[i].Activity,
          "CaseGuid" : oControllerS6.caseguid,
          "WitemId" : "",
          "Agent" : oControllerS6.flatObj[i].Agent,
          "PosidLed" : "",
          "DueDays" : 0,
          "op" : op,
          "Parentid" : parentId,
         });

     // add batch operation
     oModel.addBatchChangeOperations([ batchOp ]);
     isParallel = 'X'; // all the rows inserted
          // after the first one need
          // to be inserted in
          // parallel to it
    }

    // submit the batch and store the results
                                                                                     
                    }
                     oModel.submitBatch(function(oResponse, oData) {
                    
        // Success function
        // Reloading the workflow and closing the busy
        // indicator
        oControllerS6.loadTreeTable();
//        wftree.expand(wftree.getSelectedIndex());
        oControllerS6.customBusyDialogClose();
       }, function(oResponse) {
        // failure function
        // through the error and close the busy
        // indicator
        oControllerS6.customBusyDialogClose();
       }, true);
                     }
//                    oControllerS6.saveFlag=true;
                    
                    if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                        oEvent.getSource().getParent().close();
                 } else {
                        oEvent.getSource().getParent().getParent().close();
                 }
            },

            convertToFlatForCreateWorkflow : function(result, i, level,type,fromSource) {
             var factoryCalendar=sap.ui.getCore().byId("idFactoryCalendar").getValue();
              level=level.toString();
              if(result[i].Type=="Sequence"){
                     result[i].Label=level.substring(0,level.length-1)+(parseInt(level.substring((level.length-1),(level.length)))-1).toString();
                     var nodeType="S";
                     for ( var j = 0; j < result[i].nodes.length; j++) {
                        oControllerS6.convertToFlatForCreateWorkflow(
                                   result[i].nodes, j, result[i].Label + "_"
                                                + (j + 1),nodeType);
                     }
              }else if(result[i].Type=="Parallel"){
                     result[i].Label=level.substring(0,level.length-1)+(parseInt(level.substring((level.length-1),(level.length)))-1).toString();
                     var nodeType="P";
                     for ( var j = 0; j < result[i].nodes.length; j++) {
                        oControllerS6.convertToFlatForCreateWorkflow(
                                   result[i].nodes, j, result[i].Label + "_"
                                                + (j + 1),nodeType);
                     }
              }else{
                          result[i].Label = level.toString();
                          if(result[i].Fullname=="" || result[i].Fullname==undefined){
                          result[i].Fullname = result[i].Stext;
                          }else{
                           result[i].Stext=result[i].Fullname;
                          }
                          if(sap.ui.getCore().byId("rightTree").getRows().length!=0){
                         if(fromSource=="createWF"){
                          result[i].Actdc = sap.ui.getCore().byId("rightTree")
                                  .getRows()[i+1].getCells()[2].getSelectedItem().getText(); // not a correct way TEMPORARY FIX
                          result[i].Activity = sap.ui.getCore().byId("rightTree")
                                     .getRows()[i+1].getCells()[2].getSelectedItem()
                                     .getKey();
                          }
                          }
                          result[i].OrgObj=factoryCalendar;
                      if (type == "P") {
                             result[i].isParallel = 'X';
                      } else {
                             result[i].isParallel = "";
                      }
                      oControllerS6.flatObj[oControllerS6.globalCounter] = result[i];
                      oControllerS6.globalCounter++;
              }
              },
              
              loadRemainingTree : function(oEvent){
               
               var nodeParams=oEvent.getSource().getParent().getBindingContext().getObject();
               var oTable=sap.ui.getCore().byId("leftTree");
               if(nodeParams.Otype.length<2){
                nodeParams.Otype+=' ';
               }
               nodeParams.OobjId=nodeParams.Otype+nodeParams.Objid;
               nodeParams.Level="";
               var result=oControllerS6.leftTreeNodes;
               var oModel = new sap.ui.model.json.JSONModel();
               oModel.attachRequestCompleted(oControllerS6,function(oEvent){
                if(oEvent.mParameters.errorobject){
                 oModel.detachRequestCompleted();
                       sap.m.MessageBox.alert(getErrorJson(oEvent.mParameters.errorobject.responseText));
       return;
                }
                  },oControllerS6);
               oModel.loadData(serviceUrl
                          + "/ORGU_MEM_ETSet?$filter=OobjId eq '"
                          + nodeParams.OobjId + "' and LevelDesc eq '"+nodeParams.LevelDesc+"'",
                          null, false);
               try{
               result=result.concat(oModel.getData().d.results);
               }
               catch(err){
                
               }
               oControllerS6.leftTreeNodes=result;
                  // /////////////////
                                    var obj = {
                                            "nodes" : [],
                                            "Label" : "Sequence"
                                     };
                                     for ( var i = 0; i < result.length; ++i) {
                                            result[i].__metadata = null;
                                            var levels = result[i].LevelDesc.split("_");

                                            for ( var k = 0; k < levels.length; ++k) {
                                                   levels[k] = parseInt(levels[k]) - 1;
                                            }

                                            var tempObj = obj;

                                            for ( var j = 0; j < levels.length - 2; ++j) {
                                                   tempObj = tempObj.nodes[levels[j]];
                                            }

                                            if (tempObj.nodes[levels[j]] == undefined) {
                                                   result[i].nodes = [];
                                                   tempObj.nodes[levels[j]] = result[i];
                                                   continue;
                                            }

                                            result[i].nodes = [];
                                            tempObj.nodes[levels[j]].nodes.push(result[i]);
                                     }

                                     oModel.setData(obj);
                                    // ////////////////

//oModel.setData(result);

                                    oTable.setModel(oModel); // set
                // model
                // to
                                                                                    // Table*/
                                    
                                    oTable.bindRows("/");
                                    for(var i=0;i<result.length;i++){
                                     oTable.expand(i);
                                    }
              },
              
              changeLevels : function(result,currLabel,prevLabel,t){ //recursive function to change levels for adding special node
                
               var l=1;
               for(var i=t+1;i<result.length;i++){
                if(result[i].Label.slice(0,-2) == prevLabel && result[i].Label.length==prevLabel.length+2){
                 var tempLabel=result[i].Label;
                 result[i].Label = currLabel+"_"+(l++);
                    oControllerS6.changeLevels(result,result[i].Label,tempLabel,i); 
                }
               }
              },
              
              loadTreeTable : function(oEvent) {
                  
                  var oModel = new sap.ui.model.json.JSONModel();
                   oModel
                                              .loadData(
                                                           serviceUrl
                                                                         + "/FILE_PROUTE_ES?$filter=CaseGuid eq '"
                                                                         + this.caseguid + "' and TabType eq '"+this.fromTab+"' and WitemId eq '' and ISDAAK eq true",
                                                           null, false);
                   
                  // create hierarchy from the flat dataset returned by
                  // server
                  var result = oModel.oData.d.results;
                //Replace '_' with '0' for sorting purpose
                  for(var i=0;i<result.length;i++){
                   result[i].sortIndex=result[i].Label.split('_').join('0');
                  }
                //To sort the workflow for adding special nodes
                  result.sort(function(a, b){ 
                   return a.sortIndex-b.sortIndex;
                  });
                  for(var i=0;i<result.length;i++){
                   if(result[i].Photourl=="/sap/zmys/anand.jpg"){
                    result[i].Photourl="";
                   }
                   result[i].Photourl = decodeURIComponent(result[i].Photourl);
                  }

                  var obj = {
                         "nodes" : [],
                         "Label" : "Sequence"
                  };
                  var oTreeTable = this.getView().byId("daakWftree");
                  for ( var i = 0; i < result.length; ++i) {
                                          
                       if(result[i].Nodetype=="PB"){
                              result[i].Nodetype="PB*";
                              var spclNode = {
                                   "nodes" : [],
                                   "Fullname" : "Parallel Steps",
                                   "Label" : result[i].Label,
                                   "Posid" : result[i].Posid,
                                   "Parentid" : result[i].Parentid,
                                   "Nodetype" : "P",
                                   "isParallel" : "X",
                                   "isSpecial" : "X"
                                 };

                              result.splice(i,0,spclNode);
                              var t=i+1,l=0,prevLabel;
                              //Till the whole parallel block is found
                              while(result[t].Nodetype!="PE"){ 
                               //All children sequence nodes will be handled by the changeLevel function
                               if(result[t].Nodetype!="S"){ 
                               prevLabel = result[t].Label;
                               result[t].Label = result[i].Label+"_"+(++l);
                               oControllerS6.changeLevels(result,result[t].Label,prevLabel,t);
                               }
                               t++;
                              }
                              prevLabel = result[t].Label;
                              result[t].Label = result[i].Label+"_"+(++l);
                              oControllerS6.changeLevels(result,result[t].Label,prevLabel,t);
                             }
                         result[i].__metadata = null;
                         var levels = result[i].Label.split("_");

                         for ( var k = 0; k < levels.length; ++k) {
                                levels[k] = parseInt(levels[k]) - 1;
                         }

                         var tempObj = obj;

                         for ( var j = 0; j < levels.length - 2; ++j) {
                                tempObj = tempObj.nodes[levels[j]];
                         }

                         if (tempObj.nodes[levels[j]] == undefined) {
                                result[i].nodes = [];
                                tempObj.nodes[levels[j]] = result[i];
                                continue;
                         }

                         result[i].nodes = [];
                         tempObj.nodes[levels[j]].nodes.push(result[i]);
                  }

                  var selectedNodeData=oTreeTable.getContextByIndex(oTreeTable.getSelectedIndex());
                  oModel.setData(obj);

                  oTreeTable.setModel(oModel,"workflow"); // set model to Table*/
                  oTreeTable.bindRows("workflow>/");
                  if(selectedNodeData){
                      var sndPath = selectedNodeData.getPath().split('/');
                      var expandIndex=parseInt(sndPath[2]);
                      for(var i=4;i<sndPath.length;i+=2){
                       oTreeTable.expand(expandIndex);
                       expandIndex+=parseInt(sndPath[i])+1;
                      }
                      }
                  oTreeTable.setExpandFirstLevel(true);
           },
           
           onInsertInWorkflow : function(oEvent) { // CHANGE
               if(this.fromTab == "CREATEDAAK" || this.fromTab == "DRAFTDAAK"){
               oControllerS6.flatObj = new Array();
               if (sap.ui.getCore().byId("idSequenceRadioButton")
                             .getSelected() == true) {
                      // var
                      var processor = sap.ui.getCore().byId("idSelect1")
                                   .getSelectedItem().getText();
                      var sendTo = sap.ui.getCore().byId("idUsername")
                                   .getValue();
                      var agent = sap.ui.getCore().byId("idUsername")
                                   .getName();
                      var activity = sap.ui.getCore().byId("idSelect2")
                                   .getSelectedItem().getText();
                      var activityKey = sap.ui.getCore()
                                    .byId("idSelect2").getSelectedItem()
                                   .getKey();
                      var processingDate = sap.ui.getCore().byId(
                                    "idDatePickerSendTo").getValue();
                      // var
                      // processingTime=sap.ui.getCore().byId("idInputTime").getValue();
                      var processingDay = sap.ui.getCore().byId(
                                   "idInputDays").getValue();
                      if ((sendTo == "" || activity == "" || processor == "")) {
                             sap.m.MessageToast
                                          .show(this.getView().getModel("i18n").getObject("MESSAGE_20"));
                             oControllerS6.customBusyDialogClose();
                             return;
                      }
                      if (processingDate != "" && processingDay != "") {
                             sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
                      sap.ui.getCore().byId("idInputDays").setValue("");
                      sap.m.MessageBox
                                    .alert(this.getView().getModel(
                                    "i18n").getObject("MESSAGE_21"));
                      oControllerS6.customBusyDialogClose();
                             return;
                      }
//                      oControllerS6.saveFlag = true;
                      var nodeType = "S";
//                      var d=new Date();
                      var newObj = {
                             "Actdc" : activity,
                             "Activity" : activityKey,
                             "Agent" : agent,
                             "Nodetype" : nodeType,
                             "Text" : processor,
                             "Fullname" : sendTo,
                             "Creadate" : "",
                             "PosidLed" : processingDate,
                             "processor" : processor,
                             "Statustext" : "Not Yet Started",
                             "Days" : processingDay,
                             "nodes" : []
                      };
                      oControllerS6.flatObj[0] = newObj;

                      oControllerS6.addSequenceCreateWorkflow(oEvent,newObj,"sendTo");
               } else if (sap.ui.getCore().byId(
                             "idParallelRadioButton").getSelected() == true) {
                      
                      var parList = sap.ui.getCore().byId(
                                    "idProcessorsTable").getModel("dummy")
                                   .getData().data;
                      for (var i = 0; i < parList.length; i++) {
                             var sendTo = parList[i].Name;
                             var activity = parList[i].Actdc;
                             var processingDate = parList[i].Date;
                             // var
                             // processingTime=parList[i].getCells()[4].getText();
                             var processingDay = parList[i].Days;
                             var agent = parList[i].Agent;
                             var activityKey = parList[i].Activity;
                             var nodeType = "P";
                             var newObj = {
                                   "Actdc" : activity,
                                   "Activity" : activityKey,
                                   "Agent" : agent,
                                   "Nodetype" : nodeType,
                                   "Fullname" : sendTo,
                                   "Text" : processor,
                                   "Creadate" : "",
                                   "PosidLed" : processingDate,
                                   "Statustext" : "Not Yet Started",
                                   "nodes" : []
                             };
                             oControllerS6.flatObj[i] = newObj;
                             oControllerS6.addSequence(newObj);
                      }
                      
               }
               // oEvent.getSource().getParent().getParent().close();
               sap.ui.getCore().byId("idUsername").setValue("");
               sap.ui.getCore().byId("idSelect1").getSelectedItem().setText("");
               sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
               sap.ui.getCore().byId("idInputDays").setValue("");
    if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
     oEvent.getSource().getParent().close();
    } else {
     oEvent.getSource().getParent().getParent().close();
    }
               }else{
             // Set the busy indicator
     oControllerS6.customBusyDialogOpen();
     var nodeType="";
     // Handle insertion for both sequence
     if (sap.ui.getCore().byId("idSequenceRadioButton")
       .getSelected() == true) {
      var processor = sap.ui.getCore().byId("idSelect1")
        .getSelectedItem().getText();
      var sendTo = sap.ui.getCore().byId("idUsername")
        .getValue();
      var agent = sap.ui.getCore().byId("idUsername")
        .getName();
      var activity = sap.ui.getCore().byId("idSelect2")
        .getSelectedItem().getText();
      var activityKey = sap.ui.getCore()
        .byId("idSelect2").getSelectedItem()
        .getKey();
      var processingDate = "";
      if(sap.ui.getCore().byId("idDatePickerSendTo").getValue() != ""){
       processingDate = sap.ui.getCore().byId("idDatePickerSendTo").getValue();
      }

      var processingDays = 0;
      if(sap.ui.getCore().byId("idInputDays").getValue() != ""){
       processingDays = parseInt(sap.ui.getCore().byId("idInputDays").getValue());
      }

      if ((sendTo == "" || activity == "" || processor == "")) {
       sap.m.MessageToast.show(this.getView()
         .getModel("i18n").getObject(
           "MESSAGE_48"));
       oControllerS6.customBusyDialogClose();
       return;
      }
      if (processingDate != "" && processingDays != "") {
       sap.ui.getCore().byId("idDatePickerSendTo")
         .setValue("");

       sap.ui.getCore().byId("idInputDays").setValue(
         "");

       sap.m.MessageBox.alert(this.getView().getModel(

       "i18n").getObject("MESSAGE_21"));
       oControllerS6.customBusyDialogClose();
       return;
      }
      var wftree=oControllerS6.byId("daakWftree");
      if(wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().isSpecial=="X"){
                         nodeType="P";
//                         oControllerS3.flatObj[i].isParallel="";
                        }
      var newObj = {
       "Actdc" : activity,
       "Activity" : activityKey,
       "Agent" : agent,
       "Nodetype" : nodeType,
       "op" : "INTRAY",
       "CaseGuid" : oControllerS6.caseguid,
       "Fullname" : sendTo,
       "PosidLed" : processingDate,
       "DueDays" : processingDays,
       "Parentid" : this.byId("daakWftree")
         .getContextByIndex(
           this.byId("daakWftree")
             .getSelectedIndex())
         .getObject().Posid,
      };

      var oWfModel = oControllerS6.getView().getModel();
      oWfModel
        .create(
          "/FILE_PROUTE_ES",
          newObj,
          {
           success : function(oResponse) {

            // Reloading the workflow
            // and closing the busy
            // indicator
            oControllerS6.data.buttons.ISSENDRESPONSE=true;
            oControllerS6
              .reloadWorkflow(oControllerS6);

           },
           error : function(oResponse) {

            // through the error and
            // close the busy indicator
            oControllerS6
              .customBusyDialogClose();
            sap.m.MessageBox.alert(oControllerS6.getView()
              .getModel("i18n").getObject("MESSAGE_68"));
           },
           async : false,
          });
     } else if (sap.ui.getCore().byId("idParallelRadioButton").getSelected() == true) {
      // Parallel scenario is handled here

      var parList = sap.ui.getCore().byId(
        "idProcessorsTable").getModel("dummy")
        .getData().data;
      if (parList.length < 1) {
       // Raise an error to select two or more entries
       sap.m.MessageBox
         .alert(this.getView().getModel("i18n").getObject("MESSAGE_90"));
       oControllerS6.customBusyDialogClose();
       return;
      }
      var oModel = oControllerS6.getView().getModel();
      // set batch use as true
      oModel.setUseBatch(true);
      oModel.clearBatch();
      var isParallel = "X";
      var nodeType = "P";
      for (var i = 0; i < parList.length; i++) {
//       var sendTo = parList[i].Name;
       var activity = parList[i].Actdc;
       var processingDate = parList[i].Date;
       var processingDays = 0;
       if(parList[i].Days != ""){
        processingDays = parseInt(parList[i].Days);
       }
       var agent = parList[i].Agent;
       var activityKey = parList[i].Activity;
       var op = " ";
       var parentid = oControllerS6.byId("daakWftree")
        .getContextByIndex(
          oControllerS6.byId("daakWftree")
            .getSelectedIndex()).getObject().Posid;


       if (i == parList.length - 1) {
        op = "INTRAY";  // op --> Represents that
            // this is the last record
            // sent in the create call.
            // This flag is used to
            // store data to DB
       }
       var batchOp = oModel
         .createBatchOperation(
           "/FILE_PROUTE_ES",
           'POST',
           {
            "isParallel" : isParallel,
            "Nodetype" : nodeType,
            "Actdc" : activity,
            "Activity" : activityKey,
            "CaseGuid" : oControllerS6.caseguid,
            "WitemId" : oControllerS6.wiId,
            "Agent" : agent,
            "PosidLed" : processingDate,
            "DueDays" : processingDays,
            "op" : op,
            "Parentid" : parentid,
           });

       // add batch operation
       oModel.addBatchChangeOperations([ batchOp ]);
       isParallel = 'X'; // all the rows inserted
            // after the first one need
            // to be inserted in
            // parallel to it
      }

      // submit the batch and store the results
      oModel.submitBatch(function(oResponse, oData) {
       // Success function
       // Reloading the workflow and closing the busy
       // indicator
       oControllerS6.reloadWorkflow(oControllerS6);
//       oControllerS2.customBusyDialogClose();
      }, function(oResponse) {
       // failure function
       // through the error and close the busy
       // indicator
       oControllerS6.customBusyDialogClose();
      }, true);

     }
     oControllerS6.oSequenceSend.close();
               }
        },
        reloadWorkflow : function(controller) {
   // load the service and set the model
   controller.customBusyDialogOpen();
   oWorkflowModel = new sap.ui.model.json.JSONModel();
   oWorkflowModel
     .attachRequestCompleted(
       controller,
       function(oEvent) {
        oWorkflowModel
          .detachRequestCompleted();
        var result = oWorkflowModel.oData.d.results;
        for(var i=0;i<result.length;i++){
         if(result[i].Photourl=="/sap/zmys/anand.jpg"){
                        result[i].Photourl="";
                       }
                       result[i].Photourl = decodeURIComponent(result[i].Photourl);
                      }

        controller.data.workflow = oWorkflowModel.oData.d.results;

        controller.getView().getModel(
          "createdaak").checkUpdate();
        /*controller.byId("idWorkflowGrid")
          .setBusy(false);*/
        controller
          .initializeWorkflow(controller);
        controller.getView().getModel(
          "createdaak").checkUpdate();
        controller.byId("daakWftree").setSelectedIndex(-1);
        controller.byId("idDaakDeleteButton")
          .setEnabled(false);
        controller.byId("idDaakAddNewWorkflowButton").setEnabled(false);
        controller.customBusyDialogClose();
       }, controller);
   oWorkflowModel.loadData(serviceUrl
     + "/FILE_PROUTE_ES?$filter=CaseGuid eq '"
     + controller.caseguid + +"' and TabType eq '"
     + controller.fromTab + "' and WitemId eq '"
     + controller.wiId + "' and ISDAAK eq true", null, true);
  },
  initializeWorkflow : function(controller) { // CHANGE

   var oTreeTable = controller.getView().byId("daakWftree");
   var result = controller.data.workflow;
   //Replace '_' with '0' for sorting purpose
            for(var i=0;i<result.length;i++){
             result[i].sortIndex=result[i].Label.split('_').join('0');
            }
          //To sort the workflow for adding special nodes
            result.sort(function(a, b){ 
             return a.sortIndex-b.sortIndex;
            });
   if (result.length > 0) {
    if (result[1].IsSuperUser) {
     oControllerS6.workflowAdminAuthorization = true;
    }
    if (result[1].AddParallel){
     oControllerS6.workflowParallelEnabled = true;
    }

   }
   oControllerS6.flatTreeTableData = result;
   for (var i = 1; i < result.length; ++i) {
    result[i].Label=(parseInt(result[i].Label.substring(0,1))+1).toString()+result[i].Label.substring(1,result[i].Label.length);
   }
   for (var i = 0; i < result.length; i++) {
    //result[i].Photourl = decodeURIComponent(result[i].Photourl);
    result[i].shortPrefix1 = decodeURIComponent(result[i].Prefix1).substring(0, 500)+"<a/>";
//    }
//    if(result[i].Prefix2.substr(result[i].Prefix2.length-6,result[i].Prefix2)-1!="</br>"){
    result[i].shortPrefix2 = decodeURIComponent(result[i].Prefix2).substring(0, 500)+"<a/>";
//    }
    if (result[i].PosidWiid == oControllerS6.wiId) {
     oControllerS6.wftreeIndex = i;
     break;
    }

   }
   var obj = {
    "nodes" : [],
    "Label" : "Sequence"
   };

   oControllerS6.addPrefixLineBreak = false;
   for (var i = 0; i < result.length; ++i) {
//    if(result[i].Label.length==1){

//    }
    if(result[i].Nodetype=="PB"){
                  result[i].Nodetype="PB*";
                  var spclNode = {
                       "nodes" : [],
                       "Fullname" : "Parallel Steps",
                       "Label" : result[i].Label,
                       "Posid" : result[i].Posid,
                       "Parentid" : result[i].Parentid,
                       "Nodetype" : "P",
                       "isParallel" : "X",
                       "isSpecial" : "X"
                     };

                  result.splice(i,0,spclNode);
                  var t=i+1,l=0,prevLabel;
                  //Till the whole parallel block is found
                  while(result[t].Nodetype!="PE"){ 
                   //All children sequence nodes will be handled by the changeLevel function
                   if(result[t].Nodetype!="S"){ 
                   prevLabel = result[t].Label;
                   result[t].Label = result[i].Label+"_"+(++l);
                   oControllerS6.changeLevels(result,result[t].Label,prevLabel,t);
                   }
                   t++;
                  }
                  prevLabel = result[t].Label;
                  result[t].Label = result[i].Label+"_"+(++l);
                  oControllerS6.changeLevels(result,result[t].Label,prevLabel,t);
                 }
    result[i].__metadata = null;
    var levels = result[i].Label.split("_");

    for (var k = 0; k < levels.length; ++k) {
     levels[k] = parseInt(levels[k]) - 1;
    }

    var tempObj = obj;

    for (var j = 0; j < levels.length - 2; ++j) {
     tempObj = tempObj.nodes[levels[j]];
    }

    if (tempObj.nodes[levels[j]] == undefined) {
     result[i].nodes = [];
     tempObj.nodes[levels[j]] = result[i];
     continue;
    }

    result[i].nodes = [];
    tempObj.nodes[levels[j]].nodes.push(result[i]);
   }
   var selectedNodeData=oTreeTable.getContextByIndex(oTreeTable.getSelectedIndex());
   oTreeModel = new sap.ui.model.json.JSONModel();
   oTreeModel.setData(obj);

   oTreeTable.setModel(oTreeModel); // set model to
   // Table*/

   oTreeTable.bindRows("/");
   oTreeTable.setExpandFirstLevel(true);
   if(selectedNodeData){
                var sndPath = selectedNodeData.getPath().split('/');
                var expandIndex=parseInt(sndPath[2]);
                for(var i=4;i<sndPath.length;i+=2){
                 oTreeTable.expand(expandIndex);
                 expandIndex+=parseInt(sndPath[i])+1;
                }
            }
  },

  onWorkflowItemSelect : function(oEvent) {
   if(oControllerS6.fromTab=="DRAFTDAAK" || oControllerS6.fromTab=="CREATEDAAK"){
    if (!oControllerS6._workflowActionSheet || oControllerS6._workflowActionSheet.getButtons().length == 0){
     this._workflowActionSheet = sap.ui.xmlfragment(
       "flm.fiori.view.addNewWorkflow", this);
     this.getView().addDependent(this._workflowActionSheet);
    }
             if(oControllerS6.byId("daakWftree").getSelectedIndex()==-1){
              oControllerS6.byId("idDaakDeleteButton").setEnabled(false);
                 sap.ui.getCore().byId("addInParallel").setEnabled(false);
              oControllerS6.byId("idDaakAddNewWorkflowButton").setEnabled(true);

             }else if(oControllerS6.byId("daakWftree").getSelectedIndices().length>1){
              oControllerS6.byId("idDaakDeleteButton").setEnabled(true);
              oControllerS6.byId("idDaakAddNewWorkflowButton").setEnabled(false);
             }else{
              oControllerS6.byId("idDaakAddNewWorkflowButton").setEnabled(true);
              oControllerS6.byId("idDaakDeleteButton").setEnabled(true); 
                 sap.ui.getCore().byId("addInParallel").setEnabled(true);
                var lmod = this.getView().byId("daakWftree").getModel("workflow").oData;
                if(lmod.nodes[0].isParallel=="")
                {sap.ui.getCore().byId("addInParallel").setEnabled(false);}
             }
   }else{
   if (this.byId("daakWftree").getSelectedIndex() == "-1") {
    // hide the delete button
    this.byId("idDaakDeleteButton").setEnabled(false);
    this.byId("idDaakAddNewWorkflowButton").setEnabled(false);
    return;
   }else if(oControllerS6.byId("daakWftree").getSelectedIndices().length>1){
          oControllerS6.byId("idDaakDeleteButton").setEnabled(false);
          oControllerS6.byId("idDaakAddNewWorkflowButton").setEnabled(false);
          return;
         }
   var currNode = this.byId("daakWftree").getContextByIndex(
     this.byId("daakWftree").getSelectedIndex())
     .getObject();

   // Already processed users cannot be selected for both adding and deleting
   if (currNode.Enddate != ""){
    // hide the delete button
    this.byId("idDaakDeleteButton").setEnabled(false);
    //if special node then check for the last child node, if it has not completed processing enable add button
    if(currNode.isSpecial!='X'){
    this.byId("idDaakAddNewWorkflowButton").setEnabled(false);
    }else{
     if(currNode.nodes[currNode.nodes.length-1].Enddate!=""){
      this.byId("idDaakAddNewWorkflowButton").setEnabled(false);
     }else{
      this.byId("idDaakAddNewWorkflowButton").setEnabled(true);
     }
    }
    return;
   }
   // Currently processing users can add after them but not delete
   else if (currNode.Creadate != "" && currNode.Enddate == ""){
    // hide the delete button
    this.byId("idDaakDeleteButton").setEnabled(false);

    // add button visibility
    // Special authorized person can also add

    if (oControllerS6.workflowAdminAuthorization) {
     this.byId("idDaakAddNewWorkflowButton").setEnabled(true);
    } else if (currNode.PosidWiid == oControllerS6.wiId) {
     /*Add button will be displayed based on whether he had already added or not*/
     if(this.byId("daakWftree").getContextByIndex(this.byId("daakWftree").getSelectedIndex()+1)){
      var nextNode = this.byId("daakWftree").getContextByIndex(
        this.byId("daakWftree").getSelectedIndex()+1)
        .getObject();
      // if next row is inserted by him then he cannot add
      if(nextNode.IsDelete){
       this.byId("idDaakAddNewWorkflowButton").setEnabled(false);
      }else{
       this.byId("idDaakAddNewWorkflowButton").setEnabled(true);
      }
     }else{
      this.byId("idDaakAddNewWorkflowButton").setEnabled(true);
     }

    } else {
     this.byId("idDaakAddNewWorkflowButton").setEnabled(false);
    }
    if(currNode.isSpecial=='X'){
    var selPath = oControllerS6.byId("daakWftree").getContextByIndex(oControllerS6.byId("daakWftree").getSelectedIndex()).getPath().split('/');
    var selNode = oControllerS6.byId("daakWftree").getModel().oData;
    for(var i=2;i<selPath.length-2;i+=2){
     if(i!=selPath.length-3){
      selNode=selNode.nodes[parseInt(selPath[i])];
     }else{
      selNode=selNode.nodes[parseInt(selPath[i])+1];
     }
    }
    if(!selNode || selNode.Pospast==""){
     this.byId("idDaakAddNewWorkflowButton").setEnabled(true);
    }else{
     this.byId("idDaakAddNewWorkflowButton").setEnabled(false);
    }
    }
    return;
   }

   /* 1. In future processors, authorised person can delete/add users as per his wish
    * 2. Normal processor can user can add 1(sequntial)/multiple(parallel) under him and 
    *    delete the added ones before he sends the file to next processor.
    */
   else if (currNode.Creadate == "" && currNode.Enddate == ""){
    if (oControllerS6.workflowAdminAuthorization ) {     // Super user or the processors the current users has added
     this.byId("idDaakDeleteButton").setEnabled(true);
     this.byId("idDaakAddNewWorkflowButton").setEnabled(true);
    }else if (currNode.IsDelete == true){
     this.byId("idDaakDeleteButton").setEnabled(true);
     // addition is allowed but only in parallel
     if(this.workflowParallelEnabled){
      this.byId("idDaakAddNewWorkflowButton").setEnabled(true);
     }else{
      this.byId("idDaakAddNewWorkflowButton").setEnabled(false);
     }
    }
    else {
     this.byId("idDaakDeleteButton").setEnabled(false);
     this.byId("idDaakAddNewWorkflowButton").setEnabled(false);
    }
    return;
   }
   }
  },
           handleValueHelp : function(oEvent) {
               oControllerS6.customBusyDialogOpen("");
               if (!oControllerS6._oDynamicF4Dialog) {
                      oControllerS6._oDynamicF4Dialog = sap.ui
                                    .xmlfragment(
                                                  "flm.fiori.view.dynamicF4popup",
                                                 oControllerS6);

               }
               
               var otypeModel = new sap.ui.model.json.JSONModel();
               
               oF4Texts = new sap.ui.model.json.JSONModel();
               if (oEvent.getSource().getId() == "idUsername") {
                      var f4text = {

                             title : sap.ui.getCore().byId("idSelect1")
                                           .getSelectedItem().getText(),

                             id : "idUsername",

                             path : "/d/results"
                      };
                      
                      if (sap.ui.getCore().byId("idSelect1").getSelectedKey() != 'SPACE') {
                       otypeModel.attachRequestCompleted(oControllerS6,function(oEvent){
                        otypeModel.setData(otypeModel.oData.d.results);
                        oControllerS6._oDynamicF4Dialog.setModel(otypeModel);
                            oControllerS6.customBusyDialogClose();
                            otypeModel.detachRequestCompleted();
                            },oControllerS6);
                       otypeModel.loadData(serviceUrl
                                       + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                               + this.caseguid
                                                               + "' and ID eq '"
                                       + sap.ui.getCore().byId("idSelect1").getSelectedKey()
                                       + "' and WF eq true", null, false);
                          
                      }
                      oControllerS6._oDynamicF4Dialog.setModel(otypeModel);
                      
               }else if (oEvent.getSource().getId() == "idOrgUnit") {
                      

                      otypeModel
                                    .loadData(
                                                 serviceUrl
                                                               + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                               + this.caseguid
                                                               + "' and ID eq 'O' and WF eq true",
                                                 null, false);
                      var otextModel = new sap.ui.model.json.JSONModel();
                      var f4text = {

                             title : this.getView().getModel("i18n").getObject("ORG_UNIT"),

                             id : "idOrgUnit",

                             path : "/d/results"
                      };
                      var oResponse=otypeModel.oData.d.results;
                      otypeModel.setData(oResponse);
                      oControllerS6._oDynamicF4Dialog
                                    .setModel(otypeModel);
                      oControllerS6.customBusyDialogClose();
               } else if (oEvent.getSource().getId() == "idFactoryCalendar") {
                      

                      otypeModel
                                    .loadData(
                                                 serviceUrl
                                                               + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                               + this.caseguid
                                                               + "' and ID eq 'FC' and OtherF4 eq true",
                                                 null, false);
                      var otextModel = new sap.ui.model.json.JSONModel();
                      var f4text = {

                             title : this.getView().getModel("i18n").getObject("FACTORY_CALENDAR"),

                             id : "idFactoryCalendar",

                             path : "/d/results"
                     };
                      var oResponse=otypeModel.oData.d.results;
                      otypeModel.setData(oResponse);
                      oControllerS6._oDynamicF4Dialog
                                    .setModel(otypeModel);
                      oControllerS6.customBusyDialogClose();
               } else if (oEvent.getSource().getId() == "idProcessorName") {
                   var f4text = {

                           title : sap.ui.getCore().byId("idProcessorSelect")
                                         .getSelectedItem().getText(),

                           id : "idProcessorName",

                           path : "/d/results"
                    };
                    
                    if (sap.ui.getCore().byId("idProcessorSelect").getSelectedKey() != 'SPACE') {
                     otypeModel.attachRequestCompleted(oControllerS6,function(oEvent){
                      otypeModel.setData(otypeModel.oData.d.results);
                      oControllerS6._oDynamicF4Dialog.setModel(otypeModel);
                          oControllerS6.customBusyDialogClose();
                          otypeModel.detachRequestCompleted();
                          },oControllerS6);
                     otypeModel.loadData(serviceUrl
                                     + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                             + this.caseguid
                                                             + "' and ID eq '"
                                     + sap.ui.getCore().byId("idProcessorSelect").getSelectedKey()
                                     + "' and WF eq true", null, false);
                        
                    }
                    oControllerS6._oDynamicF4Dialog.setModel(otypeModel);
                    
             } else {
                      var f4text = {

                             title : this.getView().byId("daakReceiverTypeNoting").getSelectedItem().getText(),

                             id : "daakProcessorInput",

                             path : "/d/results"

                      };
                      if (oControllerS6.getView().byId("daakReceiverTypeNoting").getSelectedKey() != 'SPACE') {
                       otypeModel.attachRequestCompleted(oControllerS6,function(oEvent){
                        otypeModel.setData(otypeModel.oData.d.results);
                        oControllerS6._oDynamicF4Dialog.setModel(otypeModel);
                            oControllerS6.customBusyDialogClose();
                            otypeModel.detachRequestCompleted();
                            },oControllerS6);
                          otypeModel.loadData(serviceUrl
                                       + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                               + this.caseguid
                                                               + "' and ID eq '"
                                       + oControllerS6.getView().byId("daakReceiverTypeNoting").getSelectedKey()
                                       + "' and WF eq true", null, false);
                          }
                      oControllerS6._oDynamicF4Dialog.setModel(otypeModel);
                      
               }

               oF4Texts.setData(f4text);

               oControllerS6._oDynamicF4Dialog.setModel(

               oF4Texts, "dyntext");
               oControllerS6.customBusyDialogClose();
               // open value help dialog
               oControllerS6._oDynamicF4Dialog.open();
        },
        
     openBusinessCard : function(oEvent) {
            if(oControllerS6.setCustomBusinessCard){
             oControllerS6.setCustomBusinessCard(oControllerS6,oEvent);
              }else{
                     if (!oControllerS6._oBusinessCard) {
                     oControllerS6._oBusinessCard = sap.ui.xmlfragment(
                                   "flm.fiori.view.businessCard", oControllerS6);
              }
              // oControllerS3._oBusinessCard.setModel(oControllerS2.oTreeTable.getModel());
              var contactModel = new sap.ui.model.json.JSONModel();
              contactModel.setData(oEvent.getSource().getBindingContext().getObject());
              oControllerS6._oBusinessCard.setModel(contactModel);
              oControllerS6._oBusinessCard.bindElement("/");
              oControllerS6._oBusinessCard.openBy(oEvent.getSource());
              }
},

openNoteText : function(oEvent) {
             if (!oControllerS6.noteTextExpand) {
             oControllerS6.noteTextExpand = sap.ui.xmlfragment(
                           "flm.fiori.view.noteTextWorkflow", oControllerS6);
      }
      // oControllerS3._oBusinessCard.setModel(oControllerS2.oTreeTable.getModel());
      var noteTextModel = new sap.ui.model.json.JSONModel();
      noteTextModel.setData(oEvent.getSource()
                    .getBindingContext("workflow").getObject());
      oControllerS6.noteTextExpand.setModel(noteTextModel);
      oControllerS6.noteTextExpand.bindElement("/");
      oControllerS6.noteTextExpand.openBy(oEvent.getSource());
      
},


 // Send Daak Actions
  sendDaakEventPressed : function(oEvent,isRes) {
//    oEvent.getSource().getParent().close();
    //To check whether daak is sent for response or normally
    /*var isResponse="";
    if(this["confirmDialog"]){
     isResponse=this["confirmDialog"].isResponse;
    }*/
   var messageText = "";
   if(oEvent.getSource().getId() == "sendDaakAction"){
    isRes = "";
    messageText = oControllerS6.getView().getModel("i18n").getObject("MESSAGE_82");
   }else if(oEvent.getSource().getId() == "sendResponseAction"){
    isRes = "R";
    messageText = oControllerS6.getView().getModel("i18n").getObject("MESSAGE_84");
   }
    this.customBusyDialogOpen();
    sap.m.MessageBox.confirm(messageText,
      function(response) {
        if (response == "OK") {
    if(oControllerS6.data.basic.DigSignReq || oControllerS6.createSignFlag){
      if(oControllerS6.customDigitalSignData){
       oControllerS6.customDigitalSignData(oControllerS6.data, jQuery.proxy(function() {
        oControllerS6.confirmSendFile(oControllerS6.caseguid,
          oControllerS6.fileid,
          oControllerS6.fromTab,isRes);
                    
                    }, oControllerS6));
      }else{
       sap.m.MessageBox.alert(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_73"));
       oControllerS6.customBusyDialogClose();
      }
     }
     else{
      oControllerS6.confirmSendFile(oControllerS6.caseguid,oControllerS6.fileid,oControllerS6.fromTab,isRes);
     }
    }
   });

   },

   /*Send file action on user response */

 confirmSendFile : function(caseguid, fileid, fromTab,
   isRes,isConfirmed) {
  if (isConfirmed == null) {
   isConfirmed = "";
  }
  var oModel = new sap.ui.model.json.JSONModel();

  oModel
    .attachRequestCompleted(
      oControllerS6,
      function(oEvent) {

       oModel.detachRequestCompleted();

       if (oModel.getData().d.results[0].msg_type == "C"
         && oModel.getData().d.results[0].msg_id == 373) {
        sap.m.MessageBox
          .confirm(
            oModel
              .getData().d.results[0].msg_text,
            function(
              response) {
             if (response == "OK") {
              // check for digital signature customizationg
              if(oControllerS6.data.basic.DigSignReq || oControllerS6.createSignFlag){
               if(oControllerS6.customDigitalSignData){
                oControllerS6.customDigitalSignData(oControllerS6.data, jQuery.proxy(function() {
                    oControllerS6.confirmSendFile(oControllerS6.caseguid,
                      oControllerS6.fileid,
                      oControllerS6.fromTab,isRes, "X");
                                
                                }, oControllerS6));
               }
               else{
                sap.m.MessageBox.alert(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_73"));
                oControllerS6.customBusyDialogClose();
               }
              }else{
               oControllerS6.confirmSendFile(caseguid,fileid,fromTab,isRes,"X");
              }
             } else {
              oControllerS6
                .customBusyDialogClose(oControllerS6);
             }
            });

       } else if (oModel.getData().d.results[0].msg_type == "E") {
        oControllerS6
          .customBusyDialogClose(oControllerS6);
        sap.m.MessageBox
          .alert(oModel.getData().d.results[0].msg_text);
       } else {

        // delete the file from the tab

        var oTableId = null;
        var oEntitySet = null;

        switch (oControllerS6.fromTab) {
        case "INTRAYDAAK":
         oTableId = "idFilesTable";
         oEntitySet = "/FILE_INTRAY_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
         break;

        case "DRAFTDAAK":
         oTableId = "idDraftsTable";
         oEntitySet = "/FILE_DRAFT_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
         break;

        case "SUBSTDAAK":
         oTableId = "idSubstituteTable";
         oEntitySet = "/FILE_SUBST_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
         break;
        }

        var tempModel = oControllerS6.oRouter
          .getView(
            "flm.fiori.view.S1")
          .byId(oTableId)
          .getModel("files");

        tempModel
          .attachRequestCompleted(
            oControllerS6,
            function(oEvent) {
             tempModel
               .detachRequestCompleted();
             if (tempModel.oData.d != undefined) {
              tempModel
                .setData(tempModel.oData.d);
              tempModel
                .checkUpdate();
              sap.m.MessageToast
                .show(oModel
                  .getData().d.results[0].msg_text);
             }
             oControllerS6
               .customBusyDialogClose(oControllerS6);
             oControllerS6.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId(
                 "sendAction")
               .setEnabled(
                 false);
             oControllerS6.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId(
                 oTableId)
               .removeSelections();
             destroyDialogs(oControllerS6); //destroy all common fragments
             oControllerS6.oRouter
               .navTo("fullscreen");
            },
            oControllerS6);
        tempModel.loadData(serviceUrl
          + oEntitySet, null,
          true);
       }

      }, oControllerS6);
  //Add Processor for SendResponse
  if(isRes=="R"){
   oControllerS6.addResponseNode();
  }

  oModel
  .loadData(
    serviceUrl
      + "/FILES_FI?param_1='SE'&param_2='"
      + oControllerS6.caseguid
      + "'&param_3='"+oControllerS6.wiId+"'&param_4='"
      + oControllerS6.fileid
      + "'&param_5=''&check_1=''&check_2='ISDAAK'&check_3=''&param_6=''&param_7='"
      + oControllerS6.fromTab
      + "'&param_8=''&param_9=''&param_10=''",
    null, false);

 },

   onDialogCloseButton : function(oEvent) {
    oControllerS6.customBusyDialogClose();
         if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                oEvent.getSource().getParent().close();
         } else {
                oEvent.getSource().getParent().getParent().close();
         }
  },

        onDialogCloseButtonF4 : function(oEvent) {
                             if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                                    oEvent.getSource().getParent().close();
                             } else {
                                    oEvent.getSource().getParent().getParent().close();
                             }
                      },
        handleDeleteProcessor : function(evt) { // ADD CHANGE
      var oTable = sap.ui.getCore().byId("idProcessorsTable");
      // var
      // i=evt.getParameter("listItem").getBindingContext("dummy").getObject().position;
      for (var i = 0; i < oTable.getItems().length; i++) {
       if (evt.getParameter("listItem").getBindingContext(
         "dummy").getObject().position == oTable
         .getItems()[i].getBindingContext("dummy")
         .getObject().position) {
        evt.getSource().getModel("dummy").oData.data
          .splice(i, 1);
        break;
       }
      }

      evt.getSource().getModel("dummy").checkUpdate();
     },

  onAddClick : function(oEvent) { // CHANGE
      
      var oTable = sap.ui.getCore().byId("idProcessorsTable");
      var processor = sap.ui.getCore().byId("idSelect1")
                    .getSelectedItem().getText();
      var sendTo = sap.ui.getCore().byId("idUsername")
                    .getValue();
      var agent = sap.ui.getCore().byId("idUsername")
                    .getName();
      var activity = sap.ui.getCore().byId("idSelect2")
                    .getSelectedItem().getText();
      var activityKey = sap.ui.getCore().byId("idSelect2")
                    .getSelectedItem().getKey();
      var processingDate = "";
      if (sap.ui.getCore().byId(
      "idDatePickerSendTo").getValue() !=""){
             processingDate = sap.ui.getCore().byId(
             "idDatePickerSendTo").getValue();
      }
      var processingDay = sap.ui.getCore()
                    .byId("idInputDays").getValue();
      if ((sendTo == "" || activity == "" || processor == "")) {
             sap.m.MessageToast.show(this.getView().getModel(
                           "i18n").getObject("MESSAGE_20"));
             return;
      }
      if (processingDate != "" && processingDay != "") {
             sap.m.MessageToast.show(this.getView().getModel(
                           "i18n").getObject("MESSAGE_21"));
             return;
      }
      var oModel = oTable.getModel("dummy");
      oModel.getData().data.push({
             "Processor" : sap.ui.getCore().byId("idSelect1")
                           .getSelectedItem().getText(),
             "Name" : sap.ui.getCore().byId("idUsername")
                           .getValue(),
             "Agent" : sap.ui.getCore().byId("idUsername")
                           .getName(),
             "Activity" : sap.ui.getCore().byId("idSelect2")
                           .getSelectedItem().getKey(),
             "Actdc" : sap.ui.getCore().byId("idSelect2")
                           .getSelectedItem().getText(),
             "Date" : sap.ui.getCore()
                           .byId("idDatePickerSendTo").getValue(),
             "Days" : sap.ui.getCore().byId("idInputDays")
                           .getValue(),
             "position" : oControllerS6.gCounter++,
      });
      oModel.checkUpdate();
      
      //Resetting the fields
      sap.ui.getCore().byId("idUsername").setValue("");
      sap.ui.getCore().byId("idUsername").setName("");
      sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
      sap.ui.getCore().byId("idInputDays").setValue("");
      sap.ui.getCore().byId("idSelect2").setSelectedKey();
   },

   onDeleteSelect : function(oEvent){
             if(oControllerS6.getView().byId("daakWftree").getSelectedIndex()==-1){
              sap.m.MessageBox.alert(oControllerS6.getView().getModel("i18n").getObject("MESSAGE76"));
              return;
             }
    sap.m.MessageBox.confirm(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_92"),
               function(response) {
       if (response == "OK") {
        oControllerS6.customBusyDialogOpen();
//                         var currNode = oControllerS2.byId("wftree").getContextByIndex(
//                           oControllerS2.byId("wftree").getSelectedIndex());
                         oControllerS6.onDeleteButtonPress();
//          oControllerS6.reloadWorkflow(oControllerS2);
//       oControllerS2.byId("wftree").setSelectedIndex(-1);
       }
       else{
        oControllerS6.customBusyDialogClose();
        return;
       }
                   });
            },

   onDeleteButtonPress : function(oEvent){
   if(oControllerS6.getView().byId("daakWftree").getSelectedIndex()==-1){
   sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_91"));
   return;
   }
   oControllerS6.customBusyDialogOpen();
   var selectedNodes=oControllerS6.byId("daakWftree").getSelectedIndices();
   for(var i=selectedNodes.length-1;i>=0;i--){
   var currNode = oControllerS6.byId("daakWftree").getContextByIndex(
              selectedNodes[i])
              .getObject();
   oControllerS6.deleteCurrentNode(currNode);
   }
   if(oControllerS6.fromTab=="CREATEDAAK" || oControllerS6.fromTab=="DRAFTDAAK"){
   oControllerS6.loadTreeTable();
   }else{
   oControllerS6.reloadWorkflow(oControllerS6);
   }
       oControllerS6.byId("daakWftree").setSelectedIndex(-1);
   },

   deleteCurrentNode : function(currNode){
   var oModel = oControllerS6.getView().getModel();
   if(currNode.isSpecial=="X"){
   for(var i=0;i<currNode.nodes.length;i++){
   if(currNode.nodes[i].uiDeleted!='X'){
   oControllerS6.deleteCurrentNode(currNode.nodes[i]);
   }
   }
   }else{

   oModel.remove("/FILE_PROUTE_ES(Posid='"
              + currNode.Posid + "',CaseGuid='"
              + oControllerS6.caseguid + "',WitemId='"+oControllerS6.wiId+"')", {
       success : function(oResponse) {

              currNode.uiDeleted="X"; //To prevent multiple deletion in case of parallel block
              oControllerS6.customBusyDialogClose();
       },
       error : function(oResponse) {
              oControllerS6.customBusyDialogClose();
       },
       async : false,
   });
   }
   },

  //Create Daak Number Format
   createDaakNo : function() {
          
          var daak_type = sap.ui.getCore().getModel("passdaak").getData()[0];
          
          // setting the name of Creator
          this.getView().byId("idDaakCreatedBy").setValue(
                        this.createFileResponse[0].UNAME);
          oControllerS6.createSignFlag = this.createFileResponse[0].DigSignReq;
          var vbox = new sap.m.VBox({});
          var hbox = this.getView().byId("idDaakNumberHbox");
          if (hbox.getItems()[0] != undefined) {
                 hbox.removeAllItems();
          }
          var l ;
          if(this.createFileResponse.length < 10){
          l = 90 / this.createFileResponse.length;
          }else{
          l = 180 / this.createFileResponse.length;
          } 
          for ( var i = 0; i < this.createFileResponse.length; i++) {
                 var elemID = "FID00" + i;

                 if (this.createFileResponse[i].NAME == "SEPR") {
                        hbox.addItem(new sap.m.VBox({
                               width : "1.5rem"
                        }));
                        hbox.getItems()[i].addItem(new sap.m.Text({
                               text : this.createFileResponse[i].HEADER
                        }));
                        hbox.getItems()[i]
                                      .addItem(new sap.ui.core.HTML({
                                            content : "<span>&nbsp;</span>"
                                      }));
                        hbox.getItems()[i]
                                      .addItem(new sap.m.Text(
                                                   elemID,
                                                   {
                                                          text : this.createFileResponse[i].VALUE,
                                                          textAlign : "Center",
                                                          vAlign : "Center",
                                                          hAlign : "Center"
                                                   }));
                        hbox.getItems()[i].getItems()[2]
                                      .addStyleClass("separator");
                        hbox.getItems()[i]
                                     .addItem(new sap.ui.core.HTML({
                                            content : "<span>&nbsp;</span>"
                                      }));
                        // hbox.addItem(new sap.m.Text({text:
                        // this.createFileResponse[i].HEAD}));
                 }

                 else if (this.createFileResponse[i].NAME == "GRPN"
                               || this.createFileResponse[i].NAME == "CNRN"
                               || this.createFileResponse[i].NAME == "GRPY"
                               || this.createFileResponse[i].NAME == "CNRY" || this.createFileResponse[i].NAME == "NRYN" || this.createFileResponse[i].NAME == "NRYD") {
                        hbox.addItem(new sap.m.VBox({
                               width : l + "%"
                        }));
                        hbox.getItems()[i].addItem(new sap.m.Text({
                               text : this.createFileResponse[i].HEADER,
                               tooltip : this.createFileResponse[i].HEADER,
                               wrapping:false
                        }));
                        hbox.getItems()[i]
                                      .addItem(new sap.ui.core.HTML({
                                            content : "<HR/>"
                                      }));
                        hbox.getItems()[i]
                                      .addItem(new sap.m.Input(
                                                   elemID,
                                                   {
                                                          type : "Text",
                                                          value : this.createFileResponse[i].VALUE,
                                                          name : this.createFileResponse[i].NAME,
                                                          editable : false
                                                   }));
                 }

                 else if (this.createFileResponse[i].NAME == "FTXT") {

                        if (this.createFileResponse[i].F4VALUES != "") {
                               hbox.addItem(new sap.m.VBox({
                                      width : l + "%"
                               }));
                               hbox.getItems()[i]
                                            .addItem(new sap.m.Text(
                                                          {
                                                                 text : this.createFileResponse[i].HEADER,
                                                                 tooltip : this.createFileResponse[i].HEADER
                                                          }));
                               hbox.getItems()[i]
                                            .addItem(new sap.ui.core.HTML({
                                                   content : "<HR/>"
                                            }));
                               hbox.getItems()[i]
                                            .addItem(new sap.m.Input(
                                                          elemID,
                                                          {
                                                                 type : "Text",
                                                                 placeholder : oControllerS6.getView().getModel("i18n").getObject("SELECT"),
                                                                 valueHelpRequest : "handleValueHelpDaakNo",
                                                                 showValueHelp : true
                                                          }));

                        } else if (this.createFileResponse[i].DDVALUES != "") {
                               hbox.addItem(new sap.m.VBox({
                                      width : l + "%"
                               }));
                               hbox.getItems()[i]
                                            .addItem(new sap.m.Text(
                                                          {
                                                                 text : this.createFileResponse[i].HEADER,
                                                                 tooltip : this.createFileResponse[i].HEADER,
                                                                 wrapping:false
                                                          }));
                               hbox.getItems()[i]
                                            .addItem(new sap.ui.core.HTML({
                                                   content : "<HR/>"
                                            }));
                               var arr = getF4Array(this.createFileResponse[i].DDVALUES);
                               var ddmodel = new sap.ui.model.json.JSONModel();
                               ddmodel.setData(arr);
                               var ddsel = new sap.m.Select(elemID, {
                                      autoAdjustWidth : true,
                                      value : "Select",
                                      items : {
                                            path : "/",
                                            template : new sap.ui.core.Item({
                                                   key : "{ResulltCol1}",
                                                   text : "{ResulltCol1}"
                                            })
                                      }
                               });
                               ddsel.setModel(ddmodel);
                               hbox.getItems()[i].addItem(ddsel);
                        } else {
                               hbox.addItem(new sap.m.VBox({
                                      width : l + "%"
                               }));
                               hbox.getItems()[i]
                                            .addItem(new sap.m.Text(
                                                          {
                                                                 text : this.createFileResponse[i].HEADER,
                                                                 tooltip : this.createFileResponse[i].HEADER,
                                                                 wrapping:false
                                                          }));
                               hbox.getItems()[i]
                                            .addItem(new sap.ui.core.HTML({
                                                   content : "<HR/>"
                                            }));
                               hbox.getItems()[i]
                                            .addItem(new sap.m.Input(
                                                          elemID,
                                                          {
                                                                 type : "Text",
                                                                 value : this.createFileResponse[i].VALUE
                                                          }));
                        }

                 } else if (this.createFileResponse[i].NAME == "DATE") {
                  oControllerS6.numberDateObjDaak = "DATE";
                        hbox.addItem(new sap.m.VBox({
                               width : l + "%"
                        }));
                        hbox.getItems()[i].addItem(new sap.m.Text({
                               text : this.createFileResponse[i].HEADER,
                               tooltip : this.createFileResponse[i].HEADER,
                               wrapping:false
                        }));
                        hbox.getItems()[i]
                                      .addItem(new sap.ui.core.HTML({
                                            content : "<HR/>"
                                      }));
                        if (this.createFileResponse[i].F4VALUES != "") {
                               var dummy = new sap.m.Input(
                                            elemID,
                                            {
                                                   type : "Text",
                                                   placeholder : oControllerS6.getView().getModel("i18n").getObject("SELECT"),
                                                   valueHelpRequest : this.handleValueHelpDaakNo,
                                                   showValueHelp : true
                                            });
                               hbox.getItems()[i].addItem(dummy);
                        } else {
                               hbox.getItems()[i]
                                            .addItem(new sap.m.Input(
                                                          {
                                                                 type : "Text",
                                                                 value : this.createFileResponse[i].VALUE
                                                          }));
                        }
                 }

                 else if (this.createFileResponse[i].NAME == "SYSD") {
                        hbox.addItem(new sap.m.VBox({
                               width : l + "%"
                        }));
                        hbox.getItems()[i].addItem(new sap.m.Text({
                               text : this.createFileResponse[i].HEADER,
                               tooltip : this.createFileResponse[i].HEADER,
                               wrapping:false
                        }));
                        hbox.getItems()[i]
                                      .addItem(new sap.ui.core.HTML({
                                            content : "<HR/>"
                                      }));
                        hbox.getItems()[i]
                                      .addItem(new sap.m.Input(
                                                   elemID,
                                                   {
                                                          type : "Text",
                                                          value : this.createFileResponse[i].VALUE,
                                                          editable : false
                                                   }));

                 } else if (this.createFileResponse[i].NAME == "CONS") {
                        hbox.addItem(new sap.m.VBox({
                               width : l + "%"
                        }));
                        hbox.getItems()[i].addItem(new sap.m.Text({
                               text : this.createFileResponse[i].HEADER,
                               tooltip : this.createFileResponse[i].HEADER,
                               wrapping:false
                        }));
                        hbox.getItems()[i]
                                      .addItem(new sap.ui.core.HTML({
                                            content : "<HR/>"
                                      }));
                        hbox.getItems()[i]
                                      .addItem(new sap.m.Input(
                                                   elemID,
                                                   {
                                                          type : "Text",
                                                          value : this.createFileResponse[i].VALUE,
                                                          editable : false
                                                   }));

                 } else if (this.createFileResponse[i].NAME == "ORGU") {

                        hbox.addItem(new sap.m.VBox({
                               width : l + "%"
                        }));
                        hbox.getItems()[i].addItem(new sap.m.Text({
                               text : this.createFileResponse[i].HEADER,
                               tooltip : this.createFileResponse[i].HEADER,
                               wrapping:false
                        }));
                        hbox.getItems()[i]
                                      .addItem(new sap.ui.core.HTML({
                                            content : "<HR/>"
                                      }));
                        if (this.createFileResponse[i].F4VALUES != "") {
                               var dummy = new sap.m.Input(
                                            elemID,
                                            {
                                                   type : "Text",
                                                   placeholder : oControllerS6.getView().getModel("i18n").getObject("SELECT"),
                                                   valueHelpRequest : this.handleValueHelpDaakNo,
                                                   showValueHelp : true
                                            });
                               hbox.getItems()[i].addItem(dummy);
                        } else {
                               hbox.getItems()[i]
                                            .addItem(new sap.m.Input(
                                                          {
                                                                 type : "Text",
                                                                 value : this.createFileResponse[i].VALUE
                                                          }));
                        }
                 }
          }
   },

   handleValueHelpDaakNo : function(oEvent) {
       
       // Compare event id and set the corresponding F4 values'
       // model
       var i = 0;
       var h = oControllerS6.getView()
                     .byId("idDaakNumberHbox").getItems();
       for (i = 0; i < h.length; i++) {
              var v = h[i].getItems()[2];
              if (v.getId() == oEvent.getSource().getId()) {
                     break;
              }
       }
       var arr;
       if(oControllerS6.numberDateObjDaak == "DATE"){
       arr = getDateArray(oControllerS6.createFileResponse[i].F4VALUES);
       }else{
       arr = getF4Array(oControllerS6.createFileResponse[i].F4VALUES);
       }
       var f4model = new sap.ui.model.json.JSONModel();
       f4model.setData(arr);
       globalModel = f4model;
       
       inputId = oEvent.getSource();
        if (oControllerS6._valueHelpDialog==undefined) {
        oControllerS6._valueHelpDialog = sap.ui.xmlfragment(
                     "flm.fiori.view.F4helpDialog2", oControllerS6);
        }
   //     else
       // if(this._valueHelpDialog.getModel()!=undefined){
       // this._valueHelpDialog.getModel().destroy();
       // }
       var oTable = sap.ui.getCore().byId("idF4ValueTable");
       oTable.setModel(globalModel);
       if (globalModel.oData[0].ResulltCol1 != undefined) {

              var c = sap.ui.getCore().byId("idF4ValueTable")
                            .getColumns();
              sap.ui.getCore().byId("f4collabl1").setText(
                            globalModel.oData[0].ResulltCol1);
       }
       if (globalModel.oData[0].ResultCol2 != undefined) {
              sap.ui.getCore().byId("f4collabl2").setText(
                            globalModel.oData[0].ResultCol2);
       }
       if (globalModel.oData[0].ResulltCol3 != undefined) {
              sap.ui.getCore().byId("f4collabl3").setText(
                            globalModel.oData[0].ResulltCol3);
       }
       oTable.getItems()[0].setVisible(false);
       oControllerS6._valueHelpDialog.open();
   },
     F4ValueSelected : function(oEvent) {
      if(oControllerS6.numberDateObjDaak == "DATE"){
                            var t = oEvent.getParameters().listItem.getCells()[0].getText().substr(0,4);
                      }else{
                       t = oEvent.getParameters().listItem.getCells()[0].getText();
                      }

       inputId.setValue(t);
        if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
         oEvent.getSource().getParent().close();
          } else {
           oEvent.getSource().getParent().getParent().close();
                      }
   },

   /*Confidential State Change*/

   daakConfidentialStateChange: function(oEvent) {
    if (this.getView().byId("idConfidentialDaakSwitch").getState() == false) {
                       oControllerS6.customBusyDialogOpen();
                      var oModel = new sap.ui.model.json.JSONModel();
                      oModel
                                    .loadData(
                                                  serviceUrl
                                                                + "/FILES_FI?param_1='ND'&param_2='"
                                                                + this.caseguid
                                                                + "'&param_3=''&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                                  null, false);
                      if (oModel.getData().d.results.length == 0) {
                       this.getView().byId("idConfidentialDaakSwitch").setTooltip(this.getView().getModel("i18n").getObject("OFF"));
       this.getView().byId("idConfidentialDaakSwitch").rerender();
                       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_69"));
                             oControllerS6.customBusyDialogClose();
                      } else if (oModel.getData().d.results[0].msg_type == 'E') {
                             sap.m.MessageBox
                             .alert(oModel.getData().d.results[0].msg_text);

                      }
                } else if (this.getView().byId("idConfidentialDaakSwitch")
                             .getState() == true) {
                       oControllerS6.customBusyDialogOpen();
                      var oModel = new sap.ui.model.json.JSONModel();
                      oModel
                                    .loadData(
                                                  serviceUrl
                                                                + "/FILES_FI?param_1='CD'&param_2='"
                                                                + this.caseguid
                                                                + "'&param_3=''&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                                  null, false);
                      if (oModel.getData().d.results.length == 0) {
                       this.getView().byId("idConfidentialDaakSwitch").setTooltip(this.getView().getModel("i18n").getObject("ON"));
       this.getView().byId("idConfidentialDaakSwitch").rerender();
                             sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_69"));
                             oControllerS6.customBusyDialogClose();
                      } else if (oModel.getData().d.results[0].msg_type == 'E') {
                             sap.m.MessageBox
                             .alert(oModel.getData().d.results[0].msg_text);
                      }
                }
         },
         
         /*Changes for Integration starts */
         objectButtonPressed : function(oEvent) {

             if (!this._docTypeSelectDialog) {
                   this._docTypeSelectDialog = sap.ui.xmlfragment(
                                 "flm.fiori.view.documentTypeSelectDialog",
                                 this);
                   var docTypeModel = new sap.ui.model.json.JSONModel();
                   docTypeModel
                                 .loadData(serviceUrl
                                               + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                 + this.caseguid
                                 + "' and OtherF4 eq true and ID eq 'DT'");
                    this._docTypeSelectDialog.setModel(docTypeModel,
                                 "docType");
                    this._docTypeSelectDialog.setModel(this.getView()
                                 .getModel("i18n"), "i18n");
             } else {
                    sap.ui.getCore().byId("docNumberId").setValue("");
                    sap.ui.getCore().byId("docTypeSelect")
                                 .setSelectedItem(
                                               sap.ui.getCore().byId(
                                                             "docTypeSelect")
                                                             .getFirstItem());
             }
             sap.ui.getCore().byId("attachmentTypeid").setValue(
                          oEvent.getSource().getId());
             oModel = new sap.ui.model.json.JSONModel();
             if (oEvent.getSource().getId() == "objectAction") {

                   oModel.loadData(serviceUrl
                                 + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                 + this.caseguid
                                 + "' and OtherF4 eq true and ID eq 'OO'",
                                 null, false);
                    sap.ui.getCore().byId("docTypeSelectId").setTitle(
                                 oControllerS6.getView().getModel("i18n").getObject(
                                               "OBJECT"));
             } else if (oEvent.getSource().getId() == "reportAction") {

                   oModel.loadData(serviceUrl
                                 + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                 + this.caseguid
                                 + "' and OtherF4 eq true and ID eq 'RO'",
                                 null, false);
                    sap.ui.getCore().byId("docTypeSelectId").setTitle(
                                 oControllerS6.getView().getModel("i18n").getObject(
                                               "REPORT"));
             }
             this._docTypeSelectDialog.setModel(oModel);
             // oModel.setData(doctype);
             this._docTypeSelectDialog.open();
      },
      
      _handleDocSelectOk : function(oEvent) {

     var doc_num = sap.ui.getCore().byId("docNumberId");

   for (var i = 0; i < oControllerS6.data.attachments.length; i++) {
    if (doc_num.getValue() == oControllerS6.data.attachments[i].DocumentName) {
     sap.m.MessageToast
       .show(this.getView().getModel("i18n").getObject("MESSAGE_35"));
     return;
    }
   }
             var documentData = {
                   "BorID" : null,
                   "BorType" : null,
                   "DocumentName" : null,
                   "DocumentType" : null,
                   "CreatedByName" : null,
                   "CreatedOn" : null,
                   "FileTitle" : null,
                   "FileSizeDescr" : null,
                   "ParentKey" : "" /*this.uploadNode.getBindingContext(
                                 "global").getProperty("RowKey")*/,
                   "IsAttachment" : false,
                   "IsFile" : false,
                   "IsObject" : false,
                   "IsIpi" : false,
                   "IsReport" : false,
                   "ElementType" : null,
                   "FileName" : null,
                   "DocumentClass" : null,
                   "AttachmentLoioID" : null,
                   "FileSizeDescr" : null,
                   "NotingEnabledRef" : true,
                   "DeleteEnabledRef" : true,
                   "Variant" : null,
             };

             var fileDetails = {
                   "caseGuiId" : this.caseguid,
                   "workItemId" : this.wiId,
                   "fileId" : this.fileid,
             };

             var objDetails = {
                   "objectType" : null,
                   "elementType" : null,
                   "attachmentType" : sap.ui.getCore().byId(
                                 "attachmentTypeid").getValue(),// sap.ui.getCore().byId("docTypeSelectId").getTitle(),
             };
             var docObject = {};
             
             docObject.document = documentData;
             docObject.fileDetails = fileDetails;
             docObject.objectDetails = objDetails;
             docObject.event = oEvent;

             docObject.document.DocumentName = sap.ui.getCore()
                          .byId("docNumberId").getValue();

             if (docObject.document.DocumentName == ""
                          || sap.ui.getCore().byId("idDocTypeTable")
                                        .getSelectedItem() == undefined) {
                    sap.m.MessageToast.show(this.getView().getModel(
                                 "i18n").getObject("enterdocumentnumber"));
                   return;
             } else {
                   docObject.document.DocumentType = sap.ui.getCore()
                                 .byId("docTypeSelect").getSelectedKey();
                   docObject.document.FileName = sap.ui.getCore()
                                 .byId("docTypeSelect").getSelectedItem()
                                 .getText();
                    docObject.objectDetails.objectType = sap.ui
                                 .getCore().byId("idDocTypeTable")
                                 .getSelectedItem().getBindingContext()
                                 .getObject().ResulltCol1;
                    docObject.objectDetails.elementType = sap.ui
                                 .getCore().byId("idDocTypeTable")
                                 .getSelectedItem().getBindingContext()
                                 .getObject().ResultCol3;
             }
             // closing the popup and calling the hook function
             this._docTypeSelectDialog.close();
             if (this.attachCustomObject) {
     this.attachCustomObject(docObject);
    }
      },

      _handleDocSelectCancel : function(oEvent) {
             this._docTypeSelectDialog.close();
      },

      // attach document in the tree in ui

      _attachObjectUI : function(oDocument) {
             
             try {
                    oControllerS6.getView().getModel("global")
                                 .getData().attachments.push(oDocument);
                    oControllerS6.getView().getModel("global")
                                 .refresh();
             } catch (err) {
                   return false;
             }
             var heading = oControllerS6.uploadNode
    .getTitle().getText();
             var subHead1 = heading
    .substring(
      0,
      heading
        .lastIndexOf("("));
             var subHead2 = heading
    .substring(
      heading
        .lastIndexOf("(") + 1,
      heading
        .lastIndexOf(")"));
             oControllerS6.uploadNode
    .getTitle()
    .setText(
      subHead1
        + " ("
        + (++subHead2)
        + ")");
             return true;
      },
         /*Changes for Integration endss */
         
         /*Track daak events change */
         
         daakTrackedStateChange : function(oEvent) {
          if (this.getView().byId("idTrackDaakSwitch").getState() == false) {
                    oControllerS6.customBusyDialogOpen();
                   var oModel = new sap.ui.model.json.JSONModel();
                   oModel.loadData(serviceUrl
                                                             + "/FILES_FI?param_1='UF'&param_2='"
                                                             + this.caseguid
                                                             + "'&param_3='"
                                                            + this.wiId
                                                             + "'&param_4='"
                                                             + this.fileid
                                                             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                               null, false);
                   if (oModel.getData().d.results.length == 0) {
                    this.getView().byId("idTrackDaakSwitch").setTooltip(this.getView().getModel("i18n").getObject("OFF"));
      this.getView().byId("idTrackDaakSwitch").rerender();
                          sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_77"));
                          oControllerS6.customBusyDialogClose();
                   } else if (oModel.getData().d.results[0].msg_type == 'E') {
                          sap.m.MessageBox
                          .alert(oModel.getData().d.results[0].msg_text);

                   }
             } else if (this.getView().byId("idTrackDaakSwitch")
                          .getState() == true) {
                    oControllerS6.customBusyDialogOpen();
                   var oModel = new sap.ui.model.json.JSONModel();
                   oModel
                                 .loadData(
                                               serviceUrl
                                                             + "/FILES_FI?param_1='TF'&param_2='"
                                                             + this.caseguid
                                                             + "'&param_3='"
                                                             + this.wiId
                                                             + "'&param_4='"
                                                             + this.fileid
                                                             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                               null, false);
                   if (oModel.getData().d.results.length == 0) {
                    this.getView().byId("idTrackDaakSwitch").setTooltip(this.getView().getModel("i18n").getObject("ON"));
      this.getView().byId("idTrackDaakSwitch").rerender();
                          sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_78"));
                          oControllerS6.customBusyDialogClose();
                   } else if (oModel.getData().d.results[0].msg_type == 'E') {
                          sap.m.MessageBox
                          .alert(oModel.getData().d.results[0].msg_text);
                   }
             }
      },
      
      /*Options for Send Daak */
      sendDaakOptionsOpen : function(oEvent) {
   var oButton = oEvent.getSource();
   //if (!this._sendActionSheet) {
    if (!oControllerS6._sendDaakActionSheet || oControllerS6._sendDaakActionSheet.getButtons().length == 0){
    this._sendDaakActionSheet = sap.ui.xmlfragment(
      "flm.fiori.view.daakSendOptions", this);
    this.getView().addDependent(this._sendDaakActionSheet);
   }
   jQuery.sap.delayedCall(0, this, function() {
    this._sendDaakActionSheet.openBy(oButton);
   });
  },

  // Close File Actions
  closeButtonPressed : function(oEvent) {
    oControllerS6.openDialog('closeFileDialog');

  },

  // event handler for closing the file
  onCloseButtonPressedOk : function(oEvent) {

   var oTableId = null;
   var oEntitySet = null;
   switch (this.fromTab) {

   case "INTRAYDAAK":
    oTableId = "idFilesTable";
    oEntitySet = "/FILE_INTRAY_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
    break;
   case "DRAFTDAAK":
    oTableId = "idDraftsTable";
    oEntitySet = "/FILE_DRAFT_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
    break;
   case "SUBSTDAAK":
    oTableId = "idSubstituteTable";
    oEntitySet = "/FILE_SUBST_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
    break;

   }


   if (oTableId != null) {
    this.customBusyDialogOpen();

    var oModel = new sap.ui.model.json.JSONModel();// oControllerS2.oRouter.getView("flm.fiori.view.S1").byId(oTableId).getModel("files");
    var oTable = oControllerS6.oRouter.getView(
      "flm.fiori.view.S1").byId(oTableId);
    oModel
      .attachRequestCompleted(
        this,
        function(oEvent) {

         oModel.detachRequestCompleted();
         // delete the file from the tab
         var tempArr = oTable
           .getModel("files").oData.results;
         var i = 0, j = -1;
         while (i < tempArr.length) {
          if (tempArr[i].CaseGuid == oControllerS6.caseguid) {
           j = i;
           break;
          }
          i++;
         }
         if (j != -1) {
          oTable.removeSelections();
          tempArr.splice(j, 1);
          oTable.getModel("files").oData.__count--;
          oTable.getModel("files")
            .checkUpdate();
         }

         sap.m.MessageToast
           .show(this
             .getView()
             .getModel(
               "i18n")
             .getObject(
               "FILECLOSED"));
         this.customBusyDialogClose();
         oControllerS6.oRouter.getView(
           "flm.fiori.view.S1")
           .byId("closeAction")
           .setEnabled(false);
         oControllerS6.oRouter.getView(
           "flm.fiori.view.S1")
           .byId("sendAction")
           .setEnabled(false);
         oTable.removeSelections();
         destroyDialogs(oControllerS6); //destroy all common fragments
         this.oRouter
           .navTo("fullscreen");
        }, this);
    // Failure
    oModel.attachRequestFailed(this, function(oEvent) {
     oModel.detachRequestCompleted();
     oModel.detachRequestFailed();
     sap.m.MessageBox.alert(this.getView().getModel(
       "i18n").getObject("MESSAGE_27"));
     this.customBusyDialogClose();
    }, this);

    oModel
      .loadData(
        serviceUrl
        + "/FILES_FI?param_1='CF'&param_2='"
        + oControllerS6.caseguid
        + "'&param_3=''&param_4='"
        + oControllerS6.fileid
        + "'&param_5=''&check_1=''&check_2='ISDAAK'&check_3=''&param_6=''&param_7='"
        + oControllerS6.fromTab
        + "'&param_8=''&param_9=''&param_10=''",
      null, true);
   }
  },

  onCloseButtonPressedCancel : function(oEvent) {
   this.closeDialog('closeFileDialog');
  },

  printDaakActionsOpen : function(oEvent) {
   var oButton = oEvent.getSource();
   if (!this._printActionSheet) {
    this._printActionSheet = sap.ui.xmlfragment(
      "flm.fiori.view.printActionButtons", this);
    this.getView().addDependent(this._printActionSheet);
   }
   jQuery.sap.delayedCall(0, this, function() {
    this._printActionSheet.openBy(oButton);
   });
  },
                          
  onCloseButton : function(oEvent) {
   if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
    oEvent.getSource().getParent().close();
   } else {
    oEvent.getSource().getParent().getParent().close();
   }

  },

  ipiButtonPressed : function(oEvent){
   oControllerS6.isAttachment = false;
            oControllerS6.isFile = false;
            oControllerS6.isReport = false;
            oControllerS6.isObject = false;
            oControllerS6.isIPI = false;
            oControllerS6.isDaak = true;
           // this.fileDialog = null;
            if(! oControllerS6.daakDialog){
             oControllerS6.daakDialog = sap.ui.xmlfragment(
                          "flm.fiori.view.daakAttach",  oControllerS6);
            }
            sap.ui.getCore().byId("idDaakNumber").setValue("");
            oControllerS6.daakDialog.open();
  },

  deleteAttachment : function(oEvent,oItem) {
            
            oControllerS6.customBusyDialogOpen();
            var temp = oItem.getBindingContext("createdaak");
                        oControllerS6.documentId = oItem.getModel("createdaak")
                                      .getObject(temp.getPath());


            oModel = new sap.ui.model.json.JSONModel();
            
            oModel
                               .attachRequestCompleted(
                                             oEvent,
                                             function(oEvent) {
                                              
                                                    oModel.detachRequestCompleted();
                                                    
                                                    var err = oModel.oData.d.results[0];
                                                   if (err != undefined
                                                                 && err.msg_type == 'E') {
                                                          sap.m.MessageBox
                                                                        .alert(err.msg_text);
                                                          // sap.m.MessageToast.show(err.msg_text);
                                                   } else {
                                                          
                                                          var k = oControllerS6.documentId;
                                 var deleteNode = oItem.getParent()
                                               .getParent().getParent().getParent()
                                               .getParent().getId();
                                 var oAttachmentList=oControllerS6.getView().getModel("createdaak").oData.attachments;
                                 // oEvent.getSource().getParent().getParent().getParent().destroy();
                                 for ( var i = 0; i < oAttachmentList.length; i++) {
                                        if (k.DocumentName == oAttachmentList[i].DocumentName) {
                                               oAttachmentList.splice(i,1);
                                               break;
                                        }
                                }
                                 oControllerS6.getView().getModel("createdaak").refresh();

                                                     oControllerS6.customBusyDialogClose();

                                 sap.m.MessageToast
                                               .show(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_15"));
                                                   }

                                                   oControllerS6
                                                                 .customBusyDialogClose();

                                             }, oControllerS6);
            // if(oControllerS3.documentId<gResponse.length){
            if (oControllerS6.documentId
                          .IsAttachment) {
                   oModel.loadData(serviceUrl
                                 + "/FILE_DOC_FI?param_1='DA'&param_2='"
                                 + oControllerS6.caseguid
                                 + "'&param_3='"
                                 + encodeURIComponent(oControllerS6.documentId
                                              .DocumentName)
                                 + "'&param_4='"
                                 + oControllerS6.documentId
                                              .DocumentType
                                 + "'&param_5=''", null, true);
                   
            } else if (oControllerS6.documentId.IsFile || oControllerS6.documentId.IsObject || oControllerS6.documentId.IsReport || oControllerS6.documentId.IsDaak) {
                   oModel.loadData(serviceUrl
                                 + "/FILE_DOC_FI?param_1='DO'&param_2='"
                                 + oControllerS6.caseguid
                                 + "'&param_3='"
                                 + encodeURIComponent(oControllerS6.documentId
                                              .DocumentName)
                                 + "'&param_4='"
                                 + oControllerS6.documentId
                                               .CaseGuid
                                 + "'&param_5='" + oControllerS6.wiId + "'",
                                null, true);
                   
            }else if(oControllerS6.documentId.IsIpi){
              oModel.loadData(serviceUrl
                         + "/FILE_DOC_FI?param_1='DD'&param_2='"
                         + oControllerS6.caseguid
                         + "'&param_3='"
                         + encodeURIComponent(oControllerS6.documentId
                                      .DocumentName)
                         + "'&param_4='000000000000'&param_5=''",
                        null, true);
            }
            
     },

     
     /*Navigation back to previous screens */
 navToPreviousAction : function(oEvent){

         oControllerS6.navFlagDaak = true;
         this.getView().byId("idDaakAttachmentsList").destroyItems();
         this.getView().byId("dynamicAttrForm").destroyContent();
         
         try{
        if(oControllerS2){
         if(oControllerS2.navBackArr.length!=0)
          this.S2flag = true;
         else
          this.S2flag = false;
        }
       }catch(err){
        this.S2flag = false;
       }
       try{
        if(oControllerS3){
         if(oControllerS3.navBackArrS3.length!=0)
          this.S3flag = true;
         else
          this.S3flag = false;
        }
       }catch(err){
        this.S3flag = false;
       }
         
         if(oControllerS6.navBackArrS6.length == 1 && !this.S2flag){

        this.getView().byId("daakNotingPanel").setVisible(true);
        this.getView().byId("daakPrivateToLabel")
          .setVisible(true);
        this.getView().byId("daakReceiverTypeNoting")
          .setVisible(true);
        this.getView().byId("daakProcessorInput").setVisible(true);
        this.getView().byId("daakNotingCreateAction").setVisible(
          true);
        //this.oRouter.navTo("fullscreen");
        var paramPop = oControllerS6.navBackArrS6.pop();
        this.fromTab = paramPop.fromTab;
        this.caseguid = paramPop.caseguid;
        this.fileid = paramPop.fileid;
        this.wiId = paramPop.wiId;
        /*this.oRouter.navTo("subscreen", {
         caseguid : paramPop.caseguid,
         fileid : paramPop.fileid,
         wiId : paramPop.wiId,
        }, true);*/
        this.oRouter.navTo("daakscreen");

       }else if (oControllerS6.navBackArrS6.length >= 1 && this.S2flag) {

        var paramPop = oControllerS6.navBackArrS6.pop();
        this.fromTab = paramPop.fromTab;
        docGuid = paramPop.caseguid;
        docFileid = paramPop.fileid;
        docWiid = paramPop.wiId;
         oControllerS6.oRouter.navTo("daakdocscreen", {
                                     caseguid : paramPop.caseguid
                              },true);

        this.getView().byId("daakNotingPanel").setVisible(false);
        this.getView().byId("daakPrivateToLabel")
          .setVisible(false);
        this.getView().byId("daakReceiverTypeNoting")
          .setVisible(false);
        this.getView().byId("daakProcessorInput").setVisible(false);
        this.getView().byId("daakNotingCreateAction").setVisible(
          false);
       }else if (this.fromFileSearch) {
        /*navigation from file search */
        this.oRouter.navTo("daaksearchscreen");
       }else if(this.fromDocSearch){
        /*navigation from document search */
        this.oRouter.navTo("docscreen");

       }else if(this.S2flag){
        var paramPop = oControllerS2.navBackArr.pop();
        this.fromTab = paramPop.fromTab;
        this.caseguid = paramPop.caseguid;
        this.fileid = paramPop.fileid;
        this.wiId = paramPop.wiId;
        this.oRouter.navTo("subscreen", {
         caseguid : paramPop.caseguid,
         fileid : paramPop.fileid,
         wiId : paramPop.wiId,
        }, true);
       }else if(this.S3flag){
         var paramPop1 = oControllerS3.navBackArrS3.pop();
       this.fromTab = paramPop1.fromTab;
       this.caseguid = paramPop1.caseguid;
       this.fileid = paramPop1.fileid;
       this.wiId = paramPop1.wiId;
       oControllerS1.tabType = "draft";
       this.oRouter.navTo("myscreen");
       }
       else{
                        oControllerS1.caseguid = null;
                           oControllerS1.fileid = null;
                           oControllerS1.filenumber = null;
                           oControllerS1.digitalsign = null;
                           
                           if(sap.ui.getCore().byId("idSendToDialog")){
                                  sap.ui.getCore().byId("idSendToDialog").destroy();
                           }
                           destroyDialogs(oControllerS6);
                           this.getView().byId("createDaak").setBusy(false);
                           oControllerS6.customBusyDialogOpen();
                           var oTable = null;
                           var oTab = null;
                           if (oControllerS1.getView().byId("TAB_CONTAINER")
                                        .getSelectedKey() == "file") {
                                  oTable = oControllerS1.getView().byId("idFilesTable");
                                  oTab = "/FILE_INTRAY_ES?$filter=Filetype eq '"+oControllerS1.objectType+"'";
                           } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                        .getSelectedKey() == "draft") {
                                  oTable = oControllerS1.getView().byId("idDraftsTable");
                                  oTab = "/FILE_DRAFT_ES?$filter=Filetype eq '"+oControllerS1.objectType+"'";
                           } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                        .getSelectedKey() == "cabinet") {
                                  oTable = oControllerS1.getView().byId("idCabinetTable");
                                  oTab = "/FILE_CABIN_ES?$filter=Filetype eq '"+oControllerS1.objectType+"'";
                           } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                        .getSelectedKey() == "substitute") {
                                  oTable = oControllerS1.getView().byId("idSubstituteTable");
                                  oTab = "/FILE_SUBST_ES?$filter=Filetype eq '"+oControllerS1.objectType+"'";
                           }else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                        .getSelectedKey() == "sent") {
                                  oTable = oControllerS1.getView().byId("idSentFilesTable");
                                  oTab = "/FILE_SENT_ES?$filter=Subject eq '"+oControllerS1.objectType+"'";
                           } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                        .getSelectedKey() == "track") {
                                  oTable = oControllerS1.getView().byId("idTrackFilesTable");
                                  oTab = "/FILE_TRACK_ES?$filter=CaseType eq '"+oControllerS1.objectType+"'";
                           }
//                           oControllerS6.customBusyDialogOpen();
                           if (oTab != null && oTable != null) {
                                  oTable.setBusy(true);
                                  oTable.removeSelections();
                                  var oTabModel = new sap.ui.model.json.JSONModel();
                                  // success
                                  oTabModel.attachRequestCompleted(oEvent, function(
                                               oEvent) {
                                        
                                         oTabModel.detachRequestCompleted();
                                         oTabModel.detachRequestFailed();
                                        if (oTabModel.oData.d != undefined) {
                                               oModel = oTable.getModel("files");
                                               
                                               oModel.setData(oTabModel.oData.d);
                                               oControllerS6.customBusyDialogClose();
//                                               sap.m.MessageToast.show(oControllerS1.getView()
//                                                             .getModel("i18n").getObject(
//                                                                          "DATAREFRESHED"));
                                        }
                                        oTable.setBusy(false);
                                  });
                                  // Failure
                                  oTabModel.attachRequestFailed(oControllerS1,
                                               function(oEvent) {
                                                      oTabModel.detachRequestCompleted();
                                                      oTabModel.detachRequestFailed();
                                                      oTable.setBusy(false);
                                               }, oControllerS1);
                                  oTabModel.loadData(serviceUrl + oTab, null, true);
                                  oControllerS6.customBusyDialogClose();

                           } else {
                            oControllerS6.customBusyDialogClose();
                           }
        this.fromTab = "CREATEDAAK";
                        this.oRouter.navTo("fullscreen");
       }
                       },
                           
                           workflowOptionsOpen : function(oEvent) {
                var oButton = oEvent.getSource();
                if(this.fromTab == "CREATEDAAK" || this.fromTab == "DRAFTDAAK"){
                //if (!this._workflowActionSheet) {
                 if (!oControllerS6._workflowActionSheet || oControllerS6._workflowActionSheet.getButtons().length == 0){
                 this._workflowActionSheet = sap.ui.xmlfragment(
                   "flm.fiori.view.addNewWorkflow", this);
                 this.getView().addDependent(this._workflowActionSheet);
                }
                jQuery.sap.delayedCall(0, this, function() {
                 this._workflowActionSheet.openBy(oButton);
                });
                }else{
                 oControllerS6.onAddNewWorkflow();
                }
               },
                           
               onDeleteWorkflowSelect : function(oEvent){
              var rightTree = sap.ui.getCore().byId("rightTree");
                                rightTree.rerender();
                                var rightIndices = rightTree.getSelectedIndices();
//                                var rightIndex = rightTree.getSelectedIndex()-1;
                                if (rightIndices.length==0) {
                                       alert(this.getView().getModel("i18n").getObject("MESSAGE_16"));
                                }
                                else{
                                 var data = rightTree.getModel().oData.results;
                                 for(var i=rightIndices.length-1;i>=0;i--){
                                 if(rightIndices[i]==0){
                                  continue;
                                 }else{
                                  data[0].nodes.splice(rightIndices[i]-1,1);
                                 }
                                 }
                                    rightTree.getModel().checkUpdate();
                                    sap.ui.getCore().byId("rightTree").setSelectedIndex(0);
                                    rightTree.rerender();
                                   }
                                rightTree.setSelectedIndex(0);
                                return;
             },

             onCreateWFRowSelectionChange : function(oEvent){
                             if(sap.ui.getCore().byId("rightTree").getSelectedIndex()==-1){
                                 sap.ui.getCore().byId("idAddProcessorButton").setEnabled(false);
                                 sap.ui.getCore().byId("idDeleteProcessorButton").setEnabled(false);
                                 sap.ui.getCore().byId("idClearTreeButton").setEnabled(false);
                             }else if(sap.ui.getCore().byId("rightTree").getSelectedIndex()==0){
                              sap.ui.getCore().byId("idAddProcessorButton").setEnabled(true);
                                 sap.ui.getCore().byId("idDeleteProcessorButton").setEnabled(false);
                             }else{
                              sap.ui.getCore().byId("idAddProcessorButton").setEnabled(true);
                                 sap.ui.getCore().byId("idDeleteProcessorButton").setEnabled(true);
                                 sap.ui.getCore().byId("idClearTreeButton").setEnabled(true);
                             }
                            },
                            
                            clearDateTime : function(oEvent){
                             if(oEvent.getSource().getId()=="idOrgUnitClear"){
                              sap.ui.getCore().byId("idOrgUnit").setValue("");
                              sap.ui.getCore().byId("leftTree").setModel(new sap.ui.model.json.JSONModel());
                              sap.ui.getCore().byId("idOrgUnitClear").setVisible(false);
                              sap.ui.getCore().byId("leftTree").setSelectedIndex(-1);
                             }else if(oEvent.getSource().getId()=="idFactoryCalendarClear"){
                              sap.ui.getCore().byId("idFactoryCalendar").setValue("");
                              sap.ui.getCore().byId("idFactoryCalendarClear").setVisible(false);
                             }
                            },
                            
                            clearRespondDate : function(oEvent){
                              this.getView().byId("idResponddate").setValue("");
                              this.getView().byId("deleteDate").setVisible(false);
                            },
                            
                            /* Open Daak search view */
                            openDaakSearchView : function(oEvent){
                             if (!oControllerS6.daakSearchPopup) {
                  oControllerS6.daakSearchPopup = sap.ui.xmlfragment(
                    "flm.fiori.view.daakSearch", oControllerS6);
                 }
                  oControllerS6.daakSearchPopup.setModel(this.getView().getModel(
                    "i18n"), "i18n");
                  var oPrioModel = new sap.ui.model.json.JSONModel();
                  oPrioModel.setData(this.data.priority);
                  oControllerS6.daakSearchPopup.setModel(oPrioModel, "priority");

                  oControllerS6.daakSearchPopup.setModel(this
                    .initializeSearchHelp(this), "createdaak");

                 oControllerS6.daakSearchPopup.open();
                            },
                            
                            onSearchDialogCloseButton : function(oEvent) {
                 this.daakSearchPopup.close();
                },
                onToUserFilesPopupCloseButton : function(oEvent) {
                 this.toUserFilesPopup.close();
                },
                onpressf4Filetype : function(oEvent) {
                if (!this.f4popup) {
                 this.f4popup = sap.ui.xmlfragment(
                   "flm.fiori.view.dynamicF4popup", this);
                 // sap.ui.getCore().addDependent(this.f4popup);
                }

                oF4Texts = new sap.ui.model.json.JSONModel();
                var f4text = {
                 title : this.getView().getModel("i18n").getObject(
                   "DAAKTYPE"),
                 id : oEvent.getSource().getId()
                };
                oF4Texts.setData(f4text);
                this.f4popup.setModel(oF4Texts, "dyntext");
                var oF4Model = new sap.ui.model.json.JSONModel();
                oF4Model
                  .loadData(
                    serviceUrl
                      + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                         + this.caseguid
                                                         + "' and ID eq 'IT' and OtherF4 eq true",
                    null, false);
                oF4Model.setData(oF4Model.oData.d.results);
                this.f4popup.setModel(oF4Model);
                this.f4popup.open();
               },

               onpressf4User : function(oEvent) {
                if (!this.f4popup) {
                 this.f4popup = sap.ui.xmlfragment(
                   "flm.fiori.view.dynamicF4popup", this);
                 // sap.ui.getCore().addDependent(this.f4popup);
                }

                oF4Texts = new sap.ui.model.json.JSONModel();
                var f4text = {
                 title : this.getView().getModel("i18n").getObject(
                   "USERS"),
                 id : oEvent.getSource().getId()
                };
                oF4Texts.setData(f4text);
                this.f4popup.setModel(oF4Texts, "dyntext");

                var oF4Model = new sap.ui.model.json.JSONModel();
                oF4Model
                  .loadData(
                    serviceUrl
                      + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                         + this.caseguid
                                                         + "' and ID eq 'US' and WF eq true",
                    null, false);
                oF4Model.setData(oF4Model.oData.d.results);
                this.f4popup.setModel(oF4Model);
                this.f4popup.open();
               },

               onpressf4RecievedMode : function(oEvent) {
                if (!this.f4popup) {
                 this.f4popup = sap.ui.xmlfragment(
                   "flm.fiori.view.dynamicF4popup", this);
                 // sap.ui.getCore().addDependent(this.f4popup);
                }

                oF4Texts = new sap.ui.model.json.JSONModel();
                var f4text = {
                 title : this.getView().getModel("i18n").getObject(
                   "RECIEVED_MODE"),
                 id : oEvent.getSource().getId()
                };
                oF4Texts.setData(f4text);
                this.f4popup.setModel(oF4Texts, "dyntext");

                var oF4Model = new sap.ui.model.json.JSONModel();
                oF4Model
                  .loadData(
                    serviceUrl
                      + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                         + this.caseguid
                                                         + "' and ID eq 'RM' and OtherF4 eq true",
                    null, false);
                oF4Model.setData(oF4Model.oData.d.results);
                this.f4popup.setModel(oF4Model);
                this.f4popup.open();
               },

               onPressDaakSearch : function(oEvent) {

                var i = -1;
                var searchFields = new Array();
                if (sap.ui.getCore().byId("value1").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value1").getValue();
                 searchFields[i].op = sap.ui.getCore().byId("op1")
                   .getSelectedKey();
                 searchFields[i].criteria = "CASE_TITLE";
                }
                if (sap.ui.getCore().byId("value2").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value2").getValue();
                 searchFields[i].op = sap.ui.getCore().byId("op2")
                   .getSelectedKey();
                 searchFields[i].criteria = "DAAK_TYPE";
                }
                if (sap.ui.getCore().byId("value3").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value3").getValue();
                 searchFields[i].op = sap.ui.getCore().byId("op3")
                   .getSelectedKey();
                 searchFields[i].criteria = "REF_NUMBER";
                }
                if (sap.ui.getCore().byId("value4").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value4").getName();
                 searchFields[i].op = sap.ui.getCore().byId("op4")
                   .getSelectedKey();
                 searchFields[i].criteria = "CREATED_BY";
                }
                if (sap.ui.getCore().byId("value5").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value5").getName();
                 searchFields[i].op = sap.ui.getCore().byId("op5")
                   .getSelectedKey();
                 searchFields[i].criteria = "CLOSED_BY";
                }
                if (sap.ui.getCore().byId("value6").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value6").getValue();
                 searchFields[i].op = sap.ui.getCore().byId("op6")
                   .getSelectedKey();
                 searchFields[i].criteria = "CREATE_TIME";
                }
                if (sap.ui.getCore().byId("value7").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value7").getValue();
                 searchFields[i].op = sap.ui.getCore().byId("op7")
                   .getSelectedKey();
                 searchFields[i].criteria = "DAAK_NUMBER";
                }
                if (sap.ui.getCore().byId("value8").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value8").getValue();
                 searchFields[i].op = sap.ui.getCore().byId("op8")
                   .getSelectedKey();
                 searchFields[i].criteria = "RECIEVED_DATE";
                }
                if (sap.ui.getCore().byId("value9").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value9").getValue();
                 searchFields[i].op = sap.ui.getCore().byId("op9")
                   .getSelectedKey();
                 searchFields[i].criteria = "LETTER_DATE";
                }
                if (sap.ui.getCore().byId("value10").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value10").getValue();
                 searchFields[i].op = sap.ui.getCore().byId("op10")
                   .getSelectedKey();
                 searchFields[i].criteria = "RECEIVED_MODE";
                }

                if (sap.ui.getCore().byId("value11").getValue() != "") {
                 i++;
                 searchFields[i] = {};
                 searchFields[i].value = sap.ui.getCore().byId(
                   "value11").getValue();
                 searchFields[i].op = sap.ui.getCore().byId("op11")
                   .getSelectedKey();
                 searchFields[i].criteria = "RECP_NAME";
                }
                var criteria1 = "";
                var criteria2 = "";
                var criteria3 = "";
                var criteria4 = "";
                var criteria5 = "";

                var op1 = "";
                var op2 = "";
                var op3 = "";
                var op4 = "";
                var op5 = "";
        var obType = "";
        obType = "DAAK";
                var value1 = "";
                var value2 = "";
                var value3 = "";
                var value4 = "";
                var value5 = "";
                var max_res = sap.ui.getCore().byId("resultCount")
                  .getValue();
                if (searchFields.length > 5) {
                 sap.m.MessageToast.show(this.getView().getModel(
                   "i18n").getObject("MESSAGE_01"));
                } else if (searchFields.length == 0) {
                 sap.m.MessageToast.show(this.getView().getModel(
                   "i18n").getObject("MESSAGE_02"));
                } else {
                 for (var j = 0; j < searchFields.length; j++) {
                  if (j == 0) {
                   criteria1 = searchFields[j].criteria;
                   op1 = searchFields[j].op;
                   value1 = searchFields[j].value;
                  } else if (j == 1) {
                   criteria2 = searchFields[j].criteria;
                   op2 = searchFields[j].op;
                   value2 = searchFields[j].value;
                  } else if (j == 2) {
                   criteria3 = searchFields[j].criteria;
                   op3 = searchFields[j].op;
                   value3 = searchFields[j].value;
                  } else if (j == 3) {
                   criteria4 = searchFields[j].criteria;
                   op4 = searchFields[j].op;
                   value4 = searchFields[j].value;
                  } else if (j == 4) {
                   criteria5 = searchFields[j].criteria;
                   op5 = searchFields[j].op;
                   value5 = searchFields[j].value;
                  }

                 }
                 var osearchResultsModel = new sap.ui.model.json.JSONModel();
                 osearchResultsModel.loadData(serviceUrl
                   + "/FILE_SRCH_FI?action='SI'&crit_1='"
                   + criteria1 + "'&crit_2='" + criteria2
                   + "'&crit_3='" + criteria3 + "'&crit_4='"
                   + criteria4 + "'&crit_5='" + criteria5
                   + "'&oper_1='" + op1 + "'&oper_2='" + op2
                   + "'&oper_3='" + op3 + "'&oper_4='" + op4
                   + "'&oper_5='" + op5 + "'&value_1='"
                   + encodeURIComponent(value1) + "'&value_2='" + encodeURIComponent(value2)
                   + "'&value_3='" + encodeURIComponent(value3) + "'&value_4='"
                   + encodeURIComponent(value4) + "'&value_5='" + encodeURIComponent(value5)
                   + "'&max_res='" + max_res + "'&is_type='" + obType + "'", null,
                   false);
                 oEvent.getSource().getModel("createdaak").oData.searchResult = osearchResultsModel.oData.d.results;

                 oEvent.getSource().getModel("createdaak").checkUpdate();

                }

               },

               /*clear search values*/
               onPressClear : function(oEvent) {
              sap.ui.getCore().byId("value1").setValue("");
              sap.ui.getCore().byId("value2").setValue("");
              sap.ui.getCore().byId("value3").setValue("");
              sap.ui.getCore().byId("value4").setValue("");
              sap.ui.getCore().byId("value5").setValue("");
              sap.ui.getCore().byId("value6").setValue("");
              sap.ui.getCore().byId("value7").setValue("");
              sap.ui.getCore().byId("value8").setValue("");
              sap.ui.getCore().byId("value10").setValue("");
              sap.ui.getCore().byId("value11").setValue("");

              sap.ui.getCore().byId("op1").setSelectedKey("01");
              sap.ui.getCore().byId("op2").setSelectedKey("01");
              sap.ui.getCore().byId("op3").setSelectedKey("01");
              sap.ui.getCore().byId("op4").setSelectedKey("01");
              sap.ui.getCore().byId("op5").setSelectedKey("01");
              sap.ui.getCore().byId("op6").setSelectedKey("01");
              sap.ui.getCore().byId("op8").setSelectedKey("11");
              sap.ui.getCore().byId("op9").setSelectedKey("01");
              sap.ui.getCore().byId("op10").setSelectedKey("01");
              sap.ui.getCore().byId("op11").setSelectedKey("01");

              oEvent.getSource().getModel("createdaak").oData.searchResult = null;
              // // this.data.searchResults =
              oEvent.getSource().getModel("createdaak").checkUpdate();
             },

               initializeSearchHelp : function(controller) {

                                var srchData = {
                                      criteria : null,
                                      operators : null,
                                      searchData : null,
                                };
                                
                               
                                srchData.criteria = [
           {
            key : "CASE_TITLE",
            title : this.getView().getModel("i18n")
              .getObject("SUBJECT")
           },
           {
            key : "DAAK_TYPE",
            title : this.getView().getModel("i18n")
              .getObject("FILENUMBER")
           },
           {
            key : "CREATED_BY",
            title : this.getView().getModel("i18n")
              .getObject("CREATEDBY")
           },
           {
            key : "CHANGED_BY",
            title : this.getView().getModel("i18n")
              .getObject("LASTCHANGEDBY")
           },
           {
            key : "CLOSED_BY",
            title : this.getView().getModel("i18n")
              .getObject("CLOSEDBYUSER")
           },
           {
            key : "CREATE_TIME",
            title : this.getView().getModel("i18n")
              .getObject("CREATEDON")
           },
           {
            key : "EXT_KEY",
            title : this.getView().getModel("i18n")
              .getObject("FILEID")
           },
           {
            key : "PLAN_END_DATE",
            title : this.getView().getModel("i18n")
              .getObject("DUEDATE")
           },
           {
            key : "ARCHIVE",
            title : this.getView().getModel("i18n")
              .getObject("READFROMARCHIVE")
           },
           {
            key : "STAT_ORDERNO",
            title : this.getView().getModel("i18n")
              .getObject("STATUS")
           },
           {
            key : "SAP_FLM_PRIO",
            title : this.getView().getModel("i18n")
              .getObject("PRIORITY")
           },
           {
            key : "FILE_TYPE",
            title : this.getView().getModel("i18n")
              .getObject("FILETYPE")
           },
           {
            key : "ORG_UNIT",
            title : this.getView().getModel("i18n")
              .getObject("ORGANIZATIONGROUP")
           }, ];

                               srchData.operators = [
        {
        criteria : "GEN1",
        opkey : "01",
        optext : this.getView().getModel("i18n")
        .getObject("IS")
        },
        {
        criteria : "GEN2",
        opkey : "05",
        optext : this.getView().getModel("i18n")
        .getObject("CONTAINS")
        },
        {
        criteria : "GEN2",
        opkey : "04",
        optext : this.getView().getModel("i18n")
        .getObject("STARTSWITH")
        },
        {
        criteria : "DATE",
        opkey : "11",
        optext : this.getView().getModel("i18n")
        .getObject("ISEARLIERTHAN")
        },
        {
        criteria : "DATE",
        opkey : "12",
        optext : this.getView().getModel("i18n")
        .getObject("ISLATERTHAN")
        },
        {
        criteria : "DATE",
        opkey : "21",
        optext : this.getView().getModel("i18n")
        .getObject("ISEARLIERTHANORON")
        },
        {
        criteria : "DATE",
        opkey : "22",
        optext : this.getView().getModel("i18n")
        .getObject("ISLATERTHANORON")
        },
        {
        criteria : "ISNOT",
        opkey : "02",
        optext : this.getView().getModel("i18n")
        .getObject("ISNOT")
        } ];

                                srchData.searchData = {
                                  criteria1 : "CASE_TITLE",
                   op1 : "01",
                   value1 : "",
                   criteria2 : "DAAK_TYPE",
                   op2 : "01",
                   value2 : "",
                   criteria3 : "CREATED_BY",
                   op3 : "01",
                   value3 : "",
                   criteria4 : "CHANGED_BY",
                   op4 : "01",
                   value4 : "",
                   criteria5 : "CLOSED_BY",
                   op5 : "01",
                   value5 : ""
                  };
                              

                                srchData.searchResult = null;
                                var oSearchModel = new sap.ui.model.json.JSONModel();
                                oSearchModel.setData(srchData);
                                return oSearchModel;
                         },
                         
                         onSelectDaak : function(oEvent) {

           var daakNumber = oEvent.getParameters().listItem
             .getBindingContext("createdaak").getObject().DaakNumber;
           if (this.getView().byId("idInputDaakNumber2").getValue() == daakNumber) {
            sap.m.MessageBox
              .alert(this.getView().getModel("i18n").getObject("MESSAGE_44"));
            return;
           } else {
            sap.ui.getCore().byId("idDaakNumber").setValue(
              daakNumber);
            this.daakSearchPopup.close();
           }
          },

          toUserFiles : function(oEvent){
           oControllerS6.customBusyDialogOpen();
                         if (!oControllerS6.toUserFilesPopup) {
              oControllerS6.toUserFilesPopup = sap.ui.xmlfragment(
                "flm.fiori.view.selectFileForDaak", oControllerS6);
              oControllerS6.customBusyDialogOpen();
                                var oModel = oControllerS6.getView().getModel();
                                oModel.clearBatch();
                                var batchOp = oModel.createBatchOperation(
                                             "/FILE_INTRAY_ES?$filter=Filetype+eq+'FILE'", 'GET');
                                oModel.addBatchReadOperations([ batchOp ]);
                                batchOp = oModel.createBatchOperation("/FILE_DRAFT_ES?$filter=Filetype+eq+'FILE'",
                                             'GET');
                                oModel.addBatchReadOperations([ batchOp ]);
                                batchOp = oModel.createBatchOperation("/FILE_CABIN_ES?$filter=Filetype+eq+'FILE'",
                                             'GET');
                                oModel.addBatchReadOperations([ batchOp ]);
                                batchOp = oModel.createBatchOperation("/FILE_SUBST_ES?$filter=Filetype+eq+'FILE'",
                                             'GET');
                                oModel.addBatchReadOperations([ batchOp ]);
                                oModel
                                .submitBatch(
                                              function(oResponse, oData) {
                                                     
                                                    var i = 0;
                                                     if(oResponse.__batchResponses[i].data != undefined){
                                                    var oIntrayModel = new sap.ui.model.json.JSONModel();
                                                     oIntrayModel
                                                                  .setData(oResponse.__batchResponses[i].data);
                                                    
                                                    
                                              for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                           var afterSplit = oResponse.__batchResponses[i].data.results[j].Duedate.split(".");
                                                             var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                             oResponse.__batchResponses[i].data.results[j].dueDate = newDate;

                                                    }
                                              
                                                     sap.ui.getCore().byId(
                                                                  "idFilesTable").setModel(
                                                                  oIntrayModel, "files");
                                                    }else{
                                                           sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                                                           controller
                                                           .customBusyDialogClose(controller);
                                                           return;
                                                    }
                                                    i++;
                                                     if(oResponse.__batchResponses[i].data != undefined){
                                                   
//                                                     Setting decoded value for subject
                                                    for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                           var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].Subject);
                                                           oResponse.__batchResponses[i].data.results[j].Subject = subValue;
                                                           oIntrayModel.getData().results.push(oResponse.__batchResponses[i].data.results[j]);
                                                    }
                                                    
                                                    for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                           var afterSplit = oResponse.__batchResponses[i].data.results[j].Duedate.split(".");
                                                             var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                             oResponse.__batchResponses[i].data.results[j].dueDate = newDate;
                                                    }
                                              
                                                    }else{
                                                           sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                                                           controller
                                                           .customBusyDialogClose(controller);
                                                           return;
                                                    }
                                                    i++;
                                                     if(oResponse.__batchResponses[i].data != undefined){
                                                    var oCabinetModel = new sap.ui.model.json.JSONModel();
//                                                     oIntrayModel
//                                                                  .getData().push(oResponse.__batchResponses[i].data);
//                                                     Setting decoded value for subject
                                                    for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                           var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].Subject);
                                                           oResponse.__batchResponses[i].data.results[j].Subject = subValue;
                                                           oIntrayModel.getData().results.push(oResponse.__batchResponses[i].data.results[j]);
                                                    }
                                                    
                                                    for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                           var afterSplit = oResponse.__batchResponses[i].data.results[j].Duedate.split(".");
                                                             var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                             oResponse.__batchResponses[i].data.results[j].dueDate = newDate;
                                                    }
                                              
                                                    }else{
                                                           sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                                                           controller
                                                           .customBusyDialogClose(controller);
                                                           return;
                                                    }
                                                     sap.ui.getCore().byId("idFilesTable").getModel("files").refresh();
                                                     sap.ui.getCore().byId("idFilesTable")
                                                     .getBinding("items").filter(new sap.ui.model.Filter("IconColor",sap.ui.model.FilterOperator.EQ,"#009de0"))
                                                     oControllerS6
                                                                  .customBusyDialogClose();
//                                                  }
                                                    
                                              },
                                              function(oResponse) {
                                                    
                                                    // perform error handling
                                                     oControllerS6
                                                                  .customBusyDialogClose();
                                              },false);
                         }

              oControllerS6.toUserFilesPopup.setModel(this.getView().getModel(
                "i18n"), "i18n");
             oControllerS6.customBusyDialogClose();
             oControllerS6.toUserFilesPopup.open();
                        
          },

          onFilesSearch : function(oEvnt) {
                            var sQuery = oEvnt.getSource().getValue();
                            var oTable = sap.ui.getCore().byId("idFilesTable");
                            var oBinding = oTable.getBinding("items");
                            if (sQuery && sQuery.length > 0) {
                                   var filter1 = new sap.ui.model.Filter([
                                                new sap.ui.model.Filter("Createdby",
                                                              "Contains", sQuery),
                                                
                                                new sap.ui.model.Filter("Subject",
                                                              "Contains", sQuery),
                                                new sap.ui.model.Filter("Priority",
                                                              "Contains", sQuery),
                                                new sap.ui.model.Filter("Duedate",
                                                              "Contains", sQuery),
                                                new sap.ui.model.Filter("Shorttext",
                                                              "Contains", sQuery),
                                               
                                                new sap.ui.model.Filter("Filenumber",
                                                              "Contains", sQuery), 
                                                
                                                new sap.ui.model.Filter("Actdc",
                                                              "Contains", sQuery), ], "OR");
                                   var filter2 = new sap.ui.model.Filter("IconColor",
                                    "Contains","#009de0");

                                   oBinding.filter([filter1,filter2],"AND");
                            }else{
                                   oBinding.filter(new sap.ui.model.Filter("IconColor",
                                     "Contains","#009de0"),
                                     new sap.ui.model.Filter("Createdby",
                                                "Contains", ""));
                            }
                     },
                     
                     selectFile : function(oEvent){
                      if (!oControllerS6.selectFolderPopup) {
           oControllerS6.selectFolderPopup = sap.ui.xmlfragment(
             "flm.fiori.view.selectFolder", oControllerS6);
          }
           oControllerS6.selectFolderPopup.setModel(this.getView().getModel(
             "i18n"), "i18n");
           var guid = oEvent.getParameters().listItem
                                .getBindingContext("files").getObject().CaseGuid;
           workItemId = oEvent.getParameters().listItem.getBindingContext("files").getObject().WiID;
           oFolderModel = new sap.ui.model.json.JSONModel();
           oFolderModel
                                .loadData(
                                             serviceUrl
                                                           + "/FILE_DOC_FI?param_1='FS'&param_2='"+ guid+ "'&param_3='ARCHIVE'&param_4=''&param_5=''",
                                             null, true);
           sap.ui.getCore().byId("idFileNumberForSelectFolder").setValue(oEvent.getParameters().listItem
                                     .getBindingContext("files").getObject().Filenumber);
           sap.ui.getCore().byId("idFileNumberForSelectFolder").setName(oEvent.getParameters().listItem
                                     .getBindingContext("files").getObject().CaseGuid);
           sap.ui.getCore().byId("idFoldersForFile").setModel(oFolderModel);
          oControllerS6.selectFolderPopup.open();
                     },
                     
                     onSelectFolderOkButton : function(oEvent){
                      oModel = new sap.ui.model.json.JSONModel();
       oModel
         .attachRequestCompleted(
           oEvent,
           function(oEvt) {
            oModel
              .detachRequestCompleted();
            var fileUploadResponse = oModel.oData.d.results[0];
            if (fileUploadResponse.msg_type != "E") {
             sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_86"));
            } else {
             sap.m.MessageBox
               .alert(fileUploadResponse.msg_text);
            }
            sap.ui.getCore().byId("idFolderForFileDialog").close();
            sap.ui.getCore().byId("idSelectFileForDaak").close();
            oControllerS6
              .customBusyDialogClose();

           }, oControllerS6);
       oControllerS6.customBusyDialogOpen();
       oModel.loadData(serviceUrl
         + "/FILE_DOC_FI?param_1='AD'&param_2='"
         + sap.ui.getCore().byId("idFileNumberForSelectFolder").getName()
         + "'&param_3='"
         + encodeURIComponent(oControllerS6.data.basic.FileNumber)
         + "'&param_4='"
         + workItemId
         + "'&param_5='"
         + sap.ui.getCore().byId("idFoldersForFile").getSelectedKey()
         +"'",
         null, true);
     },

     /*Action called on different Button actions*/
     continueAfterSave : function(actionId) {
      if (actionId == "navButtonPress") {
       oControllerS6.navToPreviousAction();
      } else if (actionId == "idPrint1") {
       oControllerS6.printWorkflowAction();
      } else if (actionId == "idPrint2") {
       oControllerS6.printNotingPrivateAction();
      } else if (actionId == "idPrint3") {
       oControllerS6.printNotingAction();
      } else if (actionId == "sendAction") {
       oControllerS6.sendFileButtonPressed();
      } else if (actionId == "shareAction") {
       if(oControllerS6.byId("commenteditor").getValue()==""){
        sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_66"));
        return;
       }
       oControllerS6.shareButtonPressed();
      } else if (actionId.indexOf("moveToCabinetDaakAction") != -1) {
       oControllerS6.moveToCabinetButtonPressed();
      } else if (actionId.indexOf("closeFileAction") != -1) {
       oControllerS6.closeFileButtonPressed();
      } else if (actionId == "sendPreviousAction") {
       oControllerS6.sendPreviousButtonPressed();
      }
     },

   /*Function to invoke saving data*/
     invokeForSave : function(oEvent) {

      var actionId = "";
      if (oEvent.getId() == "navButtonPress") {
       actionId = oEvent.getId();
      } else {
       actionId = oEvent.getSource().getId();
      }
      if (oControllerS6.saveFlag) {
       if(actionId == "sendAction"){
        sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_100"));
        return;
       }
       else{
       sap.m.MessageBox
         .confirm(
           this.getView().getModel("i18n").getObject("MESSAGE_99"),
           function(response) {
            if (response == "OK") {
//             oControllerS2.saveButtonPressed();
             oControllerS6.continueAfterSave(actionId);
             oControllerS6.saveFlag = false;
//             oControllerS2.flatObj=undefined;
            } else {
//             oControllerS2.continueAfterSave(actionId);
//             oControllerS2.saveFlag = false;
//             oControllerS2.flatObj = undefined;
             return;
            }
           });
       }
      } else {
       oControllerS6.continueAfterSave(actionId);
      }
     },

     /*Print Actions*/
     printWorkflowAction : function(oEvent) {
      window
        .open(serviceUrl
          + "/FILE_DOC_ES(Guid='"
          + this.caseguid
          + "',DocumentNumber='',DocumentName='',Version='',PhysVersion='')/$value");


     },
     printNotingPrivateAction : function(oEvent) {
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.loadData(serviceUrl
        + "/FILE_DOC_FI?param_1='PN'&param_2='"
        + this.caseguid + "'&param_3='" + this.fileid
        + "'&param_4='"+this.wiId+"'&param_5=''", null, false);
      if (oModel.getData().d.results[0].FileType == "text/html") {

       var newWindow = window.open("Notings.html",
         "daakwin", '');
       try{
       newWindow.document
         .write(decodeURIComponent(oModel.getData().d.results[0].FileContent));
       }catch(err){
        newWindow.document
        .write(oModel.getData().d.results[0].FileContent);
       }

       // .open("data:text/html," +
       // oModel.getData().d.results[0].FileContent);
       // + encodeURIComponent(oModel
       // .getData().d.results[0].FileContent));
      }
     },
     printNotingAction : function(oEvent) {
      // var str_pdf;

      var oModel = new sap.ui.model.json.JSONModel();
      oModel.loadData(serviceUrl
        + "/FILE_DOC_FI?param_1='PY'&param_2='"
        + this.caseguid + "'&param_3='" + this.fileid
        + "'&param_4='"+this.wiId+"'&param_5=''", null, false);
      if (oModel.getData().d.results[0].FileType == "text/html") {
//       window
//         .open("data:text/html,"
//           + encodeURIComponent(oModel
//             .getData().d.results[0].FileContent));
       var newWindow = window.open("Notings.html",
         "daakwin", '');
       try{
       newWindow.document
         .write(decodeURIComponent(oModel.getData().d.results[0].FileContent));
       }catch(err){
        newWindow.document
        .write(oModel.getData().d.results[0].FileContent);
       }
      }
     },

     moveToCabinetButtonPressed : function(oEvent) {

      var assistFlag = this.oSource.getController().assistFlag;
      if (assistFlag == true) {
       this.cabinetSharedDialogOpen();
      } else {
       if (!this.oMoveToCabinet) {
        this.oMoveToCabinet = sap.ui.xmlfragment(
          "flm.fiori.view.moveToCabinet", this);
       }
       sap.ui.getCore().byId("datePick").setValue("");
       this.oMoveToCabinet.open();
      }
     },

     onResubDateCloseButton : function(oEvent) {
      sap.ui.getCore().byId("datePick").setValue("");
      oEvent.getSource().getParent().close();
     },

     onResubDateOkButton : function(oEvent) {
      this.customBusyDialogOpen();

      var date = new Date();

      if ((date.getMonth() + 1) < 10) {
       month = "0" + (date.getMonth() + 1);
      } else {
       month = date.getMonth() + 1;
      }
      if ((date.getDate()) < 10) {
       day = "0" + (date.getDate());
      } else {
       day = date.getDate();
      }
      var year = date.getFullYear();
      var dateMonth = month+day;
      var currentDate = year + dateMonth;
      var resubDate = sap.ui.getCore().byId("datePick")
        .getValue();
      if (resubDate == "") {
       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_28"));
       this.customBusyDialogClose();

      } else if (resubDate <= currentDate) {
       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_29"));
       this.customBusyDialogClose();

      } else {

       var oModel = new sap.ui.model.json.JSONModel();
       oModel
         .attachRequestCompleted(
           oEvent,
           function(oEvt) {

            oModel.detachRequestCompleted();
            if (oModel.getData().d.results[0].msg_type == "S") {
             var tempModel = this.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId(
                 "idFilesTable")
               .getModel("files");
             var tempArr = tempModel.oData.results;
             var i = 0, j = -1, file = null;
             while (i < tempArr.length) {
              if (tempArr[i].CaseGuid == oControllerS6.caseguid) {
               j = i;
               break;
              }
              i++;
             }
             if (j != -1) {
              this.oRouter
                .getView(
                  "flm.fiori.view.S1")
                .byId(
                  "idFilesTable")
                .removeSelections();
              file = tempArr.splice(
                j, 1);
              tempModel.oData.__count--;
              tempModel.checkUpdate();
             }
             if (file != null) {
              var tempModel = this.oRouter
                .getView(
                  "flm.fiori.view.S1")
                .byId(
                  "idCabinetTable")
                .getModel(
                  "files");
              var tempArr = tempModel.oData.results;

              file[0].Readmail = "sap-icon://email";
              tempArr.splice(0, 0,
                file[0]);
              tempModel.oData.__count++;
              tempDate = sap.ui.getCore().byId("datePick").getDateValue();
                function pad(s) {
                 return (s < 10) ? '0' + s : s; 
                 }
              tempModel.oData.results[0].Rdate = [pad(tempDate.getDate()),pad(tempDate.getMonth()+1),tempDate.getFullYear()].join('.');
              tempModel.checkUpdate();
             }
             oControllerS6
               .customBusyDialogClose();
             oControllerS6.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId("closeAction")
               .setEnabled(false);
             oControllerS6.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId("sendAction")
               .setEnabled(false);
             oControllerS6.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId(
                 "idFilesTable")
               .removeSelections();
             destroyDialogs(oControllerS6); //destroy all common fragments
             oControllerS6.oRouter
               .navTo("fullscreen");
             if (oModel.getData().d.results[0].msg_type == "S") {
              sap.m.MessageToast
                .show(oModel
                  .getData().d.results[0].msg_text);
             } else {
              sap.m.MessageToast
                .show(oModel
                  .getData().d.results[0].msg_text);
             }

            } else {
             sap.m.MessageBox
               .alert(oModel
                 .getData().d.results[0].msg_text);
             this
               .customBusyDialogClose();
            }

           }, oControllerS6);
       oModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='MC'&param_2='"
             + this.caseguid
             + "'&param_3='"
             + this.wiId
             + "'&param_4='"
             + this.fileid
             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='INTRAY'&param_8='"
             + resubDate
             + "'&param_9=''&param_10=''",
           null, true);
      }
     },

     // Move to Intray Action
     moveToIntrayButtonPressed : function(oEvent) {

      var oModel = new sap.ui.model.json.JSONModel();
      oModel
        .attachRequestCompleted(
          oEvent,
          function(oEvent) {

           oModel.detachRequestCompleted();
           var tempModel = this.oRouter
             .getView(
               "flm.fiori.view.S1")
             .byId("idCabinetTable")
             .getModel("files");
           var tempArr = tempModel.oData.results;
           var i = 0, j = -1, file = null;
           while (i < tempArr.length) {
            if (tempArr[i].CaseGuid == oControllerS6.caseguid) {
             j = i;
             break;
            }
            i++;
           }
           if (j != -1) {
            this.oRouter.getView(
              "flm.fiori.view.S1")
              .byId("idCabinetTable")
              .removeSelections();
            file = tempArr.splice(j, 1);
            tempModel.oData.__count--;
            tempModel.checkUpdate();
           }
           if (file != null) {
            var tempModel = this.oRouter
              .getView(
                "flm.fiori.view.S1")
              .byId("idFilesTable")
              .getModel("files");
            var tempArr = tempModel.oData.results;

            file[0].Readmail = "sap-icon://email";
            tempArr.splice(0, 0, file[0]);
            tempModel.oData.__count++;
            tempModel.checkUpdate();
           }
           oControllerS6
             .customBusyDialogClose();
           this.oRouter.getView(
           "flm.fiori.view.S1").byId(
           "moveIntrayAction").setEnabled(
           false);
           this.oRouter.getView(
             "flm.fiori.view.S1").byId(
             "sendAction").setEnabled(
             false);
           this.oRouter.getView(
             "flm.fiori.view.S1").byId(
             "closeAction").setEnabled(
             false);
           this.oRouter.getView(
             "flm.fiori.view.S1").byId(
             "idFilesTable")
             .removeSelections();
           this.oRouter.getView(
           "flm.fiori.view.S1").byId(
           "idCabinetTable")
           .removeSelections();
           destroyDialogs(oControllerS6); //destroy all common fragments
           oControllerS6.oRouter
             .navTo("fullscreen");
           if (oModel.getData().d.results[0].msg_type == "S") {
            sap.m.MessageToast
              .show(oModel.getData().d.results[0].msg_text);
           } else {
            sap.m.MessageToast
              .show(oModel.getData().d.results[0].msg_text);
           }
          }, oControllerS6);

      this.customBusyDialogOpen();
      oModel
        .loadData(
          serviceUrl
            + "/FILES_FI?param_1='MI'&param_2='"
            + this.caseguid
            + "'&param_3='"
            + this.wiId
            + "'&param_4='"
            + this.fileid
            + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
          null, true);
     },

                    onF4Search : function(oEvt) {

                        var aFilters = [];
                        var sQuery = oEvt.getSource().getValue();
                        var oTable = sap.ui.getCore().byId("idF4ValueTable");
                        var oBinding = oTable.getBinding("items");
                        if (sQuery && sQuery.length > 0) {
                              oBinding.filter(new sap.ui.model.Filter([
                                             new sap.ui.model.Filter("ResulltCol1",
                                                          "Contains", sQuery),
                                             new sap.ui.model.Filter("ResultCol2",
                                                          "Contains", sQuery),
                                             new sap.ui.model.Filter("ResulltCol3",
                                                          "Contains", sQuery), ], "OR"));
                       }

                        var list = sap.ui.getCore().byId("idF4ValueTable");
                        var k = list.getItems();

                        var binding = list.getBinding("items");
                        binding.filter(aFilters, "Application");
                        this.afterSearchRecovery();
                 },
                 
                 afterSearchRecovery : function() {
                     
                     var oTable = sap.ui.getCore().byId("idF4ValueTable");
                     var t = oTable.getItems()[0].getCells();
                     if (t[0].getText() == sap.ui.getCore().byId(
                                   "f4collabl1").getText()
                                   && t[1].getText() == sap.ui.getCore().byId(
                                                 "f4collabl2").getText()
                                   && t[2].getText() == sap.ui.getCore().byId(
                                                 "f4collabl3").getText()) {
                            oTable.getItems()[0].setVisible(false);
                     }
              },
              
           /* Send section from search */
              sendFromSearchActionDaak : function(oEvent) {
     if (!this._sendSameUser) {
      this._sendSameUser = sap.ui.xmlfragment(
        "flm.fiori.view.searchSend", this);
     }
     sap.ui.getCore().byId("idProcessorName").setValue("");
     sap.ui.getCore().byId("idProcDate").setValue("");
     sap.ui.getCore().byId("idProcDays").setValue("");
     sap.ui.getCore().byId("sendCommentEditor").setValue("");
     var procSelect = sap.ui.getCore().byId("idProcessorSelect");
     var procSelectModel = new sap.ui.model.json.JSONModel({});
     procSelectModel
       .loadData(serviceUrl
         + "/FILE_F4_ES?$filter=CaseGuid eq '"
            + this.caseguid
            + "' and OtherF4 eq true and ID eq 'WC'");
     procSelect.setModel(procSelectModel, "procType");
     var select2 = sap.ui.getCore().byId("idActivitySelect");
     var select2Model = new sap.ui.model.json.JSONModel({});
     select2Model
       .loadData(serviceUrl
         + "/FILE_F4_ES?$filter=CaseGuid eq '"
            + this.caseguid
            + "' and OtherF4 eq true and ID eq 'TY'");
     select2.setModel(select2Model, "actvt");
     this._sendSameUser.open();
    },

    searchSendActionPress : function(oEvent) {
     var agentName = sap.ui.getCore().byId("idProcessorName").getName();
     var procDays = sap.ui.getCore().byId("idProcDays")
       .getValue();
     if (sap.ui.getCore().byId("idActivitySelect")
       .getSelectedKey() == " ") {
      sap.m.MessageBox
        .alert(this.getView().getModel("i18n").getObject("MESSAGE_47"));
      return;
     } else {
      var activity = sap.ui.getCore().byId(
        "idActivitySelect").getSelectedKey();
     }
     var date = new Date();

     if ((date.getMonth() + 1) < 10) {
      month = "0" + (date.getMonth() + 1);
     } else {
      month = date.getMonth() + 1;
     }
     var currentDate = date.getFullYear()+ "/" + month + "/"+ date.getDate();
     var procDate = sap.ui.getCore().byId("idProcDate")
       .getValue();
     var pDate = procDate.replace("/", "").replace("/", "");
     if (procDate == null) {
      sap.m.MessageToast
        .show(this.getView().getModel("i18n").getObject("MESSAGE_28"));

     } else if (procDate <= currentDate) {
      sap.m.MessageToast
        .show(this.getView().getModel("i18n").getObject("MESSAGE_29"));
     }
     var comment = sap.ui.getCore().byId("sendCommentEditor").getValue();
     if(comment == ""){
      sap.m.MessageBox.alert(this.getView()
        .getModel("i18n").getObject(
          "MESSAGE_36"));
     }
     if (procDate != "" && procDays != "") {

      sap.m.MessageToast
        .show(this.getView().getModel("i18n").getObject("MESSAGE_46"));

      return;

     } else
      var oModel = new sap.ui.model.json.JSONModel();
     oModel
       .loadData(
         serviceUrl
           + "/FILES_FI?param_1='SS'&param_2='"
           + this.caseguid
           + "'&param_3='"
           + activity
           + "'&param_4='"
           + pDate
           + "'&param_5='"
           + procDays
           + "'&check_1=''&check_2='ISDAAK'&check_3=''&param_6='"+agentName+"'&param_7='"+comment+"'&param_8=''&param_9=''&param_10=''",
         null, false);
     if (oModel.getData().d.results[0].msg_type == "S") {
      sap.m.MessageToast
        .show(oModel.getData().d.results[0].msg_text);
     } else {
      sap.m.MessageToast
        .show(oModel.getData().d.results[0].msg_text);
      return;
     }
     this._sendSameUser.close();
     this.oRouter.navTo("daaksearchscreen");
     ;
    },

    onSendSearchCloseButton : function(oEvent) {
     this._sendSameUser.close();
    },


    onChangeTypeSelection : function(oEvent) {
     if (!oControllerS6._oDynamicF4Dialog) {
      oControllerS6._oDynamicF4Dialog = sap.ui
        .xmlfragment(
          "flm.fiori.view.dynamicF4popup",
          oControllerS6);

     }
     if (sap.ui.getCore().byId("idUsername") != undefined) {
      sap.ui.getCore().byId("idUsername").setValue("");
     }
     if (sap.ui.getCore().byId("idProcessorName") != undefined) {
      sap.ui.getCore().byId("idProcessorName").setValue("");
     }
     var otypeModel = new sap.ui.model.json.JSONModel();var otextModel = new sap.ui.model.json.JSONModel();
     var otext = {
      title : oEvent.getSource().getSelectedItem()
        .getText(),
      id : "nameInput",
     };
     otextModel.setData(otext);
     oControllerS6._oDynamicF4Dialog.setModel(otextModel,
       "dyntext");
     oControllerS6._oDynamicF4Dialog.setModel(otypeModel);
     oControllerS6.getView().byId("daakProcessorInput").setValue("");

    },

    raiseFlag : function(oEvent){

     sap.m.MessageToast.show(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_57"));
     oEvent.getSource().setValue("");
    },

    /*Check noting in a larger view from workflow*/
     onSeeMorePress1 : function(oEvent){
      if (!oControllerS6.seeMoreOpen) {
       oControllerS6.seeMoreOpen = sap.ui.xmlfragment(
         "flm.fiori.view.seeMoreNote", oControllerS6);
      }
      oControllerS6.seeMoreOpen.rerender();
      sap.ui.getCore().byId("seeMoreText").setContent(null);
      sap.ui.getCore().byId("seeMoreText").setContent(decodeURIComponent(oEvent.getSource().getParent().getParent().getBindingContext().getObject().Prefix1));
      oControllerS6.seeMoreOpen.open();

    },

    onSeeMorePress2 : function(oEvent){
     if (!oControllerS6.seeMoreOpen) {
      oControllerS6.seeMoreOpen = sap.ui.xmlfragment(
        "flm.fiori.view.seeMoreNote", oControllerS6);
     }
     oControllerS6.seeMoreOpen.rerender();
     sap.ui.getCore().byId("seeMoreText").setContent(null);
     sap.ui.getCore().byId("seeMoreText").setContent(decodeURIComponent(oEvent.getSource().getParent().getParent().getBindingContext().getObject().Prefix2));
     oControllerS6.seeMoreOpen.open();

    },

    onSeeMoreNoteCloseButton : function(oEvent) {
     oEvent.getSource().getParent().close();
    },

    /*Sending back to previous processor */
    sendBackDaakEventPressed : function(oEvent){
     oControllerS6.customBusyDialogOpen();
     sap.m.MessageBox
     .confirm(
       this.getView().getModel("i18n").getObject("MESSAGE_101"),
       function(oResponse){
        if (oResponse == "OK") {
               // check for digital signature customizationg
                if(oControllerS6.data.basic.DigSignReq || oControllerS6.createSignFlag){
                 if(oControllerS6.customDigitalSignData){
                  oControllerS6.customDigitalSignData(oControllerS6.data, jQuery.proxy(function() {
                   oControllerS6.confirmSendBackFile(oControllerS6.caseguid,
                     oControllerS6.wiId,
                     oControllerS6.fileid,
                     oControllerS6.fromTab);
                               
                               }, oControllerS6));
                 }else{
                  sap.m.MessageBox.alert(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_73"));
                  oControllerS6
                  .customBusyDialogClose();
                  }
                }else{
                 oControllerS6
                 .confirmSendBackFile(
                   oControllerS6.caseguid,
                   oControllerS6.wiId,
                   oControllerS6.fileid,
                   oControllerS6.fromTab);
                }
        }else{
         oControllerS6
         .customBusyDialogClose();
        }
       });

    },


   confirmSendBackFile : function(caseguid, wiId, fileid, fromTab) {
    var oModel = new sap.ui.model.json.JSONModel();

    oModel
      .attachRequestCompleted(
        oControllerS6,
        function(oEvent) {

         oModel.detachRequestCompleted();

         if (oModel.getData().d.results[0].msg_type == "E") {
          oControllerS6
            .customBusyDialogClose(oControllerS6);
          sap.m.MessageBox
            .alert(oModel.getData().d.results[0].msg_text);
         } else {

          // delete the file from the tab
          var oTableId = null;
          var oEntitySet = null;
          switch (oControllerS6.fromTab) {
          case "INTRAYDAAK":
           oTableId = "idFilesTable";
           oEntitySet = "/FILE_INTRAY_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
           break;

          case "SUBSTITUTEDAAK":
           oTableId = "idSubstituteTable";
           oEntitySet = "/FILE_SUBST_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
           break;
          }
          var tempModel = oControllerS6.oRouter
            .getView(
              "flm.fiori.view.S1")
            .byId(oTableId)
            .getModel("files");
          tempModel
            .attachRequestCompleted(
              oControllerS6,
              function(oEvent) {
               tempModel
                 .detachRequestCompleted();
               if (tempModel.oData.d != undefined) {
                tempModel
                  .setData(tempModel.oData.d);
                tempModel
                  .checkUpdate();
                sap.m.MessageToast
                  .show(oModel
                    .getData().d.results[0].msg_text);
               }
               oControllerS6
                 .customBusyDialogClose(oControllerS6);

               oControllerS6.oRouter
                 .getView(
                   "flm.fiori.view.S1")
                 .byId(
                   oTableId)
                 .removeSelections();
               destroyDialogs(oControllerS6); //destroy all common fragments
               oControllerS6.oRouter
                 .navTo("fullscreen");
              },
              oControllerS6);
          tempModel.loadData(serviceUrl
            + oEntitySet, null,
            true);
         }

        }, oControllerS6);

    oModel
      .loadData(
        serviceUrl
          + "/FILES_FI?param_1='OS'&param_2='"
          + oControllerS6.caseguid
          + "'&param_3='"
          + oControllerS6.wiId
          + "'&param_4='"
          + oControllerS6.fileid
          + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
          + oControllerS6.fromTab
          + "'&param_8=''&param_9=''&param_10=''",
        null, false);

   },

   onUploadCompleteNV : function(oEvent) // uploading new version
   {

    oControllerS6.customBusyDialogOpen();
    var sResponse = oEvent.getParameter("response");
    var resToken = sResponse.split(',');
    var fileAttr = new Array();
    var nameVal, statusMsg = "", statusIcon = null;
    for (var i = 0; i < resToken.length; ++i) {
     nameVal = resToken[i].split(':');
     fileAttr[nameVal[0]] = nameVal[1];
    }
    if (fileAttr["Status"] == "Successful") {
     sap.m.MessageToast
       .show(this.getView().getModel("i18n").getObject("MESSAGE_40"));
     oControllerS6.documentId.getObject().DeleteEnabledRef = false;
     oControllerS6.getView().getModel("createdaak")
       .checkUpdate();
     sap.ui.getCore().byId("idNewVersionUpload")
       .close();
    } else {
     sap.m.MessageToast.show(oControllerS6.getView().getModel("i18n").getObject("MESSAGE_41"));
    }
    oControllerS6.customBusyDialogClose();
   },
                           });