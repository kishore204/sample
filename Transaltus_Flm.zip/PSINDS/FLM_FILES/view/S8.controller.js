/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.ca.ui.message.message");
var archiveFlag = false;
sap.ca.scfld.md.controller.BaseFullscreenController.extend("flm.fiori.view.S8", {
	data: {
		priority: null,
		criteria: null,
		operators: null,
		searchData: null,
		searchResults: null,
	},
	linkPress: false,
	onInit: function() {
		serviceUrl = this.getView().getModel().sServiceUrl;
		if (sap.ui.getCore().getModel("i18n") == undefined) {
			sap.ui.getCore().setModel(this.getView().getModel("i18n"), "i18n")
		}
		this.getView().addEventDelegate({
			onBeforeShow: jQuery.proxy(function(e) {
				this.onBeforeShow(e)
			}, this)
		});
		this.mGroupFunctions = {
			PriorityText: function(c) {
				var n = c.getProperty("PriorityText");
				return {
					key: n,
					text: n
				}
			},
			CreatedByFname: function(c) {
				var n = c.getProperty("CreatedByFname");
				return {
					key: n,
					text: n
				}
			},
			CaseTypeDescr: function(c) {
				var n = c.getProperty("CaseTypeDescr");
				return {
					key: n,
					text: n
				}
			},
		};
		this._oTPS = new sap.m.TablePersoController({
			table: this.getView().byId("idSearchTable"),
			persoService: flm.fiori.utils.inboxPersonalDialog
		}).activate();
		if (!this.f4popup) {
			this.f4popup = sap.ui.xmlfragment("flm.fiori.view.dynamicF4popup", this)
		}
		var p = new sap.ui.model.json.JSONModel();
		p.loadData(serviceUrl + "/FILE_F4_ES?$filter=ID eq 'PRIO'", null, false);
		this.data.priority = p.oData.d.results;
		this.data.criteria = [{
			key: "CASE_TITLE",
			title: this.getView().getModel("i18n").getObject("SUBJECT")
		}, {
			key: "DAAK_TYPE",
			title: this.getView().getModel("i18n").getObject("FILENUMBER")
		}, {
			key: "CREATED_BY",
			title: this.getView().getModel("i18n").getObject("CREATEDBY")
		}, {
			key: "CHANGED_BY",
			title: this.getView().getModel("i18n").getObject("LASTCHANGEDBY")
		}, {
			key: "CLOSED_BY",
			title: this.getView().getModel("i18n").getObject("CLOSEDBYUSER")
		}, {
			key: "CREATE_TIME",
			title: this.getView().getModel("i18n").getObject("CREATEDON")
		}, {
			key: "PLAN_END_DATE",
			title: this.getView().getModel("i18n").getObject("DUEDATE")
		}, {
			key: "ARCHIVE",
			title: this.getView().getModel("i18n").getObject("READFROMARCHIVE")
		}, {
			key: "STAT_ORDERNO",
			title: this.getView().getModel("i18n").getObject("STATUS")
		}, {
			key: "SAP_FLM_PRIO",
			title: this.getView().getModel("i18n").getObject("PRIORITY")
		}, {
			key: "FILE_TYPE",
			title: this.getView().getModel("i18n").getObject("FILETYPE")
		}, {
			key: "ORG_UNIT",
			title: this.getView().getModel("i18n").getObject("ORGANIZATIONGROUP")
		}, ];
		this.data.operators = [{
			criteria: "GEN1",
			opkey: "01",
			optext: this.getView().getModel("i18n").getObject("IS")
		}, {
			criteria: "GEN2",
			opkey: "05",
			optext: this.getView().getModel("i18n").getObject("CONTAINS")
		}, {
			criteria: "GEN2",
			opkey: "04",
			optext: this.getView().getModel("i18n").getObject("STARTSWITH")
		}, {
			criteria: "DATE",
			opkey: "11",
			optext: this.getView().getModel("i18n").getObject("ISEARLIERTHAN")
		}, {
			criteria: "DATE",
			opkey: "12",
			optext: this.getView().getModel("i18n").getObject("ISLATERTHAN")
		}, {
			criteria: "DATE",
			opkey: "21",
			optext: this.getView().getModel("i18n").getObject("ISEARLIERTHANORON")
		}, {
			criteria: "DATE",
			opkey: "22",
			optext: this.getView().getModel("i18n").getObject("ISLATERTHANORON")
		}, {
			criteria: "ISNOT",
			opkey: "02",
			optext: this.getView().getModel("i18n").getObject("ISNOT")
		}];
		this.data.searchData = {
			criteria1: "CASE_TITLE",
			op1: "01",
			value1: "",
			criteria2: "DAAK_TYPE",
			op2: "01",
			value2: "",
			criteria3: "CREATED_BY",
			op3: "01",
			value3: "",
			criteria4: "CHANGED_BY",
			op4: "01",
			value4: "",
			criteria5: "CLOSED_BY",
			op5: "01",
			value5: ""
		};
		var s = new sap.ui.model.json.JSONModel();
		s.setData(this.data);
		this.getView().setModel(s, "searchDaak");
		if (this.customInitializeDaakSearchData) {
			this.customInitializeDaakSearchData(this)
		}
	},
	onBeforeShow: function(e) {
		if (e.fromId.indexOf("xmlview2") > -1) {
			this.getView().byId("value1").setValue("");
			this.getView().byId("value2").setValue("");
			this.getView().byId("value3").setValue("");
			this.getView().byId("value4").setValue("");
			this.getView().byId("value5").setValue("");
			this.getView().byId("value6").setValue("");
			this.getView().byId("value8").setValue("");
			this.getView().byId("op1").setSelectedKey("01");
			this.getView().byId("op2").setSelectedKey("01");
			this.getView().byId("op3").setSelectedKey("01");
			this.getView().byId("op4").setSelectedKey("01");
			this.getView().byId("op5").setSelectedKey("01");
			this.getView().byId("op6").setSelectedKey("01");
			this.getView().byId("op8").setSelectedKey("11");
			this.getView().byId("op9").setSelectedKey("01");
			this.getView().byId("op10").setSelectedKey("01");
			this.data.searchResults = null;
			this.getView().getModel("searchDaak").checkUpdate()
		}
	},
	onpressf4User: function(e) {
		oF4Texts = new sap.ui.model.json.JSONModel();
		var f = {
			title: this.getView().getModel("i18n").getObject("USERS"),
			id: e.getSource().getId()
		};
		oF4Texts.setData(f);
		this.f4popup.setModel(oF4Texts, "dyntext");
		var F = new sap.ui.model.json.JSONModel();
		F.loadData(serviceUrl + "/FILE_F4_ES?$filter=ID eq 'US' and WF eq true", null, false);
		F.setData(F.oData.d.results);
		this.f4popup.setModel(F);
		this.f4popup.open()
	},
	onpressRecievedMode: function(e) {
		oF4Texts = new sap.ui.model.json.JSONModel();
		var f = {
			title: this.getView().getModel("i18n").getObject("RECIEVED_MODE"),
			id: e.getSource().getId()
		};
		oF4Texts.setData(f);
		this.f4popup.setModel(oF4Texts, "dyntext");
		var F = new sap.ui.model.json.JSONModel();
		F.loadData(serviceUrl + "/FILE_F4_ES?$filter=ID eq 'RM' and OtherF4 eq true", null, false);
		F.setData(F.oData.d.results);
		this.f4popup.setModel(F);
		this.f4popup.open()
	},
	onpressf4Filetype: function(e) {
		oF4Texts = new sap.ui.model.json.JSONModel();
		var f = {
			title: this.getView().getModel("i18n").getObject("FILETYPE"),
			id: e.getSource().getId()
		};
		oF4Texts.setData(f);
		this.f4popup.setModel(oF4Texts, "dyntext");
		var F = new sap.ui.model.json.JSONModel();
		F.loadData(serviceUrl + "/FILE_F4_ES?$filter=ID eq 'IT' and OtherF4 eq true", null, false);
		F.setData(F.oData.d.results);
		this.f4popup.setModel(F);
		this.f4popup.open()
	},
	onpressf4Orgunit: function(e) {
		oF4Texts = new sap.ui.model.json.JSONModel();
		var f = {
			title: this.getView().getModel("i18n").getObject("ORGANIZATIONGROUP"),
			id: e.getSource().getId()
		};
		oF4Texts.setData(f);
		this.f4popup.setModel(oF4Texts, "dyntext");
		var F = new sap.ui.model.json.JSONModel();
		F.loadData(serviceUrl + "/FILE_F4_ES?$filter=ID eq 'OC' and OtherF4 eq true", null, false);
		F.setData(F.oData.d.results);
		this.f4popup.setModel(F);
		this.f4popup.open()
	},
	_handleF4HelpSearch1: function(e) {
		var v = e.getParameter("value");
		var f = new sap.ui.model.Filter("ResulltCol1", sap.ui.model.FilterOperator.Contains, v);
		var F = new sap.ui.model.Filter("ResultCol2", sap.ui.model.FilterOperator.Contains, v);
		var o = new sap.ui.model.Filter("ResultCol3", sap.ui.model.FilterOperator.Contains, v);
		e.getSource().getBinding("items").filter(new sap.ui.model.Filter([f, F, o]), "OR")
	},
	_handleF4HelpClose1: function(e) {
		var s = e.getParameter("selectedItem");
		var i = e.getSource().getModel("dyntext").getData().id;
		var I;
		if (s) {
			if (sap.ui.getCore().byId(i) != undefined) {
				I = sap.ui.getCore().byId(e.getSource().getModel("dyntext").getData().id)
			} else {
				I = this.getView().byId(e.getSource().getModel("dyntext").getData().id)
			}
			if (s.getBindingContext().getObject().ResultCol3.substr(0, 2) == "US") {
				I.setName(s.getBindingContext().getObject().ResultCol3);
				I.setValue(s.getBindingContext().getObject().ResultCol2 + " " + s.getBindingContext().getObject().ResulltCol1)
			} else {
				I.setName(s.getBindingContext().getObject().ResultCol3);
				I.setValue(s.getBindingContext().getObject().ResulltCol1)
			}
		}
		e.getSource().getBinding("items").filter([])
	},
	onPressClear: function(e) {
		this.getView().byId("value1").setValue("");
		this.getView().byId("value2").setValue("");
		this.getView().byId("value3").setValue("");
		this.getView().byId("value4").setValue("");
		this.getView().byId("value5").setValue("");
		this.getView().byId("value6").setValue("");
		this.getView().byId("value7").setValue("");
		this.getView().byId("value8").setValue("");
		this.getView().byId("value9").setValue("");
		this.getView().byId("value10").setValue("");
		this.getView().byId("value11").setValue("");
		this.getView().byId("op1").setSelectedKey("01");
		this.getView().byId("op2").setSelectedKey("01");
		this.getView().byId("op3").setSelectedKey("01");
		this.getView().byId("op4").setSelectedKey("01");
		this.getView().byId("op5").setSelectedKey("01");
		this.getView().byId("op6").setSelectedKey("01");
		this.getView().byId("op7").setSelectedKey("01");
		this.getView().byId("op8").setSelectedKey("01");
		this.getView().byId("op9").setSelectedKey("01");
		this.getView().byId("op10").setSelectedKey("01");
		this.getView().byId("op11").setSelectedKey("01");
		this.data.searchResults = null;
		this.getView().getModel("searchDaak").checkUpdate()
	},
	onPressDaakSearch: function(e) {
		var i = -1;
		var s = new Array();
		if (this.getView().byId("value1").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value1").getValue();
			s[i].op = this.getView().byId("op1").getSelectedKey();
			s[i].criteria = "CASE_TITLE"
		}
		if (this.getView().byId("value2").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value2").getValue();
			s[i].op = this.getView().byId("op2").getSelectedKey();
			s[i].criteria = "DAAK_TYPE"
		}
		if (this.getView().byId("value3").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value3").getValue();
			s[i].op = this.getView().byId("op3").getSelectedKey();
			s[i].criteria = "REF_NUMBER"
		}
		if (this.getView().byId("value4").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value4").getName();
			s[i].op = this.getView().byId("op4").getSelectedKey();
			s[i].criteria = "CREATED_BY"
		}
		if (this.getView().byId("value5").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value5").getName();
			s[i].op = this.getView().byId("op5").getSelectedKey();
			s[i].criteria = "CLOSED_BY"
		}
		if (this.getView().byId("value6").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value6").getValue();
			s[i].op = this.getView().byId("op6").getSelectedKey();
			s[i].criteria = "CREATE_TIME"
		}
		if (this.getView().byId("value7").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value7").getValue();
			s[i].op = this.getView().byId("op7").getSelectedKey();
			s[i].criteria = "DAAK_NUMBER"
		}
		if (this.getView().byId("value8").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value8").getValue();
			s[i].op = this.getView().byId("op8").getSelectedKey();
			s[i].criteria = "RECIEVED_DATE"
		}
		if (this.getView().byId("value9").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value9").getValue();
			s[i].op = this.getView().byId("op9").getSelectedKey();
			s[i].criteria = "LETTER_DATE"
		}
		if (this.getView().byId("value10").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value10").getValue();
			s[i].op = this.getView().byId("op10").getSelectedKey();
			s[i].criteria = "RECEIVED_MODE"
		}
		if (this.getView().byId("value11").getValue() != "") {
			i++;
			s[i] = {};
			s[i].value = this.getView().byId("value11").getValue();
			s[i].op = this.getView().byId("op11").getSelectedKey();
			s[i].criteria = "RECP_NAME"
		}
		var c = "";
		var a = "";
		var b = "";
		var d = "";
		var f = "";
		var o = "";
		var g = "";
		var h = "";
		var k = "";
		var l = "";
		var v = "";
		var m = "";
		var n = "";
		var p = "";
		var q = "";
		var r = this.getView().byId("resultCount").getValue();
		if (s.length > 5) {
			sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_01"))
		} else if (s.length == 0) {
			sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_02"))
		} else {
			for (var j = 0; j < s.length; j++) {
				if (j == 0) {
					c = s[j].criteria;
					o = s[j].op;
					v = s[j].value
				} else if (j == 1) {
					a = s[j].criteria;
					g = s[j].op;
					m = s[j].value
				} else if (j == 2) {
					b = s[j].criteria;
					h = s[j].op;
					n = s[j].value
				} else if (j == 3) {
					d = s[j].criteria;
					k = s[j].op;
					p = s[j].value
				} else if (j == 4) {
					f = s[j].criteria;
					l = s[j].op;
					q = s[j].value
				}
			}
			var t = new sap.ui.model.json.JSONModel();
			this.busyDialogOpen();
			t.attachRequestCompleted(this, function(e) {
				this.data.searchResults = t.oData.d.results;
				for (var j = 0; j < t.oData.d.results.length; j++) {
					var u = t.oData.d.results[j].PlanEndDate.split(".");
					var w = new Date(u[2], u[1] - 1, u[0]);
					t.oData.d.results[j].dueDate = w
				}
				for (var j = 0; j < t.oData.d.results.length; j++) {
					var x = t.oData.d.results[j].CreateTime.split(" ");
					var y = x[0].split(".");
					var w = new Date(y[2], y[1] - 1, y[0]);
					t.oData.d.results[j].crDate = w
				}
				this.getView().getModel("searchDaak").checkUpdate();
				this.busyDialogClose()
			}, this);
			t.loadData(serviceUrl + "/FILE_SRCH_FI?action='SI'&crit_1='" + c + "'&crit_2='" + a + "'&crit_3='" + b + "'&crit_4='" + d +
				"'&crit_5='" + f + "'&oper_1='" + o + "'&oper_2='" + g + "'&oper_3='" + h + "'&oper_4='" + k + "'&oper_5='" + l + "'&value_1='" +
				encodeURIComponent(v) + "'&value_2='" + encodeURIComponent(m) + "'&value_3='" + encodeURIComponent(n) + "'&value_4='" +
				encodeURIComponent(p) + "'&value_5='" + encodeURIComponent(q) + "'&max_res='" + r + "'&is_type=''", null, true)
		}
	},
	navToFirstPage: function(e) {
		this.oRouter.navTo("fullscreen")
	},
	navToDetailsPage: function(e) {
		if (this.linkPress) {
			this.linkPress = false;
			return
		}
		if (this.getView().byId("value9").getState() == true) {
			archiveFlag = true;
			var a = new sap.ui.model.json.JSONModel();
			a.loadData(serviceUrl + "/FILES_FI?param_1='AR'&param_2='" + e.getParameters().listItem.getBindingContext("searchDaak").getObject().CaseGuid +
				"'&param_3='" + e.getParameters().listItem.getBindingContext("searchDaak").getObject().Wfpthid + "'&param_4='" + e.getParameters().listItem
				.getBindingContext("searchDaak").getObject().PsReference +
				"'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''", null, false);
			if (a.getData().d.results.length == 0) {
				this.oRouter.navTo("subscreen", {
					caseguid: e.getParameters().listItem.getBindingContext("searchDaak").getObject().CaseGuid,
					fileid: e.getParameters().listItem.getBindingContext("searchDaak").getObject().ExtKey,
					wiId: e.getParameters().listItem.getBindingContext("searchDaak").getObject().WiID
				})
			} else if (a.getData().d.results[0].msg_type == "E") {
				sap.m.MessageBox.alert(a.getData().d.results[0].msg_text);
				return
			}
		} else {
			var b = new sap.ui.model.json.JSONModel();
			b.loadData(serviceUrl + "/FILES_FI?param_1='OD'&param_2='" + e.getParameters().listItem.getBindingContext("searchDaak").getObject().CaseGuid +
				"'&param_3='" + e.getParameters().listItem.getBindingContext("searchDaak").getObject().Wfpthid +
				"'&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''", null, false);
			if (b.getData().d.results.length == 0) {
				this.oRouter.navTo("subscreen", {
					caseguid: e.getParameters().listItem.getBindingContext("searchDaak").getObject().CaseGuid,
					fileid: e.getParameters().listItem.getBindingContext("searchDaak").getObject().ExtKey,
					wiId: e.getParameters().listItem.getBindingContext("searchDaak").getObject().WiID
				})
			} else if (b.getData().d.results[0].msg_type == "E") {
				sap.m.MessageBox.alert(b.getData().d.results[0].msg_text);
				return
			}
		}
	},
	onProcessorLinkClick: function(e) {
		this.linkPress = true;
		if (!this.processorNames) {
			this.processorNames = sap.ui.xmlfragment("flm.fiori.view.processorsList", this)
		}
		var P = e.getSource().getParent().getBindingContext("searchDaak").getObject().Wfpthid;
		var m = new sap.ui.model.json.JSONModel();
		m.loadData(serviceUrl + "/FILE_SENT_FI?param_1='MP'&param_2='" + P + "'&param_3=''", null, false);
		this.processorNames.setModel(m, "sentModelDetail");
		this.processorNames.openBy(e.getSource())
	},
	onSentProcessorsListAction: function(e) {
		e.getSource().getParent().getParent().destroy()
	},
	busyDialogOpen: function(b) {
		if (!this._busyDialog) {
			this._dialog = sap.ui.xmlfragment("flm.fiori.view.busyDialog", this)
		}
		if (b != null) {
			this._dialog.setText(b)
		} else {
			this._dialog.setText("")
		}
		this._dialog.open()
	},
	busyDialogClose: function() {
		this._dialog.close()
	},
	raiseFlag: function(e) {
		sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_57"));
		e.getSource().setValue("")
	},
	onResultSearch: function(e) {
		var q = e.getSource().getValue();
		var t = this.getView().byId("idSearchTable");
		var b = t.getBinding("items");
		if (q && q.length > 0) {
			b.filter(new sap.ui.model.Filter([new sap.ui.model.Filter("CreatedByFname", "Contains", q), new sap.ui.model.Filter("PsReference",
					"Contains", q), new sap.ui.model.Filter("CaseTitle", "Contains", q), new sap.ui.model.Filter("Status", "Contains", q), new sap.ui
				.model.Filter("PriorityText", "Contains", q), new sap.ui.model.Filter("CaseTypeDescr", "Contains", q), new sap.ui.model.Filter(
					"AgentFullname", "Contains", q), new sap.ui.model.Filter("CreateTime", "Contains", q), new sap.ui.model.Filter("DateRecieved",
					"Contains", q), new sap.ui.model.Filter("Actdc", "Contains", q),
			], "OR"))
		} else {
			b.filter(new sap.ui.model.Filter("CreatedByFname", "Contains", ""))
		}
	},
	handleSearchFilter: function(e) {
		this._oDialog = sap.ui.xmlfragment("flm.fiori.view.searchFilterDialog", this);
		this._oDialog.open()
	},
	handleSearchPersonalization: function(e) {
		this._oTPS.openDialog()
	},
	handleSearchSettings: function(e) {
		var v = this.getView();
		var t = v.byId("idSearchTable");
		var p = e.getParameters();
		var b = t.getBinding("items");
		var s = [];
		if (p.groupItem) {
			var P = p.groupItem.getKey();
			var d = p.groupDescending;
			var g = this.mGroupFunctions[P];
			s.push(new sap.ui.model.Sorter(P, d, g))
		}
		var P = p.sortItem.getKey();
		var d = p.sortDescending;
		s.push(new sap.ui.model.Sorter(P, d));
		b.sort(s);
		var f = [];
		jQuery.each(p.filterItems, function(i, I) {
			var P = I.getKey();
			if (P != 'query_filter_files') {
				var F = new sap.ui.model.Filter(P, sap.ui.model.FilterOperator.EQ, true);
				f.push(F)
			}
		});
		b.filter(f)
	},
	onSelectDaak: function(e) {
		if (this.linkPress) {
			this.linkPress = false;
			return
		}
		var a = new sap.ui.model.json.JSONModel();
		a.loadData(serviceUrl + "/FILES_FI?param_1='OD'&param_2='" + e.getParameters().listItem.getBindingContext("searchDaak").getObject().CaseGuid +
			"'&param_3='" + e.getParameters().listItem.getBindingContext("searchDaak").getObject().Wfpthid +
			"'&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''", null, false);
		if (a.getData().d.results.length == 0) {
			this.oRouter.navTo("daakdocscreen", {
				caseguid: e.getParameters().listItem.getBindingContext("searchDaak").getObject().CaseGuid,
				fileid: e.getParameters().listItem.getBindingContext("searchDaak").getObject().ExtKey,
				wiId: e.getParameters().listItem.getBindingContext("searchDaak").getObject().WiID
			})
		} else if (a.getData().d.results[0].msg_type == "E") {
			sap.m.MessageBox.alert(a.getData().d.results[0].msg_text);
			return
		}
	},
});