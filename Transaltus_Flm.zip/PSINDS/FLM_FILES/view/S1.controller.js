jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
//jQuery.sap.require("flm.fiori.view.component");
// jQuery.sap.require("test.fiori.Formatter");
jQuery.sap.require("sap.m.TablePersoController");
jQuery.sap.require("flm.fiori.utils.inboxPersonalDialog");
jQuery.sap.require("flm.fiori.utils.formatter");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require("flm.fiori.utils.utilities");
jQuery.sap.addUrlWhitelist(undefined);
var oControllerS1 = null;

sap.ca.scfld.md.controller.BaseFullscreenController
              .extend(
                           "flm.fiori.view.S1",
                           {
                                 sentById : null,
                                 attSection : null,
                                 fromOtherView : true,
                                 docSection : null,
                                 noteSection : null,
                                 workflowTab : null,
                                 wfInfo : null,
                                 parentOrgCode : null,
                                 fileTypeSelected : false,
                                 digSignFlag : true,
                                 itemType : null,
                                 winUrl : null,
                                 objectType : null,
                                 linkPress : false,
                                 onInit : function() {
                                        serviceUrl = this.getView().getModel().sServiceUrl;
                                        if(sap.ui.getCore().getModel("i18n") == undefined){
                                               sap.ui.getCore().setModel(this.getView().getModel("i18n"),"i18n");
                                        }
                                        
                                        //Disable following actions whenever navigate to 1st screen
                                        this.oRouter.attachRouteMatched(
                                          function(oEvent) {
                                            this.getView().byId("closeAction").setEnabled(false);
                                            this.getView().byId("sendAction").setEnabled(false);
                                               }, this);
                                        
                                        winUrl = window.location.href ;
                                        if(winUrl.search("OBJECT='FILE'") !== -1 || winUrl.search("OBJECT=%27FILE%27") !== -1){
                                         this.objectType = "FILE";
                                         this.getView().byId("assistIconTab").setVisible(true);
                                         this.getView().byId("fdueDateCol").setVisible(true);
                                         this.getView().byId("idS1IntrayDuedate").setVisible(true);
                                         this.getView().byId("fpriorityCol").setVisible(true);
                                         this.getView().byId("idS1IntrayPriority").setVisible(true);
                                         this.getView().byId("ddueDateCol").setVisible(true);
                                         this.getView().byId("idS1DraftDuedate").setVisible(true);
                                         this.getView().byId("dpriorityCol").setVisible(true);
                                         this.getView().byId("idS1DraftPriority").setVisible(true);
                                         this.getView().byId("cdueDateCol").setVisible(true);
                                         this.getView().byId("idS1CabinetDuedate").setVisible(true);
                                         this.getView().byId("cpriorityCol").setVisible(true);
                                         this.getView().byId("idS1CabinetPriority").setVisible(true);
                                         this.getView().byId("sdueDateCol").setVisible(true);
                                         this.getView().byId("idS1SubstituteDuedate").setVisible(true);
                                         this.getView().byId("spriorityCol").setVisible(true);
                                         this.getView().byId("idS1SubstitutePriority").setVisible(true);
                                         this.getView().byId("tfdueDateCol").setVisible(true);
                                         this.getView().byId("idS1TrackDuedate").setVisible(true);
                                         this.getView().byId("tfpriorityCol").setVisible(true);
                                         this.getView().byId("idS1TrackPriority").setVisible(true);
                                        }else if(winUrl.search("OBJECT='DAAK'") !== -1 || winUrl.search("OBJECT=%27DAAK%27") !== -1){
                                         this.objectType = "DAAK";
                                         this.getView().byId("assistIconTab").setVisible(false);
                                         this.getView().byId("fdueDateCol").setVisible(false);
                                         this.getView().byId("idS1IntrayDuedate").setVisible(false);
                                         this.getView().byId("fpriorityCol").setVisible(false);
                                         this.getView().byId("idS1IntrayPriority").setVisible(false);
                                         this.getView().byId("ddueDateCol").setVisible(false);
                                         this.getView().byId("idS1DraftDuedate").setVisible(false);
                                         this.getView().byId("dpriorityCol").setVisible(false);
                                         this.getView().byId("idS1DraftPriority").setVisible(false);
                                         this.getView().byId("cdueDateCol").setVisible(false);
                                         this.getView().byId("idS1CabinetDuedate").setVisible(false);
                                         this.getView().byId("cpriorityCol").setVisible(false);
                                         this.getView().byId("idS1CabinetPriority").setVisible(false);
                                         this.getView().byId("sdueDateCol").setVisible(false);
                                         this.getView().byId("idS1SubstituteDuedate").setVisible(false);
                                         this.getView().byId("spriorityCol").setVisible(false);
                                         this.getView().byId("idS1SubstitutePriority").setVisible(false);
                                         this.getView().byId("tfdueDateCol").setVisible(false);
                                         this.getView().byId("idS1TrackDuedate").setVisible(false);
                                         this.getView().byId("tfpriorityCol").setVisible(false);
                                         this.getView().byId("idS1TrackPriority").setVisible(false);
                                        }else{
                                         this.objectType = "";
                                         this.getView().byId("assistIconTab").setVisible(true);
                                         this.getView().byId("fdueDateCol").setVisible(true);
                                         this.getView().byId("idS1IntrayDuedate").setVisible(true);
                                         this.getView().byId("fpriorityCol").setVisible(true);
                                         this.getView().byId("idS1IntrayPriority").setVisible(true);
                                         this.getView().byId("ddueDateCol").setVisible(true);
                                         this.getView().byId("idS1DraftDuedate").setVisible(true);
                                         this.getView().byId("dpriorityCol").setVisible(true);
                                         this.getView().byId("idS1DraftPriority").setVisible(true);
                                         this.getView().byId("cdueDateCol").setVisible(true);
                                         this.getView().byId("idS1CabinetDuedate").setVisible(true);
                                         this.getView().byId("cpriorityCol").setVisible(true);
                                         this.getView().byId("idS1CabinetPriority").setVisible(true);
                                         this.getView().byId("sdueDateCol").setVisible(true);
                                         this.getView().byId("idS1SubstituteDuedate").setVisible(true);
                                         this.getView().byId("spriorityCol").setVisible(true);
                                         this.getView().byId("idS1SubstitutePriority").setVisible(true);
                                         this.getView().byId("tfdueDateCol").setVisible(true);
                                         this.getView().byId("idS1TrackDuedate").setVisible(true);
                                         this.getView().byId("tfpriorityCol").setVisible(true);
                                         this.getView().byId("idS1TrackPriority").setVisible(true);
                                        }
                                        oControllerS1 = this;
                                        this.loadInitialData(this);
                                        this.tableItemSelected = false;
                                        
                                    
                                        this.mGroupFunctions = {
                                               Priority : function(oContext) {
                                                     var name = oContext.getProperty("Priority");
                                                     return {
                                                            key : name,
                                                            text : name
                                                     };
                                               },
                                               Createdby : function(oContext) {
                                                     var name = oContext.getProperty("Createdby");
                                                     return {
                                                            key : name,
                                                            text : name
                                                     };
                                               },
                                               Shorttext : function(oContext) {
                                                     var name = oContext.getProperty("Shorttext");
                                                     return {
                                                            key : name,
                                                            text : name
                                                     };
                                               },
                                        };
                                        this._oTPF = new sap.m.TablePersoController({

                                               table : this.getView().byId("idFilesTable"),
                                               persoService : flm.fiori.utils.inboxPersonalDialog

                                        }).activate();
                                        this._oTPD = new sap.m.TablePersoController({

                                               table : this.getView().byId("idDraftsTable"),
                                               persoService : flm.fiori.utils.inboxPersonalDialog

                                        }).activate();
                                        this._oTPC = new sap.m.TablePersoController({

                                               table : this.getView().byId("idCabinetTable"),
                                               persoService : flm.fiori.utils.inboxPersonalDialog

                                        }).activate();
                                        this._oTPS = new sap.m.TablePersoController({

                                               table : this.getView().byId("idSubstituteTable"),
                                               persoService : flm.fiori.utils.inboxPersonalDialog

                                        }).activate();
                                        this._oTPA = new sap.m.TablePersoController({

                                               table : this.getView().byId("idAssistantTable"),
                                               persoService : flm.fiori.utils.inboxPersonalDialog

                                        }).activate();
                                        
                                        this._oTPT = new sap.m.TablePersoController({

                                               table : this.getView().byId("idTrackFilesTable"),
                                               persoService : flm.fiori.utils.inboxPersonalDialog

                                        }).activate();
                                        
                                        if(this.customInitializeData){
                            this.customInitializeData(this);
                                        }

                                 },
                                 
                                 handleFilesFilter : function(oEvent) {

                                        this._oDialog = sap.ui.xmlfragment(
                                                      "flm.fiori.view.filterDialog", this);

                                        this._oDialog.open();
                                 },

                                 handleDraftFilter : function(oEvent) {

                                        this._oDialog = sap.ui.xmlfragment(
                                                      "flm.fiori.view.draftFilterDialog", this);

                                        this._oDialog.open();
                                 },

                                 handleCabinetFilter : function(oEvent) {

                                        this._oDialog = sap.ui.xmlfragment(
                                                      "flm.fiori.view.cabinetFilterDialog", this);

                                        this._oDialog.open();
                                 },

                                 handleSubstituteFilter : function(oEvent) {

                                        this._oDialog = sap.ui.xmlfragment(
                                                      "flm.fiori.view.substituteFilterDialog", this);

                                        this._oDialog.open();
                                 },

                                 handleAssistantFilter : function(oEvent) {

                                        this._oDialog = sap.ui.xmlfragment(
                                                      "flm.fiori.view.assistantFilterDialog", this);

                                        this._oDialog.open();
                                 },
                                 
                                 handleTrackFilter : function(oEvent) {

                                        this._oDialog = sap.ui.xmlfragment(
                                                      "flm.fiori.view.trackFilterDialog", this);

                                        this._oDialog.open();
                                 },

                                 handleFilesPersonalization : function(oEvent) {
                                        this._oTPF.openDialog();
                                 },

                                 handleDraftsPersonalization : function(oEvent) {
                                        this._oTPD.openDialog();
                                 },

                                 handleCabinetPersonalization : function(oEvent) {
                                        this._oTPC.openDialog();
                                 },

                                 handleSubstitutePersonalization : function(oEvent) {
                                        this._oTPS.openDialog();
                                 },

                                 handleAssistantPersonalization : function(oEvent) {
                                        this._oTPA.openDialog();
                                 },

                                 handleSentFilesPersonalization : function(oEvent) {
                                        this._oTPSF.openDialog();
                                 },
                                 
                                 handleTrackedFilesPersonalization : function(oEvent) {
                                        this._oTPST.openDialog();
                                 },

                                 handleFilesSettings : function(oEvent) {

                                        var oView = this.getView();
                                        var oTable = oView.byId("idFilesTable");

                                        var mParams = oEvent.getParameters();   
                                        var oBinding = oTable.getBinding("items");

                                        var aSorters = [];
                                        if (mParams.groupItem) {
                                               var sPath = mParams.groupItem.getKey();
                                               var bDescending = mParams.groupDescending;
                                               var vGroup = this.mGroupFunctions[sPath];
                                               aSorters.push(new sap.ui.model.Sorter(sPath,
                                                            bDescending, vGroup));
                                        }
                                        var sPath = mParams.sortItem.getKey();
                                     var bDescending = mParams.sortDescending;
                                     aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
                                     if (sPath == "recDate") {
                                                aSorters.push(new sap.ui.model.Sorter("TimeRecieved",
                                                bDescending));
                                            }

                                     oBinding.sort(aSorters);
                                        var aFilters = [];

                                        jQuery.each(mParams.filterItems, function(i, oItem) {
                                               var sPath = oItem.getKey();
                                               if (sPath != 'query_filter_files') {
                                                     var oFilter = new sap.ui.model.Filter(sPath,
                                                                   sap.ui.model.FilterOperator.EQ, true);
                                                     aFilters.push(oFilter);
                                               }

                                        });

                                        oBinding.filter(aFilters);
                                 },

                                 handleDraftSettings : function(oEvent) {

                                        var oView = this.getView();
                                        var oTable = oView.byId("idDraftsTable");

                                        var mParams = oEvent.getParameters();
                                        var oBinding = oTable.getBinding("items");

                                        // apply sorter to binding
                                        // (grouping comes before sorting)
                                        var aSorters = [];
                                        if (mParams.groupItem) {
                                               var sPath = mParams.groupItem.getKey();
                                               var bDescending = mParams.groupDescending;
                                               var vGroup = this.mGroupFunctions[sPath];
                                               aSorters.push(new sap.ui.model.Sorter(sPath,
                                                            bDescending, vGroup));
                                        }
                                        var sPath = mParams.sortItem.getKey();
                                        var bDescending = mParams.sortDescending;
                                        aSorters.push(new sap.ui.model.Sorter(sPath,
                                        bDescending));
                                        if (sPath == "crDate")
                                        {
                                        aSorters.push(new sap.ui.model.Sorter("CrTime",
                                                                                bDescending));
                                        }

                                        oBinding.sort(aSorters);

                                        var aFilters = [];

                                        jQuery.each(mParams.filterItems, function(i, oItem) {
                                               var sPath = oItem.getKey();
                                               if (sPath != 'query_filter_draft') {
                                                     var oFilter = new sap.ui.model.Filter(sPath,
                                                                   sap.ui.model.FilterOperator.EQ, true);
                                                     aFilters.push(oFilter);
                                               }

                                        });

                                        oBinding.filter(aFilters);

                                 },

                                 handleCabinetSettings : function(oEvent) {

                                        var oView = this.getView();
                                        var oTable = oView.byId("idCabinetTable");

                                        var mParams = oEvent.getParameters();
                                        var oBinding = oTable.getBinding("items");

                                        var aSorters = [];
                                        if (mParams.groupItem) {
                                               var sPath = mParams.groupItem.getKey();
                                               var bDescending = mParams.groupDescending;
                                               var vGroup = this.mGroupFunctions[sPath];
                                               aSorters.push(new sap.ui.model.Sorter(sPath,
                                                            bDescending, vGroup));
                                        }
                                        var sPath = mParams.sortItem.getKey();
                                     var bDescending = mParams.sortDescending;
                                     aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
                                      if (sPath == "recDate") {
                                                aSorters.push(new sap.ui.model.Sorter("TimeRecieved",
                                                bDescending));
                                            }
                                     oBinding.sort(aSorters);
                                     
                                        var aFilters = [];

                                        jQuery.each(mParams.filterItems, function(i, oItem) {
                                               var sPath = oItem.getKey();
                                               if (sPath != 'query_filter_cabinet') {
                                                     var oFilter = new sap.ui.model.Filter(sPath,
                                                                   sap.ui.model.FilterOperator.EQ, true);
                                                     aFilters.push(oFilter);
                                               }

                                        });

                                        oBinding.filter(aFilters);

                                 },

                                 handleAssistantSettings : function(oEvent) {

                                        var oView = this.getView();
                                        var oTable = oView.byId("idAssistantTable");

                                        var mParams = oEvent.getParameters();
                                        var oBinding = oTable.getBinding("items");

                                        var aSorters = [];
                                        if (mParams.groupItem) {
                                               var sPath = mParams.groupItem.getKey();
                                               var bDescending = mParams.groupDescending;
                                               var vGroup = this.mGroupFunctions[sPath];
                                               aSorters.push(new sap.ui.model.Sorter(sPath,
                                                            bDescending, vGroup));
                                        }

                                        var sPath = mParams.sortItem.getKey();
                                     var bDescending = mParams.sortDescending;
                                     aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
                                     oBinding.sort(aSorters);
                                        var aFilters = [];

                                        jQuery.each(mParams.filterItems, function(i, oItem) {
                                               var sPath = oItem.getKey();
                                               if (sPath != 'query_filter_assistant') {
                                                     var oFilter = new sap.ui.model.Filter(sPath,
                                                                   sap.ui.model.FilterOperator.EQ, true);
                                                     aFilters.push(oFilter);
                                               }

                                        });

                                        oBinding.filter(aFilters);

                                 },

                                 handleSubstituteSettings : function(oEvent) {

                                        var oView = this.getView();
                                        var oTable = oView.byId("idSubstituteTable");

                                        var mParams = oEvent.getParameters();
                                        var oBinding = oTable.getBinding("items");
                                        var aSorters = [];
                                        if (mParams.groupItem) {
                                               var sPath = mParams.groupItem.getKey();
                                               var bDescending = mParams.groupDescending;
                                               var vGroup = this.mGroupFunctions[sPath];
                                               aSorters.push(new sap.ui.model.Sorter(sPath,
                                                            bDescending, vGroup));
                                        }

                                        var sPath = mParams.sortItem.getKey();
                                     var bDescending = mParams.sortDescending;
                                     aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
                                      if (sPath == "recDate") {
                                                aSorters.push(new sap.ui.model.Sorter("TimeRecieved",
                                                bDescending));
                                            }
                                     oBinding.sort(aSorters);
                                        var aFilters = [];

                                        jQuery.each(mParams.filterItems, function(i, oItem) {
                                               var sPath = oItem.getKey();
                                               if (sPath != 'query_filter_substitute') {
                                                     var oFilter = new sap.ui.model.Filter(sPath,
                                                                   sap.ui.model.FilterOperator.EQ, true);
                                                     aFilters.push(oFilter);
                                               }

                                        });

                                        oBinding.filter(aFilters);

                                 },
                                 
                                 handleTrackedSettings : function(oEvent) {

                                        var oView = this.getView();
                                        var oTable = oView.byId("idTrackFilesTable");

                                        var mParams = oEvent.getParameters();
                                        var oBinding = oTable.getBinding("items");
                                        var aSorters = [];
                                        if (mParams.groupItem) {
                                               var sPath = mParams.groupItem.getKey();
                                               var bDescending = mParams.groupDescending;
                                               var vGroup = this.mGroupFunctions[sPath];
                                               aSorters.push(new sap.ui.model.Sorter(sPath,
                                                            bDescending, vGroup));
                                        }

                                        var sPath = mParams.sortItem.getKey();
                                     var bDescending = mParams.sortDescending;
                                     aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
                                     oBinding.sort(aSorters);
                                        var aFilters = [];

                                        jQuery.each(mParams.filterItems, function(i, oItem) {
                                               var sPath = oItem.getKey();
                                               if (sPath != 'query_filter_substitute') {
                                                     var oFilter = new sap.ui.model.Filter(sPath,
                                                                   sap.ui.model.FilterOperator.EQ, true);
                                                     aFilters.push(oFilter);
                                               }

                                        });

                                        oBinding.filter(aFilters);

                                 },
                                 
                                 
                                 
                                 openDialog : function(sType) {
                                        if (!this[sType]) {
                                               this[sType] = sap.ui.xmlfragment("flm.fiori.view."
                                                            + sType, this // associate controller with
                                               // the fragment
                                               );
                                               this.getView().addDependent(this[sType]);
                                        }
                                        this[sType].open();
                                 },
                                 closeDialog : function(sType) {
                                        if (!this[sType]) {
                                               this[sType] = sap.ui.xmlfragment("flm.fiori.view."
                                                            + sType, this // associate controller with
                                               // the fragment
                                               );
                                               this.getView().addDependent(this[sType]);
                                        }
                                        this[sType].close();
                                 },

                                /* sendButtonPressed : function(oEvent) {
                                        this.openDialog('confirmDialog');
                                 },*/
                                /* closeButtonPressed : function(oEvent) {
                                        this.openDialog('closeFileDialog');
                                 },*/
                                 refreshButtonPressed : function(oEvent) {
                                        // this.customBusyDialogOpen(this);

                                        var oTable = null;
                                        var oTab = null;
                                        if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "file") {
                                               oTable = this.getView().byId("idFilesTable");
                                               oTab = "/FILE_INTRAY_ES?$filter=Filetype eq '"+this.objectType+"'";
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "draft") {
                                               oTable = this.getView().byId("idDraftsTable");
                                               oTab = "/FILE_DRAFT_ES?$filter=Filetype eq '"+this.objectType+"'";
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "cabinet") {
                                               oTable = this.getView().byId("idCabinetTable");
                                               oTab = "/FILE_CABIN_ES?$filter=Filetype eq '"+this.objectType+"'";
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "substitute") {
                                               oTable = this.getView().byId("idSubstituteTable");
                                               oTab = "/FILE_SUBST_ES?$filter=Filetype eq '"+this.objectType+"'";
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "assistant") {
                                               oTable = this.getView().byId("idAssistantTable");
                                               oTab = "/FILE_ASSIT_ES";
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "sent") {
                                               oTable = this.getView().byId("idSentFilesTable");
                                               oTab = "/FILE_SENT_ES?$filter=Subject eq '"+this.objectType+"'";
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "track") {
                                               oTable = this.getView().byId("idTrackFilesTable");
                                               oTab = "/FILE_TRACK_ES?$filter=CaseType eq '"+this.objectType+"'";
                                        }
                                        if (oTab != null && oTable != null) {
                                               oTable.setBusy(true);
                                               oTable.removeSelections();
                                               var oTabModel = new sap.ui.model.json.JSONModel();
                                               // success
                                               oTabModel.attachRequestCompleted(oEvent, function(
                                                            oEvent) {
                                                     
                                                      oTabModel.detachRequestCompleted();
                                                      oTabModel.detachRequestFailed();
                                                     if (oTabModel.oData.d != undefined) {
                                                            oModel = oTable.getModel("files");
                                                            
                                                            /*Code for escaping the subject text*/
                                                     /*     if(oTable == oControllerS1.getView().byId("idTrackFilesTable")){
                                                                   for (var j = 0; j < oTabModel.oData.d.results.length; j++) {
                                                                         var subValue = decodeURIComponent(oTabModel.oData.d.results[j].CaseTitle);
                                                                          oTabModel.oData.d.results[j].CaseTitle = subValue;
                                                            }
                                                                   }
                                                            else
                                                            {
                                                            for (var j = 0; j < oTabModel.oData.d.results.length; j++) {
                                                                   var subValue = decodeURIComponent(oTabModel.oData.d.results[j].Subject);
                                                                   oTabModel.oData.d.results[j].Subject = subValue;
                                                            }
                                                     
                                                     }*/
                                                            oModel.setData(oTabModel.oData.d);
                                                            
                                                            sap.m.MessageToast.show(oControllerS1.getView()
                                                                          .getModel("i18n").getObject(
                                                                                       "DATAREFRESHED"));
                                                     }
                                                     oTable.setBusy(false);
                                               });
                                               // Failure
                                               oTabModel.attachRequestFailed(this,
                                                            function(oEvent) {
                                                                   oTabModel.detachRequestCompleted();
                                                                   oTabModel.detachRequestFailed();
                                                                   sap.m.MessageBox.alert(this.getView()
                                                                                .getModel("i18n").getObject(
                                                                                             "DATAREFRESHFAILED"));
                                                                   oTable.setBusy(false);
                                                            }, this);
                                               oTabModel.loadData(serviceUrl + oTab, null, true);

                                        } else {
                                               sap.m.MessageBox.alert(this.getView().getModel(
                                                            "i18n").getObject("DATAREFRESHFAILED"));
                                        }

                                 },

                                 lastProcButtonPressed : function(oEvent) {
                                        this.openDialog('lastProcDialog');
                                 },
                                 assistNotButtonPressed : function(oEvent) {
                                        this.openDialog('assistNotification');
                                 },

                                 sendBackButtonPressed : function(oEvent) {
                                        this.openDialog('sendBackAssistDialog');
                                 },

                                 onlastProcCancelButton : function(oEvent) {
                                        this.closeDialog('lastProcDialog');
                                 },
                                 assistCloseButton : function(oEvent) {
                                        this.closeDialog('assistNotification');
                                 },
                                 onCloseSharedCancel : function(oEvent) {
                                        this.closeDialog('closeSharedConfirmDialog');
                                 },
                                 onSendBackCloseButton : function(oEvent) {
                                        this.closeDialog('sendBackAssistDialog');
                                 },

                                 sendButtonPressed : function(oEvent) {
                                  var oTable = null;
                                     var fromTab = null;
                                     switch (oControllerS1.getView().byId("TAB_CONTAINER")
                                                  .getSelectedKey()) {
                                     case "file":
                                            oTable = oControllerS1.byId("idFilesTable");
                                            fromTab = "INTRAY";
                                            break;

                                     case "draft":
                                            oTable = oControllerS1.byId("idDraftsTable");
                                            fromTab = "DRAFT";
                                            break;

                                     case "substitute":
                                            oTable = oControllerS1.byId("idSubstituteTable");
                                            fromTab = "SUBSTITUTE";
                                            break;
                                     }
                                  var fileNo = oTable.getSelectedItem().getBindingContext("files").getObject().Filenumber;
                                  sap.m.MessageBox.confirm(this.getView().getModel("i18n").getObject("MESSAGE_94") + " " + fileNo + " " + this.getView().getModel("i18n").getObject("MESSAGE_95"),
                     function(response) {
                       if (response == "OK") {
                        oControllerS1.customBusyDialogOpen(oControllerS1);
//                                        oEvent.getSource().getParent().close();
                                       

                                        // fill the variables
                                        var caseguid = oTable.getSelectedItem()
                                                      .getBindingContext("files").getObject().CaseGuid;
                                        var wiId = oTable.getSelectedItem().getBindingContext(
                                                     "files").getObject().WiID;
                                        var fileid = oTable.getSelectedItem()
                                                      .getBindingContext("files").getObject().Fileid;
                                        var sentToAssistFlag = oTable.getSelectedItem()
                                                      .getBindingContext("files").getObject().SenttoAssistFlag;
                                        digSignFlag = oTable.getSelectedItem()
                                                            .getBindingContext("files").getObject().DigSignReq;

                                        if (sentToAssistFlag == true) {
                                               // this.assistNotButtonPressed();

                                               sap.m.MessageBox
                                                            .confirm(
                                                                          oControllerS1.getView().getModel("i18n").getObject("MESSAGE_26"),
                                                                          function(response) {
                                                                                if (response == "OK") {
                                                                                       // check for digital signature customizationg
                                                                                       if(digSignFlag){
                                                                                             if(oControllerS1.customDigitalSignData){
                                                                                        /*var flag = oControllerS1.customDigitalSignData(oTable.getSelectedItem().getBindingContext("files").getObject());
                                                                                        if(flag == "X"){
                                                                                       oControllerS1
                                                                                                    .confirmSendFile(caseguid,wiId,fileid,
                                                                                                                 fromTab,
                                                                                                                 oTable);
                                                                                        }*/
                                                                                                    oControllerS1.customDigitalSignData(oTable.getSelectedItem().getBindingContext("files").getObject(), jQuery.proxy(function() {
                                                                                                           oControllerS1.confirmSendFile(caseguid, wiId, fileid,
                                                                                                                                     fromTab, oTable);
                                                                                                
                                                                                                }, oControllerS1));
                                                                                        }else{
                                                                                                           sap.m.MessageBox.alert(oControllerS1.getView().getModel("i18n").getObject("MESSAGE_73"));
                                                                                                           oControllerS1
                                                                                                           .customBusyDialogClose(oControllerS1);
                                                                                                           }
                                                                                             }else{
                                                                                                    oControllerS1
                                                                                                    .confirmSendFile(
                                                                                                                 caseguid,
                                                                                                                 wiId,
                                                                                                                 fileid,
                                                                                                                 fromTab,
                                                                                                                 oTable);
                                                                                             }
                                                                                       
                                                                                
                                                                                } else {
                                                                                       oControllerS1
                                                                                                    .customBusyDialogClose(oControllerS1);
                                                                                }
                                                                         });

                                        } else {
                                               if(digSignFlag){
                                                      if(oControllerS1.customDigitalSignData){
                                                 oControllerS1.customDigitalSignData(oTable.getSelectedItem().getBindingContext("files").getObject(), jQuery.proxy(function() {
//                                              if(flag == "X"){
                                                  oControllerS1.confirmSendFile(caseguid, wiId, fileid,
                                                                                       fromTab, oTable);
//                                                     }
                                                 
                                                 }, this));
                                                
                                                     }else{
                                                            sap.m.MessageBox.alert(oControllerS1.getView().getModel("i18n").getObject("MESSAGE_73"));
                                                            oControllerS1
                                                            .customBusyDialogClose(oControllerS1);
                                                     }
                                               }else{
                                                oControllerS1.confirmSendFile(caseguid, wiId, fileid,
                                                                   fromTab, oTable);
                                               }
                                        }
                                 }else{

                                  oControllerS1.customBusyDialogClose(oControllerS1);
               }
                });
                                               
                                        

                                 },

                                 confirmSendFile : function(caseguid, wiId, fileid, fromTab,
                                               oTable, isConfirmed) {
                                        /*var digSignFlag = oTable.getSelectedItem()
                                        .getBindingContext("files").getObject().DigSignReq;*/
                                        if (isConfirmed == null) {
                                               isConfirmed = "";
                                        }
                                        var oModel = new sap.ui.model.json.JSONModel();

                                        oModel
                                                     .attachRequestCompleted(
                                                                   oControllerS1,
                                                                   function(oEvent) {

                                                                          oModel.detachRequestCompleted();

                                                                         if (oModel.getData().d.results[0].msg_type == "C"
                                                                                       && oModel.getData().d.results[0].msg_id == 373) {
                                                                                // oControllerS1.lastProcButtonPressed();
                                                                                sap.m.MessageBox
                                                                                             .confirm(
                                                                                                           oModel
                                                                                                                        .getData().d.results[0].msg_text,
                                                                                                           function(
                                                                                                                        response) {
                                                                                                                 if (response == "OK") {
                                                                                                                        // check for digital signature customizationg
                                                                                                                        if(digSignFlag){
                                                                                                                               if(oControllerS1.customDigitalSignData){
                                                                                                                          /*var flag = oControllerS1.customDigitalSignData(oTable.getSelectedItem().getBindingContext("files").getObject());
                                                                                                                          if(flag == "X"){
                                                                                                                         
                                                                                                                           oControllerS1
                                                                                                                                            .confirmSendFile(
                                                                                                                                                         caseguid,
                                                                                                                                                         wiId,
                                                                                                                                                         fileid,
                                                                                                                                                         fromTab,
                                                                                                                                                         oTable,
                                                                                                                                                         "X");
                                                                                                                          }*/
                                                                                                                                      oControllerS1.customDigitalSignData(oTable.getSelectedItem().getBindingContext("files").getObject(), jQuery.proxy(function() {
                                                                                                                                            oControllerS1.confirmSendFile(caseguid, wiId, fileid,
                                                                                                                                                                       fromTab, oTable, "X");
                                                                                                                                 
                                                                                                                                 }, oControllerS1));
                                                                                                                               }
                                                                                                                               else{
                                                                                                                                      sap.m.MessageBox.alert(oControllerS1.getView().getModel("i18n").getObject("MESSAGE_73"));
                                                                                                                                     oControllerS1
                                                                                                                                      .customBusyDialogClose(oControllerS1);
                                                                                                                               }
                                                                                                                        }else{
                                                                                                                               oControllerS1
                                                                                                                               .confirmSendFile(
                                                                                                                                            caseguid,
                                                                                                                                            wiId,
                                                                                                                                            fileid,
                                                                                                                                            fromTab,
                                                                                                                                            oTable,
                                                                                                                                            "X");
                                                                                                                        }
                                                                                                                        
                                                                                                                 } else {
                                                                                                                        oControllerS1
                                                                                                                                     .customBusyDialogClose(oControllerS1);
                                                                                                                 }
                                                                                                           });

                                                                         } else if (oModel.getData().d.results[0].msg_type == "E") {
                                                                                oControllerS1
                                                                                             .customBusyDialogClose(oControllerS1);
                                                                                sap.m.MessageBox
                                                                                             .alert(oModel.getData().d.results[0].msg_text);
                                                                         } else {
                                                                                
                                                                                // delete the file from the tab
                                                                                var tempArr = oTable
                                                                                             .getModel("files").oData.results;
                                                                                var i = 0, j = -1;
                                                                                while (i < tempArr.length) {
                                                                                       if (tempArr[i].CaseGuid == oTable
                                                                                                    .getSelectedItem()
                                                                                                    .getBindingContext(
                                                                                                                 "files")
                                                                                                    .getObject().CaseGuid) {
                                                                                             j = i;
                                                                                             break;
                                                                                       }
                                                                                       i++;
                                                                                }
                                                                                if (j != -1) {
                                                                                       oTable.removeSelections();
                                                                                       tempArr.splice(j, 1);
                                                                                       oTable.getModel("files").oData.__count--;
                                                                                       oTable.getModel("files")
                                                                                                    .checkUpdate();
                                                                                       oControllerS1.getView()
                                                                                                    .byId("sendAction")
                                                                                                    .setEnabled(false);
                                                                                       oControllerS1
                                                                                                    .getView()
                                                                                                    .byId("closeAction")
                                                                                                    .setEnabled(false);
                                                                                }
                                                                                oControllerS1
                                                                                             .customBusyDialogClose(oControllerS1);
                                                                                // sap.m.MessageToast.show(oControllerS1.getView().getModel("i18n").getObject("filesent"));
                                                                                sap.m.MessageToast
                                                                                             .show(oModel.getData().d.results[0].msg_text);
                                                                         }

                                                                   }, oControllerS1);

                                        oModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILES_FI?param_1='SE'&param_2='"
                                                                                + caseguid
                                                                                + "'&param_3='"
                                                                                + wiId
                                                                                + "'&param_4='"
                                                                                + fileid
                                                                                + "'&param_5=''&check_1='"
                                                                                + isConfirmed
                                                                                + "'&check_2=''&check_3=''&param_6=''&param_7='"
                                                                                + fromTab
                                                                                + "'&param_8=''&param_9=''&param_10=''",
                                                                   null, false);

                                 },

                                 onDialogCloseButton : function(oEvent) {
                                        if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                                               oEvent.getSource().getParent().close();
                                        } else {
                                               oEvent.getSource().getParent().getParent().close();
                                        }
                                 },

                                 closeSharedDialog : function(oEvent) {
                                        this.openDialog('closeSharedConfirmDialog');
                                 },

                                 onCloseButtonPressedCancel : function(oEvent) {
                                        this.closeDialog('closeFileDialog');
                                 },

                                 // event handler for closing the file
                                 closeButtonPressed : function(oEvent) {

                                        var oTable = null;
                                        var fromTab = null;

                                        if (oControllerS1.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "file") {
                                               oTable = oControllerS1.byId("idFilesTable");
                                               oTab = "/FILE_INTRAY_ES?$filter=Filetype+eq+'"+this.objectType+"'";
                                               fromTab = "INTRAY";
                                        } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "draft") {
                                               oTable = oControllerS1.byId("idDraftsTable");
                                               oTab = "/FILE_DRAFT_ES?$filter=Filetype+eq+'"+this.objectType+"'";
                                               fromTab = "DRAFT";
                                        } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "substitute") {
                                               oTable = oControllerS1.byId("idSubstituteTable");
                                               oTab = "/FILE_SUBST_ES?$filter=Filetype+eq+'"+this.objectType+"'";
                                               fromTab = "SUBSTITUTE";
                                        }
                                        var fileNo = oTable.getSelectedItem().getBindingContext("files").getObject().Filenumber;
                                      sap.m.MessageBox.confirm(this.getView().getModel("i18n").getObject("MESSAGE_96") + " " + fileNo + " " + this.getView().getModel("i18n").getObject("MESSAGE_97"),
                        function(response) {
                          if (response == "OK") {
                                        if (oTable != null) {
                                               oTable.setBusy(true);
                                               var caseguid = oTable.getSelectedItem()
                                                            .getBindingContext("files").getObject().CaseGuid;
                                               var wiId = oTable.getSelectedItem()
                                                            .getBindingContext("files").getObject().WiID;
                                               var fileid = oTable.getSelectedItem()
                                                            .getBindingContext("files").getObject().Fileid;

                                               var oModel = new sap.ui.model.json.JSONModel();
                                               oModel
                                                            .attachRequestCompleted(
                                                                         this,
                                                                          function(oEvent) {
                                                                                oModel.detachRequestCompleted();
                                                                                
                                                                                // delete the file from the tab
                                                                                var tempArr = oTable
                                                                                             .getModel("files").oData.results;
                                                                                var i = 0, j = -1;
                                                                                while (i < tempArr.length) {
                                                                                       if (tempArr[i].CaseGuid == oTable
                                                                                                    .getSelectedItem()
                                                                                                    .getBindingContext(
                                                                                                                 "files")
                                                                                                    .getObject().CaseGuid) {
                                                                                             j = i;
                                                                                             break;
                                                                                       }
                                                                                       i++;
                                                                                }
                                                                                if (j != -1) {
                                                                                       oTable.removeSelections();
                                                                                       tempArr.splice(j, 1);
                                                                                       oTable.getModel("files").oData.__count--;
                                                                                       oTable.getModel("files")
                                                                                                    .checkUpdate();
                                                                                }
                                                                                oControllerS1.getView().byId(
                                                                                             "sendAction")
                                                                                             .setEnabled(false);
                                                                                oControllerS1.getView().byId(
                                                                                             "closeAction")
                                                                                             .setEnabled(false);
                                                                                sap.m.MessageToast
                                                                                             .show(oControllerS1
                                                                                                           .getView()
                                                                                                           .getModel(
                                                                                                                        "i18n")
                                                                                                           .getObject(
                                                                                                                        "FILECLOSED"));
                                                                                oTable.setBusy(false);
                                                                         }, this);
                                               // Failure
                                               oModel.attachRequestFailed(this, function(oEvent) {
                                                      oModel.detachRequestCompleted();
                                                     oModel.detachRequestFailed();
                                                      sap.m.MessageBox.alert(oControllerS1.getView().getModel(
                                                                   "i18n").getObject("FILECLOSEFAILED"));
                                                     oTable.setBusy(false);
                                               }, this);

                                               oModel
                                                            .loadData(
                                                                          serviceUrl
                                                                                       + "/FILES_FI?param_1='CF'&param_2='"
                                                                                       + caseguid
                                                                                       + "'&param_3='"
                                                                                       + wiId
                                                                                       + "'&param_4='"
                                                                                       + fileid
                                                                                       + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
                                                                                       + fromTab
                                                                                       + "'&param_8=''&param_9=''&param_10=''",
                                                                         null, true);
                                               oControllerS1.customBusyDialogClose(oControllerS1);
                                               
                                        }}else{

                                         oControllerS1.customBusyDialogClose(oControllerS1);
                      }
                       });
                                 },

                                 moveIntrayButtonPressed : function(oEvent) {
                                        this.customBusyDialogOpen(this);
                                        

                                        var caseguid = this.byId("idCabinetTable")
                                                      .getSelectedItem().getBindingContext("files")
                                                     .getObject().CaseGuid;
                                        var wiId = this.byId("idCabinetTable")
                                                      .getSelectedItem().getBindingContext("files")
                                                     .getObject().WiID;
                                        var fileid = this.byId("idCabinetTable")
                                                      .getSelectedItem().getBindingContext("files")
                                                     .getObject().Fileid;

                                        var oModel = new sap.ui.model.json.JSONModel();

                                        oModel
                                                     .attachRequestCompleted(
                                                                   oEvent,
                                                                   function(oEvt) {
                                                                         var file = null;
                                                                          oModel.detachRequestCompleted();
                                                                         if (oModel.getData().d.results[0].msg_id == 013) {

                                                                                sap.m.MessageToast
                                                                                             .show(oModel.getData().d.results[0].msg_text);

                                                                         } else {
                                                                                
                                                                                var tempArr = this.getView()
                                                                                .byId("idCabinetTable")
                                                                                .getModel("files").oData.results;
                                                                   var oTable = this.getView()
                                                                                .byId("idCabinetTable");
                                                                   var i = 0, j = -1;
                                                                   while (i < tempArr.length) {
                                                                         if (tempArr[i].CaseGuid == caseguid) {
                                                                                j = i;
                                                                                break;
                                                                         }
                                                                         i++;
                                                                   }
                                                                   if (j != -1) {
                                                                          oTable.removeSelections();
                                                                         file = tempArr.splice(j, 1);
                                                                          oTable.getModel("files").oData.__count--;
                                                                          oTable.getModel("files")
                                                                                       .checkUpdate();
                                                                   }
                                                                   if (file != null) {
                                                                         oTable = this
                                                                                       .getView()
                                                                                       .byId(
                                                                                                    "idFilesTable");
                                                                         tempArr = oTable
                                                                                       .getModel("files").oData.results;
                                                                          file[0].Readmail = "sap-icon://email";
                                                                          tempArr.splice(0,0,file[0]);
                                                                          oTable.getModel("files").oData.__count++;
                                                                          oTable.getModel("files")
                                                                                       .checkUpdate();
                                                                   }

                                                                   this.getView().byId(
                                                                                "moveIntrayAction")
                                                                                .setEnabled(false);
                                                                                
                                                                                sap.m.MessageToast
                                                                                             .show(oModel.getData().d.results[0].msg_text);
                                                                         }
                                                                          this.customBusyDialogClose(this);
                                                                   }, this);
                                        oModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILES_FI?param_1='MI'&param_2='"
                                                                                + caseguid
                                                                                + "'&param_3='"
                                                                                + wiId
                                                                                + "'&param_4='"
                                                                                + fileid
                                                                                + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                                                   null, true);
                                 },

                                 onSendBackOkButton : function(oEvent) {
                                        this.customBusyDialogOpen(this);

                                        var caseguid = this.byId("idAssistantTable")
                                                      .getSelectedItem().getBindingContext("files")
                                                     .getObject().CaseGuid;
                                        var sentById = this.byId("idAssistantTable")
                                                      .getSelectedItem().getBindingContext("files")
                                                     .getObject().SentByID;
                                        oEvent.getSource().getParent().close();
                                        var oModel = new sap.ui.model.json.JSONModel();
                                        this.customBusyDialogOpen(this);
                                        oModel.attachRequestCompleted(oEvent,function(oEvt){
                                               oModel.detachRequestCompleted();

                                               var tempModel = this.getView().byId("idAssistantTable").getModel("files");
                                               tempArr = tempModel.oData.results;
                                               
                                               var i = 0, j = -1;
                                               while (i < tempArr.length) {
                                                     if (tempArr[i].CaseGuid == caseguid) {
                                                            j = i;
                                                            break;
                                                     }
                                                     i++;
                                               }
                                               if (j != -1) {
                                                      this.getView().byId("idAssistantTable").removeSelections();
                                                     tempArr.splice(j, 1);
                                                     tempModel.oData.__count--;
                                                     tempModel.checkUpdate();
                                               }

                                               this.getView().byId("sendBackAction").setEnabled(false);
                                               this.customBusyDialogClose(this);
                                               if (oModel.getData().d.results[0].msg_id == 010) {
                                                     sap.m.MessageToast
                                                                   .show(oModel.getData().d.results[0].msg_text);
                                               } else {
                                                      sap.m.MessageToast
                                                                   .show(oModel.getData().d.results[0].msg_text);
                                               }
                                               ;
                                               
                                        },this);
                                        oModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILES_FI?param_1='SB'&param_2='"
                                                                                + caseguid
                                                                                + "'&param_3='"
                                                                                + sentById
                                                                                + "'&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                                                   null, true);
                                        
                                 },

                                 onFilesSearch : function(oEvnt) {
                                        var sQuery = oEvnt.getSource().getValue();
                                        var oTable = this.getView().byId("idFilesTable");
                                        var oBinding = oTable.getBinding("items");
                                        if (sQuery && sQuery.length > 0) {
                                               oBinding.filter(new sap.ui.model.Filter([
                                                            new sap.ui.model.Filter("Createdby",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("TimeRecieved",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Subject",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Priority",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Duedate",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Shorttext",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Filetype",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Filenumber",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("DateRecieved",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Actdc",
                                                                          "Contains", sQuery), ], "OR"));

                                        }else{
                                               oBinding.filter(new sap.ui.model.Filter("Createdby",
                                                            "Contains", ""));
                                        }
                                 },

                                 onDraftsSearch : function(oEvnt) {
                                        var sQuery = oEvnt.getSource().getValue();
                                        var oTable = this.getView().byId("idDraftsTable");
                                        var oBinding = oTable.getBinding("items");
                                        if (sQuery && sQuery.length > 0) {
                                               oBinding.filter(new sap.ui.model.Filter([
                                                            new sap.ui.model.Filter("Createdby",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("CrDate",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Priority",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Duedate",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Shorttext",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Subject",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("CrTime",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Filenumber",
                                                                          "Contains", sQuery), ], "OR"));
                                        }else{
                                               oBinding.filter(new sap.ui.model.Filter("Createdby",
                                                            "Contains", ""));
                                        }
                                 },

                                 onCabinetSearch : function(oEvnt) {
                                        var sQuery = oEvnt.getSource().getValue();
                                        var oTable = this.getView().byId("idCabinetTable");
                                        var oBinding = oTable.getBinding("items");
                                        if (sQuery && sQuery.length > 0) {
                                               oBinding.filter(new sap.ui.model.Filter([
                                                            new sap.ui.model.Filter("Createdby",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Priority",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Subject",
                                                                          "Contains", sQuery),       
                                                            new sap.ui.model.Filter("Duedate",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Shorttext",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Filenumber",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("RDate",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("DateRecieved",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("TimeRecieved",
                                                                          "Contains", sQuery), ], "OR"));
                                        }else{
                                               oBinding.filter(new sap.ui.model.Filter("Createdby",
                                                            "Contains", ""));
                                        }
                                 },
                           
                                 onSubstituteSearch : function(oEvnt) {
                                        var sQuery = oEvnt.getSource().getValue();
                                        var oTable = this.getView().byId("idSubstituteTable");
                                        var oBinding = oTable.getBinding("items");
                                        if (sQuery && sQuery.length > 0) {
                                               oBinding.filter(new sap.ui.model.Filter([
                                                       new sap.ui.model.Filter("Createdby",
                                                                   "Contains", sQuery),
                                                      new sap.ui.model.Filter("TimeRecieved",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Subject",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Priority",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Duedate",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Shorttext",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("FileNumber",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("DateRecieved",
                                                                                "Contains", sQuery), 
                                                            new sap.ui.model.Filter("Actdc",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Substitutefor",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("SubstRsn",
                                                                          "Contains", sQuery),], "OR"));
                                        }else{
                                               oBinding.filter(new sap.ui.model.Filter("Createdby",
                                                            "Contains", ""));
                                        }
                                 },

                                 onAssistantSearch : function(oEvnt) {
                                        var sQuery = oEvnt.getSource().getValue();
                                        var oTable = this.getView().byId("idAssistantTable");
                                        var oBinding = oTable.getBinding("items");
                                        if (sQuery && sQuery.length > 0) {
                                               oBinding.filter(new sap.ui.model.Filter([
                                                            new sap.ui.model.Filter("Fno",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Subject",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Description",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("SentOn",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("SentBy",
                                                                          "Contains", sQuery), ], "OR"));
                                        }else{
                                               oBinding.filter(new sap.ui.model.Filter("Fno",
                                                            "Contains", ""));
                                        }
                                 },

                                 onTrackFilesSearch : function(oEvnt) {
                                        var sQuery = oEvnt.getSource().getValue();
                                        var oTable = this.getView().byId("idTrackFilesTable");
                                        var oBinding = oTable.getBinding("items");
                                        if (sQuery && sQuery.length > 0) {
                                               oBinding.filter(new sap.ui.model.Filter([
                                                            new sap.ui.model.Filter("CaseTitle",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("PsReference",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("PlanEndDate",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("PriorityText",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Activity",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("ProcessingSince",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("CaseTypeDescr",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("ProcessorFname",
                                                                          "Contains", sQuery), ], "OR"));

                                        }else{
                                               oBinding.filter(new sap.ui.model.Filter("CaseTitle",
                                                            "Contains", ""));
                                        }
                                 },

                                 afterSearchRecovery : function() {
                                        var oTable = this.byId("idSentFilesTable");
                                        var m = oTable.getItems();

                                        for (var i = 0; i < oTable.getItems().length; i++) {
                                               var t = m[i].getCells();

                                               if (!m[i].getBindingContext("files").getObject().LinkEnable) {
                                                     t[3].setEnabled(false);
                                                     t[2].setSrc("sap-icon://employee");
                                               } else {
                                                     t[3].setEnabled(true);
                                                     t[2].setSrc("sap-icon://group");
                                               }
                                        }
                                 },

                                 onSentFilesSearch : function(oEvnt) {
                                        var sQuery = oEvnt.getSource().getValue();
                                        var oTable = this.getView().byId("idSentFilesTable");
                                        var oBinding = oTable.getBinding("items");
                                        if (sQuery && sQuery.length > 0) {
                                               oBinding.filter(new sap.ui.model.Filter([
                                                            new sap.ui.model.Filter("Subject",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("FileNo",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Activity",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Senttoname",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Sentdate",
                                                                          "Contains", sQuery),
                                                            new sap.ui.model.Filter("Senttime",
                                                                          "Contains", sQuery), ], "OR"));
                                        }else{
                                               oBinding.filter(new sap.ui.model.Filter("Subject",
                                                            "Contains", ""));
                                        }
                                        this.afterSearchRecovery();
                                 },
                                 hideActions : function(oEvent) {
                                        
                                        if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "file") {
                                               this.getView().byId("moveIntrayAction").setVisible(
                                                            false);
                                               this.getView().byId("sendBackAction").setVisible(
                                                            false);
                                               this.getView().byId("sendAction").setVisible(true);
                                               this.getView().byId("closeAction").setVisible(true);
                                               if (this.byId("idFilesTable").getSelectedItem() == null) {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   false);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   false);
                                               } else {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   true);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   true);
                                               }
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "draft") {

                                               this.getView().byId("sendBackAction").setVisible(
                                                            false);
                                               this.getView().byId("moveIntrayAction").setVisible(
                                                            false);
                                               this.getView().byId("sendAction").setVisible(true);
                                               this.getView().byId("closeAction").setVisible(true);
                                               if (this.byId("idDraftsTable").getSelectedItem() == null) {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   false);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   false);
                                               } else {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   true);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   true);
                                               }
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "cabinet") {
                                               this.getView().byId("sendAction").setVisible(false);
                                               this.getView().byId("sendBackAction").setVisible(
                                                            false);
                                               this.getView().byId("closeAction")
                                                            .setVisible(false);
                                               this.getView().byId("moveIntrayAction").setVisible(
                                                            true);
                                               if (this.byId("idCabinetTable").getSelectedItem() == null) {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   false);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   false);
                                               } else {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   true);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   true);
                                               }
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "substitute") {
                                               this.getView().byId("sendBackAction").setVisible(
                                                            false);
                                               this.getView().byId("moveIntrayAction").setVisible(
                                                            false);
                                               this.getView().byId("sendAction").setVisible(true);
                                               this.getView().byId("closeAction").setVisible(true);
                                               if (this.byId("idSubstituteTable")
                                                            .getSelectedItem() == null) {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   false);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   false);
                                               } else {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   true);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   true);
                                               }
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "assistant") {
                                               this.getView().byId("sendAction").setVisible(false);
                                               this.getView().byId("moveIntrayAction").setVisible(
                                                            false);
                                               this.getView().byId("closeAction")
                                                            .setVisible(false);
                                               this.getView().byId("sendBackAction").setVisible(
                                                            true);
                                               if (this.byId("idAssistantTable").getSelectedItem() == null) {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   false);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   false);
                                               } else {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   true);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   true);
                                               }
                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "sent") {
                                               this.getView().byId("sendAction").setVisible(false);
                                               this.getView().byId("sendBackAction").setVisible(
                                                            false);
                                               this.getView().byId("closeAction")
                                                            .setVisible(false);
                                               this.getView().byId("moveIntrayAction").setVisible(
                                                            false);
                                               if (this.byId("idSentFilesTable").getSelectedItem() == null) {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   false);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   false);
                                               } else {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   true);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   true);
                                               }

                                               // if sent files are not loaded

                                               if (oEvent.getParameter("selectedItem").getModel(
                                                            "files") == undefined) {
                                                      this.byId("idSentFilesTable").setBusy(true);
                                                     var oSentModel = new sap.ui.model.json.JSONModel();
                                                     // success
                                                     oSentModel
                                                                   .attachRequestCompleted(
                                                                                this,
                                                                                function(oEvent) {
                                                                                       
                                                                                       oSentModel
                                                                                                    .detachRequestCompleted();
                                                                                       oSentModel
                                                                                                    .detachRequestFailed();

                                                                                       if (oSentModel.oData.d != undefined) {
                                                                                             oSentModel
                                                                                                           .setData(oSentModel.oData.d);
                                                                                             /*for (var j = 0; j < oSentModel.oData.results.length; j++) {
                                                                                                    var subValue = decodeURIComponent(oSentModel.oData.results[j].Subject);
                                                                                                    oSentModel.oData.results[j].Subject = subValue;
                                                                                             }*/
                                                                                             this
                                                                                                           .byId(
                                                                                                                        "sentIconTab")
                                                                                                           .setModel(
                                                                                                                        oSentModel,
                                                                                                                        "files");
                                                                                             
                                                                                       }

                                                                                       this.byId(
                                                                                                    "idSentFilesTable")
                                                                                                    .setBusy(false);

                                                                                }, this);
                                                     // Failure
                                                      oSentModel.attachRequestFailed(this, function(
                                                                   oEvent) {
                                                            oSentModel.detachRequestCompleted();
                                                            oSentModel.detachRequestFailed();
                                                            sap.m.MessageBox.alert(this.getView()
                                                                          .getModel("i18n").getObject(
                                                                                       "datarefreshfailed"));
                                                            this.byId("idSentFilesTable")
                                                                          .setBusy(false);
                                                     }, this);
                                                      oSentModel.loadData(serviceUrl
                                                                   + "/FILE_SENT_ES?$filter=Subject eq '"+this.objectType+"'", null, true);

                                               }

                                        } else if (this.getView().byId("TAB_CONTAINER")
                                                     .getSelectedKey() == "track") {
                                               this.getView().byId("sendAction").setVisible(false);
                                               this.getView().byId("sendBackAction").setVisible(
                                                            false);
                                               this.getView().byId("closeAction")
                                                            .setVisible(false);
                                               this.getView().byId("moveIntrayAction").setVisible(
                                                            false);
                                               if (this.byId("idTrackFilesTable")
                                                            .getSelectedItem() == null) {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   false);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   false);
                                               } else {
                                                      this.getView().byId("sendAction").setEnabled(
                                                                   true);
                                                      this.getView().byId("closeAction").setEnabled(
                                                                   true);
                                               }
                                        }
                                        
                                        if(this.customHandleActionTabSwitch){
                                               this.customHandleActionTabSwitch(this,this.getView().byId("TAB_CONTAINER").getSelectedKey());
                                        }
                                 },
                                 handleFileSelectionChange : function(oEvent) {
                                        this.getView().byId("sendAction").setEnabled(true);
                                        this.getView().byId("closeAction").setEnabled(true);
                                        this.tableItemSelected = true;
                                 },
                                 handleDraftSelectionChange : function(oEvent) {
                                        this.getView().byId("sendAction").setEnabled(true);
                                        this.getView().byId("closeAction").setEnabled(true);
                                        this.tableItemSelected = true;
                                 },
                                 handleCabinetSelectionChange : function(oEvent) {
                                        this.getView().byId("moveIntrayAction")
                                                     .setEnabled(true);
                                        this.tableItemSelected = true;
                                 },
                                 handleSubstituteSelectionChange : function(oEvent) {

                                        this.getView().byId("sendAction").setEnabled(true);
                                        this.getView().byId("closeAction").setEnabled(true);
                                        this.tableItemSelected = true;
                                 },
                                 handleAssistantSelectionChange : function(oEvent) {
                                        this.getView().byId("sendBackAction").setEnabled(true);
                                        this.getView().byId("closeAction").setEnabled(true);
                                        this.tableItemSelected = true;
                                 },

                                 customBusyDialogOpen : function(controller) {

                                        if (!controller._dialog) {

                                               controller._dialog = sap.ui.xmlfragment(
                                                            "flm.fiori.view.busyDialog", controller);
                                               controller.getView().addDependent(
                                                            controller._dialog);
                                        }

                                        controller._dialog.open();
                                 },

                                 customBusyDialogClose : function(controller) {
                                        controller._dialog.close();
                                 },

                                 navToPage : function(oEvent) {
                                        
                                        if(this.fileTypeSelected){
                                               this.fileTypeSelected=false;
                                               return;
                                        }
                                        if(this.getView().byId("TAB_CONTAINER").getSelectedKey() == "track"){
                                         if (this.linkPress) {
                           // navigation should not be done when link is
                           // clicked
                           this.linkPress = false;
                           return;
                          }
                                        }
                                        if (!this.tableItemSelected) {
                                               this.sentById = oEvent.getParameters().listItem
                                                            .getBindingContext("files").getObject().SentByID;
                                               this.attSection = oEvent.getParameters().listItem
                                                            .getBindingContext("files").getObject().IsAttribute;
                                               this.docSection = oEvent.getParameters().listItem
                                                            .getBindingContext("files").getObject().IsDocument;
                                               this.noteSection = oEvent.getParameters().listItem
                                                            .getBindingContext("files").getObject().IsNoting;
                                               this.workflowTab = oEvent.getParameters().listItem
                                                            .getBindingContext("files").getObject().IsWorkflow;
                                               this.wfInfo = oEvent.getParameters().listItem
                                                            .getBindingContext("files").getObject().WfInfo;
                                               this.assistFlag = oEvent.getParameters().listItem
                                                            .getBindingContext("files").getObject().SenttoAssistFlag;
                                               this.itemType = oEvent.getParameters().listItem
                                                            .getBindingContext("files").getObject().IconColor;
                                               this.tabType=this.getView().byId("TAB_CONTAINER").getSelectedKey();
                                               //set the icon to read
                                               oEvent.getParameters().listItem.getBindingContext("files").getObject().Readmail = "sap-icon://email-read";
                                               // this.customBusyDialogOpen(this);
                                               
                                               oEvent.getSource().removeSelections();
                                               if(this.getView().byId("TAB_CONTAINER").getSelectedKey() != "draft"){
                                                     var fromTab=null;
                                               if(this.itemType == "#009de0"){
                                                     switch (this.getView().byId("TAB_CONTAINER").getSelectedKey()){
                                                     case "file": fromTab = "INTRAY"; break;
                                                     case "assistant": fromTab = "ASSISTANT"; break;
                                                     case "substitute": fromTab = "SUBSTITUTE"; break;
                                                     case "cabinet": fromTab = "CABINET"; break;
                                                     case "track": fromTab = "TRACK"; break;
                                                     }
                                                     
                                                     if (fromTab != null){
                                                            
                                                            authModel = new sap.ui.model.json.JSONModel();
                                                            
                                                            authModel.loadData(serviceUrl+"/FILES_FI?param_1='CI'&param_2='"
                                                                         + oEvent.getParameters().listItem.getBindingContext("files").getObject().CaseGuid
                                                                         + "'&param_3='"
                                                                         + oEvent.getParameters().listItem.getBindingContext("files").getObject().WiID
                                                                         + "'&param_4='"
                                                                         + oEvent.getParameters().listItem.getBindingContext("files").getObject().Fileid
                                                                         + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
                                                                         + fromTab
                                                                         + "'&param_8=''&param_9=''&param_10=''",null,false);
                                                            
                                                            if(authModel.oData.d.results.length ==0){
                                                                   this.oRouter
                                                                   .navTo(
                                                                                "subscreen",
                                                                                {
                                                                                       caseguid : oEvent
                                                                                                    .getParameters().listItem
                                                                                                    .getBindingContext(
                                                                                                                 "files")
                                                                                                    .getObject().CaseGuid,
                                                                                       fileid : oEvent.getParameters().listItem
                                                                                                    .getBindingContext(
                                                                                                                 "files")
                                                                                                    .getObject().Fileid,
                                                                                       wiId : oEvent.getParameters().listItem
                                                                                                    .getBindingContext(
                                                                                                                 "files")
                                                                                                    .getObject().WiID,
                                                                                });
                                                            }else{
                                                                   sap.m.MessageBox.alert(authModel.oData.d.results[0].msg_text,{title: oControllerS1.getView().getModel("i18n").getObject("UNAUTHORIZED"),});
                                                                   return;
                                                            }
                                                     }
                                               }else if(this.itemType == "#6A7174"){
                                                     switch (this.getView().byId("TAB_CONTAINER").getSelectedKey()){
                                                     case "file": fromTab = "INTRAYDAAK"; break;
                                                     case "substitute": fromTab = "SUBSTITUTEDAAK"; break;
                                                     case "cabinet": fromTab = "CABINETDAAK"; break;
                                                     case "track": fromTab = "TRACKDAAK"; break;
                                                     }
                                                     this.caseguid=oEvent.getParameters().listItem.getBindingContext("files").getObject().CaseGuid;
                                                     this.fileid=oEvent.getParameters().listItem.getBindingContext("files").getObject().Fileid;
                                                     this.wiId=oEvent.getParameters().listItem.getBindingContext("files").getObject().WiID;
                                                     this.respondBy=oEvent.getParameters().listItem.getBindingContext("files").getObject().Respondby;
                                                     if (fromTab != null){
                                                                   
                                                                   daakAuthModel = new sap.ui.model.json.JSONModel();
                                                                   
                                                            daakAuthModel.loadData(serviceUrl+"/FILES_FI?param_1='CI'&param_2='"
                                                                                + oEvent.getParameters().listItem.getBindingContext("files").getObject().CaseGuid
                                                                                + "'&param_3='"
                                                                                + oEvent.getParameters().listItem.getBindingContext("files").getObject().WiID
                                                                                + "'&param_4='"
                                                                                + oEvent.getParameters().listItem.getBindingContext("files").getObject().Fileid
                                                                                + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
                                                                                + fromTab
                                                                                + "'&param_8=''&param_9=''&param_10=''",null,false);
                                                            if(daakAuthModel.oData.d.results.length ==0){
                                                                   this.oRouter.navTo("daakscreen");
                                                            }else{
                                                                   sap.m.MessageBox.alert(authModel.oData.d.results[0].msg_text,{title: oControllerS1.getView().getModel("i18n").getObject("UNAUTHORIZED"),});
                                                                   return;
                                                            }
                                                     }
                                               }

                                               }else if(this.itemType == "#6A7174"){
                                                     this.caseguid=oEvent.getParameters().listItem.getBindingContext("files").getObject().CaseGuid;
                                                     this.fileid=oEvent.getParameters().listItem.getBindingContext("files").getObject().Fileid;
                                                     this.oRouter.navTo("daakscreen");
                                               }
                                               else{
                                                     this.assistFlag = oEvent.getParameters().listItem
                                                      .getBindingContext("files").getObject().SenttoAssistFlag;
                                this.caseguid=oEvent.getParameters().listItem.getBindingContext("files").getObject().CaseGuid;
                                this.fileid=oEvent.getParameters().listItem.getBindingContext("files").getObject().Fileid;
                                this.oRouter.navTo("myscreen");

                                               }
                                         }
                                         else {
                                               this.tableItemSelected = false;
                                        }

                                 },
                                 /* Navigating to Create File screen */
                                 onItemSelected : function(oEvent) {
                                        this.oRouter.navTo("myscreen");
                                 },
                                 
                                 
                                 //opening options for search
                                 
                                 openSearchView: function(oEvent){
                                        if(!this.searchButtons){
                                               this.searchButtons = sap.ui.xmlfragment("flm.fiori.view.searchButtons",this);
                                        this.getView().addDependent(this.searchButtons);
                                        }
                                        jQuery.sap.delayedCall(0, this, function() {
                                               this.searchButtons.openBy(this.byId("searchAction"));
                                        });
                                        if(oActionModel.getData() != undefined){
            if(oActionModel.getData().d.ISFILESEARCH == true){
             sap.ui.getCore().byId("fileSearchId").setVisible(true);
            }else{
             sap.ui.getCore().byId("fileSearchId").setVisible(false);
            }
            if(oActionModel.getData().d.ISDOCSEARCH == true){
             sap.ui.getCore().byId("docSearchId").setVisible(true);
            }else{
             sap.ui.getCore().byId("docSearchId").setVisible(false);
            }
            if(oActionModel.getData().d.ISDAAKSEARCH == true){
             sap.ui.getCore().byId("daakSearchId").setVisible(true);
            }else{
             sap.ui.getCore().byId("daakSearchId").setVisible(false);
            }
            }
            else if(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers) == "Resource not found for segment 'FILE_BUTTONS_ET'."){

             sap.ui.getCore().byId("fileSearchId").setVisible(false);
             sap.ui.getCore().byId("docSearchId").setVisible(false);
             sap.ui.getCore().byId("daakSearchId").setVisible(false);
             oControllerS1
                                                 .customBusyDialogClose(oControllerS1);
            }
            else{
             sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
             oControllerS1
                                                 .customBusyDialogClose(oControllerS1);
             return;
            }
                                 },
                                 /* Navigating to Files Search Screen */
                                 searchFileButtonPressed : function(oEvent) {
                                        
                                        this.oRouter.navTo("searchscreen");
                                 },
                                 
                                 /* Navigating to Documents Search Screen */
                                 searchDocButtonPressed : function(oEvent) {
                                        
                                        this.oRouter.navTo("docscreen");
                                 },
                                 
                                 /*searchDocButtonPressed : function(oEvent) {
                                     
                                     this.oRouter.navTo("daaksearchscreen");
                                 },*/

                                 createButtonPressed : function(oEvent) {
                                        oControllerS1.tabType="create";
                                        var oModel = new sap.ui.model.json.JSONModel();
                                        this.customBusyDialogOpen(this);
                                        oModel.attachRequestCompleted(oEvent,function(oEvt){
                                               if (this.oHierchicalSelectDialog == undefined) {
                                                     this.oHierchicalSelectDialog = sap.ui.xmlfragment(
                                                                   "flm.fiori.view.workArea", this);
                                               }
                                               var oTable = sap.ui.getCore().byId("idCreateTable");
                                               oTable.setModel(oModel, "files");
                                               var t = oTable.getItems();
                                               for (var i = 0; i < t.length; i++) {
                                                     if (t[i].getBindingContext("files").getObject().ParOrgCode != "") {
                                                            t[i].setVisible(false);
                                                     }
                                                     var m = t[i].getCells();
                                                     if (t[i].getBindingContext("files").getObject().IsFile) {
                                                            m[0].setSrc("sap-icon://create");
                                                            m[2].setSrc("sap-icon://tags");
                                                     } else {
                                                            m[0].setSrc("sap-icon://folder-full");
                                                     }
                                               }

                                               this.oHierchicalSelectDialog.open();
                                               var oTable = sap.ui.getCore().byId("idCreateTable");
                                               var t = oTable.getItems();
                                               this.parentOrgCode = "";
                                               for (var i = 0; i < t.length; i++) {
                                                     if (t[i].getBindingContext("files").getObject().ParOrgCode != "") {
                                                            t[i].setVisible(false);
                                                     } else {
                                                            t[i].setVisible(true);
                                                     }
                                               }
                                               this.customBusyDialogClose(this);
                                        },this);
                                        oModel.loadData(serviceUrl + "/FILE_HRCHY_ES", null,
                                                     true);
                                 },

                                 onCreatedbyClick : function(oEvent) {
                                        var item = oEvent.getSource();
                                        item.setEnabled(false);
                                 },

                                 onSentToClick : function(oEvent) {
                                  
                         this.linkPress = true;

                  if (!this.processorNames) {
                   this.processorNames = sap.ui.xmlfragment(
                     "flm.fiori.view.processorsList", this);
                  }

                  var Pathid = oEvent.getSource().getParent()
                    .getBindingContext("files").getObject().Wfpthid;

                  var oModel = new sap.ui.model.json.JSONModel();
                  oModel.loadData(serviceUrl
                    + "/FILE_SENT_FI?param_1='MP'&param_2='"
                    + Pathid + "'&param_3=''", null, false);
                  this.processorNames.setModel(oModel, "sentModelDetail");
                  this.processorNames.openBy(oEvent.getSource());
                                        
               /*                         if (oEvent.getSource().getParent().getBindingContext(k
                                                      "files").getObject().LinkEnable == true) {
                                               if(this.oSendTo == undefined){
                                               this.oSendTo = sap.ui.xmlfragment(
                                                            "flm.fiori.view.sentToDetails", this);
                                               }
                                               this.oSendTo.open();
                                               var oTable = sap.ui.getCore().byId(
                                                            "idApproversTable");
                                               var Pathid = oEvent.getSource().getParent()
                                                            .getBindingContext("files").getObject().Pathid;
                                               var PosidWiid = oEvent.getSource().getParent()
                                                            .getBindingContext("files").getObject().PosidWiid;

                                               var oModel = new sap.ui.model.json.JSONModel();
                                               oModel.loadData(serviceUrl
                                                            + "/FILE_SENT_FI?param_1='SP'&param_2='"
                                                            + Pathid + "'&param_3='" + PosidWiid + "'",
                                                            null, false);
                                               oTable.setModel(oModel, "sentModelDetail");
                                        } else {
                                               this.getView().byId("idLinkSentTo").setEnabled(
                                                            false);
                                        }*/
                                        // oIconTab.setModel(oModel,"sentModel");
                                 },

                                 workAreaSelect : function(oEvent) {
                        // Clear searchField after item selection starts
                        var s = sap.ui.getCore().byId("idSearchField")
                                                        .getValue();
                        if (s !== "") {
                                        sap.ui.getCore().byId("idSearchField").setValue("");
                        }
                        if(!this.fileTypeSelected){
                        oControllerS1.onHierarchySearch();
                        sap.ui.getCore().byId("idNavBack").setVisible(true);
                        }
                        // Ends
                        this.parentOrgCode = oEvent.getParameters().listItem
                                                        .getBindingContext("files").getObject().ParOrgCode;
                        var m = new Array(2);
                        m[0] = oEvent.getParameters().listItem
                                                        .getBindingContext("files").getObject().OrgCode;
                        m[1] = oEvent.getParameters().listItem
                                                        .getBindingContext("files").getObject().Desc;
                        var f = oEvent.getParameters().listItem
                                                        .getBindingContext("files").getObject().IsFile;
//                    if (f) {
//                                    this.customBusyDialogOpen(this);
//                                    this.customBusyDialogClose(this);
//                    }

                        
                        var oTable1 = sap.ui.getCore().byId("idCreateTable");
                        var t = oTable1.getItems();
                        if (!f) {
                                        for (var i = 0; i < t.length; i++) {
                                                        if (t[i].getBindingContext("files").getObject().ParOrgCode != m[0]) {
                                                                        t[i].setVisible(false);
//                                                                    t[i].getBindingContext("files").getObject().Visible="false";
                                                        } else {
                                                                        t[i].setVisible(true);
//                                                                    t[i].getBindingContext("files").getObject().Visible="true";
                                                        }
                                        }
                        } else {
                                        
                                                        if (this.fileTypeSelected) {
                                                                        // navigation should not be done when link is
                                                                        // clicked
                                                                        this.fileTypeSelected = false;
                                                                        return;
                                                        }
                                        var oModel = new sap.ui.model.json.JSONModel();
                                        oModel.setData(m);
                                        sap.ui.getCore().setModel(oModel, "pass");
//                                    this.oRouter.navTo("myscreen", null);
                                        
                                        this.oRouter.navTo("myscreen");
                                        
                        }

        },


                                 onBackPress : function(oEvent1) {
                                        var temp = this.parentOrgCode;
                                        var oTable1 = sap.ui.getCore().byId("idCreateTable");
                                        var t = oTable1.getItems();

                                        for (var i = 0; i < t.length; i++) {
                                               if (t[i].isActive()) {
                                                     temp = t[i].getBindingContext("files")
                                                                   .getObject().ParOrgCode;
                                                     break;
                                               }
                                        }
                                        if (temp == "") {
                                               sap.ui.getCore().byId("idNavBack")
                                                            .setVisible(false);
                                        } else {
                                               sap.ui.getCore().byId("idNavBack").setVisible(true);
                                        }

                                        for (var i = 0; i < t.length; i++) {
                                               if (t[i].getBindingContext("files").getObject().OrgCode == temp) {
                                                     this.parentOrgCode = t[i].getBindingContext(
                                                                   "files").getObject().ParOrgCode;
                                                     break;
                                               }
                                        }

                                        for (var i = 0; i < t.length; i++) {
                                               if (t[i].getBindingContext("files").getObject().ParOrgCode != this.parentOrgCode) {
                                                     t[i].setVisible(false);
                                               } else {
                                                     t[i].setVisible(true);
                                               }
                                        }
                                 },

                                 onSentProcessorsListAction : function(oEvent) {
                                        oEvent.getSource().getParent().getParent().destroy();
                                        // oEvent.getSource().getParent().close();

                                 },

                                 afterSearchRecovery2 : function() {
                                        var oTable = sap.ui.getCore().byId("idCreateTable");
                                        var t = oTable.getItems();
                                        for (var i = 0; i < t.length; i++) {
                                               var m = t[i].getCells();
                                               // var p = m[0].getItems();
                                               if (t[i].getBindingContext("files").getObject().IsFile) {
                                                     m[0].setSrc("sap-icon://create");
                                                     m[2].setSrc("sap-icon://tags");
                                               } else {
                                                     m[0].setSrc("sap-icon://folder-full");
                                               }
                                        }
                                 },

                                 onHierarchySearch : function(oEvt) {
                        // add filter for search
                        var aFilters = [];
                        if (oEvt == undefined) {
                                        sQuery = "";
                        } else {
                                        var sQuery = oEvt.getSource().getValue();
                        }
                        sap.ui.getCore().byId("idNavBack").setVisible(false);
                        var list = sap.ui.getCore().byId("idCreateTable");
                        var binding = list.getBinding("items");
                        for(var i=0;i<list.getItems().length;i++){
                                        list.getItems()[i].setVisible(true);
                        }
                        binding.filter(aFilters);
                        if (sQuery && sQuery.length > 0) {
                                        var filter2 = new sap.ui.model.Filter("Desc",
                                                                        sap.ui.model.FilterOperator.Contains,
                                                                        sQuery);
                                        aFilters.push(filter2);
                        }
                        binding.filter(aFilters);
                        this.afterSearchRecovery2();
        },


                                 settingsPressed : function(oEvent) {
                                        
                                        var oButton = oEvent.getSource();
                                        // if (!oControllerS1._settingsActionSheet) {
                                        oControllerS1._settingsActionSheet = sap.ui
                                                      .xmlfragment("flm.fiori.view.settingsButton",
                                                                   oControllerS1);
                                        oControllerS1.getView().addDependent(
                                                      oControllerS1._settingsActionSheet);
                                        // }
                                        jQuery.sap.delayedCall(0, oControllerS1, function() {
                                               oControllerS1._settingsActionSheet.openBy(oButton);
                                        });
                                 },

                                 setWorkAreaPressed : function(oEvent) {
                                        
                                        oModel = new sap.ui.model.json.JSONModel();
                                        oModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILES_FI?param_1='GW'&param_2='USADDON_TST'"
                                                                                + "&param_3='20140512'&param_4='20140519'&param_5=''"
                                                                                + "&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''"
                                                                                + "&check_1=''&check_2=''&check_3=''",
                                                                   null, false);
                                        var response = oModel.oData.d.results;
                                        if (!oControllerS1.oWorkArea) {
                                               oControllerS1.oWorkArea = sap.ui.xmlfragment(
                                                            "flm.fiori.view.selectWorkArea",
                                                            oControllerS1);
                                        }
                                        
                                        sap.ui.getCore().byId("idInputRMS").setValue(
                                                     response[0].add_info);
                                        oControllerS1.oWorkArea.open();
                                 },

                                 setSubstitutionPressed : function(oEvent) {
                                        
                                        if (!oControllerS1.oSubstitution) {
                                               oControllerS1.oSubstitution = sap.ui.xmlfragment(
                                                            "flm.fiori.view.setSubstitution",
                                                            oControllerS1);
                                        }
                                        oControllerS1.oSubstitution.open();
                                        oModel = new sap.ui.model.json.JSONModel();
                                        oModel.loadData(serviceUrl + "/FILE_SUBST_OP_ES", null,
                                                     false);
                                        var response = oModel.oData.d.results;

                                        if (response == []) {
                                               /*sap.ui.getCore().byId("idStatusText").setText(
                                                            "Inactive");*/
                                        } else {
                                               oModel.setData(response);
                                               oControllerS1.oSubstitution.setModel(oModel);
                                               /*sap.ui.getCore().byId("idStatusText").setText(
                                                            response[0].OvStatusText);*/
                                        }

                                        // this.oSubstitution.open();
                                 },

                                 handleWorkAreaValueHelp : function(oEvent) {
                                        
                                        oF4Texts = new sap.ui.model.json.JSONModel();
//                                      if (sap.ui.getCore().byId("idLabelRMS") != undefined
//                                                   && oEvent.getSource().getId() == "idInputRMS") {
                                        if(oEvent.getSource().getId() == "idInputRMS"){
                                               var f4text = {
                                                     title : this.getView().getModel("i18n").getObject("SET_WORKAREA"),
                                                     id : "idInputRMS"
                                               };
                                        } 
//                                      else if (sap.ui.getCore().byId("idLabelAssignee") != undefined
//                                                   && oEvent.getSource().getId() == "idInputAssignee") {
                                        else if(oEvent.getSource().getId() == "idInputAssignee"){
                                               var f4text = {
                                                     title : this.getView().getModel("i18n").getObject("USER"),
                                                     id : "idInputAssignee"
                                               };
                                        }
                                        oF4Texts.setData(f4text);
                                        var oTitle = f4text.id;
                                        if (!oControllerS1._oDynamicF4Dialog) {
                                               oControllerS1._oDynamicF4Dialog = sap.ui
                                                            .xmlfragment(
                                                                          "flm.fiori.view.dynamicF4popup",
                                                                          oControllerS1);
                                        }
                                        oControllerS1._oDynamicF4Dialog.setModel(oF4Texts,
                                                     "dyntext");
                                        oF4Model = new sap.ui.model.json.JSONModel();
                                        if (oTitle == "idInputRMS") {
                                               oF4Model
                                                            .loadData(
                                                                          serviceUrl
                                                                                       + "/FILE_F4_ES?$filter=OtherF4 eq true and ID eq  'WA'",
                                                                         null, false);
                                        } else if (oTitle == "idInputAssignee") {
                                               oF4Model
                                                            .loadData(
                                                                          serviceUrl
                                                                                       + "/FILE_F4_ES?$filter=WF eq true and ID eq  'US'",
                                                                         null, false);
                                        }
                                        var response = oF4Model.oData.d.results;
                                        oF4Model.setData(response);
                                        oControllerS1._oDynamicF4Dialog.setModel(oF4Model);
                                        oControllerS1._oDynamicF4Dialog.open();
                                 },
//                               _handleF4HelpClose : function(evt) {
//                                      
//                                      evt.getSource().destroy();
//                               },

                                 _handleF4HelpSearch1 : function(evt) {
                                        var sValue = evt.getParameter("value"); 
                                        var oFilter = new sap.ui.model.Filter("ResulltCol1",
                                                      sap.ui.model.FilterOperator.Contains, sValue);
                                        var oFilter1 = new sap.ui.model.Filter("ResultCol2",
                                                      sap.ui.model.FilterOperator.Contains, sValue);
                                        var oFilter2 = new sap.ui.model.Filter("ResultCol3",
                                                      sap.ui.model.FilterOperator.Contains, sValue);
                                        evt.getSource().getBinding("items").filter(
                                                     new sap.ui.model.Filter([ oFilter,oFilter1,oFilter2 ],
                                                                   "OR"));
                                 },

                                 _handleF4HelpClose1 : function(evt) {
                                        
                                        var oSelectedItem = evt.getParameter("selectedItem");
                                        var id = evt.getSource().getModel("dyntext").getData().id;
                                        var oInput;
                                        if (oSelectedItem) {
                                               if (sap.ui.getCore().byId(id) != undefined) {
                                                     oInput = sap.ui.getCore().byId(
                                                                   evt.getSource().getModel("dyntext")
                                                                                .getData().id);

                                               } else {
                                                     oInput = this.getView().byId(
                                                                   evt.getSource().getModel("dyntext")
                                                                                .getData().id);
                                               }
                                               ; // get the id and
                                               // place it here
                                               if (oInput.getId() == "idInputRMS") {
                                                     oInput
                                                                   .setValue(oSelectedItem
                                                                                .getBindingContext()
                                                                                .getObject().ResulltCol1);
                                               } else {
                                                     oInput
                                                                   .setValue(oSelectedItem
                                                                                .getBindingContext()
                                                                                .getObject().ResultCol2
                                                                                + " "
                                                                                + oSelectedItem
                                                                                             .getBindingContext()
                                                                                             .getObject().ResulltCol1);

                                               }
                                               oInput.setName(oSelectedItem.getBindingContext()
                                                            .getObject().ResultCol3);
                                        }
                                        evt.getSource().getBinding("items").filter([]);
                                 },

                                 substituteSelectionChange : function(evt) {
                                        
                                        var table = sap.ui.getCore()
                                                     .byId("idSubstitutionTable");
                                        var oItem = table.getSelectedItem();
                                        sap.ui.getCore().byId("idDeleteButton")
                                                     .setEnabled(true);
                                        // if(oItem.getBindingContext("files")!=undefined){
                                        // var
                                        // oObj=oItem.getBindingContext("files").getObject();
                                        // if(oObj.Active){
                                        // sap.ui.getCore().byId("idDeactivateButton").setEnabled(true);
                                        // sap.ui.getCore().byId("idActivateButton").setEnabled(false);
                                        // }
                                        // else{
                                        // sap.ui.getCore().byId("idDeactivateButton").setEnabled(false);
                                        // sap.ui.getCore().byId("idActivateButton").setEnabled(true);
                                        // }
                                        // }
                                        // else{
                                        if (oItem.getCells()[3].getText() == "Active") {
                                               sap.ui.getCore().byId("idDeactivateButton")
                                                            .setEnabled(true);
                                               sap.ui.getCore().byId("idActivateButton")
                                                            .setEnabled(false);
                                        } else {
                                               sap.ui.getCore().byId("idDeactivateButton")
                                                            .setEnabled(false);
                                               sap.ui.getCore().byId("idActivateButton")
                                                            .setEnabled(true);
                                        }
                                        // }
                                 },

                                 onCreateSubstituteButton : function(evt) {
                                        // if(!oControllerS1.oCreateSub){
                                        
                                        var oddModel = new sap.ui.model.json.JSONModel();
                                        if (!oControllerS1.oCreateSub) {
                                               oControllerS1.oCreateSub = sap.ui.xmlfragment(
                                                            "flm.fiori.view.createSub", oControllerS1);
                                        }
                                        // clear the fields in the popup
                                        sap.ui.getCore().byId("idInputAssignee").setValue("");
                                        sap.ui.getCore().byId("idValidityFrom").setValue("");
                                        sap.ui.getCore().byId("idValidityTo").setValue("");
                                        sap.ui.getCore().byId("idSubReason").setValue("");
                                        
                                        sap.ui.getCore().byId("idSubProfile")
                                        .setSelectedItem(
                                                     sap.ui.getCore().byId(
                                                                   "idSubProfile")
                                                                   .getFirstItem());
                                        sap.ui.getCore().byId("idSubState").setState(false);
                                        
                                        oddModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILE_F4_ES?$filter=OtherF4 eq true and ID eq  'SP'",
                                                                   null, false);
                                        var response = oddModel.oData.d.results;

                                        oddModel.setData(response);
                                        oControllerS1.oCreateSub.setModel(oddModel);
                                        // }
                                        oControllerS1.oCreateSub.open();
                                 },

                                 onCreateSubOkButton : function(evt) {
                                        
                                        var oCSModel = new sap.ui.model.json.JSONModel();
                                        var assignee = sap.ui.getCore().byId("idInputAssignee");
                                        var profile = sap.ui.getCore().byId("idSubProfile")
                                                     .getSelectedItem();
                                        var state = sap.ui.getCore().byId("idSubState")
                                                     .getState();
                                        var stateValue2 = (state == true) ? "X" : "";
                                        var stateValue = (state == true) ? "Active"
                                                     : "InActive";
                                        var vfDate = sap.ui.getCore().byId("idValidityFrom")
                                                     .getValue();
                                        var vf, vf2;
                                        vf2 = vfDate.replace("/", "").replace("/", "");
                                        var vtDate = sap.ui.getCore().byId("idValidityTo")
                                                     .getValue();
                                        var vt, vt2;
                                        vt2 = vtDate.replace("/", "").replace("/", "");
                                        
                                        var reason = sap.ui.getCore().byId("idSubReason")
                                        .getValue();
                                        
                                        if(assignee.getValue() == "" || vfDate == "" || vtDate == "" || reason=="" ){
                                               sap.m.MessageToast.show(oControllerS1.getView().getModel("i18n").getObject("MESSAGE_36"));
                                               return;
                                        }

                                        
                                        oCSModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILES_FI?param_1='AS'&param_2='"
                                                                                + assignee.getName()
                                                                                + "'&param_3='"
                                                                                + vf2
                                                                                + "'&param_4='"
                                                                                + vt2
                                                                                + "'&param_5='"
                                                                                + profile.getKey()
                                                                                + "'&param_6='"
                                                                                + stateValue2
                                                                                + "'&param_7='"
                                                                                + reason
                                                                                + "'&param_8=''&param_9=''&param_10=''&check_1=''&check_2=''&check_3=''",
                                                                   null, false);
                                        if(oCSModel.getData().d.results[0].msg_type=='E'){
                                               sap.m.MessageBox.alert(oCSModel.getData().d.results[0].msg_text);
                                        }
                                        oModel = new sap.ui.model.json.JSONModel();
                                        oModel.loadData(serviceUrl + "/FILE_SUBST_OP_ES", null,
                                                     false);
                                        var response = oModel.oData.d.results;
                                        oModel.setData(response);
                                        oControllerS1.oSubstitution.setModel(oModel);
                                        /*sap.ui.getCore().byId("idStatusText").setText(response[0].OvStatusText);*/
                                        oControllerS1.oCreateSub.close();
                                        // evt.getSource().getParent().getParent().destroy();
                                 },

                                 onDeleteSubstituteButton : function(evt) {
                                        
                                        // var
                                        // oItem=sap.ui.getCore().byId("idSubstitutionTable").getSelectedItem();
                                        var oItem = evt.getParameter("listItem");
                                        var assignee = oItem.getCells()[0].getBindingContext()
                                                     .getObject().Otype
                                                     + oItem.getCells()[0].getBindingContext()
                                                                   .getObject().Objid;
                                        var vf = oItem.getCells()[4].getText().replace(".", "")
                                                     .replace(".", "");
                                        vf = vf.substr(4, 4) + vf.substr(2, 2)
                                                     + vf.substr(0, 2); // 01.06.2014
                                        var vt = oItem.getCells()[5].getText().replace(".", "")
                                                     .replace(".", "");
                                        vt = vt.substr(4, 4) + vt.substr(2, 2)
                                                     + vt.substr(0, 2);
                                        var oDSModel = new sap.ui.model.json.JSONModel();
                                        oDSModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILES_FI?param_1='DS'&param_2='"
                                                                                + assignee
                                                                                + "'&param_3='"
                                                                                + vf
                                                                                + "'&param_4='"
                                                                                + vt
                                                                                + "'&param_5=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''&check_1=''&check_2=''&check_3=''",
                                                                   null, false);
                                        var response = oDSModel.oData.d.results[0];
                                        if (response.msg_type != 'E') {
                                               /*sap.ui.getCore().byId("idStatusText").setText(
                                                            response.add_info);
                                               sap.ui.getCore().byId("idStatusText").setText(response.OvStatusText);*/
                                               oItem.destroy();
                                        } else {
                                               sap.m.MessageToast
                                                            .show(oModel.getData().d.results[0].msg_text);
                                        }
                                 },

                                 substituteStatusChange : function(oEvent) {
                                        
                                        var oItem = oEvent.getSource().getParent();
                                        var assignee = oItem.getCells()[0].getBindingContext()
                                                     .getObject().Otype
                                                     + oItem.getCells()[0].getBindingContext()
                                                                   .getObject().Objid;
                                        var reason=oItem.getBindingContext().getObject().Reason;
                                        var vf = oItem.getCells()[4].getText().replace(".", "")
                                                     .replace(".", "");
                                        vf = vf.substr(4, 4) + vf.substr(2, 2)
                                                     + vf.substr(0, 2);
                                        var vt = oItem.getCells()[5].getText().replace(".", "")
                                                     .replace(".", "");
                                        vt = vt.substr(4, 4) + vt.substr(2, 2)
                                                     + vt.substr(0, 2);
                                        var oActivateModel = new sap.ui.model.json.JSONModel();
                                        if (oEvent.getSource().getState()) {
                                               oActivateModel
                                                            .loadData(
                                                                          serviceUrl
                                                                                       + "/FILES_FI?param_1='AC'&param_2='"
                                                                                       + assignee
                                                                                       + "'&param_3='"
                                                                                       + vf
                                                                                       + "'&param_4='"
                                                                                       + vt
                                                                                       + "'&param_5='"+reason+"'&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''&check_1=''&check_2=''&check_3=''",
                                                                         null, false);

                                        } else {
                                               oActivateModel
                                                            .loadData(
                                                                          serviceUrl
                                                                                       + "/FILES_FI?param_1='DC'&param_2='"
                                                                                       + assignee
                                                                                       + "'&param_3='"
                                                                                       + vf
                                                                                       + "'&param_4='"
                                                                                       + vt
                                                                                       + "'&param_5='"+reason+"'&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''&check_1=''&check_2=''&check_3=''",
                                                                         null, false);

                                        }
                                        var response = oActivateModel.oData.d.results[0];
                                        if (response.msg_type != 'E') {
                                               /*sap.ui.getCore().byId("idStatusText").setText(
                                                            response.add_info);*/
                                        } else {
                                               sap.m.MessageToast.show(response.msg_text);
                                        }
                                 },

                                 onActivateButton : function(evt) {
                                        var oItem = sap.ui.getCore()
                                                      .byId("idSubstitutionTable").getSelectedItem();
                                        var assignee = oItem.getCells()[0].getBindingContext()
                                                     .getObject().Otype
                                                     + oItem.getCells()[0].getBindingContext()
                                                                   .getObject().Objid;
                                        var vf = oItem.getCells()[4].getText().replace(".", "")
                                                     .replace(".", "");
                                        vf = vf.substr(4, 4) + vf.substr(2, 2)
                                                     + vf.substr(0, 2);
                                        var vt = oItem.getCells()[5].getText().replace(".", "")
                                                     .replace(".", "");
                                        vt = vt.substr(4, 4) + vt.substr(2, 2)
                                                     + vt.substr(0, 2);
                                        var oActivateModel = new sap.ui.model.json.JSONModel();
                                        oActivateModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILES_FI?param_1='AC'&param_2='"
                                                                                + assignee
                                                                                + "'&param_3='"
                                                                                + vf
                                                                                + "'&param_4='"
                                                                                + vt
                                                                                + "'&param_5=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''&check_1=''&check_2=''&check_3=''",
                                                                   null, false);
                                        var response = oActivateModel.oData.d.results[0];
                                        if (response.msg_type != 'E') {
                                               /*sap.ui.getCore().byId("idStatusText").setText(
                                                            response.add_info);*/
                                               oItem.getCells()[3].setText("Active");
                                               sap.ui.getCore().byId("idDeactivateButton")
                                                            .setEnabled(true);
                                               sap.ui.getCore().byId("idActivateButton")
                                                            .setEnabled(false);
                                        } else {
                                               sap.m.MessageToast
                                                            .show(oModel.getData().d.results[0].msg_text);
                                        }
                                 },

                                 onDeactivateButton : function(evt) {
                                        
                                        var oItem = sap.ui.getCore()
                                                      .byId("idSubstitutionTable").getSelectedItem();
                                        var assignee = oItem.getCells()[0].getBindingContext()
                                                     .getObject().Otype
                                                     + oItem.getCells()[0].getBindingContext()
                                                                   .getObject().Objid;
                                        var vf = oItem.getCells()[4].getText().replace(".", "")
                                                     .replace(".", "");
                                        vf = vf.substr(4, 4) + vf.substr(2, 2)
                                                     + vf.substr(0, 2);
                                        var vt = oItem.getCells()[5].getText().replace(".", "")
                                                     .replace(".", "");
                                        vt = vt.substr(4, 4) + vt.substr(2, 2)
                                                     + vt.substr(0, 2);
                                        var oActivateModel = new sap.ui.model.json.JSONModel();
                                        oActivateModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILES_FI?param_1='DC'&param_2='"
                                                                                + assignee
                                                                                + "'&param_3='"
                                                                                + vf
                                                                                + "'&param_4='"
                                                                                + vt
                                                                                + "'&param_5=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''&check_1=''&check_2=''&check_3=''",
                                                                   null, false);
                                        var response = oActivateModel.oData.d.results[0];
                                        if (response.msg_type != 'E') {
                                               /*sap.ui.getCore().byId("idStatusText").setText(
                                                            response.msg_text);*/
                                               oItem.getCells()[3].setText("InActive");
                                               sap.ui.getCore().byId("idDeactivateButton")
                                                            .setEnabled(false);
                                               sap.ui.getCore().byId("idActivateButton")
                                                            .setEnabled(true);
                                        } else {
                                               sap.m.MessageToast
                                                            .show(oModel.getData().d.results[0].msg_text);
                                        }
                                 },

                                 onStaticDialogCloseButton : function(oEvent) {
                                        if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                                               oEvent.getSource().getParent().close();
                                        } else {
                                               oEvent.getSource().getParent().getParent().close();
                                        }
                                 },

                                 onWorkAreaSave : function(oEvent) {
                                        var wa = sap.ui.getCore().byId("idInputRMS").getName();
                                        if(wa!=""){
                                        var oActivateModel = new sap.ui.model.json.JSONModel();
                                        oActivateModel
                                                     .loadData(
                                                                   serviceUrl
                                                                                + "/FILES_FI?param_1='UW'&param_2='"
                                                                                + wa
                                                                                + "'&param_3=''&param_4=''&param_5=''"
                                                                                + "&param_6=''&param_7=''&param_8=''"
                                                                                + "&param_9=''&param_10=''&check_1=''&check_2=''&check_3=''",
                                                                   null, false);
                                        }
                                        if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                                               oEvent.getSource().getParent().close();
                                        } else {
                                               oEvent.getSource().getParent().getParent().close();
                                        }

                                        this.loadInitialData(this);
                                        // window.location.reload();

                                 },

                                 // load initial data
                                 loadInitialData : function(controller) {
                                        controller.customBusyDialogOpen(controller);
                                       
                                        
                                      oActionModel = new sap.ui.model.json.JSONModel();
                                        oActionModel.loadData(serviceUrl
                                                +"/FILE_BUTTONS_ES(GUID='',TABTYPE='INITLOAD',FILEID='',FILETYPE='"+this.objectType+"',WIID='',ISDAAK=false)",null,false);
                                        
                                        var oModel = controller.getView().getModel();
                                        oModel.clearBatch();
                                        var batchOp = oModel.createBatchOperation(
                                                     "/FILE_INTRAY_ES?$filter=Filetype+eq+'"+this.objectType+"'", 'GET');
                                        oModel.addBatchReadOperations([ batchOp ]);
                                        batchOp = oModel.createBatchOperation("/FILE_DRAFT_ES?$filter=Filetype+eq+'"+this.objectType+"'",
                                                     'GET');
                                        oModel.addBatchReadOperations([ batchOp ]);
                                        batchOp = oModel.createBatchOperation("/FILE_CABIN_ES?$filter=Filetype+eq+'"+this.objectType+"'",
                                                     'GET');
                                        oModel.addBatchReadOperations([ batchOp ]);
                                        batchOp = oModel.createBatchOperation("/FILE_SUBST_ES?$filter=Filetype+eq+'"+this.objectType+"'",
                                                     'GET');
                                        oModel.addBatchReadOperations([ batchOp ]);
                                        batchOp = oModel.createBatchOperation("/FILE_ASSIT_ES",
                                                     'GET');
                                        oModel.addBatchReadOperations([ batchOp ]);
                                 /*     batchOp = oModel.createBatchOperation("/FILE_SENT_ES",'GET');
                                        oModel.addBatchReadOperations([ batchOp ]);*/
                                        batchOp = oModel.createBatchOperation("/FILE_TRACK_ES?$filter=CaseType+eq+'"+this.objectType+"'",
                                                     'GET');
                                        oModel.addBatchReadOperations([ batchOp ]);
                                        // batchOp =
                                        // oModel.createBatchOperation("/FILE_HRCHY_ES",'GET');
                                        // oModel.addBatchReadOperations([ batchOp ]);
                                        
                                        
                                        oModel
                                                     .submitBatch(
                                                                   function(oResponse, oData) {
                                                                          /*if(oData.data.__batchResponses[0].message !=undefined){
                                                                                sap.m.MessageBox.alert(getErrorMessage());
                                                                                controller
                                                                                .customBusyDialogClose(controller);
                                                                                return;
                                                                         }else{*/
                                                                         
                                                                         var i = 0;
                                                                          if(oResponse.__batchResponses[i].data != undefined){
                                                                         var oIntrayModel = new sap.ui.model.json.JSONModel();
                                                                          oIntrayModel
                                                                                       .setData(oResponse.__batchResponses[i].data);
                                                                         /* Setting decoded value for subject*/
                                                                         /*for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].Subject);
                                                                                oResponse.__batchResponses[i].data.results[j].Subject = subValue;
                                                                         }*/
                                                                         
                                                                   for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var afterSplit = oResponse.__batchResponses[i].data.results[j].Duedate.split(".");
                                                                                  var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                                  oResponse.__batchResponses[i].data.results[j].dueDate = newDate;
                                                                         }
                                                                   for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                         var afterSplit = oResponse.__batchResponses[i].data.results[j].DateRecieved.split(".");
                                                                           var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                           oResponse.__batchResponses[i].data.results[j].recDate = newDate;
                                                                   }
                                                                          controller.getView().byId(
                                                                                       "fileIconTab").setModel(
                                                                                       oIntrayModel, "files");
                                                                         }else{
                                                                                sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                                                                                controller
                                                                                .customBusyDialogClose(controller);
                                                                                return;
                                                                         }
                                                                         i++;
                                                                          if(oResponse.__batchResponses[i].data != undefined){
                                                                         var oDraftModel = new sap.ui.model.json.JSONModel();
                                                                          oDraftModel
                                                                                       .setData(oResponse.__batchResponses[i].data);
                                                                         /* Setting decoded value for subject*/
                                                                         /*for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].Subject);
                                                                                oResponse.__batchResponses[i].data.results[j].Subject = subValue;
                                                                         }*/
                                                                         
                                                                         for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var afterSplit = oResponse.__batchResponses[i].data.results[j].Duedate.split(".");
                                                                                  var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                                  oResponse.__batchResponses[i].data.results[j].dueDate = newDate;
                                                                         }
                                                                   for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                         var afterSplit = oResponse.__batchResponses[i].data.results[j].CrDate.split(".");
                                                                           var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                           oResponse.__batchResponses[i].data.results[j].crDate = newDate;
                                                                   }
                                                                          controller.getView().byId(
                                                                                       "draftIconTab").setModel(
                                                                                       oDraftModel, "files");
                                                                         }else{
                                                                                sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                                                                                controller
                                                                                .customBusyDialogClose(controller);
                                                                                return;
                                                                         }
                                                                         i++;
                                                                          if(oResponse.__batchResponses[i].data != undefined){
                                                                         var oCabinetModel = new sap.ui.model.json.JSONModel();
                                                                          oCabinetModel
                                                                                       .setData(oResponse.__batchResponses[i].data);
                                                                         /* Setting decoded value for subject*/
                                                                         /*for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].Subject);
                                                                                oResponse.__batchResponses[i].data.results[j].Subject = subValue;
                                                                         }*/
                                                                         
                                                                         for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var afterSplit = oResponse.__batchResponses[i].data.results[j].Duedate.split(".");
                                                                                  var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                                  oResponse.__batchResponses[i].data.results[j].dueDate = newDate;
                                                                         }
                                                                   for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                         var afterSplit = oResponse.__batchResponses[i].data.results[j].DateRecieved.split(".");
                                                                           var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                           oResponse.__batchResponses[i].data.results[j].recDate = newDate;
                                                                   }
                                                                   for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                         var afterSplit = oResponse.__batchResponses[i].data.results[j].Rdate.split(".");
                                                                           var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                           oResponse.__batchResponses[i].data.results[j].resubDate = newDate;
                                                                   }
                                                            
                                                                          controller.getView().byId(
                                                                                       "cabinetIconTab").setModel(
                                                                                       oCabinetModel, "files");
                                                                         }else{
                                                                                sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                                                                                controller
                                                                                .customBusyDialogClose(controller);
                                                                                return;
                                                                         }
                                                                         i++;
                                                                          if(oResponse.__batchResponses[i].data != undefined){
                                                                         var oSubstituteModel = new sap.ui.model.json.JSONModel();
                                                                          oSubstituteModel
                                                                                       .setData(oResponse.__batchResponses[i].data);
                                                                         /* Setting decoded value for subject*/
                                                                         /*for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].Subject);
                                                                                oResponse.__batchResponses[i].data.results[j].Subject = subValue;
                                                                         }*/
                                                                         
                                                                         for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var afterSplit = oResponse.__batchResponses[i].data.results[j].Duedate.split(".");
                                                                                  var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                                  oResponse.__batchResponses[i].data.results[j].dueDate = newDate;
                                                                         }
                                                                   for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                         var afterSplit = oResponse.__batchResponses[i].data.results[j].DateRecieved.split(".");
                                                                           var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                           oResponse.__batchResponses[i].data.results[j].recDate = newDate;
                                                                   }
                                                                          controller.getView().byId(
                                                                                       "substituteIconTab")
                                                                                       .setModel(oSubstituteModel,
                                                                                                    "files");
                                                                         }else{
                                                                                sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                                                                                controller
                                                                                .customBusyDialogClose(controller);
                                                                                return;
                                                                         }
                                                                         i++;
                                                                          if(oResponse.__batchResponses[i].data != undefined){
                                                                         var oAssistantModel = new sap.ui.model.json.JSONModel();
                                                                          oAssistantModel
                                                                                       .setData(oResponse.__batchResponses[i].data);
                                                                         /* Setting decoded value for subject*/
                                                                         /*for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].Subject);
                                                                                oResponse.__batchResponses[i].data.results[j].Subject = subValue;
                                                                         }*/
                                                                         
                                                                         for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var afterSplit = oResponse.__batchResponses[i].data.results[j].SentOn.split(".");
                                                                                  var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                                  oResponse.__batchResponses[i].data.results[j].sentDate = newDate;
                                                                         }
                                                                          controller.getView().byId(
                                                                                       "assistIconTab").setModel(
                                                                                       oAssistantModel, "files");
                                                                         }else{
                                                                                sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                                                                                controller
                                                                                .customBusyDialogClose(controller);
                                                                                return;
                                                                         }
                                                                         i++;
                                                                         /* var oSendModel = new sap.ui.model.json.JSONModel();
                                                                         oSendModel.setData(oResponse.__batchResponses[i].data);
                                                                         controller.getView().byId("sentIconTab").setModel(oSendModel,"files");
                                                                         i++;*/
                                                                          if(oResponse.__batchResponses[i].data != undefined){
                                                                         var oTrackModel = new sap.ui.model.json.JSONModel();
                                                                          oTrackModel
                                                                                       .setData(oResponse.__batchResponses[i].data);
                                                                         /* Setting decoded value for subject*/
                                                                         /*for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].CaseTitle);
                                                                                oResponse.__batchResponses[i].data.results[j].CaseTitle = subValue;
                                                                         }*/
                                                                         
                                                                         for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                                var afterSplit = oResponse.__batchResponses[i].data.results[j].PlanEndDate.split(".");
                                                                                  var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
                                                                                  oResponse.__batchResponses[i].data.results[j].dueDate = newDate;
                                                                         }
                                                                          controller.getView().byId(
                                                                                       "trackIconTab").setModel(
                                                                                       oTrackModel, "files");
                                                                         }else{
                                                                                sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                                                                                controller
                                                                                .customBusyDialogClose(controller);
                                                                                return;
                                                                         }
                                                                         i++;
                                                                         
                                                                        
                                                                          controller
                                                                                       .customBusyDialogClose(controller);
//                                                                       }
                                                                         
                                                                   },
                                                                   function(oResponse) {
                                                                         
                                                                         // perform error handling
                                                                          controller
                                                                                       .customBusyDialogClose(controller);
                                                                   }, true);

                                 },
                                 filetypeInformationShown : function(oEvent){
                                        this.fileTypeSelected = true;
                                        if (!this.fileTypeDesc) {
                                               this.fileTypeDesc = sap.ui.xmlfragment(
                                                            "flm.fiori.view.fileTypeDescription", this);
                                        }
                                        // this._oBusinessCard.setModel(oControllerS2.oTreeTable.getModel());
                                        var descModel = new sap.ui.model.json.JSONModel();
                                        descModel.setData(oEvent.getSource()
                                                      .getBindingContext("files").getObject());
                                        this.fileTypeDesc.setModel(descModel);
                                        this.fileTypeDesc.bindElement("/");
                                        this.fileTypeDesc.openBy(oEvent.getSource());
                                 },
                                 
                                 raiseFlag : function(oEvent){
                                        sap.m.MessageToast
                                        .show(oControllerS1.getView().getModel("i18n").getObject("MESSAGE_57"));
                                        oEvent.getSource().setValue("");
                                 },
                                 
                                 showSubstitutionReason : function(oEvent){
                                        oControllerS1.fileTypeSelected = true;
                                        if (!oControllerS1.substitutionReason) {
                                               oControllerS1.substitutionReason = sap.ui.xmlfragment(
                                                            "flm.fiori.view.showSubstitutionReason", oControllerS1);
                                        }
                                        // this._oBusinessCard.setModel(oControllerS2.oTreeTable.getModel());
                                        var descModel = new sap.ui.model.json.JSONModel();
                                        descModel.setData(oEvent.getSource()
                                                      .getBindingContext("files").getObject());
                                        oControllerS1.substitutionReason.setModel(descModel);
                                         oControllerS1.substitutionReason.bindElement("/");
                                        oControllerS1.substitutionReason.openBy(oEvent.getSource());
                                 },
                                 
                                 createActionsOpen : function(oEvent) {
                                        var oButton = oEvent.getSource();
                                        //if (!this._sendActionSheet) {
                                        if (!oControllerS1.createActionSheet){
                                               this.createActionSheet = sap.ui.xmlfragment(
                                                            "flm.fiori.view.createActions", this);
                                               this.getView().addDependent(this.createActionSheet);
                                        }
                                        jQuery.sap.delayedCall(0, this, function() {
                                               this.createActionSheet.openBy(oButton);
                                        });
                                        if(oActionModel.getData() != undefined){
                                           if(oActionModel.getData().d.ISFILECREATE == true){
            sap.ui.getCore().byId("idCreateFile").setVisible(true);
           }else{
            sap.ui.getCore().byId("idCreateFile").setVisible(false);
           }
           if(oActionModel.getData().d.ISDAAKCREATE == true){
            sap.ui.getCore().byId("idCreateDaak").setVisible(true);
           }else{
            sap.ui.getCore().byId("idCreateDaak").setVisible(false);
           }
           }
           else if(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers) == "Resource not found for segment 'FILE_BUTTONS_ET'."){
            sap.ui.getCore().byId("idCreateFile").setVisible(false);
            sap.ui.getCore().byId("idCreateDaak").setVisible(false);
            oControllerS1
                                                .customBusyDialogClose(oControllerS1);
           }
           else{
            sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
            oControllerS1
                                                .customBusyDialogClose(oControllerS1);
            return;
           }
                                        
                                 },
                                 
                                 createDaakButtonPressed : function(oEvent) {
                                        oControllerS1.tabType="createdaak";
                                        var oModel = new sap.ui.model.json.JSONModel();
                                        this.customBusyDialogOpen(this);
                                        if (this.daakNumberingTypeDialog == undefined) {
                                            this.daakNumberingTypeDialog = sap.ui.xmlfragment(
                                                          "flm.fiori.view.daakNumberingType", this);
                                      }
                                      /*  oModel.attachRequestCompleted(oEvent,function(oEvt){
                                               if (this.daakNumberingTypeDialog == undefined) {
                                                     this.daakNumberingTypeDialog = sap.ui.xmlfragment(
                                                                   "flm.fiori.view.daakNumberingType", this);
                                               }
                                               var oTable = sap.ui.getCore().byId("idDaakTable");
                                               oTable.setModel(oModel, "files");
                                               var t = oTable.getItems();
                                               for (var i = 0; i < t.length; i++) {
                                                   var m = t[i].getCells();
                                                            m[0].setSrc("sap-icon://letter");

                                               }

                                               this.daakNumberingTypeDialog.open();
                                               this.customBusyDialogClose(this);
                                        },this);*/

                                        oModel.loadData(serviceUrl + "/FILE_HRCHY_ES?$filter=ISDAAK+eq+true", null,false);
                                        oModel.setData(oModel.oData.d.results);
                                        this.daakNumberingTypeDialog.setModel(oModel);
                                        var t = this.daakNumberingTypeDialog.getItems();
                                        for (var i = 0; i < t.length; i++) {
                                            var m = t[i].getCells();
                                                     m[0].setSrc("sap-icon://letter");

                                        }
                                        this.daakNumberingTypeDialog.open();
                                        this.customBusyDialogClose(this);
//                                        fromTab = "CREATEDAAK";
//                                        this.oRouter.navTo("daakscreen");
                                 
                                  },
                                 
                                 createMailButtonPressed : function(oEvent) {
                                 
                                        this.oRouter.navTo("mailscreen");
                                 
                                 },
                                 
                                 /* Navigating to Documents Search Screen */
                                 searchDaakButtonPressed : function(oEvent) {
                                        
                                        this.oRouter.navTo("daaksearchscreen");
                                 },
                                 searchNumberingType: function(oEvent) {
                                     var sValue = oEvent.getParameter("value");
                                     var oFilter = new sap.ui.model.Filter("Desc", sap.ui.model.FilterOperator.Contains, sValue);
                                     var oBinding = oEvent.getSource().getBinding("items");
                                     oBinding.filter([oFilter]);
                                   },
                                   
                               selectNumberingType : function(oEvent){
                                
                                fromTab = "CREATEDAAK";
                                var m = new Array(2);
                                m[0] = oEvent.getParameters().selectedItem.getBindingContext().getObject().Ord;
                                m[1] = oEvent.getParameters().selectedItem.getBindingContext().getObject().Desc;

                                var oModel = new sap.ui.model.json.JSONModel();
                                oModel.setData(m);
                                sap.ui.getCore().setModel(oModel, "passdaak");
                                this.oRouter.navTo("daakscreen");
                              
                               }
                                 
                           });