/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
// jQuery.sap.require("test.fiori.Formatter");
jQuery.sap.require("flm.fiori.utils.dynamicUIAssist");
jQuery.sap.require("sap.m.TablePersoController");
jQuery.sap.require("flm.fiori.utils.inboxPersonalDialog");
jQuery.sap.require("flm.fiori.utils.dynamicUIAssist");
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require("sap.ui.thirdparty.sinon");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("flm.fiori.utils.utilities");
jQuery.sap.require("flm.fiori.utils.formatter");
jQuery.sap.require("flm.fiori.utils.validator");
jQuery.sap.require("flm.fiori.utils.BASE64Util");
//sap.ui.richtexteditor.TinyMCELicense = "sap.only";
var oControllerS3 = null;
var filetype = null;

sap.ca.scfld.md.controller.BaseFullscreenController
              .extend(
                           "flm.fiori.view.S3",
                           {
                                  data : {
                                         priority : null,
                                         fileNumber : null,
                                         dynamic : null,
                                         notes : null,
                                         folders : null,
                                         documents : null,
                                         buttons : null,
                                         privateNote : null,
                                         basic : null,
                                         attachments : [],
                                  },
                                  caseguid : "",
                                  fileid : "",
                                  filenumber : null,
                                  wiId : null,
                                  digitalsign : null,
                                  createSignFlag : false,
                                  dynUIAssistArr : null,
                                  fromTab : null,
                                  oStdDialog : null,
                                  i18 : null,
                                  navBackArrS3 : [],
                                  _formFragments : {},
                                  initFlag: true,
                                  _fragments : {},
                                  _valueHelpDialog : undefined,
                                  oCreateWorkflow : undefined,

                                  

                                  globalModel : {},
                                  inputId : {},
                                  response : {},
                                  globalCounter : {},
                                  flatObj :[],
                                  flagLocation : {},
                                  createFileResponse : {},
                                  updateWorkflowFlag : false,
                                  newWorkflowFlag : false,
                                  saveFlag : false,
                                  rightTreeData : null,
                                  leftTreeNodes : null,
                                  numberDateObjFile : null,
                                  onInit : function(oEvent) {
                                   sap.ui.richtexteditor.TinyMCELicense = "sap.only";
                                   serviceUrl = this.getView().getModel().sServiceUrl;
                                    if(sap.ui.getCore().getModel("i18n") == undefined){
                                                              sap.ui.getCore().setModel(this.getView().getModel("i18n"),"i18n");
                                                       }
                                         
                                         var oModel = new sap.ui.model.json.JSONModel();
                                         oModel.setData(this.data);
                                         this.getView().setModel(oModel,"global");

                                         this.getView().addEventDelegate({

                                                onBeforeShow : jQuery.proxy(function(evt) {
 
                                                       this.onBeforeShow(evt);

                                                }, this)

                                         });
                                         
                                         oControllerS3 = this;
                                         this.getView().byId("idFileNumberHboxMain")
                                                       .addStyleClass("filetype");
                                         this.oRouter
                                                       .attachRouteMatched(
                                                                     function(oEvent) {
                                                                     
                                                                           if (oEvent.getParameter("name") == "myscreen") {
                                                                              
                                                                                if(oControllerS1.tabType!="draft"){ 
                                                                                  var d = new Date();
                                                                                  
                                                                                  var time = d.toTimeString()
                                                                                                .substr(0, 8);
                                                                                  var today = d.toDateString();
                                                                                  // fetching value from view 1
                                                                                  this.getView().byId(
                                                                                                "idFileType").setValue(
                                                                                                sap.ui.getCore()
                                                                                                              .getModel("pass")
                                                                                                              .getData()[1]
                                                                                                              .toUpperCase());
                                                                                  this.getView().byId(
                                                                                                "idCreatedOn")
                                                                                                .setValue(
                                                                                                              today + " , "
                                                                                                                            + time);
                                                                                  this.filetype = sap.ui.getCore()
                                                                                  .getModel("pass").getData()[0];
                                                                                  }
                                                                                  else{
                                                                                   if(oControllerS1.caseguid!=undefined){
                                                                                  this.caseguid = oControllerS1.caseguid;
                                                                                  this.fileid = oControllerS1.fileid;
                                                                                   }
                                                                                  }
                                                                                
                                                                                  // this.getView().byId("descrEditor").setEditable(true);
                                                                           }
                                                                           if (oEvent.getParameter("name") == "fullscreen") {
                                                                                  this.getView().byId(
                                                                                                "idFileNumberHbox")
                                                                                                .destroyItems();
                                                                                  this
                                                                                                .getView()
                                                                                                .byId(
                                                                                                              "dynamicAttrForm")
                                                                                                .destroyContent();
                                                                           }
                                                                     }, this);
                                         this.i18 = this.getView().getModel("i18n");
                                        // Model for Priority Input
                                         
                                         // var oPriorityModel = new
                                         // sap.ui.model.json.JSONModel();
                                         // oPriorityModel.loadData(serviceUrl
                                         // + "/FILE_F4_ES?$filter=CaseGuid
           // eq '"
                                         // + this.caseguid
                                         // + "' and ID eq 'PRIO' and FileID
           // eq '"
                                         // + this.fileid + "' and FileType
           // eq '"
                                         // + filetype + "'", null, false);
                                         //
                                         // this.getView().setModel(oPriorityModel,
           // "priority");

                                         /* Workflow starts here */
                                         this.oTreeTable = this.getView().byId("wftree");
                                         this.oTreeTable.setSelectionMode("Multi");
                                         var oLink = new sap.m.Link({
                                                text : "{workflow>Fullname}",
                                                press : oControllerS3.openBusinessCard,
                                                enabled : {
                                                    "parts" : [ 'workflow>isSpecial'],
                                                    "formatter" : flm.fiori.utils.formatter.linkEnabled
                                                },
                                                emphasized : {
                                                    "parts" : [ 'workflow>isSpecial'],
                                                    "formatter" : flm.fiori.utils.formatter.linkEmphasized
                                                },
                                         });
                                         var oSpace1 = new sap.ui.core.HTML({
                                                content : "<span>&nbsp;&nbsp;</span>"
                                         });
                                         var oSpace2 = new sap.ui.core.HTML({
                                                content : "<span>&nbsp;&nbsp;</span>"
                                         });
                                         var oIcon1 = new sap.ui.core.Icon(
                                                       {
                                                              size : "1rem",
                                                              src : {
                                                                     "parts" : [ 'workflow>Nodetype'],
                                                                     "formatter" : flm.fiori.utils.formatter.treeTableFlowIcon
                                                              },
                                                              color : "#5C85FF"
                                                       });
                                         
                                         var oIcon2 = new sap.ui.core.Icon(
                                                       {
                                                              size : "1rem",
                                                              src : {
                                                                     "parts" : [ 'workflow>Pospast' , 'workflow>isSpecial'],
                                                                     "formatter" : flm.fiori.utils.formatter.treeTableIcon
                                                              },
                                                              color : {
                                                                     "parts" : [ 'workflow>Pospast' , 'workflow>isSpecial'],
                                                                     "formatter" : flm.fiori.utils.formatter.treeTableIconColor
                                                              }
                                                       });
                                         
                                         this.oLayout = new sap.ui.layout.HorizontalLayout(
                                                       {
                                                              content : [ oIcon1,oSpace1,oIcon2,oSpace2,oLink ]
                                                       });


                       this.oTreeTable.addColumn(new sap.ui.table.Column({
                        label : this.getView().getModel("i18n").getObject("PROCESSORS"),
                        template : this.oLayout,
                        width : "30rem"
                       }));
                       this.oTreeTable.addColumn(new sap.ui.table.Column({
                        label : this.getView().getModel("i18n").getObject("ACTIVITY"),
                        template : "workflow>Actdc",
                        width : "20rem"
                       }));
                       this.oTreeTable.addColumn(new sap.ui.table.Column({
                        label : this.getView().getModel("i18n").getObject("START_DATE"),
                        template : "workflow>Creadate",
                        width : "15rem"
                       }));
                       this.oTreeTable.addColumn(new sap.ui.table.Column({
                        label : this.getView().getModel("i18n").getObject("END_DATE"),
                        template : "workflow>Enddate",
                        width : "15rem"
                       }));
                       this.oTreeTable.addColumn(new sap.ui.table.Column({
                        label : this.getView().getModel("i18n").getObject("STATUS"),
                        template : "workflow>Statustext",
                        width : "20rem"
                       }));

                                         /* Workflow ends here */
                       if(this.customInitializeData){
                                            this.customInitializeData(this);
                                     }
                                  },

                                  onBeforeShow : function(oEvent) {
                                  
                                    this.initFlag = true;
                                    this.updateWorkflowFlag = false;
                                    this.getView().byId("createFile").setBusy(false);
                                    oControllerS3.getView().byId("notingEditor").setValue("");
                                    if(oControllerS1.tabType!="draft"){
                                    this.caseguid = "";
                                    this.fileid = "";
                                    this.fromTab = "CREATE";
                                    this.setInitialModels(this);
                                    this.flatObj=[];
                                    if(!this.initFlag){
                                     this.getView().byId("createFile").setBusy(true);
                                     return;
                                    }
                                    this.createFileNo();
                                   // this.getView().byId("shareDraftAction").setEnabled(false);
                                    this.getView().byId("printAction").setVisible(false);
                                    this.getView().byId("descrEditor").setValue("");
                                    this.getView().byId("idFileNumberHboxMain").setVisible(
                                              true);
                                    this.getView().byId("idLabelFileNumber").setVisible(
                                                  false);
                                    this.getView().byId("idInputFileNumber").setVisible(
                                                  false);
                                    this.getView().byId("idInputFileNumber").setValue("");
                                    this.getView().byId("idDuedate").setValue("");
                                    this.getView().byId("idPrioSelect").setSelectedKey("");

                                    this.getView().byId("idShortText").setValue("");

                                    this.getView().byId("idTrackFileLabel").setVisible(
                                                  false);
                                    this.getView().byId("idTrackFileSwitch").setVisible(
                                                  false);
                                    this.getView().byId("idTrackFileSwitch").setTooltip(this.getView().getModel("i18n").getObject("OFF"));
                                    this.getView().byId("idConfidentialFileLabel").setVisible(
                                            false);
                                    this.getView().byId("idConfidentialFileSwitch").setVisible(
                                            false);
                                    this.getView().byId("idConfidentialFileSwitch").setTooltip(this.getView().getModel("i18n").getObject("OFF"));
                                    this.getView().byId("notingPanel").setVisible(false);
                                    oControllerS3.getView().byId("idButtonSend").setEnabled(false);
                                    oControllerS3.getView().byId("idButtonClose").setEnabled(false);
                                    this.getView().byId("emptyNotingPanel").setVisible(true);
                                    this.getView().byId("descrEditor").setHeight("18rem");
                                    oControllerS3.getView().byId("idAddNewWorkflowButton").setEnabled(false);
                                    }
                                    else{
                                           this.filetype="";
                                           this.fromTab = "DRAFT";
                                           this.setInitialModels(this);
                                          // this.getView().byId("shareDraftAction").setEnabled(true);
                                           this.getView().byId("printAction").setVisible(true);
                                           this.getView().byId("idFileNumberHboxMain").setVisible(
                                                         false);
                                           this.getView().byId("idLabelFileNumber").setVisible(
                                                         true);
                                           this.getView().byId("idInputFileNumber").setVisible(
                                                         true);
                                           this.getView().byId("idInputFileNumber").setValue(oControllerS3.data.basic.FileNumber);
                                           this.getView().byId("idTrackFileLabel").setVisible(
                                                         true);
                                           this.getView().byId("idTrackFileSwitch").setVisible(
                                                         true);
                                           this.getView().byId("idConfidentialFileLabel").setVisible(
                                                   true);
                                           this.getView().byId("idConfidentialFileSwitch").setVisible(
                                                   true);
                                           this.getView().byId("emptyNotingPanel").setVisible(false);
                                           this.getView().byId("notingPanel").setVisible(true);
                                           this.getView().byId("descrEditor").setHeight("24rem");
                                           this.getView().byId("idTrackFileSwitch").setState(oControllerS3.data.basic.Track);
                                           this.getView().byId("idTrackFileSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS3.data.basic.Track));
                                           this.getView().byId("idConfidentialFileSwitch").setState(oControllerS3.data.basic.Conf);
                                           this.getView().byId("idConfidentialFileSwitch").setTooltip(flm.fiori.utils.formatter.tooltipText(oControllerS3.data.basic.Conf));
                                           this.getView().byId("idFileType").setValue(oControllerS3.data.basic.ShortText.toUpperCase());
                                           this.getView().byId("idCreatedOn").setValue(oControllerS3.data.basic.CreateTime);
                                           this.getView().byId("idCreatedBy").setValue(oControllerS3.data.basic.CreatedByID);
                                           var date=new Date();
                                           date.setFullYear(oControllerS3.data.basic.PlanEndDate.substr(6,4));
                                           date.setMonth(oControllerS3.data.basic.PlanEndDate.substr(3,2)-1);
                                           date.setDate(oControllerS3.data.basic.PlanEndDate.substr(0,2));
                                           this.getView().byId("idDuedate").setDateValue(date);
                                           this.getView().byId("idPrioSelect").setSelectedKey(oControllerS3.data.basic.Priority);
                                           
                                           /*try{
                                           this.getView().byId("idShortText").setValue(decodeURIComponent(oControllerS3.data.basic.CaseTitle));
                                           }catch(err){
                                            this.getView().byId("idShortText").setValue(oControllerS3.data.basic.CaseTitle);
                                           }*/
                                           this.getView().byId("idShortText").setValue(oControllerS3.data.basic.CaseTitle);
                                           try{
                                           this.getView().byId("descrEditor").setValue(decodeURIComponent(oControllerS3.data.basic.Description));
                                           }catch(err){
                                            this.getView().byId("descrEditor").setValue(oControllerS3.data.basic.Description); 
                                           }
                                           oControllerS3.getView().byId("idAddNewWorkflowButton").setEnabled(true);
                                           oControllerS3.getView().byId("idButtonSend").setEnabled(true);
                                           oControllerS3.getView().byId("idButtonClose").setEnabled(true);
                                           oControllerS3.byId("wftree").setSelectedIndex(-1);
                                         }
                                         
                                         
                                         // if(oSequenceSend!=undefined){
                                         /* clearing off values for Creating new template */
                                         
//                                       if(!this.oSequenceSend){
//                                              this.oSequenceSend = sap.ui.xmlfragment(
//                                                     "flm.fiori.view.sendTo", oControllerS3);
//                                       }
                                         // oCreateWorkflow = sap.ui.xmlfragment(
                                         // "flm.fiori.view.createWorkflow", oControllerS3);
                                         // Setting model for Available
                                         // this.oActionsModel = new
                                         // sap.ui.model.json.JSONModel();
                                         // this.oActionsModel
                                         // .loadData(
                                         // serviceUrl
                                         // +
                                         // "/FILE_BUTTONS_ES(GUID='',TABTYPE='CREATE',FILEID='',FILETYPE='"
                                         // + sap.ui.getCore().getModel()
                                         // .getData()[0] + "')",
                                         // null, false);
                                         // this.getView().setModel(this.oActionsModel);
                                         //
                                         // /*Attachment starts here*/
                                       // var oPanelModel = new sap.ui.model.json.JSONModel();
                                         // oPanelModel.loadData(serviceUrl
                                         // + "/FILE_DOC_FI?param_1='FS'&param_2='"
                                         // + sap.ui.getCore().getModel().getData()[0]
                                         // + "'&param_3=''&param_4=''&param_5=''", null,
                                         // false);
                                         // // var mainList=new sap.m.List({
                                         // // }).setModel(oPanelModel);
                                         // this.getView().byId("idListPanel")
                                         // .setModel(oPanelModel);
                                         //                                  

                                         // //NEW TEST FOR BINDING BEGINS
                                         /*
                                         * oListModel = new sap.ui.model.json.JSONModel();
                                         * oListModel.setDefaultBindingMode("TwoWay");
                                         * oListModel.loadData(serviceUrl +
                                         * "/FILE_DOCUM_ES?$filter=Guid eq '"+this.caseguid+"'
                                         * and TabType eq 'INTRAY' and Wiid eq '"+this.wiId+"'
                                         * and FileID eq '"+this.fileid+"'", null, false); ////
                                         * this.getView().byId("idListPanel").setModel(oListModel,"file");
                                         *///                               
                                         //                                  
                                         this
                                         .getView()
                                         .byId("idListPanel")
                                                .bindAggregation(
                                                             "items",
                                                             "global>/folders",
                                                             function(a, b) {
                                                                    
                                                                    var list = new sap.m.List()
                                                                                  .setModel(
                                                                                                oControllerS3
                                                                                                              .getView()
                                                                                                              .getModel(
                                                                                                                           "global"),
                                                                                                "global");
                                                                    var listItem = new sap.m.CustomListItem(
                                                                                  {});

                                                                    // LIST ATTRIBUTES STARTS
                                                                    var oIcon = new sap.ui.core.Icon(
                                                                                  {
                                                                                         src : "sap-icon://create",
                                                                                         size : "1rem"
                                                                                  });
                                                                    var fbox = new sap.m.FlexBox({
                                                                           width : "100%"
                                                                    });
                                                                    var fbox1 = new sap.m.FlexBox({
                                                                           alignItems : "Start",
                                                                           justifyContent : "Start",
                                                                           width : "5%"
                                                                    });
                                                                    var fbox2 = new sap.m.FlexBox({
                                                                           alignItems : "Start",
                                                                           justifyContent : "Start",
                                                                           width : "80%"
                                                                    });
                                                                    var fbox3 = new sap.m.FlexBox({
                                                                           alignItems : "Start",
                                                                           justifyContent : "End",
                                                                           width : "15%"
                                                                    });
                                                                    var vbox = new sap.m.VBox({});
                                                                    vbox
                                                                                  .addItem(new sap.m.Link(
                                                                                                {
                                                                                                       text : "{global>DocumentName}",
                                                                                                       press : oControllerS3.onLinkPress
                                                                                                }).addStyleClass("docLink"));
                                                                    vbox
                                                                                  .addItem(new sap.m.Text(
                                                                                                {
                                                                                                       "text" : {
                                                                                                              "parts" : [
                                                                                                                           'global>CreatedByName',
                                                                                                                           'global>CreatedOn' ],

                                                                                                              "formatter" : flm.fiori.utils.formatter.documentRow1
                                                                                                       }
                                                                                                // str1
                                                                                                }).addStyleClass("docDetails"));
                                                                    vbox
                                                                                  .addItem(new sap.m.Text(
                                                                                                {
                                                                                                       text : {
                                                                                                              "parts" : [
                                                                                                                           'global>IsAttachment',
                                                                                                                           'global>IsFile',
                                                                                                                           'global>IsDaak',
                                                                                                                           'global>IsObject',
                                                                                                                           'global>IsReport',
                                                                                                                           'global>FileSizeDescr',
                                                                                                                           'global>FileTitle',
                                                                                                                           'global>FileName' ],

                                                                                                              "formatter" : flm.fiori.utils.formatter.documentRow2
                                                                                                       }
                                                                                                // str2
                                                                                                }).addStyleClass("docDetails"));
                                                                    fbox1.addItem(oIcon);
                                                                    fbox2.addItem(vbox);
                                                                    var hbox = new sap.m.HBox({});
                                                                    hbox
                                                                                  .addItem(new sap.m.Link(
                                                                                                {
                                                                                                       visible : "{global>NotingEnabledRef}",
                                                                                                       text : oControllerS3.getView().getModel("i18n").getObject("ADD_TO_NOTING"),
                                                                                                       press : oControllerS3.addHyperlinkClick,
                                                                                                       target : "_self"
                                                                                                }).addStyleClass("docLink"));
                                                                    hbox
                                                                    .addItem(new sap.ui.core.HTML(
                                                                                  {
                                                                                         visible : "{global>NotingEnabledRef}",
                                                                                         content : "<span>&nbsp&nbsp&nbsp&nbsp;</span>"
                                                                                  }).addStyleClass("docLink"));
                                                                    hbox
                                                                    .addItem(new sap.m.Link(
                                                                                  {
                                                                                         visible : "{global>NotingEnabledRef}",
                                                                                         text : oControllerS3.getView().getModel("i18n").getObject("ADD_TO_DESCRIPTION"),
                                                                                         press : oControllerS3.addHyperlinkClick,
                                                                                         target : "_top"
                                                                                  }).addStyleClass("docLink"));
                                                                    hbox
                                                                                  .addItem(new sap.ui.core.HTML(
                                                                                                {
                                                                                                       visible : "{global>NotingEnabledRef}",
                                                                                                       content : "<span>&nbsp&nbsp&nbsp&nbsp;</span>"
                                                                                                }).addStyleClass("docLink"));
                                                                    hbox
                                                                                  .addItem(new sap.m.Link(
                                                                                                {
                                                                                                       visible : "{global>IsAttachment}",
                                                                                                       text : oControllerS3.getView().getModel("i18n").getObject("ATTACH_NEW_VERSION"),
                                                                                                       press : oControllerS3.attachNewVersion
                                                                                                }).addStyleClass("docLink"));
                                                                    vbox.addItem(hbox);
                                                                    fbox3
                                                                                  .addItem(new sap.ui.core.Icon(
                                                                                                {
                                                                                                       visible : "{global>DeleteEnabledRef}",
                                                                                                       src : "sap-icon://delete",
                                                                                                       size : "1rem",
                                                                                                       tooltip : "Delete attachment",
                                                                                                       //press : oControllerS3.deleteAttachment,
                                                                                                       press : oControllerS3.confirmDelete,
                                                                                                })
                                                                                                .addStyleClass("panelButton"));
                                                                    fbox.addItem(fbox1);
                                                                    fbox.addItem(fbox2);
                                                                    fbox.addItem(fbox3);
                                                                    listItem.addContent(fbox);
                                                                    // LIST ATTRIBUTES ENDS

                                                                    list.bindAggregation("items",
                                                                                  "global>/attachments",
                                                                                  listItem);

                                                                    list
                                                                                  .getBinding("items")
                                                                                  .filter(
                                                                                                new sap.ui.model.Filter(
                                                                                                              "ParentKey",
                                                                                                              sap.ui.model.FilterOperator.EQ,
                                                                                                              b
                                                                                                                           .getObject()["RowKey"]));
                                                                    var panel = new sap.ui.commons.Panel(
                                                                                                              {
                                                                                                                     showCollapseIcon : true,
                                                                                                                     width : "90%",
                                                                                                                     collapsed : true
                                                                                                              });
                                                                                                var oButton = new sap.ui.core.Icon(
                                                                                                              {
                                                                                                                     src : "sap-icon://attachment",
                                                                                                                     size : "1rem",
                                                                                                                     tooltip : oControllerS3.getView().getModel("i18n").getObject("ADD_NEW_DOCUMENT"),
                                                                                                                     press : oControllerS3.uploadActionsOpen,
                                                                                                                     visible: flm.fiori.utils.formatter.enabledStatus(oControllerS3.fromTab)
                                                                                                              });
                                                                                                oButton
                                                                                                              .addStyleClass("panelAddButton");
                                                                                                panel.addContent(oButton);
                                                                                                panel.addContent(list);
                                                                                                return new sap.m.CustomListItem()
                                                                                                              .addContent(panel
                                                                                                                            .setText(b
                                                                                                                                         .getObject()["DocumentName"]
                                                                                                                                         + " ("
                                                                                                                                         + list
                                                                                                                                                       .getItems().length
                                                                                                                                         + ")"));
                                                                                         });

                                         // load workflow here
                                         oControllerS3.loadTreeTable();

                                         // List Model for documents
                                         oListModel = [];
//                                         var oModel = new sap.ui.model.json.JSONModel();
//                                                                   oModel.loadData(serviceUrl
//                                                   + "/FILE_NOTING_ES?$filter=TabType eq '" + this.fromTab
//                                                                                + "' and CaseGuid eq '' and Wiid eq ''", null, false);
//                                                                   var response = oModel.oData.d.results;
//                                                                   oModel.setData(response);
//                                                                   this.getView().byId("notingList").setModel(oModel);
                                  },
                                  
                                  changeLevels : function(result,currLabel,prevLabel,t){ //recursive function to change levels for adding special node
                                  
                                   var l=1;
                                   for(var i=t+1;i<result.length;i++){
                                    if(result[i].Label.slice(0,-2) == prevLabel && result[i].Label.length==prevLabel.length+2){
                                     var tempLabel=result[i].Label;
                                     result[i].Label = currLabel+"_"+(l++);
                                        oControllerS3.changeLevels(result,result[i].Label,tempLabel,i); 
                                    }
                                    /*else if(result[i].Label.slice(0,-1) == currLabel.slice(0,-1)){
                                          prevLabel = result[i].Label;
                                     result[i].Label = currLabel+"_"+(l++);
                                        oControllerS3.changeLevels(result,result[i].Label,prevLabel,i); 
                                    }*/
                                   }
                                  },

                                  loadTreeTable : function(oEvent) {
                                  
                                      var oModel = new sap.ui.model.json.JSONModel();
                                      if(oControllerS3.fromTab=="CREATE"){
                                      oModel.loadData(serviceUrl
                                                    + "/FILE_PROUTE_ES?$filter=CaseType eq '"
                                                    + sap.ui.getCore().getModel("pass").getData()[0]
                                                    + "'", null, false);
                                      }else{
                                       oModel
                                                                  .loadData(
                                                                               serviceUrl
                                                                                             + "/FILE_PROUTE_ES?$filter=CaseGuid eq '"
                                                                                             + this.caseguid + "'",
                                                                               null, false);
                                      }
                                      // create hierarchy from the flat dataset returned by
                                      // server
                                      var result = oModel.oData.d.results;
                                    //Replace '_' with '0' for sorting purpose
                                      for(var i=0;i<result.length;i++){
                                       result[i].sortIndex=result[i].Label.split('_').join('0');
                                      }
                                    //To sort the workflow for adding special nodes
                                      result.sort(function(a, b){ 
                                       return a.sortIndex-b.sortIndex;
                                      });
                                      var obj = {
                                             "nodes" : [],
                                             "Label" : "Sequence"
                                      };
                                      var oTreeTable = this.getView().byId("wftree");
                                      for ( var i = 0; i < result.length; ++i) {
                                             result[i].__metadata = null;
                                             if(result[i].Nodetype=="PB"){
                                              result[i].Nodetype="PB*";
                                              var spclNode = {
                                                   "nodes" : [],
                                                   "Fullname" : "Parallel Steps",
                                                   "Label" : result[i].Label,
                                                   "Posid" : result[i].Posid,
                                                   "Parentid" : result[i].Parentid,
                                                   "Nodetype" : "P",
                                                   "isParallel" : "X",
                                                   "isSpecial" : "X"
                                                 };

                                              result.splice(i,0,spclNode);
                                              var t=i+1,l=0,prevLabel;
                                              //Till the whole parallel block is found
                                              while(result[t].Nodetype!="PE"){ 
                                               //All children sequence nodes will be handled by the changeLevel function
                                               if(result[t].Nodetype!="S"){ 
                                               prevLabel = result[t].Label;
                                               result[t].Label = result[i].Label+"_"+(++l);
                                               oControllerS3.changeLevels(result,result[t].Label,prevLabel,t);
                                               }
                                               t++;
                                              }
                                              prevLabel = result[t].Label;
                                              result[t].Label = result[i].Label+"_"+(++l);
                                              oControllerS3.changeLevels(result,result[t].Label,prevLabel,t);
                                             }
                                             var levels = result[i].Label.split("_");

                                             for ( var k = 0; k < levels.length; ++k) {
                                                    levels[k] = parseInt(levels[k]) - 1;
                                             }

                                             var tempObj = obj;

                                             for ( var j = 0; j < levels.length - 2; ++j) {
                                                    tempObj = tempObj.nodes[levels[j]];
                                             }

                                             if (tempObj.nodes[levels[j]] == undefined) {
                                                    result[i].nodes = [];
                                                    tempObj.nodes[levels[j]] = result[i];
                                                    continue;
                                             }

                                             result[i].nodes = [];
                                             tempObj.nodes[levels[j]].nodes.push(result[i]);
                                      }
                                      
                                      var selectedNodeData=oTreeTable.getContextByIndex(oTreeTable.getSelectedIndex());
                                      oModel.setData(obj);

                                      oTreeTable.setModel(oModel,"workflow"); // set model to Table*/
                                      
                                      oTreeTable.bindRows("workflow>/");
                                      if(selectedNodeData){
                                      var sndPath = selectedNodeData.getPath().split('/');
                                      var expandIndex=parseInt(sndPath[2]);
                                      for(var i=4;i<sndPath.length;i+=2){
                                       oTreeTable.expand(expandIndex);
                                       expandIndex+=parseInt(sndPath[i])+1;
                                      }
                                      }
//                                      oTreeTable.setSelectedIndex(-1);
                               },
                                  // Create FileNumber Format
                                  createFileNo : function() {
                                         
                                         var case_type = sap.ui.getCore().getModel("pass").getData()[0];
                                         /*if (sap.ui.getCore().getModel("pass") == undefined) {
                                                case_type = "FI56";
                                         } else {
                                                case_type = sap.ui.getCore().getModel("pass").getData()[0];
                                         }*/
                                         // var oFilenumberingModel = new
                                         // sap.ui.model.json.JSONModel();
                                         // oFilenumberingModel
                                         // .loadData(
                                         // "proxy/https/ldcixka.wdf.sap.corp:44318/sap/opu/odata/PSINDS/FILES_SRV_SRV/FILE_NUMBER_ES?$filter=FILETYPE%20eq%20'"
                                         // + case_type + "'", null, false);
                                         
                                         // setting the name of Creator
                                         this.getView().byId("idCreatedBy").setValue(
                                                       this.createFileResponse[0].UNAME);
                                         oControllerS3.createSignFlag = this.createFileResponse[0].DigSignReq;
                                         var vbox = new sap.m.VBox({});
                                         var hbox = this.getView().byId("idFileNumberHbox");
                                         if (hbox.getItems()[0] != undefined) {
                                                hbox.removeAllItems();
                                         }
                                         var l ;
                                         if(this.createFileResponse.length < 10){
                                         l = 90 / this.createFileResponse.length;
                                         }else{
                                         l = 180 / this.createFileResponse.length;
                                         } 
                                         for ( var i = 0; i < this.createFileResponse.length; i++) {
                                                var elemID = "FID00" + i;

                                                if (this.createFileResponse[i].NAME == "SEPR") {
                                                       hbox.addItem(new sap.m.VBox({
                                                              width : "1.5rem"
                                                       }));
                                                       hbox.getItems()[i].addItem(new sap.m.Text({
                                                              text : this.createFileResponse[i].HEADER
                                                       }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.ui.core.HTML({
                                                                           content : "<span>&nbsp;</span>"
                                                                     }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.m.Text(
                                                                                  elemID,
                                                                                  {
                                                                                         text : this.createFileResponse[i].VALUE,
                                                                                         textAlign : "Center",
                                                                                         vAlign : "Center",
                                                                                         hAlign : "Center"
                                                                                  }));
                                                       hbox.getItems()[i].getItems()[2]
                                                                     .addStyleClass("separator");
                                                       hbox.getItems()[i]
                                                                    .addItem(new sap.ui.core.HTML({
                                                                           content : "<span>&nbsp;</span>"
                                                                     }));
                                                       // hbox.addItem(new sap.m.Text({text:
                                                       // this.createFileResponse[i].HEAD}));
                                                }

                                                else if (this.createFileResponse[i].NAME == "GRPN"
                                                              || this.createFileResponse[i].NAME == "CNRN"
                                                              || this.createFileResponse[i].NAME == "GRPY"
                                                              || this.createFileResponse[i].NAME == "CNRY") {
                                                       hbox.addItem(new sap.m.VBox({
                                                              width : l + "%"
                                                       }));
                                                       hbox.getItems()[i].addItem(new sap.m.Text({
                                                              text : this.createFileResponse[i].HEADER,
                                                              tooltip : this.createFileResponse[i].HEADER,
                                                              wrapping:false
                                                       }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.ui.core.HTML({
                                                                           content : "<HR/>"
                                                                     }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.m.Input(
                                                                                  elemID,
                                                                                  {
                                                                                         type : "Text",
                                                                                         value : this.createFileResponse[i].VALUE,
                                                                                         name : this.createFileResponse[i].NAME,
                                                                                         editable : false
                                                                                  }));
                                                }

                                                else if (this.createFileResponse[i].NAME == "FTXT") {

                                                       if (this.createFileResponse[i].F4VALUES != "") {
                                                              hbox.addItem(new sap.m.VBox({
                                                                     width : l + "%"
                                                              }));
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.m.Text(
                                                                                         {
                                                                                                text : this.createFileResponse[i].HEADER,
                                                                                                tooltip : this.createFileResponse[i].HEADER
                                                                                         }));
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.ui.core.HTML({
                                                                                  content : "<HR/>"
                                                                           }));
                                                              // var arr =
                // this
                                                              // .getF4Array(this.createFileResponse[i].F4VALUES);
                                                              // var f4model =
                // new
                                                              // sap.ui.model.json.JSONModel();
                                                              // f4model.setData(arr);
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.m.Input(
                                                                                         elemID,
                                                                                         {
                                                                                                type : "Text",
                                                                                                placeholder : oControllerS3.getView().getModel("i18n").getObject("SELECT"),
                                                                                                valueHelpRequest : "handleValueHelpFileNo",
                                                                                                showValueHelp : true
                                                                                         }));

                                                       } else if (this.createFileResponse[i].DDVALUES != "") {
                                                              hbox.addItem(new sap.m.VBox({
                                                                     width : l + "%"
                                                              }));
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.m.Text(
                                                                                         {
                                                                                                text : this.createFileResponse[i].HEADER,
                                                                                                tooltip : this.createFileResponse[i].HEADER,
                                                                                                wrapping:false
                                                                                         }));
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.ui.core.HTML({
                                                                                  content : "<HR/>"
                                                                           }));
                                                              var arr = this
                                                                            .getF4Array(this.createFileResponse[i].DDVALUES);
                                                              var ddmodel = new sap.ui.model.json.JSONModel();
                                                              ddmodel.setData(arr);
                                                              var ddsel = new sap.m.Select(elemID, {
                                                                     autoAdjustWidth : true,
                                                                     value : "Select",
                                                                     items : {
                                                                           path : "/",
                                                                           template : new sap.ui.core.Item({
                                                                                  key : "{ResulltCol1}",
                                                                                  text : "{ResulltCol1}"
                                                                           })
                                                                     }
                                                              });
                                                              ddsel.setModel(ddmodel);
                                                              hbox.getItems()[i].addItem(ddsel);
                                                       } else {
                                                              hbox.addItem(new sap.m.VBox({
                                                                     width : l + "%"
                                                              }));
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.m.Text(
                                                                                         {
                                                                                                text : this.createFileResponse[i].HEADER,
                                                                                                tooltip : this.createFileResponse[i].HEADER,
                                                                                                wrapping:false
                                                                                         }));
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.ui.core.HTML({
                                                                                  content : "<HR/>"
                                                                           }));
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.m.Input(
                                                                                         elemID,
                                                                                         {
                                                                                                type : "Text",
                                                                                                value : this.createFileResponse[i].VALUE
                                                                                         }));
                                                       }

                                                } else if (this.createFileResponse[i].NAME == "DATE") {
                                                 oControllerS3.numberDateObjFile = "DATE";
                                                       hbox.addItem(new sap.m.VBox({
                                                              width : l + "%"
                                                       }));
                                                       hbox.getItems()[i].addItem(new sap.m.Text({
                                                              text : this.createFileResponse[i].HEADER,
                                                              tooltip : this.createFileResponse[i].HEADER,
                                                              wrapping:false
                                                       }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.ui.core.HTML({
                                                                           content : "<HR/>"
                                                                     }));
                                                       if (this.createFileResponse[i].F4VALUES != "") {
                                                              // var arr =
                // this
                                                              // .getF4Array(this.createFileResponse[i].F4VALUES);
                                                              // var f4model =
                // new
                                                             // sap.ui.model.json.JSONModel();
                                                              // f4model.setData(arr);
                                                              // globalModel =
                // f4model;
                                                              var dummy = new sap.m.Input(
                                                                           elemID,
                                                                           {
                                                                                  type : "Text",
                                                                                  placeholder : oControllerS3.getView().getModel("i18n").getObject("SELECT"),
                                                                                  valueHelpRequest : this.handleValueHelpFileNo,
                                                                                  showValueHelp : true
                                                                           });
                                                              hbox.getItems()[i].addItem(dummy);
                                                       } else {
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.m.Input(
                                                                                         {
                                                                                                type : "Text",
                                                                                                value : this.createFileResponse[i].VALUE
                                                                                         }));
                                                       }
                                                }

                                                else if (this.createFileResponse[i].NAME == "SYSD") {
                                                       hbox.addItem(new sap.m.VBox({
                                                              width : l + "%"
                                                       }));
                                                       hbox.getItems()[i].addItem(new sap.m.Text({
                                                              text : this.createFileResponse[i].HEADER,
                                                              tooltip : this.createFileResponse[i].HEADER,
                                                              wrapping:false
                                                       }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.ui.core.HTML({
                                                                           content : "<HR/>"
                                                                     }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.m.Input(
                                                                                  elemID,
                                                                                  {
                                                                                         type : "Text",
                                                                                         value : this.createFileResponse[i].VALUE,
                                                                                         editable : false
                                                                                  }));

                                                } else if (this.createFileResponse[i].NAME == "CNST") {
                                                       hbox.addItem(new sap.m.VBox({
                                                              width : l + "%"
                                                       }));
                                                       hbox.getItems()[i].addItem(new sap.m.Text({
                                                              text : this.createFileResponse[i].HEADER,
                                                              tooltip : this.createFileResponse[i].HEADER,
                                                              wrapping:false
                                                       }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.ui.core.HTML({
                                                                           content : "<HR/>"
                                                                     }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.m.Input(
                                                                                  elemID,
                                                                                  {
                                                                                         type : "Text",
                                                                                         value : this.createFileResponse[i].VALUE,
                                                                                         editable : false
                                                                                  }));

                                                } else if (this.createFileResponse[i].NAME == "ORGU") {

                                                       hbox.addItem(new sap.m.VBox({
                                                              width : l + "%"
                                                       }));
                                                       hbox.getItems()[i].addItem(new sap.m.Text({
                                                              text : this.createFileResponse[i].HEADER,
                                                              tooltip : this.createFileResponse[i].HEADER,
                                                              wrapping:false
                                                       }));
                                                       hbox.getItems()[i]
                                                                     .addItem(new sap.ui.core.HTML({
                                                                           content : "<HR/>"
                                                                     }));
                                                       if (this.createFileResponse[i].F4VALUES != "") {
                                                              // var arr = this
                                                              // .getF4Array(this.createFileResponse[i].F4VALUES);
                                                              // var f4model = new
                                                              // sap.ui.model.json.JSONModel();
                                                              // f4model.setData(arr);
                                                              // globalModel = f4model;
                                                              var dummy = new sap.m.Input(
                                                                           elemID,
                                                                           {
                                                                                  type : "Text",
                                                                                  placeholder : oControllerS3.getView().getModel("i18n").getObject("SELECT"),
                                                                                  valueHelpRequest : this.handleValueHelpFileNo,
                                                                                  showValueHelp : true
                                                                           });
                                                              hbox.getItems()[i].addItem(dummy);
                                                       } else {
                                                              hbox.getItems()[i]
                                                                           .addItem(new sap.m.Input(
                                                                                         {
                                                                                                type : "Text",
                                                                                                value : this.createFileResponse[i].VALUE
                                                                                         }));
                                                       }
                                                }
                                         }
                                  },

                                  getF4Array : function(f4string) {
                                         var sep1 = "!!";
                                         var sep2 = ",";
                                         var f4arr = f4string.split(sep1);
                                         var f4Array = new Array();
                                         for ( var i = 0; i < f4arr.length; i++) {
                                                tempArr = null;
                                                tempArr = f4arr[i].split(sep2);
                                                f4Array[i] = {};
                                                // for(var i=0;i<tempArr.length;i++){
                                                // if(tempArr[i]!=undefined){
                                                // f4Array[i].ResulltCol = tempArr[i];
                                                // }
                                                if (tempArr[0] != undefined)
                                                       f4Array[i].ResulltCol1 = tempArr[0];
                                                if (tempArr[1] != undefined)
                                                       f4Array[i].ResultCol2 = tempArr[1];
                                                if (tempArr[2] != undefined)
                                                       f4Array[i].ResulltCol3 = tempArr[2];
                                                // }
                                         }
                                         return f4Array;
                                  },

                                  handleValueHelpFileNo : function(oEvent) {
                                    
                                         // Compare event id and set the corresponding F4 values'
                                         // model
                                         var i = 0;
                                         var h = oControllerS3.getView()
                                                       .byId("idFileNumberHbox").getItems();
                                         for (i = 0; i < h.length; i++) {
                                                var v = h[i].getItems()[2];
                                                if (v.getId() == oEvent.getSource().getId()) {
                                                       break;
                                                }
                                         }
                                        var arr;
                                if(oControllerS3.numberDateObjFile == "DATE"){
                                arr = getDateArray(oControllerS3.createFileResponse[i].F4VALUES);
                                }else{
                                         arr = getF4Array(oControllerS3.createFileResponse[i].F4VALUES);
                                }
                                         var f4model = new sap.ui.model.json.JSONModel();
                                         f4model.setData(arr);
                                         globalModel = f4model;
                                         
                                         inputId = oEvent.getSource();
                                          if (oControllerS3._valueHelpDialog==undefined) {
                                          oControllerS3._valueHelpDialog = sap.ui.xmlfragment(
                                                       "flm.fiori.view.F4helpDialog2", oControllerS3);
                                          }
//                                          else
                                         // if(this._valueHelpDialog.getModel()!=undefined){
                                         // this._valueHelpDialog.getModel().destroy();
                                         // }
                                         var oTable = sap.ui.getCore().byId("idF4ValueTable");
                                         oTable.setModel(globalModel);
                                         if (globalModel.oData[0].ResulltCol1 != undefined) {

                                                var c = sap.ui.getCore().byId("idF4ValueTable")
                                                              .getColumns();
                                                sap.ui.getCore().byId("f4collabl1").setText(
                                                              globalModel.oData[0].ResulltCol1);
                                         }
                                         if (globalModel.oData[0].ResultCol2 != undefined) {
                                                sap.ui.getCore().byId("f4collabl2").setText(
                                                              globalModel.oData[0].ResultCol2);
                                         }
                                         if (globalModel.oData[0].ResulltCol3 != undefined) {
                                                sap.ui.getCore().byId("f4collabl3").setText(
                                                              globalModel.oData[0].ResulltCol3);
                                         }
                                         oTable.getItems()[0].setVisible(false);
                                         oControllerS3._valueHelpDialog.open();
                                  },

                                  handleValueHelpPrivateTo : function(oEvent) {
                                         
                                         if (!oControllerS3._oDynamicF4Dialog) {
                                                oControllerS3._oDynamicF4Dialog = sap.ui
                                                              .xmlfragment(
                                                                            "flm.fiori.view.dynamicF4popup",
                                                                           oControllerS3);

                                         }
                                         oF4Texts = new sap.ui.model.json.JSONModel();
                                         if (oEvent.getSource().getId() == "idUsername") {
                                                var f4text = {

                                                       title : sap.ui.getCore().byId("idSelect1")
                                                                     .getSelectedItem().getText(),

                                                       id : "idUsername",

                                                       path : "/d/results"
                                                };
                                         } else {
                                                var f4text = {

                                                       title : this.getView().byId(
                                                                     "receiverTypeNoting").getSelectedItem()
                                                                     .getText(),

                                                       id : "processorInput",

                                                       path : "/d/results"

                                                };
                                         }

                                         oF4Texts.setData(f4text);

                                         oControllerS3._oDynamicF4Dialog.setModel(

                                         oF4Texts, "dyntext");

                                         // open value help dialog
                                         oControllerS3._oDynamicF4Dialog.open();
                                  },
                                  
                                  _handleF4HelpSearch1 : function(evt) {

                    var sValue = evt.getParameter("value");
                    var oFilter = new sap.ui.model.Filter("ResulltCol1",
                      sap.ui.model.FilterOperator.Contains, sValue);
                    var oFilter1 = new sap.ui.model.Filter("ResultCol2",
                      sap.ui.model.FilterOperator.Contains, sValue);
                    var oFilter2 = new sap.ui.model.Filter("ResultCol3",
                    sap.ui.model.FilterOperator.Contains, sValue);
                  evt.getSource().getBinding("items").filter(
                    new sap.ui.model.Filter([ oFilter,oFilter1, oFilter2 ],
                        "OR"));
                   },

                    _handleF4HelpClose1 : function(evt) {
                                     
                                     var oSelectedItem = evt.getParameter("selectedItem");
                                     var id = evt.getSource().getModel("dyntext").getData().id;
                                     var oInput;
                                     if (oSelectedItem) {// when called from FRAGMENT
                                            if (sap.ui.getCore().byId(id) != undefined) {
                                                   oInput = sap.ui.getCore().byId(
                                                                 evt.getSource().getModel("dyntext")
                                                                              .getData().id);

                                            } else {// when called from VIEW
                                                   oInput = this.getView().byId(
                                                                 evt.getSource().getModel("dyntext")
                                                                              .getData().id);
                                            }
                                            ;
                                            // get the id and
                                            // place it here
                                            if (id == "idUsername" || id=="processorInput" || id=="userValueInput") {
                                             if(oSelectedItem.getBindingContext().getObject().ResultCol3.substr(0,2) == "US"){
                                                   oInput.setValue(oSelectedItem.getBindingContext().getObject().ResultCol2
                                                                + " " + oSelectedItem.getBindingContext().getObject().ResulltCol1);
                                              
                                            }else{
                                             oInput.setValue(oSelectedItem.getBindingContext().getObject().ResulltCol1);
                                            }
                                            oInput.setName(oSelectedItem
                                                         .getBindingContext()
                                                         .getObject().ResultCol3);  
                                            } else if (id == "idOrgUnit") {

                                                   oInput.setValue(oSelectedItem.getBindingContext().getObject().ResultCol2);
                                                   var oTable = sap.ui.getCore().byId("leftTree");
                                                   var oModel = new sap.ui.model.json.JSONModel();
                                                   oModel.attachRequestCompleted(oControllerS3,function(oEvent){
                                                    if(oEvent.mParameters.errorobject){
                                                  oModel.detachRequestCompleted();
                                                        sap.m.MessageBox.alert(getErrorJson(oEvent.mParameters.errorobject.responseText));
                     return;
                                                 }
                                                   },oControllerS3);
                                                   oModel.loadData(serviceUrl
                                                                 + "/ORGU_MEM_ETSet?$filter=OobjId eq '"
                                                                 + oSelectedItem.getBindingContext()
                                                                              .getObject().ResultCol3 + "' and LevelDesc eq '1'",
                                                                 null, false);
                                                   var result = [{
                                                                 "Stext" : oSelectedItem.getBindingContext().getObject().ResultCol2 ,
                                                                 "Text" : oSelectedItem.getBindingContext().getObject().ResulltCol1,
                                                                 "Objid" : oSelectedItem.getBindingContext().getObject().ResultCol3.substr(2),
                                                                 "Otype" : oSelectedItem.getBindingContext().getObject().ResultCol3.substr(0,2),
                                                                 "ImageSrc" : "sap-icon://org-chart",
                                                                 "LevelDesc" : "1",
                                                                 nodes: [],
                                                          }];
                                                   
                                                   result=result.concat(oModel.oData.d.results);
                                                   oControllerS3.leftTreeNodes=result;
                                 ///////////////////
                                                   var obj = {
                                                           "nodes" : [],
                                                           "Label" : "Sequence"
                                                    };
                                                    for ( var i = 0; i < result.length; ++i) {
                                                           result[i].__metadata = null;
                                                           var levels = result[i].LevelDesc.split("_");

                                                           for ( var k = 0; k < levels.length; ++k) {
                                                                  levels[k] = parseInt(levels[k]) - 1;
                                                           }

                                                           var tempObj = obj;

                                                           for ( var j = 0; j < levels.length - 2; ++j) {
                                                                  tempObj = tempObj.nodes[levels[j]];
                                                           }

                                                           if (tempObj.nodes[levels[j]] == undefined) {
                                                                  result[i].nodes = [];
                                                                  tempObj.nodes[levels[j]] = result[i];
                                                                  continue;
                                                           }

                                                           result[i].nodes = [];
                                                           tempObj.nodes[levels[j]].nodes.push(result[i]);
                                                    }

                                                    oModel.setData(obj);
                                                   //////////////////

//                                                   oModel.setData(result);

                                                   oTable.setModel(oModel); // set model to
                                                                                                   // Table*/
                                                   
                                                   oTable.bindRows("/");
//                                                   for(var i=0;i<result.length;i++){
//                                                    oTable.expand(i);
//                                                   }
                                                   sap.ui.getCore().byId("idOrgUnitClear").setVisible(true);
                                            }else if (id == "idFactoryCalendar") {
                                              oInput
                                                 .setName(oSelectedItem
                                                               .getBindingContext()
                                                               .getObject().ResultCol3);

                                              oInput
                                                 .setValue(oSelectedItem
                                                               .getBindingContext()
                                                               .getObject().ResulltCol1);
                                                 sap.ui.getCore().byId("idFactoryCalendarClear").setVisible(true);                                            
                                            }
                                            else {
                                                   oInput
                                                                              .setName(oSelectedItem
                                                                                            .getBindingContext()
                                                                                            .getObject().ResultCol3);

                                                                 oInput
                                                                              .setValue(oSelectedItem
                                                                                            .getBindingContext()
                                                                                            .getObject().ResulltCol1);
                                                                 oControllerS3.onChangeFileAttribute();
//                                                   oInput
//                                                                 .setValue(oSelectedItem
//                                                                              .getBindingContext()
//                                                                              .getObject().ResultCol3);
                                            }
                                     }
                                     evt.getSource().getBinding("items").filter([]);
//                                     this._oDynamicF4Dialog.getModel().destroy();
//                                     this._oDynamicF4Dialog.getModel("dyntext").destroy();
                              },

                                  onChangeTypeSelection : function(oEvent) {
//                                   oControllerS3.customBusyDialogOpen(); 
                                                       if (!oControllerS3._oDynamicF4Dialog) {
                                                              oControllerS3._oDynamicF4Dialog = sap.ui
                                                                           .xmlfragment(
                                                                                         "flm.fiori.view.dynamicF4popup",
                                                                                         oControllerS3);

                                                       }
                                                       if (sap.ui.getCore().byId("idUsername") != undefined) {
                                                              sap.ui.getCore().byId("idUsername").setValue("");
                                                       }
//                                                       var otypeModel = new sap.ui.model.json.JSONModel();
//
//                                                       if (oEvent.getSource().getSelectedKey() != 'SPACE') {
//                                                        otypeModel.attachRequestCompleted(oControllerS3,function(oEvent){
//                                                         otypeModel.setData(otypeModel.oData.d.results);
//                                                         oControllerS3._oDynamicF4Dialog.setModel(otypeModel);
//                                                               oControllerS3.customBusyDialogClose();
//                                                               otypeModel.detachRequestCompleted();
//                                                               },oControllerS3);
//                                                        oModel.attachRequestFailed(this, function(
//                                                                   oEvent) {
//                                                            oControllerS3.customBusyDialogClose();
//                                                             otypeModel.detachRequestCompleted();
//                                                            }, oControllerS3);
//                                                              otypeModel.loadData(serviceUrl
//                                                                           + "/FILE_F4_ES?$filter=ID eq '"
//                                                                           + oEvent.getSource().getSelectedKey()
//                                                                           + "' and WF eq true", null, true);
//                                                              
//                                                       }
                                                       var otextModel = new sap.ui.model.json.JSONModel();
                                                       var otext = {
                                                              title : oEvent.getSource().getSelectedItem()
                                                                           .getText(),
                                                              id : "processorInput",
                                                       };
                                                       otextModel.setData(otext);
                                                       oControllerS3._oDynamicF4Dialog.setModel(otextModel,
                                                                     "dyntext");
                                                       oControllerS3.getView().byId("processorInput").setValue("");
                                     
                                                },

                                  F4ValueSelected : function(oEvent) {
                                   if(oControllerS3.numberDateObjFile == "DATE"){
                                         var t = oEvent.getParameters().listItem.getCells()[0].getText().substr(0,4);
                                   }else{
                                    t = oEvent.getParameters().listItem.getCells()[0].getText();
                                   }
                                         inputId.setValue(t);
                                         if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                                         oEvent.getSource().getParent().close();
                                                        } else {
                                                        oEvent.getSource().getParent().getParent().close();
                                                        }
                                  },


//                                setInitialModels : function() {
//                                       
//                                       var m = sap.ui.getCore().getModel("pass").getData();
//                                       var filetype = m[0];
//                                       var dynamicAttrModel = new sap.ui.model.json.JSONModel();
//                                       dynamicAttrModel.loadData(serviceUrl
//                                                     + "/FILE_ATTR_ES?$filter=FILETYPE eq '"
//                                                     + filetype + "' and TABTYPE eq 'CREATE'", null,
//                                                     false);
//                                       mparams = dynamicAttrModel.oData.d.results;
//
//                                       this.getView().setModel(dynamicAttrModel,
//                                                     "dynAttrModel");
//
//                                       this.dynUIAssistArr = createDynamicUI(mparams, this,
//                                                     this.getView(), "dynamicAttrForm",
//                                                     false);
//
//                                },

                                  onF4Search : function(oEvt) {

                                         var aFilters = [];
                                         var sQuery = oEvt.getSource().getValue();
                                         var oTable = sap.ui.getCore().byId("idF4ValueTable");
                                         var oBinding = oTable.getBinding("items");
                                         if (sQuery && sQuery.length > 0) {
                                               oBinding.filter(new sap.ui.model.Filter([
                                                              new sap.ui.model.Filter("ResulltCol1",
                                                                           "Contains", sQuery),
                                                              new sap.ui.model.Filter("ResultCol2",
                                                                           "Contains", sQuery),
                                                              new sap.ui.model.Filter("ResulltCol3",
                                                                           "Contains", sQuery), ], "OR"));
                                        }

                                         var list = sap.ui.getCore().byId("idF4ValueTable");
                                         var k = list.getItems();

                                         var binding = list.getBinding("items");
                                         binding.filter(aFilters, "Application");
                                         this.afterSearchRecovery();
                                  },

                                  afterSearchRecovery : function() {
                                         
                                         var oTable = sap.ui.getCore().byId("idF4ValueTable");
                                         var t = oTable.getItems()[0].getCells();
                                         if (t[0].getText() == sap.ui.getCore().byId(
                                                       "f4collabl1").getText()
                                                       && t[1].getText() == sap.ui.getCore().byId(
                                                                     "f4collabl2").getText()
                                                       && t[2].getText() == sap.ui.getCore().byId(
                                                                     "f4collabl3").getText()) {
                                                oTable.getItems()[0].setVisible(false);
                                         }
                                  },

                                  navBack : function() {
                                   //this.customBusyDialogOpen();
                                         oControllerS3.caseguid = null;
                                         oControllerS3.fileid = null;
                                         oControllerS3.filenumber = null;
                                         oControllerS3.digitalsign = null;
                                         if(sap.ui.getCore().byId("idSendToDialog")){
                                                sap.ui.getCore().byId("idSendToDialog").destroy();
                                         }
                                         destroyDialogs(oControllerS3);
                                         this.getView().byId("createFile").setBusy(false);
                                         oControllerS3.customBusyDialogOpen();
                                         // sap.ui.getCore().byId("idcreateWorkflowDialog").destroy();
                                         //this.customBusyDialogClose();
                                         var tempModel = new sap.ui.model.json.JSONModel();
                                         tempModel.attachRequestCompleted(oControllerS3,function(oEvent){
                                          tempModel.detachRequestCompleted();
                                          if(oEvent.mParameters.errorobject){ 
                                              sap.m.MessageBox.alert(getErrorJson(oEvent.mParameters.errorobject.responseText));
             return;
                                       }
                                          this.oRouter.getView("flm.fiori.view.S1").byId("idDraftsTable").getModel("files").setData(tempModel.oData.d);
                         tempModel.checkUpdate();
                                          oControllerS3.customBusyDialogClose();
                                         },oControllerS3);

                    tempModel.loadData(serviceUrl + "/FILE_DRAFT_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'",
                      null, true);
                                         
                                         this.oRouter.navTo("fullscreen");
                                         

                                  },

                                  handleF4Help : function(oEvent) {
                                         
                                         for ( var i = 0; i < mparams.length; i++) {
                                                if (mparams[i].ID == oEvent.getSource().getId()) {

                                                       if (!oControllerS3._oDynamicF4Dialog) {
                                                              oControllerS3._oDynamicF4Dialog = sap.ui
                                                                           .xmlfragment(
                                                                                         "flm.fiori.view.dynamicF4popup",
                                                                                         oControllerS3);

                                                       }

                                                       var oF4Model = null;
                                                       oF4Texts = new sap.ui.model.json.JSONModel();
                                                       var f4text = {
                                                              title : mparams[i].F4_TITLE,
                                                              id : mparams[i].ID
                                                       };
                                                       oF4Texts.setData(f4text);
                                                       oControllerS3._oDynamicF4Dialog.setModel(
                                                                     oF4Texts, "dyntext");
                                                       if (mparams[i].F4HELP_VALUES != null
                                                                     && mparams[i].F4HELP_VALUES != undefined
                                                                     && mparams[i].F4HELP_VALUES != "") {
                                                              f4array = getF4Array(mparams[i].F4HELP_VALUES);
                                                              oF4Model = new sap.ui.model.json.JSONModel();
                                                              oF4Model.setData(f4array);
                                                       } else {
                                                              oF4Model = new sap.ui.model.odata.ODataModel(
                                                                           serviceUrl
                                                                                         + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq '"
                                                                                         + mparams[i].ID
                                                                                         + "' and FileID eq '"
                                                                                         + this.fileid + "'");
                                                       }
                                                       oControllerS3._oDynamicF4Dialog
                                                                     .setModel(oF4Model);
                                                }
                                         }
                                         oControllerS3._oDynamicF4Dialog.open();
                                  },
                                  /* Full screen description */
                                  fullDescriptionPressed : function(oEvent) {

                                         if (!oControllerS3.oFullScreenDialog) {
                                                oControllerS3.oFullScreenDialog = sap.ui
                                                              .xmlfragment(
                                                                           "flm.fiori.view.fullscreenDescription",
                                                                           oControllerS3);
                                         }
                                         oControllerS3.oFullScreenDialog.getContent()[0]
                                                       .setValue(this.getView().byId("descrEditor")
                                                                     .getValue());
                                      
                                         oControllerS3.oFullScreenDialog.open();
                                  },
                                  /* Description full view value */
                                  fullScreenOkButton : function(oEvent) {
                                         this.getView().byId("descrEditor").setValue(
                                                       oControllerS3.oFullScreenDialog.getContent()[0]
                                                                     .getValue());
                                         oControllerS3.oFullScreenDialog.close();
                                  },

                                  fullScreenCancelButton : function(oEvent) {
                                         sap.ui.getCore().byId("rteFullDescription").setValue(
                                                       this.getView().byId("descrEditor").getValue());
                                         oControllerS3.oFullScreenDialog.close();
                                  },

                                  // attachmentButtonPressed : function(oEvent) {
                                  // isAttachment = true;
                                  // isFile = false;
                                  // isReport = false;
                                  // isObject = false;
                                  // isIPI = false;
                                  // this.attachmentDialog = null;
                                  // this.attachmentDialog = sap.ui.xmlfragment(
                                  // "flm.fiori.view.attachment", this);
                                  // var docType = sap.ui.getCore().byId("idDocumentType");
                                  // var ddModel = new sap.ui.model.json.JSONModel();
                                  // ddModel
                                  // .loadData(serviceUrl
                                  // + "/FILE_F4_ES?$filter=OtherF4 eq true and ID eq 'DT'");
                                  // docType.setModel(ddModel);
                                  //
                                  // this.attachmentDialog.open();
                                  // },
                                  //
                                  // fileButtonPressed : function(oEvent) {
                                  // isAttachment = false;
                                  // isFile = true;
                                  // isReport = false;
                                  // isObject = false;
                                  // isIPI = false;
                                  // this.fileDialog = null;
                                  // this.fileDialog = sap.ui.xmlfragment(
                                  // "flm.fiori.view.file", this);
                                  // this.fileDialog.open();
                                  // },

                                  /* Posting New Noting */
                                  onNewNotePostActionPressed : function(evt) {
                                                       // notingEditFlag = false;
                                                       
                                                       if (oControllerS3.getView().byId("notingEditor")
                                                                     .getValue() == "") {
                                                              sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_24"));
                                                              return;
                                                       }
                                                       var SignedTxt = "";
                                                      // if(this.digitalsign){
                                                              var crc = 0;
                                                       var htmContent = "";
                                                       
                                                       var x = this.getView().byId("notingEditor").getValue();
                                                       // x=oControllerS2.cleanBody(x);
                                                       x = "Digital Signature"; // SHOULD BE CHANGED
                                                       var htmlContent = Base64.encode(x);

                                                       try {
                                                              // htmContent =
                                                              // "<SAPSignIn><format>PKCS7</format><onlysig>X</onlysig><onlyvalid>X</onlyvalid><document
                                                              // type=&#34;HTM&#34;>"
                                                              htmContent = "<SAPSignIn><format>PKCS7</format><document type=&#34;HTM&#34;>"
                                                                           + htmlContent + "</document></SAPSignIn>";
                                                              crc = SAPSign.SignDoc(htmContent, "EXT", "B64", "",
                                                                           "");

                                                       } catch (err) {

                                                       }
                                                       ;
                                                       SignedTxt = SAPSign.signature;
                                                       SAPSign.signature = "";
                                                       if (crc != 0) {
                                                              sap.m.MessageBox.alert(SignedTxt);
                                                              return;
                                                       }
                                                      // }
                                                       var newNoting = this.getView().byId("notingEditor")
                                                                     .getValue();// oEvent.getSource().getBindingContext().getObject();
                                                       var remarkTo = "";
                                                       var bPrivate;
                                                       if (this.getView().byId("receiverTypeNoting")
                                                                     .getSelectedItem().getText() == "") {
                                                              bPrivate = "0002";
                                                       } else {
                                                              if (this.getView().byId("processorInput").getValue() == '') {
                                                                     sap.m.MessageBox
                                                                                  .alert(this.getView().getModel("i18n").getObject("MESSAGE_23"));
                                                                     return;
                                                              } else {
                                                                     bPrivate = "0004";
                                                                     remarkTo = this.getView().byId("processorInput")
                                                                                  .getName();
                                                              }
                                                       }
                                                       var newNotingData = {
                                                              TabType : this.fromTab,
                                                              Textid : bPrivate,
                                                              //Wiid : this.wiId,
                                                              CaseGuid : oControllerS3.caseguid,
                                                              NotingString : encodeURIComponent(newNoting),
                                                              SNotingString : SignedTxt,
                                                              PAgent : remarkTo
                                                       };
                                                       this.customBusyDialogOpen();
                                                      
//                                                     var ocrModel = new sap.ui.model.odata.ODataModel(serviceUrl,true);
//                                                     ocrModel.create("/FILE_NOTING_ES",newNotingData);
//                                                     
////                                                   this.getView().byId("noteList").getModel().create("",newNotingData);
//                                                     var oModel = new sap.ui.model.json.JSONModel();
//                                                     oModel.loadData(serviceUrl
//                                            + "/FILE_NOTING_ES?$filter=TabType eq '" + this.fromTab
//                                                                         + "' and CaseGuid eq '"+this.caseguid+"' and Wiid eq '"+this.wiId+"'", null, false);
//                                                     var response = oModel.oData.d.results;
//                                                     oControllerS3.getView().byId("notingList").setModel(oModel);
//                                                     //var noteEditEnable = this.getView().byId("listType");
//                                                     
//                                       oModel.setData(response);
                                                var ocrModel = this.getView().getModel();
                                                       ocrModel
                                                                     .create(
                                                                                  "/FILE_NOTING_ES",
                                                                                  newNotingData,
                                                                                  {
                                                                                         success : function(oResponse) {
                                                                                                
                                                                                                // if (oResponse.Notingid
                                                                                                // .substr(0, 1) == "P") {
                                                                                                // oResponse.idState = "Error";
                                                                                                // }
                                                                                                
                                                                                                // if(notingListModel != null){
                                                                                                var notingListModel = oControllerS3
                                                                                                              .getView().byId(
                                                                                                                            "notingList")
                                                                                                              .getModel("global").oData.notes;
                                                                                                if (notingListModel == null) {
                                                                                                       notingListModel = [ oResponse ];
                                                                                                       try{
                                                                                                        oResponse.actNote = decodeURIComponent(oResponse.NotingString);
                                                                                      }catch(err){
                                                                                       oResponse.actNote = oResponse.NotingString;
                                                                                      }
                                                                                                       
                                                                                                       oControllerS3.data.notes = notingListModel;
                                                                                                       // oControllerS2.getView()
                                                                                                       // .getModel("global")
                                                                                                       // .refresh();
                                                                                                       oControllerS3.getView()
                                                                                                                     .getModel("global")
                                                                                                                     .checkUpdate();
                                                                                                } else {
                                                                                                       notingListModel.splice(0, 0,
                                                                                                                     oResponse);
                                                                                                       //oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                                                                                                       try{
                                                                                                        oResponse.actNote = decodeURIComponent(oResponse.NotingString);
                                                                                      }catch(err){
                                                                                       oResponse.actNote = oResponse.NotingString;
                                                                                      } 
                                                                                                       oControllerS3.getView()
                                                                                                                     .getModel("global")
                                                                                                                     .refresh();
                                                                                                }
                                                                                                // }

                                                                                                // notingListModel.checkUpdate();

                                                                                                oControllerS3.customBusyDialogClose();                                                  
                                                                                         },
                                                                                         error : function(oResponse) {
                                                          sap.m.MessageBox.alert(getErrorJson(oResponse.response.body));
                                                         oControllerS3.customBusyDialogClose();
                                                        },
                                                                                         async : true
                                                                                  });
                                                //oControllerS3.customBusyDialogClose();  
                                                       this.getView().byId("notingEditor").setValue("");

                                                       this.getView().byId("processorInput").setValue("");
                                                       // this.getView().byId("notingEditor").getModel()
                                                       // .destroy();
                                                       // }

                                                       // Enable the reciever type and name field
//                                                     this.getView().byId("processorInput").setEnabled(true);
//                                                     this.getView().byId("receiverTypeNoting").setEnabled(
//                                                                   true);
                                                       oControllerS3.getView().byId("receiverTypeNoting")
                                                                     .setSelectedKey("SPACE");
                                                },

                                                // //For notings post

                                                // ///Notings Edit

                                                editNotingPressed : function(oEvent) {
                                                       // notingEditFlag = true;
                                                       this.getView().byId("notingCreateAction").setVisible(false);
                                                       this.getView().byId("notingEditAction").setVisible(true);
                                                       oControllerS3.getView().byId("notingEditor").rerender();
                                                       var clickedNote = oEvent.getSource().getParent()
                                                                     .getParent().getParent().getParent()
                                                                     .getParent().getBindingContext("global")
                                                                     .getObject();
                                                       if (!clickedNote.NoteFlag) {
                                                              oControllerS3.getView().byId("processorInput")
                                                                           .setEnabled(false);
                                                              oControllerS3.getView().byId("receiverTypeNoting")
                                                                           .setSelectedKey("SPACE");
                                                              oControllerS3.getView().byId("receiverTypeNoting")
                                                                           .setEnabled(false);
                                                       } else {
                                                              oControllerS3.getView().byId("processorInput")
                                                                           .setEnabled(true);
                                                              oControllerS3.getView().byId("receiverTypeNoting")
                                                                           .setEnabled(true);
                                                       }
                                                       var tempModel = new sap.ui.model.json.JSONModel();
                                                       tempModel.setData(oEvent.getSource().getParent()
                                                                     .getParent().getItems()[0].getBindingContext(
                                                                     "global").getObject());
                                                       this.getView().byId("notingEditor")
                                                                     .setModel(tempModel);
                                                       this.getView().byId("notingEditor").setValue(
                                                                     oEvent.getSource().getParent().getParent()
                                                                                  .getItems()[0].getContent());
                                                       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_59"));
                                                },
                                                // ///Notings Edit ends

                                                // //For new noting clear data
                                                notingNewActionPressed : function(oEvent) {
                                                       // if(!notingEditFlag){
                                                       // notingEditFlag = false;

                                                       this.getView().byId("notingEditAction").setVisible(false);
                                                       this.getView().byId("notingCreateAction").setVisible(true);
                                                       this.getView().byId("processorInput").setEnabled(true);
                                                       this.getView().byId("receiverTypeNoting").setEnabled(
                                                                     true);
                                                       this.getView().byId("notingEditor").setValue("");
                                                       this.getView().byId("processorInput").setValue("");
                                                       this.getView().byId("receiverTypeNoting")
                                                                     .setSelectedKey("SPACE");

                                                       // this.getView().byId("notingEditor").getModel().destroy();
                                                       // }else{
                                                       // notingEditFlag = false;
                                                       // }

                                                },
                                                
                                                // //For Edited Notings
                                                onEditNoteActionPressed : function(evt) { // CHANGED
                                                // notingEditFlag = true;
                                                // digital signing of code
                                                if (oControllerS3.getView().byId("notingEditor")
                                                              .getValue() == "") {
                                                       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_24"));
                                                       return;
                                                }
                                                var SignedTxt = "";
                                                       if(this.digitalsign){
                                                              var crc = 0;
                                                       var htmContent = "";
                                                       
                                                       var x = this.getView().byId("notingEditor").getValue();
                                                       // x=oControllerS2.cleanBody(x);
                                                       x = "Digital Signature"; // SHOULD BE CHANGED
                                                       var htmlContent = Base64.encode(x);

                                                       try {
                                                              // htmContent =
                                                              // "<SAPSignIn><format>PKCS7</format><onlysig>X</onlysig><onlyvalid>X</onlyvalid><document
                                                              // type=&#34;HTM&#34;>"
                                                              htmContent = "<SAPSignIn><format>PKCS7</format><document type=&#34;HTM&#34;>"
                                                                           + htmlContent + "</document></SAPSignIn>";
                                                              crc = SAPSign.SignDoc(htmContent, "EXT", "B64", "",
                                                                           "");

                                                       } catch (err) {

                                                       }
                                                       ;
                                                       SignedTxt = SAPSign.signature;
                                                       SAPSign.signature = "";
                                                       if (crc != 0) {
                                                              sap.m.MessageBox.alert(SignedTxt);
                                                              return;
                                                       }
                                                       }
                                                // end of digital signing
                                                
                                                if (this.getView().byId("notingEditor").getModel()
                                                              .getData().Notingid != undefined) {
                                                       if (this.getView().byId("notingEditor").getModel()
                                                                     .getData().NoteFlag) {
                                                              if (oControllerS3.getView().byId("processorInput")
                                                                           .getValue() == "") {
                                                                    sap.m.MessageBox
                                                                                  .alert(this.getView().getModel("i18n").getObject("MESSAGE_22"));
                                                                     return;
                                                              }
                                                       }
                                                       var remarkTo = "";
                                                       var bPrivate;
                                                       if (this.getView().byId("receiverTypeNoting")
                                                                     .getSelectedItem().getText() == ""
                                                                     || !this.getView().byId(
                                                                                  "receiverTypeNoting").getEnabled()) {
                                                              bPrivate = "0002";
                                                       } else {

                                                              if (this.getView().byId("processorInput").getValue() == ''
                                                                           || !this.getView().byId("processorInput")
                                                                                         .getEnabled()) {
                                                                     sap.m.MessageBox
                                                                                  .alert(this.getView().getModel("i18n").getObject("MESSAGE_23"));
                                                                     return;
                                                              } else {
                                                                     bPrivate = "0004";
                                                                     remarkTo = this.getView().byId("processorInput")
                                                                                  .getName();
                                                              }

                                                       }

                                                       var editedContent = {
                                                              TabType : oControllerS3.fromTab,
                                                              Textid : bPrivate,
                                                              //Wiid : oControllerS3.wiId,
                                                              CaseGuid : oControllerS3.caseguid,
                                                              NotingString : encodeURIComponent(oControllerS3.getView().byId(
                                                                           "notingEditor").getValue()),
                                                              SNotingString : SignedTxt,
                                                              PAgent : remarkTo,
                                                              Notingid : oControllerS3.getView().byId(
                                                                            "notingEditor").getModel().getData().Notingid
                                                       };
                                                       var updateModel = this.getView().getModel();
                                                       // create batch operation
                                                       // updateModel.clearBatch();
                                                       var batchOp = updateModel.createBatchOperation(
                                                                     "/FILE_NOTING_ES(Notingid='"
                                                                                  + oControllerS3.getView().byId(
                                                                                                "notingEditor").getModel()
                                                                                                .getData().Notingid + "')",
                                                                     'PUT', editedContent);
                                                       // add batch operation
                                                       updateModel.addBatchChangeOperations([ batchOp ]);
                                                       var batchOp = updateModel.createBatchOperation(
                                                                     "/FILE_NOTING_ES(Notingid='"
                                                                                  + oControllerS3.getView().byId(
                                                                                                "notingEditor").getModel()
                                                                                                .getData().Notingid + "')",
                                                                     "GET");
                                                       // add batch operation
                                                       updateModel.addBatchReadOperations([ batchOp ]);

                                                       oControllerS3.customBusyDialogOpen("");
                                                       // finally submit batch for both basic and dynamic
                                                       // attributes
                                                       updateModel
                                                                     .submitBatch(
                                                                                  function(oResponse, oData) {
                                                                                         
                                                                                         var notingList = oControllerS3
                                                                                                       .getView().byId(
                                                                                                                     "notingList")
                                                                                                       .getModel("global")
                                                                                                       .getData().notes;
                                                                                         if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {

                                                                                         for (var i = 0; i < notingList.length; i++) {
                                                                                                if (notingList[i].Notingid == oResponse.__batchResponses[1].data.Notingid) {
                                                                                                 try{
                                                                                                  notingList[i].actNote= decodeURIComponent(oResponse.__batchResponses[1].data.NotingString);
                                                                                   }catch(err){
                                                                                    notingList[i].actNote= oResponse.__batchResponses[1].data.NotingString;
                                                                                   }
                                                                                                       
                                                                                                       notingList[i].Createdate = oResponse.__batchResponses[1].data.Createdate;
                                                                                                       notingList[i].Rmrkto = oResponse.__batchResponses[1].data.Rmrkto;
                                                                                                       oControllerS3
                                                                                                                     .getView()
                                                                                                                     .byId(
                                                                                                                                   "notingList")
                                                                                                                     .getModel(
                                                                                                                                  "global")
                                                                                                                     .checkUpdate();
                                                                                                       break;
                                                                                                }
                                                                                         }
                                                                                         }
                                                                                                else{
                                                              sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                                                oResponse.__batchResponses[i].response.headers));
                                                              return;
                                                             }
                                                                                         
                                                                                         oControllerS3
                                               .customBusyDialogClose();
                                                                                  }, function(oResponse) {
                                                                                         
                                                                                  }, true);

                                                       this.getView().byId("notingEditor").setValue("");

                                                       this.getView().byId("processorInput").setValue("");
                                                       this.getView().byId("notingEditor").getModel()
                                                                     .destroy();
                                                }
                                                this.getView().byId("notingEditAction").setVisible(false);
                                                this.getView().byId("notingCreateAction").setVisible(true);

                                                // Enable the reciever type and name field
                                                this.getView().byId("processorInput").setEnabled(true);
                                                this.getView().byId("receiverTypeNoting").setEnabled(
                                                              true);
                                                oControllerS3.getView().byId("receiverTypeNoting")
                                                              .setSelectedKey("SPACE");
                                         },
                                                notingFullActionPressed : function(oEvent) {

                                                if (!oControllerS3._oFullScreenDialog1) {
                                                       oControllerS3._oFullScreenDialog1 = sap.ui
                                                                     .xmlfragment(
                                                                                  "flm.fiori.view.notingFullView",
                                                                                  oControllerS3);
                                                }
                                               
                                                oControllerS3._oFullScreenDialog1.getContent()[0]
                                                              .setValue(this.getView().byId("notingEditor")
                                                                           .getValue());
                                                oControllerS3._oFullScreenDialog1.open();
                                         },

                                         notingFullScreenCloseButton : function(oEvent) {
                                                this.getView().byId("notingEditor")
                                                              .setValue(
                                                                            oControllerS3._oFullScreenDialog1
                                                                                         .getContent()[0].getValue());
                                                oControllerS3._oFullScreenDialog1.close();
                                                // oControllerS2._oFullScreenDialog1.destroy();
                                         },

                                         notingFullScreenCancelButton : function(oEvent) {
                                                sap.ui.getCore().byId("notingFullEditor")
                                                              .setValue(
                                                                            this.getView().byId("notingEditor")
                                                                                         .getValue());
                                                oControllerS3._oFullScreenDialog1.close();
                                                // oControllerS2._oFullScreenDialog1.destroy();
                                         },

                                  convertToFlat : function(result, i, level) {
                                         
                                         result[i].Label = level.toString();
                                         oControllerS3.flatObj[oControllerS3.globalCounter] = result[i];
                                         oControllerS3.globalCounter++;
                                         for ( var j = 0; j < result[i].nodes.length; j++) {
                                                oControllerS3.convertToFlat(result[i].nodes, j,
                                                              result[i].Label + "_" + (j + 1));
                                         }
                                  },
                                  
                                  saveButtonEventPressed : function(oEvent){
                                   oControllerS3.saveButtonPressed();
                                  },
                                  saveButtonPressed : function(val) {
                                         
                                         /*
                                         * Pushing input controls into an array for validation
                                         * starts
                                         */
                                   if(val == undefined){
                                    val = '';
                                   }
                                    var fileNumberString="";
                                      var validationControls = new Array();
                                      var hboxContent = this.getView().byId(
                                                    "idFileNumberHbox");
                                      for ( var i = 0; i < hboxContent.getItems().length; i += 2) {
                                             validationControls.push(hboxContent.getItems()[i]
                                                           .getItems()[2]);
                                             if(hboxContent.getItems()[i]
                                             .getItems()[2].getType()=="Default"){
                                             fileNumberString+=hboxContent.getItems()[i]
                                             .getItems()[2].getSelectedItem().getText();
                                             }else{
                                                fileNumberString+=hboxContent.getItems()[i]
                                                 .getItems()[2].getValue()+"/";
                                             }
                                      }
                                      //check for file number length
                                      if(fileNumberString.length>100){
                                          sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_17"));
                                          return;
                                      }
                                      validationControls.push(this.getView().byId("idDuedate"));
                                      validationControls.push(this.getView().byId(
                                                    "idPrioSelect"));
                                      validationControls.push(this.getView().byId(
                                                    "idShortText"));
                                      var dynamicAttrForm = oControllerS3.getView().byId(
                                                    "dynamicAttrForm");
                                      for ( var i = 0; i < mparams.length; i++) {
                                             if (mparams[i].MANDATORY == true) {
                                                    validationControls.push(sap.ui.getCore().byId(
                                                                  mparams[i].ID));
                                             }
                                             if(mparams[i].CURR_ID!=""){
                                              if(sap.ui.getCore().byId(mparams[i].ID).getValue()!="" && sap.ui.getCore().byId(mparams[i].ID).getValue()!="0.000"){ 
                                               
                                              validationControls.push(sap.ui.getCore().byId(
                                                         mparams[i].CURR_ID));
                                              }
                                             }
                                      }
                                      var f = validateInput(oControllerS3, validationControls);
                                      if (f) {
                                             f.focus(true);
                                             return;// Break
                                      } else {
                                             // Continue
                                      }
                                      
                                      oControllerS3.customBusyDialogOpen();
                                         //Check if file is new or update
                                         if(oControllerS3.caseguid!=""){
                                         oControllerS3.updateFile();
                                         
                                         }
                                         else{
                                         
                                         /*
                                         * Pushing input controls into an array for validation
                                         * ends
                                         */
                                         
                                         // Saving Data starts
                                         var oModel = new sap.ui.model.odata.ODataModel(
                                                       serviceUrl);
                                         oModel.setUseBatch(true);
                                         // read file number
                                         
                                         for ( var i = 0; i < oControllerS3.createFileResponse.length - 1; i++) {
                                                var tempObj = {};
                                                tempObj.NAME = oControllerS3.createFileResponse[i].NAME;
                                                if (oControllerS3.createFileResponse[i].DDVALUES != "") {
                                                       tempObj.VALUE = sap.ui.getCore().byId(
                                                                     "FID00" + i).getSelectedItem().getKey();
                                                } else if (tempObj.NAME == "SEPR") {
                                                       tempObj.VALUE = sap.ui.getCore().byId(
                                                                     "FID00" + i).getText();
                                                } else {
                                                       tempObj.VALUE = sap.ui.getCore().byId(
                                                                     "FID00" + i).getValue();
                                                }
                                                // obj.push(tempObj);
                                                // create batch operation
                                                var batchOp = oModel.createBatchOperation(
                                                              "/FILE_NUMBER_ES", 'POST', tempObj);

                                                // add batch operation
                                                oModel.addBatchChangeOperations([ batchOp ]);

                                         }

                                         // read basic attr
                                         var obj = {};

                                         obj.PlanEndDate = oControllerS3.getView().byId(
                                                       "idDuedate").getValue();
                                         obj.Priority = oControllerS3.getView().byId(
                                                       "idPrioSelect").getSelectedItem().getKey();
                                         obj.CaseTitle = oControllerS3.getView().byId(
                                                       "idShortText").getValue();
                                         obj.Description = encodeURIComponent(oControllerS3.getView().byId(
                                                       "descrEditor").getValue());
                                         // create batch operation
                                         var batchOp = oModel.createBatchOperation(
                                                       "/FILE_BASIC_ES", 'POST', obj);

                                         // add batch operation
                                         oModel.addBatchChangeOperations([ batchOp ]);
//                                         this.dynUIAssistArr=this.getView().getModel("global").oData.dynamic;
                                         // read dynamic attributes
                                         for ( var i = 0; i < this.dynUIAssistArr.length; ++i) {
                                                var value = "";
                                                switch (this.dynUIAssistArr[i].type) {
                                                case "IP":
                                                       value = sap.ui.getCore().byId(
                                                                     this.dynUIAssistArr[i].id).getValue();
                                                       break;
                                                case "F4":
                                                       value = sap.ui.getCore().byId(
                                                                     this.dynUIAssistArr[i].id).getValue();
                                                       break;
                                                case "DP":
                                                       value = sap.ui.getCore().byId(
                                                                     this.dynUIAssistArr[i].id).getDateValue();
                                                       if(value != null){
                                                        value = dateFormatter(value);
                                                       }else{
                                                  value = "";
                                                 }
                                                       break;
                                                case "TP":
                                                       value = sap.ui.getCore().byId(
                                                                     this.dynUIAssistArr[i].id).getValue();
                                                       break;
                                                case "CB":
                                                       value = sap.ui.getCore().byId(
                                                                     this.dynUIAssistArr[i].id).getState();
                                                       if(value){
                                                          value='X';
                                                       }else{
                                                          value="";
                                                       }
                                                       break;
                                                case "CU":
                                                       value = sap.ui.getCore().byId(
                                                                     this.dynUIAssistArr[i].id).getValue();
                                                       break;
                                                }

                                                // create batch operation
                                                var batchOp = oModel.createBatchOperation(
                                                              "/FILE_ATTR_ES", 'POST', {
                                                                     "ID" : this.dynUIAssistArr[i].id,
                                                                     "TYPE" : this.dynUIAssistArr[i].type,
                                                                     "VALUE" : value,
                                                                     "GUID" : oControllerS3.caseguid
                                                              });

                                                // add batch operation
                                                oModel.addBatchChangeOperations([ batchOp ]);

                                         }
                                        

                                         // create batch operation
                                         var batchOp = oModel.createBatchOperation(
                                                       "/FILE_ATTR_ES", 'POST', {
                                                              "ID" : 'EOT',
                                                              "FILETYPE" : oControllerS3.filetype,// end of transfer
                                                              "GUID" : oControllerS3.caseguid,
                                                              "VALUE" : val
                                                       });

                                         // add batch operation
                                         oModel.addBatchChangeOperations([ batchOp ]);

                                         
                                         // finally submit batch for both basic and dynamic
                                         // attributes
                                         oModel
                                                       .submitBatch(
                                                                     function(oResponse, oData) {
                                                                      
//                                                                      if(oResponse.__batchResponses[oResponse.__batchResponses.length - 1] != undefined){
//                                                                           var resObj = oResponse.__batchResponses[oResponse.__batchResponses.length - 1].__changeResponses[0]; // Response
////                                                                                                                                                                                                                                                              // Values
////                                                                                                                                                                                                                                                              // Object
//                                                                           var saveStatus = resObj.statusText;
//                                                                           if (saveStatus == "Created") {
                                                                      if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {
                                                                       var resObj = oResponse.__batchResponses[oResponse.__batchResponses.length - 1].__changeResponses[0];
                                                                                  oControllerS3.getView().byId("descrEditor").setHeight("24rem");
                                                                                  oControllerS3.filenumber = resObj.data.FILENUMBER;
                                                                                  oControllerS3.fileid = resObj.data.FILEID;
                                                                                  oControllerS3.caseguid = resObj.data.GUID;
                                                                                  oControllerS3.digitalsign = resObj.DIGSIGNREQ;
                                                                                  // Fetching response for save
                                                                                  oControllerS3.getView().byId("idFileNumberHboxMain").setVisible(
                                                                                                false);
                                                                                  oControllerS3.getView().byId("idLabelFileNumber").setVisible(
                                                                                                true);
                                                                                  oControllerS3.getView().byId("idInputFileNumber").setVisible(
                                                                                                true);
                                                                                  oControllerS3.getView().byId("idInputFileNumber").setValue(
                                                                                                oControllerS3.filenumber);
                                                                                  oControllerS3.getView().byId("idTrackFileLabel").setVisible(
                                                                                          true);
                                                                                  oControllerS3.getView().byId("idTrackFileSwitch").setVisible(true);
                                                                                  oControllerS3.getView().byId("idConfidentialFileLabel").setVisible(
                                                                                          true);
                                                                                  oControllerS3.getView().byId("idConfidentialFileSwitch").setVisible(true);
                                                                                  oControllerS3.getView().byId("idButtonSend").setEnabled(true);
                                                                                  oControllerS3.getView().byId("idButtonClose").setEnabled(true);
                                                                               // Validations
                                                                     /*Notings set to editable*/            
                                                                                  oControllerS3.getView().byId("emptyNotingPanel").setVisible(false);
                                                                                  oControllerS3.getView().byId("notingPanel").setVisible(true);
                                                                                  oControllerS3.getView().byId("idAddNewWorkflowButton").setEnabled(true);
                                                                                  oControllerS3.getView().byId("printAction").setVisible(true);
                                                                                  oControllerS3.fromTab="DRAFT";
                                                                                 // oControllerS3.getView().byId("idChangeWorkflowButton").setEnabled(true);
                                                                                  //oControllerS3.getView().byId("shareDraftAction").setEnabled(true);
                                                                                  oControllerS3.saveFlag=false;
                                                                                  oControllerS3.customBusyDialogClose();
                                                                                  sap.m.MessageToast
                                                                                  .show(oControllerS3.getView().getModel("i18n").getObject("MESSAGE_13"));
                                                                                   
                                                                           } else if(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf("<severity>warning</severity>") != -1 || oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf('"severity":"warning"') != -1){
                                                                            sap.m.MessageBox.confirm(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                                                oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers),
                                                                             function(response) {
                                                   if (response == "OK") {
                                                    oControllerS3.customBusyDialogOpen();
                                                    //valueEOT = 'X';
                                                    oControllerS3.saveButtonPressed('X');
                                                   }
                                                   else{
                                                    oControllerS3.customBusyDialogClose();
                                                   }
                                                                                 });
                                                                             }else {
//                                                                                  sap.m.MessageToast
//                                                                                                .show(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message);
                                                                            sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                                              oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers));
                                                                                  oControllerS3.customBusyDialogClose();
                                                                                  return;
                                                                           }
                                                                     }, function(oResponse) {
                                                                      oControllerS3.customBusyDialogClose();
                                                                           
                                                                     });

                                         // Saving Data ends

                                         }
                                         
                                         
                                        
//                                         var oTreeTable = this.getView().byId("wftree");

//                                         var result = oTreeTable.getModel("workflow").oData.nodes;
//                                         oControllerS3.globalCounter = 0;
//                                         oControllerS3.flatObj = new Array();
//                                         for ( var i = 0; i < result.length; ++i) {
//                                                oControllerS3.convertToFlat(result, i, i + 1);
//                                         }
                                         
                                  },

                                  onChangeWorkflowSelect : function(oEvent) {
                                   if(sap.ui.getCore().byId("rightTree").getSelectedIndex()<0){
                                    alert(this.getView().getModel("i18n").getObject("MESSAGE_58"));
                                          return;
                                   }
//                                    oControllerS3.updateWorkflowFlag=true;
                                    oControllerS3.newWorkflowFlag=false;
                                         if (!oControllerS3.oSequenceSend) {
                                          oControllerS3.oSequenceSend = sap.ui.xmlfragment(
                                                              "flm.fiori.view.sendTo", oControllerS3);
                                         }
//                             sap.ui.getCore().byId("idSendToDialog").setContentWidth("50%");
//                                         sap.ui.getCore().byId("idColumnProcessingDate").setVisible(false);
//                                         sap.ui.getCore().byId("idColumnProcessingDays").setVisible(false);
                                         sap.ui.getCore().byId("idLabelSelectType").setVisible(false);
                                         sap.ui.getCore().byId("idSequenceRadioButton").setVisible(false);
                                         sap.ui.getCore().byId("idParallelRadioButton").setVisible(false);
//                                         sap.ui.getCore().byId("idDatePickerSendTo").setVisible(false);                                       
//                                         sap.ui.getCore().byId("idInputDays").setVisible(false);
                                         // if(oEvent.getSource().getId()=="__xmlview3--idChangeWorkflowButton"){
                                         oControllerS3.flagLocation = "fromChangeWorkflow";
                                         if (oEvent.getSource().getId() == "idAddProcessorButton") {
                                                oControllerS3.flagLocation = "fromAddNewWorkflow";
                                         }
                                         var oTable = sap.ui.getCore().byId("idProcessorsTable");
                                                       var oModel = new sap.ui.model.json.JSONModel({
                                                              "data" : []
                                                       });
                                                       oTable.setModel(oModel, "dummy");
                                         var select1 = sap.ui.getCore().byId("idSelect1");
                                         var select1Model = new sap.ui.model.json.JSONModel({});
                                         select1.setSelectedKey("SPACE");
                                         select1Model
                                                       .loadData(serviceUrl
                                                                     + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and OtherF4 eq true and ID eq 'WC'",null,false);
                                         select1.setModel(select1Model,"processorType");
                                         
                                         var select2 = sap.ui.getCore().byId("idSelect2");
                                         var select2Model = new sap.ui.model.json.JSONModel({});
                                         select2Model
                                                       .loadData(serviceUrl
                                                                     + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and OtherF4 eq true and ID eq 'AC'",null,false);
                                         select2.setModel(select2Model,"activity");
                                         select2.setSelectedIndex(0);
                                         if (oControllerS3._oDynamicF4Dialog) {
                                          oControllerS3._oDynamicF4Dialog.getModel().destroy();
                                         }
                                         
//                                         sap.ui.getCore().byId("idParallelRadioButton")
//                                                       .setVisible(false);
                                         this.oSequenceSend.open();
                                         
                                  },

                                  handleValueHelp : function(oEvent) {
                                         oControllerS3.customBusyDialogOpen("");
                                         if (!oControllerS3._oDynamicF4Dialog) {
                                                oControllerS3._oDynamicF4Dialog = sap.ui
                                                              .xmlfragment(
                                                                            "flm.fiori.view.dynamicF4popup",
                                                                           oControllerS3);

                                         }
                                         
                                         var otypeModel = new sap.ui.model.json.JSONModel();
                                         
                                         oF4Texts = new sap.ui.model.json.JSONModel();
                                         if (oEvent.getSource().getId() == "idUsername") {
                                                var f4text = {

                                                       title : sap.ui.getCore().byId("idSelect1")
                                                                     .getSelectedItem().getText(),

                                                       id : "idUsername",

                                                       path : "/d/results"
                                                };
                                                
                                                if (sap.ui.getCore().byId("idSelect1").getSelectedKey() != 'SPACE') {
                                                 otypeModel.attachRequestCompleted(oControllerS3,function(oEvent){
                                                  otypeModel.setData(otypeModel.oData.d.results);
                                                  oControllerS3._oDynamicF4Dialog.setModel(otypeModel);
                                                      oControllerS3.customBusyDialogClose();
                                                      otypeModel.detachRequestCompleted();
                                                      },oControllerS3);
                                                 otypeModel.loadData(serviceUrl
                                                                 + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq '"
                                                                 + sap.ui.getCore().byId("idSelect1").getSelectedKey()
                                                                 + "' and WF eq true", null, false);
                                                    
                                                }
                                                oControllerS3._oDynamicF4Dialog.setModel(otypeModel);
                                                
                                         } else if (oEvent.getSource().getId() == "idOrgUnit") {
                                                

                                                otypeModel
                                                              .loadData(
                                                                           serviceUrl
                                                                                         + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq 'O' and WF eq true",
                                                                           null, false);
                                                var otextModel = new sap.ui.model.json.JSONModel();
                                                var f4text = {

                                                       title : this.getView().getModel("i18n").getObject("ORG_UNIT"),

                                                       id : "idOrgUnit",

                                                       path : "/d/results"
                                                };
                                                var oResponse=otypeModel.oData.d.results;
                                                otypeModel.setData(oResponse);
                                                oControllerS3._oDynamicF4Dialog
                                                              .setModel(otypeModel);
                                                oControllerS3.customBusyDialogClose();
                                         } else if (oEvent.getSource().getId() == "idFactoryCalendar") {
                                                

                                                otypeModel
                                                              .loadData(
                                                                           serviceUrl
                                                                                         + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq 'FC' and OtherF4 eq true",
                                                                           null, false);
                                                var otextModel = new sap.ui.model.json.JSONModel();
                                                var f4text = {

                                                       title : this.getView().getModel("i18n").getObject("FACTORY_CALENDAR"),

                                                       id : "idFactoryCalendar",

                                                       path : "/d/results"
                                               };
                                                var oResponse=otypeModel.oData.d.results;
                                                otypeModel.setData(oResponse);
                                                oControllerS3._oDynamicF4Dialog
                                                              .setModel(otypeModel);
                                                oControllerS3.customBusyDialogClose();
                                         } else {
                                                var f4text = {

                                                       title : this.getView().byId(
                                                                     "receiverTypeNoting").getSelectedItem()
                                                                     .getText(),

                                                       id : "processorInput",

                                                       path : "/d/results"

                                                };
                                                if (oControllerS3.getView().byId("receiverTypeNoting").getSelectedKey() != 'SPACE') {
                                                 otypeModel.attachRequestCompleted(oControllerS3,function(oEvent){
                                                  otypeModel.setData(otypeModel.oData.d.results);
                                                  oControllerS3._oDynamicF4Dialog.setModel(otypeModel);
                                                      oControllerS3.customBusyDialogClose();
                                                      otypeModel.detachRequestCompleted();
                                                      },oControllerS3);
                                                    otypeModel.loadData(serviceUrl
                                                                 + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq '"
                                                                 + oControllerS3.getView().byId("receiverTypeNoting").getSelectedKey()
                                                                 + "' and WF eq true", null, false);
                                                    }
                                                oControllerS3._oDynamicF4Dialog.setModel(otypeModel);
                                                
                                         }

                                         oF4Texts.setData(f4text);

                                         oControllerS3._oDynamicF4Dialog.setModel(

                                         oF4Texts, "dyntext");
                                         oControllerS3.customBusyDialogClose();
                                         // open value help dialog
                                         oControllerS3._oDynamicF4Dialog.open();
                                  },

                                  onInsertInWorkflow : function(oEvent) { // CHANGE
                                                       
                                                       oControllerS3.flatObj = new Array();
                                                       if (sap.ui.getCore().byId("idSequenceRadioButton")
                                                                     .getSelected() == true) {
                                                              // var
                                                              var processor = sap.ui.getCore().byId("idSelect1")
                                                                           .getSelectedItem().getText();
                                                              var sendTo = sap.ui.getCore().byId("idUsername")
                                                                           .getValue();
                                                              var agent = sap.ui.getCore().byId("idUsername")
                                                                           .getName();
                                                              var activity = sap.ui.getCore().byId("idSelect2")
                                                                           .getSelectedItem().getText();
                                                              var activityKey = sap.ui.getCore()
                                                                            .byId("idSelect2").getSelectedItem()
                                                                           .getKey();
                                                              var processingDate = sap.ui.getCore().byId(
                                                                            "idDatePickerSendTo").getValue();
                                                              // var
                                                              // processingTime=sap.ui.getCore().byId("idInputTime").getValue();
                                                              var processingDay = sap.ui.getCore().byId(
                                                                           "idInputDays").getValue();
                                                              if ((sendTo == "" || activity == "" || processor == "")) {
                                                                     sap.m.MessageToast
                                                                                  .show(this.getView().getModel("i18n").getObject("MESSAGE_20"));
                                                                     return;
                                                              }
                                                              if (processingDate != "" && processingDay != "") {
                                                                     sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
                                                              sap.ui.getCore().byId("idInputDays").setValue("");
                                                              sap.m.MessageBox
                                                                            .alert(this.getView().getModel(
                                                                            "i18n").getObject("MESSAGE_21"));
                                                                     return;
                                                              }
//                                                              oControllerS3.saveFlag = true;
                                                              var nodeType = "S";
                                                              var newObj = {
                                                                     "Actdc" : activity,
                                                                     "Activity" : activityKey,
                                                                     "Agent" : agent,
                                                                     "Nodetype" : nodeType,
                                                                     "Text" : processor,
                                                                     "Fullname" : sendTo,
                                                                     "Creadate" : "",
                                                                     "PosidLed" : processingDate,
                                                                     "processor" : processor,
                                                                     "Statustext" : "Not Yet Started",
                                                                     "Days" : processingDay,
                                                                     "nodes" : []
                                                              };
                                                              oControllerS3.flatObj[0] = newObj;

                                                              oControllerS3.addSequenceCreateWorkflow(oEvent,newObj,"sendTo");
                                                       } else if (sap.ui.getCore().byId(
                                                                     "idParallelRadioButton").getSelected() == true) {
                                                              
                                                              var parList = sap.ui.getCore().byId(
                                                                            "idProcessorsTable").getModel("dummy")
                                                                           .getData().data;
                                                              for (var i = 0; i < parList.length; i++) {
                                                                     var sendTo = parList[i].Name;
                                                                     var activity = parList[i].Actdc;
                                                                     var processingDate = parList[i].Date;
                                                                     // var
                                                                     // processingTime=parList[i].getCells()[4].getText();
                                                                     var processingDay = parList[i].Days;
                                                                     var agent = parList[i].Agent;
                                                                     var activityKey = parList[i].Activity;
                                                                     var nodeType = "P";
                                                                     var newObj = {
                                                                           "Actdc" : activity,
                                                                           "Activity" : activityKey,
                                                                           "Agent" : agent,
                                                                           "Nodetype" : nodeType,
                                                                           "Fullname" : sendTo,
                                                                           "Text" : processor,
                                                                           "Creadate" : "",
                                                                           "PosidLed" : processingDate,
                                                                           "Statustext" : "Not Yet Started",
                                                                           "nodes" : []
                                                                     };
                                                                     oControllerS3.flatObj[i] = newObj;
                                                                     oControllerS3.addSequence(newObj);
                                                              }
                                                       }
                                                       // oEvent.getSource().getParent().getParent().close();
                                                       sap.ui.getCore().byId("idUsername").setValue("");
                                                       sap.ui.getCore().byId("idSelect1").getSelectedItem().setText("");
                                                       sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
                                                       sap.ui.getCore().byId("idInputDays").setValue("");
                                     if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                                      oEvent.getSource().getParent().close();
                                     } else {
                                      oEvent.getSource().getParent().getParent().close();
                                     }
                                                },

                                  addSequence : function(newObj) {
                                         var wftree = this.getView().byId("wftree");
                                         wftree.rerender();

                                         var data = wftree.getModel("workflow").oData.nodes;
                                         var obj = data;
                                         data = data.reverse();
                                         data.push(newObj);

                                         data = data.reverse();

                                         wftree.getModel("workflow").checkUpdate();

                                         wftree.rerender();
                                         this.getView().byId("idChangeWorkflowButton")
                                                       .setEnabled(false);
                                         this.getView().byId("idUndoButton").setEnabled(true);
                                         return;

                                  },

                                  onUndoSelect : function() {
                                         this.getView().byId("idChangeWorkflowButton")
                                                       .setEnabled(true);
                                         oControllerS3.loadTreeTable();
                                         this.getView().byId("idUndoButton").setEnabled(false);
                                  },

                                  onAddNewWorkflow : function(oEvent) {
                                      oControllerS3.updateWorkflowFlag=false;
                                        oControllerS3.newWorkflowFlag=true;
                                       if(oControllerS3.oCreateWorkflow==undefined){
                                      oControllerS3.oCreateWorkflow = sap.ui.xmlfragment(
                                                    "flm.fiori.view.createWorkflow", oControllerS3);
                                                                                
                                      var oTable = sap.ui.getCore().byId("leftTree");
                                      oTable.setRowHeight(50);
                                      var oText = new sap.m.Text({
                                       text : "{Text}"
                                      });
                                      
                                      var oSpace1 = new sap.ui.core.HTML({
                                          content : "<span>&nbsp;&nbsp;</span>"
                                      });
                                      
                                      var oIcon = new sap.ui.core.Icon({
                                       src : "{ImageSrc}",
                                       color : "#009DE0",
                                       press : oControllerS3.loadRemainingTree,
                                      });
                                      
                                      var oSpace = new sap.ui.core.HTML({
                                          content : "<span>&nbsp;&nbsp;</span>"
                                      });
                                      
                                      var oIcon1 = new sap.ui.core.Icon({
                                       src : "{Level}",
                                       press : oControllerS3.loadRemainingTree,
                                      });
                                      this.oLayout = new sap.ui.layout.HorizontalLayout(
                                              {
                                                     content : [oIcon1,oSpace,oIcon,oSpace1,oText ]
                                              });
                                      
                                      oTable.addColumn(new sap.ui.table.Column({
                                             label : oControllerS3.getView().getModel("i18n").getObject("HIERARCHY"),
                                             template : this.oLayout,
                                             name : "Otype" + "Objid",
                                             sortProperty : ""
                                      }));
                                      oTable.addColumn(new sap.ui.table.Column({
                                             label : oControllerS3.getView().getModel("i18n").getObject("OBJECT_NAME"),
                                             template : "Stext",
                                             sortProperty : ""
                                      }));
                                      var oModel = new sap.ui.model.json.JSONModel();
                                      oModel
                                                    .loadData(
                                                                  serviceUrl
                                                                               + "/ORGU_MEM_ETSet?$filter=OobjId eq ''",
                                                                  null, false);
                                      
                                      var result = oModel.oData.d.results;
                                      
                                      oModel.setData(result);

                                      oTable.setModel(oModel); // set model to Table*/
                                      
                                      oTable.bindRows("/");
                                      oTable.setExpandFirstLevel(true);
                                      
                                      var oTable = sap.ui.getCore().byId("rightTree");
                                      var ActivityDDModel = new sap.ui.model.json.JSONModel();
                                      ActivityDDModel
                                                    .loadData(serviceUrl
                                                                  + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq 'AC' and OtherF4 eq true");
                                     var ActivityDD = new sap.m.Select({
                                             value : "Select",
                                             selectedKey : "{Activity}",
                                             items : {
                                                    path : "keys>/d/results",
                                                    template : new sap.ui.core.Item({
                                                           key : "{keys>ResultCol3}",
                                                           text : "{keys>ResulltCol1}",
                                                           tooltip: "{keys>ResulltCol1}"
                                                    })
                                             },
                                             visible : {
                                            "parts" : [ 'Type' ],
                                                 "formatter" : flm.fiori.utils.formatter.lockSelect
                                               }
                                      });
                                      ActivityDD.setModel(ActivityDDModel,"keys");
                                      var processingDays = new sap.m.Input({
                                             type : "Text",
                                             placeholder : "0",
                                             value : "{Days}",
                                             visible : {
                                            "parts" : [ 'Type' ],
                                                 "formatter" : flm.fiori.utils.formatter.lockSelect
                                             }
                                      });
                                      var processingDate = new sap.m.DateTimeInput({
                                          value : "{PosidLed}",
                                          valueFormat : "yyyyMMdd",
                                          displayFormat : "dd/MM/yyyy",
                                          visible : {
                                         "parts" : [ 'Type' ],
                                              "formatter" : flm.fiori.utils.formatter.lockSelect
                                          }
                                      });
                                      oTable.addColumn(new sap.ui.table.Column({
                                             label : oControllerS3.getView().getModel("i18n").getObject("APPROVER_LEVEL"),
                                             template : "Text",
                                             sortProperty : ""
                                      }));
                                      oTable.addColumn(new sap.ui.table.Column({
                                             label : oControllerS3.getView().getModel("i18n").getObject("APPROVER_NAME"),
                                             template : "Stext",
                                             sortProperty : ""
                                      }));
                                      oTable.addColumn(new sap.ui.table.Column({
                                             label : oControllerS3.getView().getModel("i18n").getObject("ACTIVITY"),
                                             template : ActivityDD,
                                             sortProperty : "",
                                      }));
                                      oTable.addColumn(new sap.ui.table.Column({
                                          label : oControllerS3.getView().getModel("i18n").getObject("PROCESSING_DATE"),
                                          template : processingDate,
                                          sortProperty : "",
                                          visible : true,
                                   }));
                                      oTable.addColumn(new sap.ui.table.Column({
                                             label : oControllerS3.getView().getModel("i18n").getObject("PROCESSING_TIME"),
                                             template : processingDays,
                                             sortProperty : "",
                                             visible : true,
                                      }));

                                    //retaining existing workflow in right tree
                                      var oTable=sap.ui.getCore().byId("rightTree");
                                      oControllerS3.flatObj=new Array();
                                     oControllerS3.globalCounter = 0;
                                     var treeData=oControllerS3.getView().byId("wftree").getModel("workflow").getData();
//                                     for ( var i = 0; i < treeData.nodes.length; i++) {
//                                          oControllerS3.convertToFlatForCreateWorkflow(
//                                                        [treeData.nodes[i]], 0, 1,"S");
//                                     }
                                     var oModel = new sap.ui.model.json.JSONModel();
                                     if(oEvent.getSource().getId()=="addInSequence"){
                                      oModel.setData({
                                             "results" : [ {
                                                    "Type" : "Sequence",
                                                    "Text" : "Sequence",
                                                    "Activity" : "SPACE",
                                                    "nodes" : []
                                             } ]
                                      });
                                     }else if(oEvent.getSource().getId()=="addInParallel"){
                                    oModel.setData({
                                            "results" : [ {
                                                   "Type" : "Parallel",
                                                   "Text" : "Parallel",
                                                   "Activity" : "SPACE",
                                                   "nodes" : []
                                            } ]
                                     });
                                     }
                                      oTable.setModel(oModel); // set model to
                // Table*/
                                      oTable.setSelectedIndex(0);
                                      oTable.bindRows("/results");
//                                      for(var i=oControllerS3.flatObj.length-1;i>=0;i--){
//                                       oControllerS3.addSequenceCreateWorkflow(oEvent,oControllerS3.flatObj[i],"mainWf");
//                                      }
                                      oTable.setExpandFirstLevel(true);
                                      oTable.expand(0);
//                                      oTable.setSelectedIndex(0);
//                                      oTable.bindRows("/results");
//                                      ActivityDD.setEnabled(flm.fiori.utils.formatter
//                .selectEnabledStatus(oModel.getData().results[i].Type));
//                                            processingDays.setEnabled(flm.fiori.utils.formatter
//                      .selectEnabledStatus(oModel.getData().results[i].Type));
                                            
                                       }
                                  
                                      
                                       
                                       else{
                                         sap.ui.getCore().byId("idFactoryCalendar").setValue("");
                                        sap.ui.getCore().byId("idOrgUnit").setValue("");
                                        sap.ui.getCore().byId("leftTree").getModel().destroy();
                                       sap.ui.getCore().byId("leftTree").setSelectedIndex(-1);
                                      //retaining existing workflow in right tree
                                          var oTable=sap.ui.getCore().byId("rightTree");
                                          oControllerS3.flatObj=new Array();
                                         oControllerS3.globalCounter = 0;
                                         var treeData=oControllerS3.getView().byId("wftree").getModel("workflow").getData();
//                                         for ( var i = 0; i < treeData.nodes.length; i++) {
//                                              oControllerS3.convertToFlatForCreateWorkflow(
//                                                            [treeData.nodes[i]], 0, 1,"S");
//                                         }
                                         var oModel = new sap.ui.model.json.JSONModel();
                                       if(oEvent.getSource().getId()=="addInSequence"){
                                            oModel.setData({
                                                   "results" : [ {
                                                          "Type" : "Sequence",
                                                          "Text" : "Sequence",
                                                          "Activity" : "SPACE",
                                                          "nodes" : []
                                                   } ]
                                            });
                                           }else if(oEvent.getSource().getId()=="addInParallel"){
                                          oModel.setData({
                                                  "results" : [ {
                                                         "Type" : "Parallel",
                                                         "Text" : "Parallel",
                                                         "Activity" : "SPACE",
                                                         "nodes" : []
                                                  } ]
                                           });
                                        }
                                          oTable.setModel(oModel); // set model to
                    // Table*/
                                          oTable.setSelectedIndex(0);
                                          oTable.bindRows("/results");
                                          oTable.setExpandFirstLevel(true);
//                                          for(var i=oControllerS3.flatObj.length-1;i>=0;i--){
//                                           oControllerS3.addSequenceCreateWorkflow(oEvent,oControllerS3.flatObj[i],"mainWf");
//                                          }
                                       }
                                       
                                       
                                       //Set Activity and dueDays disabled for Sequence Node
                                       
                                       //Set Activity and dueDays disabled for Sequence Node ends
                                      sap.ui.getCore().byId("idOrgUnitClear").setVisible(false);
                                      sap.ui.getCore().byId("idFactoryCalendarClear").setVisible(false);
                                      oControllerS3.oCreateWorkflow.open();
                                      for(var i=0;i<sap.ui.getCore().byId("rightTree").getModel().getData().results.length;i++){
                                          if(sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Sequence" || sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Parallel"){
                                           sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[1].setVisible(false);
                                           sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[2].setVisible(false);
                                          }
                                      }
                               },

                               addSequenceCreateWorkflow : function(oEvent, newObj, sourceFlag) {
                                
                                if(sap.ui.getCore().byId("rightTree").getSelectedIndex()<0){
                                 alert(this.getView().getModel("i18n").getObject("MESSAGE_58"));
                                       return;
                                }
                                
                                   if (!newObj) {
                                          var leftTree = sap.ui.getCore().byId("leftTree");
                                          leftTree.rerender();
                                          var leftIndices = leftTree.getSelectedIndices();
                                          var leftObject = new Array();
                                          for(var i=0;i<leftIndices.length;i++){
//                                          var leftIndex = leftTree.getSelectedIndex();
//                                          if (leftIndex == -1) {
//                                                 alert(this.getView().getModel("i18n").getObject("MESSAGE_16"));
//                                                 return;
//                                          }
                                          leftObject[i] = {};
                                          leftObject[i].Type="";
                                          leftObject[i].Text = ""; //leftTree.getContextByIndex(
//                                                        leftIndex).getObject().Text;
                                          leftObject[i].Stext = leftTree.getContextByIndex(
                                                        leftIndices[i]).getObject().Stext;
                                          leftObject[i].Nodetype = "S";
                                          if(leftTree.getContextByIndex(
                                            leftIndices[i]).getObject().Otype.length==1){
                                           leftTree.getContextByIndex(
                                             leftIndices[i]).getObject().Otype+=' ';
                                          }
                                          leftObject[i].Agent = leftTree.getContextByIndex(
                                            leftIndices[i]).getObject().Otype
                                                        + leftTree.getContextByIndex(leftIndices[i])
                                                                      .getObject().Objid;
                                          leftTree.isParallel = "";
                                          leftTree.CaseGuid = "1";
                                          leftObject[i].Statustext="Not yet Started";
                                          leftObject[i].PosidLed="";
                                          leftObject[i].nodes = [];
                                          }
                                   }

                                   else if (newObj && sourceFlag=="sendTo") {
                                          var leftObject = newObj;
                                          leftObject.Type="";
                                          leftObject.Text="";//newObj.processor;
                                          leftObject.Stext = newObj.Fullname;
                                          leftObject.Nodetype="S";
                                          leftObject.Agent=newObj.Agent;
                                          leftObject.Statustext="Not yet Started";
//                                          leftObject.PosidLed="00000000";
                                          // leftObject.Text = newObj.Stext;
                                          // leftObject.Stext = newObj.Fullname;
                                          leftObject.key=newObj.Activity;
                                         leftObject.nodes = [];
                                   }
                                   else if (newObj && sourceFlag=="mainWf") {
                                       var leftObject = newObj;
                                       leftObject.Type="";
                                       leftObject.Nodetype="S";
                                       leftObject.Statustext="Not yet Started";
                                       leftObject.PosidLed="";
                                       leftObject.Stext = newObj.Fullname;
                                       leftObject.key=newObj.Activity;
                                       leftObject.nodes = [];
//                                       if(newObj.Agent.substr(0,2)=="US")
//                                        leftObject.Text="SAP User";
//                                       else if(newObj.Agent.substr(0,2)=="AC")
//                                        leftObject.Text="Rule";
//                                       else if(newObj.Agent.substr(0,2)=="A ")
//                                        leftObject.Text="Background";
//                                       else if(newObj.Agent.substr(0,2)=="C ")
//                                        leftObject.Text="Job";
//                                       else if(newObj.Agent.substr(0,2)=="H ")
//                                        leftObject.Text="External User";
//                                       else if(newObj.Agent.substr(0,2)=="O ")
//                                        leftObject.Text="Organizational Unit";
//                                       else if(newObj.Agent.substr(0,2)=="S ")
//                                        leftObject.Text="Position";
                                }
                                   var rightTree = sap.ui.getCore().byId("rightTree");

                                   // rerender trees

//                                   rightTree.rerender();
//                                   for(var i=0;i<sap.ui.getCore().byId("rightTree").getModel().getData().results.length;i++){
//                                       if(sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Sequence" || sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Parallel"){
//                                        sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[2].setEnabled(false);
//                                        sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[3].setEnabled(false);
//                                       }
//                                   }
                                   // get selected index of leftTree

                                   // get selected index of rightTree
                                   var rightIndex = rightTree.getSelectedIndex();

                                   
                                   // case 1 - right tree is empty or nothing is selected
                                   if (rightIndex == -1) {
                                          // append to the end of the treetable
                                          var data = rightTree.getModel().oData.results;

                                          data[0].nodes.push(leftObject);

                                          rightTree.getModel().checkUpdate();
                                          
                                          rightTree.rerender();
                                          for(var i=0;i<sap.ui.getCore().byId("rightTree").getModel().getData().results.length;i++){   
                                           if(sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Sequence" || sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Parallel"){
                                               sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[2].setEnabled(false);
                                               sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[3].setEnabled(false);
                                              }
                                          }
                                          return;
                                   }

                                   // get right tree selected Object
                                   var rightObject = rightTree.getContextByIndex(
                                                 rightIndex).getObject(); // .getRows()[rightIndex].getBindingContext().getObject();

                                   // case 2 - normal node
                                   // figure out the parent node so that you can append
                                   var data = rightTree.getModel().oData.results;
                                   var path = rightTree.getContextByIndex(rightIndex)
                                                 .getPath().substr(9).split("/");
                                   var obj = data;
                                   for ( var i = 0; i < path.length - 3; ++i) {
                                          obj = obj[path[i]];
                                   }

                                   // if parent is sequence
                                   if(leftObject.length==undefined){
                                   var tempObj = leftObject;
                                   leftObject = new Array();
                                   leftObject[0] = tempObj;
                                   }
                                   for(var j=leftObject.length-1;j>=0;j--){
                                   if (obj[path[i]].Type == "Sequence") {
                                       leftObject[j].Nodetype = "S";   
                                    obj[path[i]].nodes.splice(
                                                        parseInt(path[i + 2]) + 1, 0, leftObject[j]);
                                   } else if (obj[path[i]].Type == "Parallel") { // if
                                        leftObject[j].Nodetype = "P";                                                       // parent
                                        obj[path[i]].nodes.splice(
                                                parseInt(path[i + 2]) + 1, 0, leftObject[j]); 
                                   } // node is parallel
                                        else if (obj[path[i]].type == undefined) {
                                          obj[path[i]].nodes[0].nodes.splice(
                                                        parseInt(path[i + 2]), 0, leftObject[j]);
                                   }
                                   }
                                   rightTree.getModel().checkUpdate();
                                   rightTree.rerender();
                                   return;

                            },

                               addParallelCreateWorkflow : function(oEvent) {
                                      
                                      var leftTree = sap.ui.getCore().byId("leftTree");
                                      var rightTree = sap.ui.getCore().byId("rightTree");

                                      // rerender trees
                                      leftTree.rerender();
                                      rightTree.rerender();

                                      // get selected index of leftTree
                                      var leftIndex = leftTree.getSelectedIndex();

                                      if (leftIndex == -1) {
                                             alert(this.getView().getModel("i18n").getObject("MESSAGE_16"));
                                             return;
                                      }

                                      // get selected index of rightTree
                                      var rightIndex = rightTree.getSelectedIndex();

                                      // get left tree selected object
                                     var leftObject = {};
                                      leftObject.Text = leftTree.getContextByIndex(leftIndex)
                                                    .getObject().Text;
                                      leftObject.Stext = leftTree
                                                    .getContextByIndex(leftIndex).getObject().Stext;
                                      leftObject.Nodetype = "P";
                                      if(leftTree.getContextByIndex(
                                              leftIndex).getObject().Otype.length==1){
                                       leftTree.getContextByIndex(
                                                  leftIndex).getObject().Otype+=' ';
                                      }
                                      leftObject.Agent = leftTree
                                                    .getContextByIndex(leftIndex).getObject().Otype
                                                    + leftTree.getContextByIndex(leftIndex)
                                                                  .getObject().Objid;
                                      leftTree.isParallel = true;
                                      leftTree.CaseGuid = "1";
                                      leftObject.Statustext="Not yet Started";
                                      leftObject.PosidLed="0000000";
                                      leftObject.nodes = [];

                                      // case 1 - right tree is empty or nothing is selected
                                      if (rightIndex == -1) {
                                             // alert saying that - choose a person/agent to add
                                             // in parallel
                                             return;
                                      }

                                      // get right tree selected object
                                      var rightObject = rightTree.getContextByIndex(
                                                    rightIndex).getObject(); // .getRows()[rightIndex].getBindingContext().getObject();

                                      // case 2 - non parallel node (normal node)
                                      if (rightObject.Type != "Parallel") {
                                             // figure out the parent node so that you can remove
                                             // selected item
                                             var data = rightTree.getModel().oData.results;
                                             var path = rightTree.getContextByIndex(rightIndex)
                                                           .getPath().substr(9).split("/");
                                             var obj = data;
                                             for ( var i = 0; i < path.length - 3; ++i) {
                                                    obj = obj[path[i]];
                                             }

                                             if (obj[path[i]].Type == "Sequence") {

                                                    // remove the selected item from the list and
                                                    // add new node instead - i.e., assign type as
                                                    // parallel
                                                    var oldObject = obj[path[i]].nodes.splice(
                                                                  path[i + 2], 1, {
                                                                        "Text" : "Parallel",
                                                                        "Type" : "Parallel",
                                                                        "nodes" : []
                                                                  });

                                                   obj[path[i]].nodes[path[i + 2]].nodes = [
                                                                  oldObject[0], leftObject ];
                                             } else if (obj[path[i]].Type == "Parallel") {

                                                    obj[path[i]].nodes.push(leftObject);
                                             }

                                             rightTree.getModel().checkUpdate();

                                             rightTree.rerender();

                                             // add new node instead - assign type as parallel
                                             // add deleted item inside the parallel node
                                             // add the selected item inside the parallel node
                                             return;
                                      }

                                      // case 3 - parallel node
                                      if (rightObject.Type == "Parallel") {
                                             // alert saying that - choose a person/agent to add
                                             // in parallel
                                             return;
                                      }

                               },

                                  onSendToDialogCloseButton : function(oEvent) {
                                         
                                   sap.ui.getCore().byId("idUsername").setValue("");
                                      sap.ui.getCore().byId("idSelect1").setSelectedKey("SPACE");
                                      sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
                                      sap.ui.getCore().byId("idInputDays").setValue("");
                    if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                     oEvent.getSource().getParent().close();
                    } else {
                     oEvent.getSource().getParent().getParent().close();
                    }
                                  },

                                  onCreateWorkflowOkPress : function(oEvent) {
                                   oControllerS3.customBusyDialogOpen();
                                      /* New Addition */
                                   var wftree = oControllerS3.getView().byId("wftree");
                                   var parentId="";
                                   var selectedNodeType = "";
                                   if(wftree.getModel("workflow").oData.nodes.length == 0){
                                    wftree.setSelectedIndex(-1);
                                   }
                                   if(wftree.getModel("workflow").oData.nodes.length != 0 && wftree.getSelectedIndex()==-1){
                                    parentId="0000";
                                   }
                                   if(wftree.getSelectedIndex()!=-1){
                                   selectedNodeType = wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().Nodetype;
                                   }
//                                      oControllerS3.updateWorkflowFlag=true;
                                      var result = sap.ui.getCore().byId("rightTree") 
                                                    .getModel().oData.results; 
                                      oControllerS3.rightTreeData=result;
                                      oControllerS3.flatObj = new Array();
                                      oControllerS3.globalCounter = 0;
                                      for ( var i = 0; i < result[0].nodes.length; i++) {
                                             oControllerS3.convertToFlatForCreateWorkflow(
                                                           result[0].nodes, i, (i+1),"S","createWF");
                                      }
                                      if(oControllerS3.flatObj.length==0){
                                       sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_87"));
                                       return;
                                      }
                                      for(var i=0;i<oControllerS3.flatObj.length;i++){
                                       if(oControllerS3.flatObj[i].PosidLed!="" && oControllerS3.flatObj[i].Days!=""){
                                           sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_88"));
                                           oControllerS3.customBusyDialogClose();
                                           return;
                                          }
                                      }
//                                      var oModel = new sap.ui.model.json.JSONModel();
                                      var oModel = new sap.ui.model.odata.ODataModel(
                                              serviceUrl);
                                      var obj = {
                                              "nodes" : [],
                                              "Label" : "Sequence"
                                       };
//                                       var oTreeTable = oControllerS3.getView().byId("wftree");
//                                      oControllerS3.flatObj=oControllerS3.flatObj.reverse();
                                       result=oControllerS3.flatObj;
                                       //If Single Parallel Node is added, convert it to Sequence
                                       /*if(result.length==1 && wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().nodes.length<1
                                         && wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().Nodetype!="P"){
                                        result[0].Nodetype="S";
                                       }*/
                                       if(wftree.getSelectedIndex()==-1 && wftree.getModel("workflow").oData.nodes.length==0){
//                                        for(var i=0;i<result.length;i++){
//                                               wftree.getModel("workflow").oData.nodes.push(result[i]);
//                                           }
                                        for(var i=0;i<oControllerS3.flatObj.length;i++){
                                               var op="";
                                               if(i==oControllerS3.flatObj.length-1){
                                                      op='INTRAY';
                                               }
                                               if(oControllerS3.flatObj[i].Days == undefined || oControllerS3.flatObj[i].Days == ""){
                                                oControllerS3.flatObj[i].Days = 0;
                                               }
                                       oModel.setUseBatch(true);
                                       // create batch operation
                                       var batchOp = oModel.createBatchOperation(
                                                     "/FILE_PROUTE_ES", 'POST',
                                                                   {
                                                                         "isParallel" : oControllerS3.flatObj[i].isParallel,
                                                                         "Nodetype" : oControllerS3.flatObj[i].Nodetype,
                                                                         "Actdc" : oControllerS3.flatObj[i].Actdc,
                                                                         "Activity" : oControllerS3.flatObj[i].Activity,
                                                                         "CaseGuid" : oControllerS3.caseguid,
                                                                         "OrgObj" : oControllerS3.flatObj[i].OrgObj,
                                                                         "WitemId" : '',
                                                                         "Agent" :oControllerS3.flatObj[i].Agent, 
                                                                         "op" : op,
//                                                                         "Stext" : oControllerS3.flatObj[i].Stext,
                                                                         "DueDays" : oControllerS3.flatObj[i].Days,
                                                                         "PosidLed" : oControllerS3.flatObj[i].PosidLed,
                                                                   });
                                       
                                       
                                       // add batch operation
                                       oModel.addBatchChangeOperations([ batchOp ]);
                                        }
                                        
                                        oModel
                                           .submitBatch(
                                                         function(oResponse, oData) {
                                                          
                                                          if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {
                                                            var resObj = oResponse.__batchResponses[oResponse.__batchResponses.length - 1].__changeResponses[0]; // Response
//                                                                      sap.m.MessageToast
//                                                                                    .show(oControllerS3.getView().getModel("i18n").getObject("SAVESUCCESS"));
                                                           oControllerS3.loadTreeTable();
                                                           wftree.expand(wftree.getSelectedIndex());
                                                                      oControllerS3.saveFlag=false;
                                                                      oControllerS3.updateWorkflowFlag=false;
                                                               } else if(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf("<severity>warning</severity>") != -1 || oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf('"severity":"warning"') != -1){
                                                                sap.m.MessageBox.confirm(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                                  oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers),
                                                               function(response) {
                                     if (response == "OK") {
                                      oControllerS3.customBusyDialogOpen();
                                      //eotValue = 'X';
                                      oControllerS3.updateFile('X');

                                     }
                                                                   });
                                                               }
                                   else {
                                                                      sap.m.MessageBox
                                                                                    .alert(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                                                   oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers));
//return;
                                                               }
                                                               oControllerS3.customBusyDialogClose();
                                                         }, function(oResponse) {
                                                          oControllerS3.customBusyDialogClose();
                                                         },true); 
                                        
                                       
                                       }
                                       else{
                                        var parentId="0000",isSpecial=null;
                                        if(wftree.getSelectedIndex()!=-1){
                                         parentId = wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().Posid;
                                         if(wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().isSpecial=="X"){
                                          isSpecial='X';
                                         }
                                           }
                                        
//                                        for(var i=0;i<oControllerS3.flatObj.length;i++){
                                        if(oControllerS3.flatObj[0].PosidLed!="" && oControllerS3.flatObj[0].Days!=""){
                                              sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_89"));
                                              oControllerS3.customBusyDialogClose();
                                              return;
                                             }
                                        for(var i=oControllerS3.flatObj.length-1;i>=0;i--){
                                               var op="";
//                                               if(i==oControllerS3.flatObj.length-1){
                                               if(i==0){
                                                      op="INTRAY";
                                               }
                                               if(oControllerS3.flatObj[i].Nodetype=="P"){
                                                oControllerS3.flatObj[i].isParallel='X';
                                               }
                                               // To add in sequence after the parallel block (Nodetype='P' and isParallel='')
//                                               if(wftree.getSelectedIndex()!=-1){
                                               if( isSpecial && oControllerS3.flatObj[i].Nodetype=="S"){
                                                oControllerS3.flatObj[i].Nodetype="P";
                                                oControllerS3.flatObj[i].isParallel="";
                                               }
//                                               }
                                           if(sap.ui.getCore().byId("rightTree").getModel().getData().results[0].Type=="Sequence"){   
                                        var obj = {
                                             "isParallel" : oControllerS3.flatObj[i].isParallel,
                                                         "Actdc" : oControllerS3.flatObj[i].Actdc,
                                                         "Activity" : oControllerS3.flatObj[i].Activity,
                                                         "Agent" :oControllerS3.flatObj[i].Agent,
                                                         "Nodetype" : oControllerS3.flatObj[i].Nodetype,
                                                         "op" : "INTRAY",
//                                                         "CaseGuid" : oControllerS3.caseguid,
//                                                         "OrgObj" : oControllerS3.flatObj[i].OrgObj,
//                                                         "WitemId" : '',
                                                         "CaseGuid" : oControllerS3.caseguid,
                                                         "Fullname" : oControllerS3.flatObj[i].Stext,
                                                         "PosidLed" : "",
                                                         "DueDays" : 0,                                                         
                                                         "Parentid" : parentId,
                                                         "WitemId" : "",
                                                          };
                                        
                                        var oWfModel = oControllerS3.getView().getModel();
                      oWfModel
                        .create(
                          "/FILE_PROUTE_ES",
                          obj,
                          {
                           success : function(oResponse) {
                            oControllerS3.customBusyDialogClose();
                            // Reloading the workflow
                            // and closing the busy
                            // indicator
//                            oControllerS3
//                              .loadTreeTable();
//                            wftree.expand(wftree.getSelectedIndex());

                           },
                           error : function(oResponse) {

                            // through the error and
                            // close the busy indicator
                            oControllerS3
                              .customBusyDialogClose();
                            sap.m.MessageBox.alert(oControllerS3.getView()
                              .getModel("i18n").getObject("MESSAGE_68"));
                           },
                           async : true,
                          });
                       oControllerS3.loadTreeTable();
//                       oControllerS3.customBusyDialogClose();
                                        }
                                        else if(sap.ui.getCore().byId("rightTree").getModel().getData().results[0].Type=="Parallel"){
                                         var oModel = oControllerS3.getView().getModel();
                                         oModel.setUseBatch(true);
                          var isParallel = "X";
                          var nodeType = "P";
                                         var batchOp = oModel
                 .createBatchOperation(
                   "/FILE_PROUTE_ES",
                   'POST',
                   {
                    "isParallel" : isParallel,
                    "Nodetype" : nodeType,
                    "Actdc" : oControllerS3.flatObj[i].Actdc,
                    "Activity" : oControllerS3.flatObj[i].Activity,
                    "CaseGuid" : oControllerS3.caseguid,
                    "WitemId" : "",
                    "Agent" : oControllerS3.flatObj[i].Agent,
                    "PosidLed" : "",
                    "DueDays" : 0,
                    "op" : op,
                    "Parentid" : parentId,
                   });

               // add batch operation
               oModel.addBatchChangeOperations([ batchOp ]);
               isParallel = 'X'; // all the rows inserted
                    // after the first one need
                    // to be inserted in
                    // parallel to it
              }

              // submit the batch and store the results
                                                                                               
                                       }
                                        oModel.submitBatch(function(oResponse, oData) {
                                       
                          // Success function
                          // Reloading the workflow and closing the busy
                          // indicator
                          oControllerS3.loadTreeTable();
//                          wftree.expand(wftree.getSelectedIndex());
                          oControllerS3.customBusyDialogClose();
                         }, function(oResponse) {
                          // failure function
                          // through the error and close the busy
                          // indicator
                          oControllerS3.customBusyDialogClose();
                         }, true);
                                        }
//                                       oControllerS3.saveFlag=true;
                                       
                                       if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                                           oEvent.getSource().getParent().close();
                                    } else {
                                           oEvent.getSource().getParent().getParent().close();
                                    }
                               },

                               convertToFlatForCreateWorkflow : function(result, i, level,type,fromSource) {
                                var factoryCalendar=sap.ui.getCore().byId("idFactoryCalendar").getValue();
                                      /*if (result[i].Text != "Sequence"
                                                    && result[i].Text != "Parallel"
                                                    && result[i].Text != "") {
                                      result[i].Label = level.toString();
                                          result[i].Actdc = sap.ui.getCore().byId("rightTree")
                                                        .getRows()[i].getCells()[2].getSelectedItem()
                                                        .getText();
                                          result[i].Activity = sap.ui.getCore().byId("rightTree")
                                                           .getRows()[i].getCells()[2].getSelectedItem()
                                                           .getKey();
                                             if (result[i].Type == "P") {
                                                    result[i].isParallel = true;
                                             } else {
                                                    result[i].isParallel = "";
                                             }
                                             oControllerS3.flatObj[oControllerS3.globalCounter] = result[i];
                                             oControllerS3.globalCounter++;
                                      }
                                      //        
                                      else{for ( var j = 0; j < result[i].nodes.length; j++) {
                                       oControllerS3.convertToFlatForCreateWorkflow(
                                                  result[i].nodes, j, result[i].Label + "_"
                                                               + (j + 1)); 
                                      }*/
                                 level=level.toString();
                                 if(result[i].Type=="Sequence"){
                                        result[i].Label=level.substring(0,level.length-1)+(parseInt(level.substring((level.length-1),(level.length)))-1).toString();
                                        var nodeType="S";
                                        for ( var j = 0; j < result[i].nodes.length; j++) {
                                           oControllerS3.convertToFlatForCreateWorkflow(
                                                      result[i].nodes, j, result[i].Label + "_"
                                                                   + (j + 1),nodeType);
                                        }
                                 }else if(result[i].Type=="Parallel"){
                                        result[i].Label=level.substring(0,level.length-1)+(parseInt(level.substring((level.length-1),(level.length)))-1).toString();
                                        var nodeType="P";
                                        for ( var j = 0; j < result[i].nodes.length; j++) {
                                           oControllerS3.convertToFlatForCreateWorkflow(
                                                      result[i].nodes, j, result[i].Label + "_"
                                                                   + (j + 1),nodeType);
                                        }
                                 }else{
                                             result[i].Label = level.toString();
                                             if(result[i].Fullname=="" || result[i].Fullname==undefined){
                                             result[i].Fullname = result[i].Stext;
                                             }else{
                                              result[i].Stext=result[i].Fullname;
                                             }
                                             if(sap.ui.getCore().byId("rightTree").getRows().length!=0){
                                            if(fromSource=="createWF"){
                                             result[i].Actdc = sap.ui.getCore().byId("rightTree")
                                                     .getRows()[i+1].getCells()[2].getSelectedItem().getText(); // not a correct way TEMPORARY FIX
                                             result[i].Activity = sap.ui.getCore().byId("rightTree")
                                                        .getRows()[i+1].getCells()[2].getSelectedItem()
                                                        .getKey();
                                             }
                                             }
                                             result[i].OrgObj=factoryCalendar;
                                         if (type == "P") {
                                                result[i].isParallel = 'X';
                                         } else {
                                                result[i].isParallel = "";
                                         }
                                         oControllerS3.flatObj[oControllerS3.globalCounter] = result[i];
                                         oControllerS3.globalCounter++;
                                 }
                                      
                                      
                                      // }

//                                      
                               },


                                  /* Functions for the DOCUMENTS panel starts */
                               onLinkPress : function(oEvent) {
                                   
                                   oControllerS3.customBusyDialogOpen();
                                   var temp = oEvent.getSource().getParent().getParent()
                                                        .getParent().getParent().getBindingContext(
                                                                     "global");
                                          oControllerS3.documentId = oEvent.getSource().getModel(
                                                        "global").getObject(temp.getPath());
//                                   oControllerS3.documentId = oItem.getSource()
//                                                 .getParent().getParent().getParent()
//                                                 .getParent().getBindingContext("global");
                                   var isAttachment = null;
                                   
                                   isAttachment = oControllerS3.documentId.IsAttachment;

                                   if (isAttachment) {
                                    //Check for versions
                                    oModel = new sap.ui.model.json.JSONModel();
                                       // if(oControllerS3.documentId<gResponse.length){
                                       oModel.loadData(serviceUrl
                                                     + "/FILE_DOC_FI?param_1='AV'&param_2='"
                                                     + oControllerS3.caseguid
                                                     + "'&param_3='"
                                                     + oControllerS3.fileid
                                                     + "'&param_4='"
                                                     + encodeURIComponent(oControllerS3.documentId.DocumentName)
                                                     + "'&param_5=''", null, false);
                                       
                                       if(oModel.getData().d.results[0].msg_type=='E'){
                                        sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                                        oControllerS3.customBusyDialogClose();
                                        return;
                                       }
                                          if (oModel.oData.d.results.length > 1) {
                                                 if(!oControllerS3.oVersion){
                                                        oControllerS3.oVersion = sap.ui.xmlfragment(
                                                               "flm.fiori.view.attachmentVersion",
                                                               oControllerS3);
                                                 }
                                                 oControllerS3.oVersion.open();
                                                 sap.ui.getCore().byId("idButtonAddLink")
                                                               .setVisible(false);
                                                 sap.ui.getCore().byId("idCli")
                                                               .setType("Active");
                                                 var oTable = sap.ui.getCore().byId(
                                                               "idVersionsTable");
                                                 oTable.setModel(oModel, "versionModelDetail");
                                          }
                                          else {
                                                               if (oEvent.getSource().getBindingContext(
                                                                      "global").getObject().IsAttachment) {
                                                               var v = 1;
                                                               
                                                               oModel = new sap.ui.model.json.JSONModel();
                                                               // success
                                                               oModel
                                                                            .attachRequestCompleted(
                                                                                          this,
                                                                                          function(oEvent) {
                                                                                                 oModel
                                                                                                               .detachRequestCompleted();
                                                                                                 if (oModel.getData().d.results[0].msg_type != "E") {
                                                                                                        if (oModel
                                                                                                                      .getData().d.results[0].Url != "") {
                                                                                                               window
                                                                                                                            .open(oModel
                                                                                                                                          .getData().d.results[0].Url);
                                                                                                        }
                                                                                                 } else {
                                                                                                        sap.m.MessageBox
                                                                                                                      .alert(oModel
                                                                                                                                   .getData().d.results[0].msg_text);
                                                                                                 }
                                                                                                 
                                                                                                 oControllerS3
                                                                                                               .customBusyDialogClose();

                                                                                          }, this);
                                                               // Failure
                                                               oModel.attachRequestFailed(this, function(
                                                                            oEvent) {
                                                                     
                                                                      oControllerS3.customBusyDialogClose();
                                                                      oModel.detachRequestCompleted();
                                                                     oModel.detachRequestFailed();
                                                               }, this);
                                                               oModel
                                                                            .loadData(
                                                                                          serviceUrl
                                                                                                        + "/FILE_DOC_FI?param_1='AU'&param_2='"
                                                                                                        + v
                                                                                                        + "'&param_3='"
                                                                                                        + oControllerS3.documentId.AttachmentLoioID
                                                                                                        + "'&param_4='"
                                                                                                        + oControllerS3.documentId.DocumentClass
                                                                                                        + "'&param_5=''",
                                                                                          null, true);
                                                               // var url = oModel.oData.d.results[0].Url;
                                                               // window.open(url);
                                                               // oControllerS3.customBusyDialogClose();
                                                        }
                                                 }
                                   } else if (oControllerS3.documentId.IsFile) {
                                          
                                          //oControllerS3.fromSamePath = true;
                                   if (oEvent.getSource().getBindingContext("global")
                                                                     .getObject().CaseGuid != oControllerS3.caseguid) {

                                                               // check for authorization to display the file
                                                               var authModel = new sap.ui.model.json.JSONModel();
                                                               authModel
                                                                            .loadData(
                                                                                          serviceUrl
                                                                                                        + "/FILES_FI?param_1='OA'&param_2='"
                                                                                                        + oEvent
                                                                                                                      .getSource()
                                                                                                                      .getBindingContext(
                                                                                                                                   "global")
                                                                                                                      .getObject().CaseGuid
                                                                                                        + "'&param_3=''&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                                                                          null, false);
                                                               if (authModel.getData().d.results.length == 0) {
                                                                      oControllerS3.navBackArrS3.push({
                                                                            caseguid : oControllerS3.caseguid,
                                                                            fileid : oControllerS3.fileid,
                                                                            wiId : "0",
                                                                            fromTab : "DRAFT",
                                                                     });
                                                                      
//                                                                      if(authModel.getData().d.results[0].msg_type=='E'){
//                                                                       sap.m.MessageBox.alert(authModel.getData().d.results[0].msg_text);
//                                                                       oControllerS3.customBusyDialogClose();
//                                                                       return;
//                                                                      }
                                                                     //oControllerS3.fromSamePath = true;
                                                                     oControllerS3.fromTab = "DOCUMENT";
                                                                     oControllerS1.tabType = "draft";
                                                                      oControllerS3.getView().byId("dynamicAttrForm").destroyContent();
                                                                      oControllerS3.customBusyDialogClose();
                                                                      oControllerS3.oRouter.navTo("subscreen", {
                                                                            caseguid : oEvent.getSource()
                                                                                          .getBindingContext("global")
                                                                                          .getObject().CaseGuid,
                                                                            fileid : oEvent.getSource()
                                                                                          .getBindingContext("global")
                                                                                          .getObject().FileID,
                                                                            wiId : "0"
                                                                     });
                                                               } else if (authModel.getData().d.results[0].msg_type == "E") {
                                                                     sap.m.MessageBox
                                                                                   .alert(authModel.getData().d.results[0].msg_text);
                                                                     return;
                                                                      oControllerS3.customBusyDialogClose();
                                                               }
                                                        }

                                                 } else if(oControllerS3.documentId.IsIpi){
                                                  oModel = new sap.ui.model.json.JSONModel();
                                                     // success
                                                     oModel
                                                                  .attachRequestCompleted(
                                                                                this,
                                                                                function(oEvent) {
                                                                                       oModel
                                                                                                     .detachRequestCompleted();
                                                                                       if (oModel.getData().d.results[0].msg_type != "E") {
                                                                                              if (oModel
                                                                                                            .getData().d.results[0].Url != "") {
                                                                                                     window
                                                                                                                  .open(oModel
                                                                                                                                .getData().d.results[0].Url);
                                                                                              }
                                                                                       } else {
                                                                                              sap.m.MessageBox
                                                                                                            .alert(oModel
                                                                                                                         .getData().d.results[0].msg_text);
                                                                                       }
                                                                                       
                                                                                       oControllerS3
                                                                                                     .customBusyDialogClose();

                                                                                }, this);
                                                     // Failure
                                                     oModel.attachRequestFailed(this, function(
                                                                  oEvent) {
                                                           
                                                            oControllerS3.customBusyDialogClose();
                                                            oModel.detachRequestCompleted();
                                                           oModel.detachRequestFailed();
                                                     }, this);
                                                     oModel
                                                                  .loadData(
                                                                                serviceUrl
                                                                                              + + "/FILE_DOC_FI?param_1='DU'&param_2='"
                                                          + encodeURIComponent(oControllerS3.documentId.DocumentName)
                                                        + "'&param_3=''&param_4=''&param_5=''",
                                                                                null, true);
                                                     // var url = oModel.oData.d.results[0].Url;
                                                     // window.open(url);
                                                     // oControllerS3.customBusyDialogClose();
                                              //}
                                                 }else if (oControllerS3.documentId.IsDaak) {
                                                    
                                             if (oEvent.getSource().getBindingContext("global")
                                                                               .getObject().CaseGuid != oControllerS3.caseguid) {

                                                                          oControllerS3.navBackArrS3.push({
                                                                                      caseguid : oControllerS3.caseguid,
                                                                                      fileid : oControllerS3.fileid,
                                                                                      wiId : "0",
                                                                                      fromTab : oControllerS3.fromTab,
                                                                               });
  //                                                                        oControllerS3.fromSameDaak = true;
                                                                          oControllerS3.fromTab = "DOCUMENT";
                                                                               oControllerS1.tabType = "document";
                                                                               oControllerS3.getView().byId("dynamicAttrForm").destroyContent();
                                                                               oControllerS3.customBusyDialogClose();
 //                                                                              docGuid = oEvent.getSource().getBindingContext("global ").getObject().CaseGuid;
 //                                                                              docFileid = oEvent.getSource().getBindingContext("global ").getObject().FileID;
 //                                                                              docWiid = "0" ;
                                                             oControllerS3.oRouter.navTo("daakdocscreen", {
                                                                            caseguid : oEvent.getSource()
                                                                                          .getBindingContext("global")
                                                                                          .getObject().CaseGuid,
                                                                      });
                                                                              
                                                                  }

                                                           }
                                                 else {

                                                        oModel = new sap.ui.model.json.JSONModel();
                                                        // success
                                                        oModel
                                                                     .attachRequestCompleted(
                                                                                   this,
                                                                                   function(oEvent) {
                                                                                          oModel.detachRequestCompleted();
                                                                                          if (oModel.getData().d.results[0].msg_type != "E") {
                                                                                                 if (oModel.getData().d.results[0].Url != "") {
                                                                                                        window
                                                                                                                      .open(oModel
                                                                                                                                   .getData().d.results[0].Url);
                                                                                                 }
                                                                                          } else {
                                                                                                 sap.m.MessageBox
                                                                                                               .alert(oModel
                                                                                                                            .getData().d.results[0].msg_text);
                                                                                          }
                                                                                          
                                                                                          oControllerS3
                                                                                                        .customBusyDialogClose();

                                                                                    }, this);
                                                        
                                                        if (oControllerS3.documentId.IsObject) {

                                       oModel.loadData(serviceUrl
                                         + "/FILE_DOC_FI?param_1='OB'&param_2='"
                                         + oControllerS3.documentId.BorID
                                         + "'&param_3='"
                                         + oControllerS3.documentId.ElementType
                                         + "'&param_4='"
                                         + oControllerS3.documentId.BorType
                                         + "'&param_5=''", null, true);

                                      } else if (oControllerS3.documentId.IsReport) {

                                       oModel
                                         .loadData(
                                           serviceUrl
                                             + "/FILE_DOC_FI?param_1='OR'&param_2='"
                                             + oControllerS3.documentId.Variant
                                             + "'&param_3='"
                                             + oControllerS3.documentId.ElementType
                                             + "'&param_4=''&param_5=''",
                                           null, true);
                                      }
                                                 }
                            },
                                  
                                  confirmDelete : function(evt) {

                    var oItem = evt.getSource();
                    if (oItem.getBindingContext("global").getObject().DeleteEnabledRef
                      && oItem.getBindingContext("global")
                        .getObject().NotingEnabledRef) {
                     sap.m.MessageBox
                       .confirm(
                         oControllerS3.getView().getModel("i18n").getObject("MESSAGE_32"),
                         function(response) {
                          if (response == "OK") {
                           oControllerS3
                             .deleteAttachment(
                               evt, oItem);
                          } else {
                           return;
                          }
                         });
                    } else {

                     sap.m.MessageBox.confirm(
                       oControllerS3.getView().getModel("i18n").getObject("MESSAGE_33"),
                       function(response) {
                        if (response == "OK") {
                         oControllerS3.deleteAttachment(evt,
                           oItem);
                        } else {
                         return;
                        }
                       });
                     // oControllerS3.deleteAttachment(evt,oItem);
                    }
                   },

                                  downloadAttachment : function(oEvent) {

                                         oControllerS3.customBusyDialogOpen();
                                         var version = 1;
                       oModel = new sap.ui.model.json.JSONModel();
                       version = oEvent.getSource().getCells()[0].getText();
                        oControllerS3.customBusyDialogOpen();
                        oModel.loadData(serviceUrl
                          + "/FILE_DOC_FI?param_1='AU'&param_2='" + version
                          + "'&param_3='"
                          + oControllerS3.documentId.AttachmentLoioID
                          + "'&param_4='"
                          + oControllerS3.documentId.DocumentClass
                          + "'&param_5=''", null, false);
                        if(oModel.getData().d.results[0].msg_type=='E'){
                         sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                         oControllerS3.customBusyDialogClose();
                         return;
                         }

                       var url = oModel.oData.d.results[0].Url;

                       window.open(url);// window.open(url);
                       oControllerS3.customBusyDialogClose();
                                /*         var doc_num = null;
                                         oModel = new sap.ui.model.json.JSONModel();
                                         // if(oControllerS3.documentId<gResponse.length){
                                         oModel.loadData(serviceUrl
                                                       + "/FILE_DOC_FI?param_1='AV'&param_2='"
                                                       + this.caseguid
                                                       + "'&param_3='"
                                                       + this.fileid
                                                       + "'&param_4='"
                                                       + oControllerS3.documentId.DocumentName
                                                       + "'&param_5=''", null, false);
                                         if(oModel.getData().d.results[0].msg_type=='E'){
                                          sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                                          oControllerS3.customBusyDialogClose();
                                          return;
                                         }
                                         doc_num = oControllerS3.documentId.DocumentName;

                                         var l = oModel.oData.d.results;
                                         if (l.length > 1) {
                                                v = oEvent.getSource().getCells()[0].getText() - 1;
                                         } else {
                                                var v = 0;
                                         }
//                                         var url = "proxy/http/ldcixka.wdf.sap.corp:50018/sap/bc/doc_download";
                                        var url = "/sap/bc/doc_download";
                                         url += "?guid='" + this.caseguid + "'&doc_name='"
                                                       + doc_num + "'&phys_version='"
                                                       + l[v].PhysVersion + "'&version='"
                                                       + l[v].Version + "'";
                                         window.open(url);
                                         oControllerS3.customBusyDialogClose();*/
                                  },

                                  onDialogCloseButton : function(oEvent) {
                                   oControllerS3.customBusyDialogClose();
                                                       if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                                                              oEvent.getSource().getParent().close();
                                                       } else {
                                                              oEvent.getSource().getParent().getParent().close();
                                                       }
                                                },
                                                
                                                onDialogCloseButtonF4 : function(oEvent) {
                                                                     if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                                                                            oEvent.getSource().getParent().close();
                                                                     } else {
                                                                            oEvent.getSource().getParent().getParent().close();
                                                                     }
                                                              },
                                                              
                                                              
                                 onWorkflowDialogCloseButton : function(oEvent){
                                  oControllerS3.oCreateWorkflow.close(); 
                                 },
                                                addHyperlinkClick : function(oEvent) {

                                                    var flag='N';
                                                    if(oEvent.getSource().getTarget()=="_self"){
                                                           flag='N';
                                                    }else{
                                                           flag='D';
                                                    }
                                                     
                                                       oControllerS3.customBusyDialogOpen();
                                                       oControllerS3.documentId = oEvent.getSource()
                                                                     .getParent().getParent().getParent()
                                                                     .getParent().getBindingContext("global");
                                                       oControllerS3.documentId.getModel().oData.attachments.flag=flag; //to check whether noting or description
                                                       oModel = new sap.ui.model.json.JSONModel();
                                                       
                                                       
                                                       if(oControllerS3.documentId.getObject().IsAttachment){
                                                       // if(oControllerS3.documentId<gResponse.length){
                                                       oModel.loadData(serviceUrl
                                                                     + "/FILE_DOC_FI?param_1='AV'&param_2='"
                                                                     + oControllerS3.caseguid
                                                                     + "'&param_3='"
                                                                     + oControllerS3.fileid
                                                                     + "'&param_4='"
                                                                     + encodeURIComponent(oControllerS3.documentId
                                                                                   .getProperty("DocumentName"))
                                                                     + "'&param_5=''", null, false);
                                                       if(oModel.getData().d.results[0].msg_type=='E'){
                                                        sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                                                        oControllerS3.customBusyDialogClose();
                                                        return;
                                                       }
                                                       if (oModel.oData.d.results.length > 1) {
                                                           if(!oControllerS3.oVersion){
                                                                                      oControllerS3.oVersion = sap.ui.xmlfragment(
                                                                                             "flm.fiori.view.attachmentVersion",
                                                                                            oControllerS3);
//                                                                                    oModel.oData.d.results.flag=flag; //to check whether to add in noting or description
                                                                               }
                                                                               oControllerS3.oVersion.open();
                                                               sap.ui.getCore().byId("idButtonAddLink")
                                                                             .setVisible(true);
                                                               sap.ui.getCore().byId("idCli").setType("Inactive");
                                                               var oTable = sap.ui.getCore().byId(
                                                                             "idVersionsTable");
                                                               oTable.setModel(oModel, "versionModelDetail");
                                                        } else {
                                                               oControllerS3.attachHyperlink(oEvent);
                                                        } 
                                                       }else{
                                                        oControllerS3.attachHyperlink(oEvent);
                                                       }
//                                                       oControllerS3.customBusyDialogClose();
                                                },

                                                attachHyperlink : function(oEvent) {
                                                       
                                                       var flag='N';
                                                       oControllerS3.customBusyDialogOpen();
                                                       var hyperText = null;
                                                       oModel = new sap.ui.model.json.JSONModel();
                                                       var v = 1;
                                                                       oModel = new sap.ui.model.json.JSONModel();
                                                                       var temp = true;
                                                                       
                                                                       try {
                                                                              var temp2 = oEvent.getSource().getParent()
                                                                                           .getCells();
                                                                       } catch (err) {
                                                                              temp = false;
                                                                       }
                                                       
                                                    // success
                                                                       oModel.attachRequestCompleted(this, function(oEvent) {
                                                                           
                                                                           if(oModel.getData().d.results[0].msg_type=='E'){
                                                                            sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                                                                            oControllerS3.customBusyDialogClose();
                                                                            return;
                                                                           }
                                                                           hyperText = oControllerS3.documentId.getProperty("DocumentName");
                                                                           if(oControllerS3.documentId.getModel().oData.attachments.flag=='N'){
                                                                                  var e = oControllerS3.getView().byId("notingEditor");
                                                                           }else {
                                                                                  var e = oControllerS3.getView().byId("descrEditor");
                                                                                  oControllerS3.saveFlag=true;
                                                                           }
                                                                           
                                                                           var link=oModel.oData.d.results[0].Url;
                                                                           link=link.split('?');
                                                                           if(link[0].indexOf("ContentServer.dll")!=-1){
                                                                            if(link[1]){
                                                                                   link[1]=link[1].replace(/\(/g,"%28");
                                                                                   link[1]=link[1].replace(/\)/g,"%29");
                                                                                   link=link[0]+"?"+link[1];
                                                                                   }
                                                                                   else{
                                                                                    link=link[0];
                                                                                   }
                                                                           }
                                                                           else if(link[0].indexOf("sap/bc/gui/sap/its")!=-1){
                                                                            if(link[1]){
                                                                                   link[1]=link[1].replace(/\=/g,"%3D");
                                                                                   link[1]=link[1].replace(/\=/g,"%3D");
                                                                                   link=link[0]+"?"+link[1];
                                                                                   }
                                                                                   else{
                                                                                    link=link[0];
                                                                                   } 
                                                                           }
                                                                           e.setValue(e.getValue() +" "+ "<p><a href='"
                                                                                        + link
                                                                                        + "' target='_blank'>" + hyperText + "</a></p>");
                                                                           sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_85"));
                                                                           oModel.detachRequestCompleted();
                                                                           oControllerS3.customBusyDialogClose();

                                                                    }, this);

                                                                       oControllerS3.customBusyDialogOpen();
                                                                if (temp) {
                                                                       v = oEvent.getSource().getParent().getCells()[0]
                                                                                     .getText();
                                                                       oModel.loadData(serviceUrl
                                                                                     + "/FILE_DOC_FI?param_1='AU'&param_2='" + v
                                                                                     + "'&param_3='"
                                                                                     + oControllerS3.documentId.getProperty("AttachmentLoioID")
                                                                                     + "'&param_4='"
                                                                                     + oControllerS3.documentId.getProperty("DocumentClass")
                                                                                     + "'&param_5=''", null, true);
                                                                       
                                                                } else {
                                                                       if (oEvent.getSource().getBindingContext("global")
                                                                                     .getObject().IsAttachment) {
                                                                              oModel
                                                                                           .loadData(
                                                                                                         serviceUrl
                                                                                                                       + "/FILE_DOC_FI?param_1='AU'&param_2='"
                                                                                                                       + v
                                                                                                                       + "'&param_3='"
                                                                                                                       + oControllerS3.documentId.getProperty("AttachmentLoioID")
                                                                                                                       + "'&param_4='"
                                                                                                                       + oControllerS3.documentId.getProperty("DocumentClass")
                                                                                                                       + "'&param_5=''", null,
                                                                                                         true);
                                                                              
                                                                       } else if (oControllerS3.documentId.getObject().IsObject) {

                                                                              oModel.loadData(serviceUrl
                                                                                           + "/FILE_DOC_FI?param_1='OB'&param_2='"
                                                                                           + oControllerS3.documentId.getProperty("BorID")
                                                                                           + "'&param_3='"
                                                                                           + oControllerS3.documentId.getProperty("ElementType")
                                                                                           + "'&param_4='"
                                                                                           + oControllerS3.documentId.getProperty("BorType")
                                                                                           + "'&param_5=''", null, true);
                                                                              
                                                                       } else if (oControllerS3.documentId.getObject().IsReport) {

                                                                              oModel
                                                                                           .loadData(
                                                                                                         serviceUrl
                                                                                                                       + "/FILE_DOC_FI?param_1='OR'&param_2='"
                                                                                                                       + oControllerS3.documentId.getProperty("Variant")
                                                                                                                       + "'&param_3='"
                                                                                                                       + oControllerS3.documentId.getProperty("ElementType")
                                                                                                                       + "'&param_4=''&param_5=''",
                                                                                                         null, true);
                                                                              
                                                                       }else if (oControllerS3.documentId.getObject().IsIpi) {

                                                                           oModel
                                                                                        .loadData(
                                                                                          serviceUrl
                                                      + "/FILE_DOC_FI?param_1='DU'&param_2='"
                                                      + encodeURIComponent(oControllerS3.documentId.getProperty("DocumentName"))
                                                      + "'&param_3=''&param_4=''&param_5=''",
                                                    null, true);
                                                                           
                                                                    }
                                                                }
                                                       
                                                },

deleteAttachment : function(oEvent,oItem) {
                                    
                                    oControllerS3.customBusyDialogOpen();
                                    var temp = oItem.getBindingContext("global");
                                                oControllerS3.documentId = oItem.getModel("global")
                                                              .getObject(temp.getPath());


                                    oModel = new sap.ui.model.json.JSONModel();
                                    
                                    oModel
                                                       .attachRequestCompleted(
                                                                     oEvent,
                                                                     function(oEvent) {
                                                                      
                                                                            oModel.detachRequestCompleted();
                                                                            
                                                                            var err = oModel.oData.d.results[0];
                                                                           if (err != undefined
                                                                                         && err.msg_type == 'E') {
                                                                                  sap.m.MessageBox
                                                                                                .alert(err.msg_text);
                                                                                  // sap.m.MessageToast.show(err.msg_text);
                                                                           } else {
                                                                                  
                                                                                  var k = oControllerS3.documentId;
                                                         var deleteNode = oItem.getParent()
                                                                       .getParent().getParent().getParent()
                                                                       .getParent().getId();
                                                         var oAttachmentList=oControllerS3.getView().getModel("global").oData.attachments;
                                                         // oEvent.getSource().getParent().getParent().getParent().destroy();
                                                         for ( var i = 0; i < oAttachmentList.length; i++) {
                                                                if (k.DocumentName == oAttachmentList[i].DocumentName) {
                                                                       oAttachmentList.splice(i,1);
                                                                       break;
                                                                }
                                                        }
                                                         oControllerS3.getView().getModel("global").refresh();
                                                         var heading = sap.ui.getCore()
                                                                                         .byId(deleteNode)
                                                                                         .getTitle().getText();
                                                                            var subHead1 = heading
                                                                                         .substring(
                                                                                                       0,
                                                                                                       heading
                                                                                                                     .lastIndexOf("("));
                                                                            var subHead2 = heading
                                                                                         .substring(
                                                                                                       heading
                                                                                                                     .lastIndexOf("(") + 1,
                                                                                                       heading
                                                                                                                     .lastIndexOf(")"));
                                                                            sap.ui
                                                                                         .getCore()
                                                                                         .byId(deleteNode)
                                                                                         .getTitle()
                                                                                         .setText(
                                                                                                       subHead1
                                                                                                                     + " ("
                                                                                                                     + (--subHead2)
                                                                                                                     + ")");

                                                                             oControllerS3.customBusyDialogClose();

                                                         sap.m.MessageToast
                                                                       .show(oControllerS3.getView().getModel("i18n").getObject("MESSAGE_15"));
                                                                           }

                                                                           oControllerS3
                                                                                         .customBusyDialogClose();

                                                                     }, oControllerS3);
                                    // if(oControllerS3.documentId<gResponse.length){
                                    if (oControllerS3.documentId
                                                  .IsAttachment) {
                                           oModel.loadData(serviceUrl
                                                         + "/FILE_DOC_FI?param_1='DA'&param_2='"
                                                         + oControllerS3.caseguid
                                                         + "'&param_3='"
                                                         + encodeURIComponent(oControllerS3.documentId
                                                                      .DocumentName)
                                                         + "'&param_4='"
                                                         + oControllerS3.documentId
                                                                      .DocumentType
                                                         + "'&param_5=''", null, true);
                                           
                                    } else if (oControllerS3.documentId
                                                  .IsFile
                                                  || oControllerS3.documentId
                                                                .IsObject
                                                  || oControllerS3.documentId
                                                                .IsReport) {
                                           oModel.loadData(serviceUrl
                                                         + "/FILE_DOC_FI?param_1='DO'&param_2='"
                                                         + oControllerS3.caseguid
                                                         + "'&param_3='"
                                                         + encodeURIComponent(oControllerS3.documentId
                                                                      .DocumentName)
                                                         + "'&param_4='"
                                                         + oControllerS3.documentId
                                                                       .CaseGuid
                                                         + "'&param_5='" + oControllerS3.wiId + "'",
                                                        null, true);
                                           
                                    }else if(oControllerS3.documentId.IsIpi){
                                      oModel.loadData(serviceUrl
                                                 + "/FILE_DOC_FI?param_1='DD'&param_2='"
                                                 + oControllerS3.caseguid
                                                 + "'&param_3='"
                                                 + encodeURIComponent(oControllerS3.documentId
                                                              .DocumentName)
                                                 + "'&param_4='000000000000'&param_5=''",
                                                null, true);
                                    }
                                    
                             },


                                  uploadActionsOpen : function(oEvent) {

                                         
                                         if (oControllerS3.caseguid == "") {
                                                sap.m.MessageToast.show(oControllerS3.getView().getModel("i18n").getObject("MESSAGE_14"));
                                         } else {
                                                var oButton = oEvent.getSource();
                                                oControllerS3.uploadNode = this.getParent();
                                                if (!oControllerS3._uploadActionSheet || oControllerS3._uploadActionSheet.getButtons().length == 0){
                                                       oControllerS3._uploadActionSheet = sap.ui
                                                                     .xmlfragment(
                                                                                  "flm.fiori.view.uploadButton",
                                                                                  oControllerS3);
                                                       oControllerS3.getView().addDependent(
                                                                     oControllerS3._uploadActionSheet);
                                                       if (oControllerS3.data.buttons.ISATTACHMENT == false) {
                                                              sap.ui.getCore().byId("attachmentAction")
                                                                           .setVisible(false);
                                                       }
                                                       if (oControllerS3.data.buttons.ISIPI == false) {
                                                              sap.ui.getCore().byId("ipiAction")
                                                                           .setVisible(false);
                                                       }
                                                       if (oControllerS3.data.buttons.ISFILE == false) {
                                                              sap.ui.getCore().byId("fileAction")
                                                                           .setVisible(false);
                                                       }
                                                       if (oControllerS3.data.buttons.ISOBJECT == false) {
                                                              sap.ui.getCore().byId("objectAction")
                                                                           .setVisible(false);
                                                       }
                                                       if (oControllerS3.data.buttons.ISREPORT == false) {
                                                              sap.ui.getCore().byId("reportAction")
                                                                           .setVisible(false);
                                                       }
                                                }
                                                jQuery.sap.delayedCall(0, this, function() {
                                                      oControllerS3._uploadActionSheet
                                                                     .openBy(oButton);
                                                });
                                         }
                                 },

                                  attachmentButtonPressed : function(oEvent) {
                                         oControllerS3.isAttachment = true;
                                         oControllerS3.isFile = false;
                                         oControllerS3.isReport = false;
                                         oControllerS3.isObject = false;
                                         oControllerS3.isIPI = false;
                                         //this.attachmentDialog = null;
                                         if(!oControllerS3.attachmentDialog){
                                         oControllerS3.attachmentDialog = sap.ui.xmlfragment(
                                                       "flm.fiori.view.attachment", oControllerS3);
                                         }
                                        sap.ui.getCore().byId("idDocNumber").setValue("");
                       sap.ui.getCore().byId("idFileUpload").setValue("");
                       sap.ui.getCore().byId("idKey1").setValue("");
                       sap.ui.getCore().byId("idKey2").setValue("");
                       sap.ui.getCore().byId("idKey3").setValue("");
                       sap.ui.getCore().byId("idKey4").setValue("");
                       sap.ui.getCore().byId("idKey5").setValue("");
                                         var docType = sap.ui.getCore().byId("idDocumentType");
                                         var ddModel = new sap.ui.model.json.JSONModel();
                                         ddModel
                                                       .loadData(serviceUrl
                                                                     + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and OtherF4 eq true and ID eq 'DT'");
                                         docType.setModel(ddModel);

                                         oControllerS3.attachmentDialog.open();
                                  },

                                  fileButtonPressed : function(oEvent) {
                                         oControllerS3.isAttachment = false;
                                         oControllerS3.isFile = true;
                                         oControllerS3.isReport = false;
                                         oControllerS3.isObject = false;
                                         oControllerS3.isIPI = false;
                                        // this.fileDialog = null;
                                         if(! oControllerS3.fileDialog){
                                          oControllerS3.fileDialog = sap.ui.xmlfragment(
                                                       "flm.fiori.view.file",  oControllerS3);
                                         }
                                         sap.ui.getCore().byId("idFileNumber").setValue("");
                                         oControllerS3.fileDialog.open();
                                  },

                                  attachNewVersion : function(oEvent) {
                                        
                                         if(! oControllerS3.versionDialog){
                                         oControllerS3.versionDialog = sap.ui.xmlfragment(
                                                       "flm.fiori.view.newVersion", oControllerS3);
                                         }
                                         sap.ui.getCore().byId("idFileUploaderNV").setValue("");
                       sap.ui.getCore().byId("idKey1NV").setValue("");
                       sap.ui.getCore().byId("idKey2NV").setValue("");
                       sap.ui.getCore().byId("idKey3NV").setValue("");
                       sap.ui.getCore().byId("idKey4NV").setValue("");
                       sap.ui.getCore().byId("idKey5NV").setValue("");
                                         oControllerS3.documentId = oEvent.getSource()
                                                       .getParent().getParent().getParent()
                                                       .getParent().getBindingContext("global");

                                         oModel = new sap.ui.model.json.JSONModel();
                                         oModel.attachRequestCompleted(this, function(oEvent) {
                        oModel.detachRequestCompleted();
                        if(oModel.getData().d.results[0].msg_type=='E'){
                                             sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
                                             oControllerS3.customBusyDialogClose();
                                             return;
                                            }
                        var keys = oModel.oData.d.results[0];
                        sap.ui.getCore().byId("idKey1NV").setValue(
                          keys.Keyword1);
                        sap.ui.getCore().byId("idKey2NV").setValue(
                          keys.Keyword2);
                        sap.ui.getCore().byId("idKey3NV").setValue(
                          keys.Keyword3);
                        sap.ui.getCore().byId("idKey4NV").setValue(
                          keys.Keyword4);
                        sap.ui.getCore().byId("idKey5NV").setValue(
                          keys.Keyword5);
                        oControllerS3.customBusyDialogClose();
                        oControllerS3.versionDialog.open();

                       }, oControllerS3);

                       // if(oControllerS2.documentId<gResponse.length){
                       oControllerS3.customBusyDialogOpen();
                        oModel.loadData(serviceUrl
                                               + "/FILE_DOC_FI?param_1='NV'&param_2='"
                                               + oControllerS3.caseguid
                                               + "'&param_3='"
                                              + encodeURIComponent(oControllerS3.documentId
                                                             .getProperty("DocumentName"))
                                               + "'&param_4=''&param_5=''", null, true);

                                         // if(oControllerS3.documentId<gResponse.length){
//                                         oModel.loadData(serviceUrl
//                                                       + "/FILE_DOC_FI?param_1='NV'&param_2='"
//                                                       + oControllerS3.caseguid
//                                                       + "'&param_3='"
//                                                      + oControllerS3.documentId
//                                                                     .getProperty("DocumentName")
//                                                       + "'&param_4=''&param_5=''", null, false);
//
//                                         var keys = oModel.oData.d.results[0];
//                                         sap.ui.getCore().byId("idKey1NV").setValue(
//                                                       keys.Keyword1);
//                                         sap.ui.getCore().byId("idKey2NV").setValue(
//                                                       keys.Keyword2);
//                                         sap.ui.getCore().byId("idKey3NV").setValue(
//                                                       keys.Keyword3);
//                                         sap.ui.getCore().byId("idKey4NV").setValue(
//                                                       keys.Keyword4);
//                                         sap.ui.getCore().byId("idKey5NV").setValue(
//                                                       keys.Keyword5);
//                                         oControllerS3.versionDialog.open();

                                  },

                                  onCloseButton : function(oEvent) {
                    if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
                     oEvent.getSource().getParent().close();
                    } else {
                     oEvent.getSource().getParent().getParent().close();
                    }

                   },

                                  onOkButton : function(oEvent) {
                                    
                                         var oAttachmentList=oControllerS3.getView().getModel("global").oData.attachments;
                                         
                                         var i = 0, doc_num, flag = false;
                                         if (oControllerS3.isFile) {
                                                doc_num = sap.ui.getCore().byId("idFileNumber");
                                         } else if (oControllerS3.isAttachment) {
                                                doc_num = sap.ui.getCore().byId("idDocNumber");
                                         }
                                         
                                         for (i = 0; i < oAttachmentList.length; i++) {
                                                // if(!isFile && (gResponse[i].IsAttachment ||
                                                // gResponse[i].IsObject || gResponse[i].IsReport)){
                                                if (doc_num.getValue() == oAttachmentList[i].DocumentName) {
                                                       sap.m.MessageToast
                                                                     .show(this.getView().getModel("i18n").getObject("MESSAGE_35"));
                                                       flag = true;
                                                       break;
                                                }
                                                // }
                                         }

                                         if (oControllerS3.isAttachment && !flag) {
                                                var doc_num = sap.ui.getCore().byId("idDocNumber")
                                                              .getValue();
                                                var doc_type = sap.ui.getCore().byId(
                                                              "idDocumentType").getSelectedItem()
                                                              .getKey();
                                                var oFUploader = sap.ui.getCore().byId(
                                                              "idFileUpload");
//                                                oFUploader.setUploadUrl("proxy/https/ldcixka.wdf.sap.corp:44318/sap/bc/doc_upload");
                                                oFUploader.setUploadUrl("/sap/bc/doc_upload");
                                                if (doc_num.match(/\s/g)){
                            sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_72"));
                            return;
                           }
                                               if (oFUploader.getValue() == "" || doc_num == ""
                                                              || doc_type == "") {
                                                       sap.m.MessageToast
                                                                     .show(this.getView().getModel("i18n").getObject("MESSAGE_36"));
                                                }else if (doc_num.length > 60) {
                            sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_37"));
                    return;
                                                }else {
                                                       var par_id = oControllerS3.uploadNode
                                                                     .getBindingContext("global").getProperty(
                                                                                  "RowKey"); // PARENTKEY
                                                       var wf_id = ""; // WIID
                                                       var key_1 = sap.ui.getCore().byId("idKey1")
                                                                     .getValue();
                                                       var key_2 = sap.ui.getCore().byId("idKey2")
                                                                     .getValue();
                                                       var key_3 = sap.ui.getCore().byId("idKey3")
                                                                     .getValue();
                                                       var key_4 = sap.ui.getCore().byId("idKey4")
                                                                     .getValue();
                                                       var key_5 = sap.ui.getCore().byId("idKey5")
                                                                     .getValue();
                                                       var sInfo = '[{"CASE_GUID":"'
                                                                     + oControllerS3.caseguid
                                                                     + '","PAR_ID":"' + par_id
                                                                     + '","WF_ID":"' + wf_id
                                                                     + '","DOC_NUM":"' + doc_num
                                                                     + '","DOC_TYPE":"' + doc_type
                                                                     + '","KEY_1":"' + key_1 + '","KEY_2":"'
                                                                     + key_2 + '","KEY_3":"' + key_3
                                                                     + '","KEY_4":"' + key_4 + '","KEY_5":"'
                                                                     + key_5 + '"}]';

                                                       oFUploader.setAdditionalData(sInfo);
                                                       oControllerS3.customBusyDialogOpen();
                               oFUploader.attachUploadComplete(oControllerS3,
                                 function(oEvent) {
                                  oControllerS3
                                    .customBusyDialogClose();
                                 }, oControllerS3);
                                                       oFUploader.upload();
                                                }
                                         } else if (oControllerS3.isFile && !flag) {
                                                var today = new Date();
                                                var file_name = sap.ui.getCore().byId(
                                                              "idFileNumber").getValue();
                                                if (file_name == "") {
                                                 sap.m.MessageBox
                      .alert(this.getView().getModel("i18n").getObject("MESSAGE_36"));
                                                 return;
                                                }if (this.getView().byId("idInputFileNumber").getValue() == file_name) {
                            sap.m.MessageBox
                      .alert(this.getView().getModel("i18n").getObject("MESSAGE_44"));
                    return;
                   } else {
                                                       
                                                       oModel = new sap.ui.model.json.JSONModel();
//                                                       oModel.loadData(serviceUrl
//                                                                     + "/FILE_DOC_FI?param_1='AF'&param_2='"
//                                                                     + oControllerS3.caseguid
//                                                                     + "'&param_3='"
//                                                                     + file_name
//                                                                     + "'&param_4=''&param_5='"
//                                                                     + oControllerS3.uploadNode
//                                                                                  .getBindingContext("global")
//                                                                                  .getProperty("RowKey") + "'",
//                                                                     null, false);
                                                       oModel.attachRequestCompleted(
                           oEvent,
                           function(oEvt) {
                            oModel
                              .detachRequestCompleted();
                                                       var fileUploadResponse = oModel.oData.d.results[0];
                                                       if (fileUploadResponse.msg_type != "E") {
                                                              var doc_num = file_name;

                                                              var vData = {
                                                                       "CaseGuid" : fileUploadResponse.CaseGuid,
                                                                                                "Wiid" : "",
                                                                                                "FileID" : fileUploadResponse.FileID,
                                                                                                "DocumentName" : decodeURIComponent(doc_num),
                                                                                                "DocumentType" : "FIL",
                                                                                                "FileName" : "File",
                                                                                                "CreatedByName" : fileUploadResponse.CreatedByName,
                                                                                                "CreatedOn" : fileUploadResponse.CreatedOn/*today
                                                                                                              .toLocaleDateString().replace(
                                                                                                                            "/", ".").replace("/",
                                                                                                                            ".")
                                                                                                              + " "
                                                                                                              + today.toTimeString().substr(
                                                                                                                            0, 8)*/,
                                                                                                "FileTitle" : fileUploadResponse.FileTitle,//decodeURIComponent(fileUploadResponse.FileTitle),
                                                                                                "FileSizeDescr" : fileUploadResponse.FileSize,
                                                                                                "DocumentClass" : fileUploadResponse.DocClass,
                                                                                                "AttachmentLoioID" : fileUploadResponse.DocGuid,
                                                                                                "ParentKey" : oControllerS3.uploadNode
                                                                                                              .getBindingContext("global")
                                                                                                              .getProperty("RowKey"),
                                                                                                "IsAttachment" : oControllerS3.isAttachment,
                                                                                                "IsFile" : oControllerS3.isFile,
                                                                                                "IsObject" : oControllerS3.isObject,
                                                                                                "IsIpi" : oControllerS3.isIpi,
                                                                                                "IsReport" : oControllerS3.isReport,
                                                                                                "DeleteEnabledRef" : true,
                                                                                                "NotingEnabledRef" : false,
                                                              };

                                                              oControllerS3.getView().getModel("global").oData.attachments.push(vData);
                                                            //oControllerS3.getView().getModel("global").refresh();
                                                              oControllerS3
                .getView()
                .getModel(
                  "global")
                .checkUpdate();
                                                              sap.m.MessageToast
                                                                           .show(this.getView().getModel("i18n").getObject("MESSAGE_38"));
                                                              sap.ui.getCore().byId("idFileDialog").close();
                                                       var heading = oControllerS3.uploadNode.getTitle().getText();

         var subHead1 = heading.substring(0,heading.lastIndexOf("("));
         var subHead2 = heading.substring(heading.lastIndexOf("(") + 1, heading
           .lastIndexOf(")"));
         oControllerS3.uploadNode.getTitle()
           .setText(
             subHead1 + " ("
               + (++subHead2)

               + ")");


                                                       } else {
                                                              sap.m.MessageBox
                                                                           .alert(fileUploadResponse.msg_text);
                                                       }
                                                       oControllerS3
              .customBusyDialogClose();
                                                       
                                                }, oControllerS3);
                                                       oControllerS3.customBusyDialogOpen();
                               oModel.loadData(serviceUrl
                                 + "/FILE_DOC_FI?param_1='AF'&param_2='"
                                 + oControllerS3.caseguid
                                 + "'&param_3='"
                                 + encodeURIComponent(file_name)
                                 + "'&param_4=''&param_5='"
                                 + oControllerS3.uploadNode
                                   .getBindingContext("global")
                                   .getProperty("RowKey") + "'",
                                 null, true);
                  }
                                         }
                                  },


                                  onUploadComplete : function(oEvent) {
                                         
                                         var today = new Date();
                                         var sResponse = oEvent.getParameter("response");
                                         var resToken = sResponse.split(',');
                                         var fileAttr = new Array();
                                         var nameVal, statusMsg = "", statusIcon = null;
                                         for ( var i = 0; i < resToken.length; ++i) {
                                                nameVal = resToken[i].split('::');
                                                fileAttr[nameVal[0]] = nameVal[1];
                                         }
                                         if (fileAttr["Status"] == "Successful") {
                                                var doc_num = sap.ui.getCore().byId("idDocNumber")
                                                              .getValue();
                                                var doc_type = sap.ui.getCore().byId(
                                                              "idDocumentType").getSelectedItem();
                                                var vData = {
                                                       "DocumentName" : doc_num,
                                                       "DocumentType" : doc_type.getKey(),
                                                       "FileName" : doc_type.getText(),
                                                       "CreatedByName" : fileAttr["UploadedBy"],
                                                       "CreatedOn" : fileAttr["CreatedOn"]/*today.toLocaleDateString()
                                                                     .replace("/", ".").replace("/", ".")
                                                                     + " "
                                                                     + today.toTimeString().substr(0, 8)*/,
                                                       "FileTitle" : fileAttr["AttachmentName"],
                                                       "FileSizeDescr" : fileAttr["FileSize"],
                                                       "DocumentClass" : fileAttr["DocClass"],
                                                       "AttachmentLoioID" : fileAttr["DocGuid"],
                                                      "ParentKey" : oControllerS3.uploadNode
                                                                     .getBindingContext("global").getProperty(
                                                                                  "RowKey"),
                                                       "IsAttachment" : oControllerS3.isAttachment,
                                                       "IsFile" : oControllerS3.isFile,
                                                       "IsObject" : oControllerS3.isObject,
                                                       "IsIpi" : oControllerS3.isIpi,
                                                       "IsReport" : oControllerS3.isReport,
                                                       "DeleteEnabledRef" : true,
                                                       "NotingEnabledRef" : true,
                                                };
                                                oControllerS3.getView().getModel("global").oData.attachments.push(vData);
//                                                oControllerS3.getView().getModel("global").oData.push(vData);
                                                oControllerS3.getView().getModel("global").refresh();
                                                sap.m.MessageToast
                                                              .show(this.getView().getModel("i18n").getObject("MESSAGE_38"));
                                                sap.ui.getCore().byId("idAttachmentDialog").close();
                                                var heading = oControllerS3.uploadNode.getTitle().getText();

                     var subHead1 = heading.substring(0,heading.lastIndexOf("("));
                     var subHead2 = heading.substring(heading.lastIndexOf("(") + 1, heading
                       .lastIndexOf(")"));
                     oControllerS3.uploadNode.getTitle()
                       .setText(
                         subHead1 + " ("
                           + (++subHead2)

                           + ")");

                                         } else {
                                                sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_39"));
                                         }
                                         oControllerS3.customBusyDialogClose();
                                  },

                                  onNVOkButton : function(oEvent) {
                                      oControllerS3.customBusyDialogOpen();
                                                         oControllerS3.versionDialog.close();
                                           var i = 0;
                                           var doc_num, doc_type, doc_class, doc_guid;
                                           doc_num = oControllerS3.documentId
                                                         .getProperty("DocumentName");
                                           doc_type = oControllerS3.documentId
                                                         .getProperty("DocumentType");
                                           doc_class = oControllerS3.documentId
                                                         .getProperty("DocumentClass");
                                           doc_guid = oControllerS3.documentId
                                                         .getProperty("AttachmentLoioID");
                                           var oFUploader = sap.ui.getCore().byId(
                                                         "idFileUploaderNV");
                                           if (oFUploader.getValue() == "") {
                                                                sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_36"));
                                                                return;
                                                                } 
//                                           oFUploader.setUploadUrl("proxy/https/ldcixka.wdf.sap.corp:44318/sap/bc/doc_upload");
                                          oFUploader.setUploadUrl("/sap/bc/doc_upload");
                                           var par_id = oControllerS3.uploadNode; // PARENTKEY
                                           var wf_id = "0"; // WIID
                                           var key_1 = sap.ui.getCore().byId("idKey1NV")
                                                         .getValue();
                                           var key_2 = sap.ui.getCore().byId("idKey2NV")
                                                         .getValue();
                                           var key_3 = sap.ui.getCore().byId("idKey3NV")
                                                         .getValue();
                                           var key_4 = sap.ui.getCore().byId("idKey4NV")
                                                         .getValue();
                                           var key_5 = sap.ui.getCore().byId("idKey5NV")
                                                         .getValue();
                                           var sInfo = '[{"CASE_GUID":"' + oControllerS3.caseguid
                                                         + '","PAR_ID":"' + par_id + '","WF_ID":"'
                                                         + wf_id + '","DOC_CLASS":"' + doc_class
                                                        + '","DOC_GUID":"' + doc_guid + '","DOC_NUM":"'
                                                         + doc_num + '","DOC_TYPE":"' + doc_type
                                                         + '","KEY_1":"' + key_1 + '","KEY_2":"' + key_2
                                                         + '","KEY_3":"' + key_3 + '","KEY_4":"' + key_4
                                                         + '","KEY_5":"' + key_5 + '"}]';

                                           oFUploader.setAdditionalData(sInfo);
                                           oFUploader.attachUploadComplete(oControllerS3,
                                                                       function(oEvent) {
                                                                              oControllerS3.customBusyDialogClose();
                                                                       }, oControllerS3);
                                           oFUploader.upload();
                                    },

                                    onUploadCompleteNV : function(oEvent) // uploading new
                                    // version
                                    {
                                      oControllerS3.customBusyDialogOpen();
                                           var sResponse = oEvent.getParameter("response");
                                           var resToken = sResponse.split(',');
                                           var fileAttr = new Array();
                                           var nameVal, statusMsg = "", statusIcon = null;
                                           for ( var i = 0; i < resToken.length; ++i) {
                                                  nameVal = resToken[i].split(':');
                                                  fileAttr[nameVal[0]] = nameVal[1];
                                           }
                                           if (fileAttr["Status"] == "Successful") {
                                                  sap.m.MessageToast
                                                                .show(this.getView().getModel("i18n").getObject("MESSAGE_40"));
                                                  oControllerS3.documentId.getObject().DeleteEnabledRef = false;
                                                  oControllerS3.getView().getModel("global")
                                                                       .checkUpdate();
                                                  sap.ui.getCore().byId("idNewVersionUpload").close();
                                           } else {
                                                  sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_41"));
                                           }
                                           oControllerS3.customBusyDialogClose();
                                    },

                                
                                  /* Functions for the DOCUMENTS panel ends */

                                  // /////////////////////////////////////////////////////
                                  setInitialModels : function(controller) {
                                         
                                         oModel = controller.getView().getModel();
                                         var oBatchOp = oModel.createBatchOperation(
                                                       "/FILE_F4_ES?$filter=CaseGuid+eq+'"
                                                                     + this.caseguid
                                                                     + "'+and+ID+eq+'PRIO'+and+FileID+eq+'"
                                                                     + this.fileid + "'+and+FileType+eq+'"
                                                                     + this.filetype + "'", 'GET');
                                         oModel.addBatchReadOperations([ oBatchOp ]);
                                         
//                                         var wfInfoVal;
//                                                            if(this.oSource.getController().wfInfo == undefined){
//                                                                   wfInfoVal = '';
//                                                            }else{
//                                                                   wfInfoVal = this.oSource.getController().wfInfo.replace(" ", "***");
//                                                            }
                                                              
                                       if(oControllerS3.fromTab=="CREATE"){
                                       oBatchOp = oModel
                                                     .createBatchOperation(
                                                                   "/FILE_BUTTONS_ES(GUID='',TABTYPE='"+this.fromTab+"',FILEID='',FILETYPE='"
                                                                                + this.filetype + "',WIID='',ISDAAK=false)",'GET');
                                       }else{
                                        oBatchOp = oModel
                                           .createBatchOperation(
                                                         "/FILE_BUTTONS_ES(GUID='"+this.caseguid+"',TABTYPE='"+this.fromTab+"',FILEID='',FILETYPE='',WIID='',ISDAAK=false)",'GET'); 
                                       }
                                       oModel.addBatchReadOperations([ oBatchOp ]);
//                                       if(this.caseguid == undefined){
//                                       oBatchOp = oModel
//                                                                   .createBatchOperation(
//                                                                                "/FILE_NOTING_ES?$filter=TabType+eq+'CREATE'+and+CaseGuid+eq+''+and+Wiid+eq+''+and+Wfinfo+eq+''", 'GET');
//                                  }else{
//                                  oBatchOp = oModel
//                                                                   .createBatchOperation(
//                                                                                "/FILE_NOTING_ES?$filter=TabType+eq+'CREATE'+and+CaseGuid+eq+'"
//                                                                                              + this.caseguid
//                                                                                              + "'+and+Wiid+eq+'"
//                                                                                              + this.wiId
//                                                                                              + "'+and+Wfinfo+eq ''", 'GET');
//                                  }
//                                                     oModel.addBatchReadOperations([ oBatchOp ]);
                                         if(oControllerS3.fromTab=="CREATE"){
                                         oBatchOp = oModel
                                                       .createBatchOperation(
                                                                     "/FILE_DOC_FI?param_1='FS'&param_2='"
                                                                                  + this.filetype
                                                                                  + "'&param_3=''&param_4=''&param_5=''",
                                                                     'GET');
                                         }else{
                                                oBatchOp = oModel
                                            .createBatchOperation(
                                                          "/FILE_DOC_FI?param_1='FS'&param_2='"
                                                                       + this.caseguid
                                                                       + "'&param_3=''&param_4=''&param_5=''",
                                                          'GET');
                                         }
                                         oModel.addBatchReadOperations([ oBatchOp ]);

                                         oBatchOp = oModel
                                                       .createBatchOperation(
                                                                     "/FILE_F4_ES?$filter=CaseGuid+eq+'"
                                                                                         + this.caseguid
                                                                                         + "'+and+OtherF4+eq+true+and+ID+eq+'WC'",
                                                                     'GET');
                                         oModel.addBatchReadOperations([ oBatchOp ]);
                                         
                                         if(oControllerS3.fromTab=="CREATE"){
                                         oBatchOp = oModel.createBatchOperation(
                                                       "/FILE_NUMBER_ES?$filter=FILETYPE+eq+'"
                                                                     + this.filetype + "'", 'GET');
                                         oModel.addBatchReadOperations([ oBatchOp ]);
                                         }
                                         
                                         oBatchOp = oModel
                                         .createBatchOperation("/FILE_ATTR_ES?$filter=GUID+eq+'"
                                                                           + this.caseguid
                                                                           + "'+and+FILETYPE+eq+'"
                                                       + this.filetype + "'+and+TABTYPE+eq+'"+this.fromTab+"'", 'GET');
                                         oModel.addBatchReadOperations([ oBatchOp ]);
                                        
                                         //basic attributes
                                         oBatchOp = oModel.createBatchOperation(
                                                                     "/FILE_BASIC_ES(CaseGuid='" + this.caseguid
                                                                                  + "',TabType='" + this.fromTab
                                                                                  + "',FileType='"+this.filetype+"',ExtKey='"
                                                                                  + this.fileid + "',Wiid='',ISDAAK=false)", 'GET');
                                         oModel.addBatchReadOperations([ oBatchOp ]);
                                                                             
                                         //documents
                                         oBatchOp = oModel
                                                                    .createBatchOperation(
                                                                                 "/FILE_DOCUM_ES?$filter=Guid+eq+'"
                                                                                               + this.caseguid
                                                                                               + "'+and+TabType+eq+'"+this.fromTab+"'+and+Wiid+eq+''+and+FileID+eq+'"
                                                                                               + this.fileid + "'",
                                                                                 'GET');
                                         oModel.addBatchReadOperations([ oBatchOp ]);
                                         
                                         //notings
                                         oBatchOp = oModel.createBatchOperation(
                                                                           "/FILE_NOTING_ES?$filter=TabType+eq+'"
                                                                                         + this.fromTab
                                                                                         + "'+and+CaseGuid+eq+'"
                                                                                         + this.caseguid
                                                                                         + "'+and+Wiid+eq+''+and+Wfinfo+eq+''", 'GET');
                                         oModel.addBatchReadOperations([ oBatchOp ]);
                                         oModel
                                         .submitBatch(
                                                       function(oResponse, oData) {
                                                        
                                                              
                                                              var i = 0;
                                                              if(oResponse.__batchResponses[i].message==undefined){
                                                              controller.data.priority = oResponse.__batchResponses[i].data.results;
                                                              }
                                                              else{
                                                               sap.m.MessageBox.alert(oResponse.__batchResponses[i].message);
                                                               oControllerS3.initFlag=false;
                                                               return;
                                                              }
                                                              i++;
                                                              
                                                              if(oResponse.__batchResponses[i].message==undefined){
                                                               controller.data.buttons = oResponse.__batchResponses[i].data;
                                                               }
                                                                  else{
                                                                   sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                 oResponse.__batchResponses[i].response.headers));
                                                                   oControllerS3.initFlag=false;
                                                                   return;
                                                                  }
                                                                   i++;
// controller.data.notes = oResponse.__batchResponses[i].data.results;
// i++;
                                                                  
                                                                   if(oResponse.__batchResponses[i].message==undefined){
                                                                    controller.data.folders = oResponse.__batchResponses[i].data.results;
                                                                    }
                                                                       else{
                                                                        sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                        oResponse.__batchResponses[i].response.headers));
                                                                       
                                                                        oControllerS3.initFlag=false;
                                                                        return;
                                                                       }
                                                                    i++;
                                                                    
                                                                    if(oResponse.__batchResponses[i].message==undefined){
                                                                     controller.data.privateNote = oResponse.__batchResponses[i].data.results;
                                                                     }
                                                                        else{
                                                                         sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                         oResponse.__batchResponses[i].response.headers));
                                                                         oControllerS3.initFlag=false;
                                                                         return;
                                                                        }
                                                                     i++;
                                                                    
                                                                     if(oControllerS3.fromTab=="CREATE"){
                                                                     if(oResponse.__batchResponses[i].message==undefined){
                                                                      controller.data.fileNumber = oResponse.__batchResponses[i].data.results;
                                                                      if(controller.data.fileNumber.length==0){
                                                                       sap.m.MessageBox.alert(oControllerS3.getView().getModel("i18n").getObject("MESSAGE_55"));
                                                                       oControllerS3.initFlag=false;
                                                                          return;
                                                                      }
                                                                      }
                                                                         else{
                                                                          sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                          oResponse.__batchResponses[i].response.headers));
                                                                          oControllerS3.initFlag=false;
                                                                          return;
                                                                          }
                                                                     i++;
                                                                     }
                                                                     
                                                                     if(oResponse.__batchResponses[i].message==undefined){
                                                                      controller.data.dynamic = oResponse.__batchResponses[i].data.results;
                                                                      }
                                                                         else{
                                                                          sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                          oResponse.__batchResponses[i].response.headers));
                                                                          oControllerS3.initFlag=false;
                                                                          return;
                                                                          }
                                                                     i++;
                                                                     
                                                                     if(oResponse.__batchResponses[i].message==undefined){
                                                                      controller.data.basic = oResponse.__batchResponses[i].data;
                                                                         }
                                                                         else{
                                                                          sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                          oResponse.__batchResponses[i].response.headers));
                                                                          oControllerS3.initFlag=false;
                                                                          return;
                                                                          }
                                                                     i++;
                                                                     
                                                                     if(oResponse.__batchResponses[i].message==undefined){
                                                                      controller.data.attachments = oResponse.__batchResponses[i].data.results;
                                                                     /* for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                             var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].FileTitle);
                             oResponse.__batchResponses[i].data.results[j].FileTitle = subValue;
                           }*/
                                                                         }
                                                                         else{
                                                                          sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                          oResponse.__batchResponses[i].response.headers));
                                                                          oControllerS3.initFlag=false;
                                                                          return;
                                                                          }
                                                                     i++;
                                                                     
                                                                     if(oResponse.__batchResponses[i].message==undefined){
                                                                      if (oResponse.__batchResponses[i].data.results.length == 0) {
                                                                      oControllerS3
                   .getView()
                   .byId(
                     "notingEditor")
                   .setValue(
                     "");
                                                                      
                 controller.data.notes = oResponse.__batchResponses[i].data.results;
                  for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                   try{
                    oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                                                        }catch(err){
                                                         oResponse.__batchResponses[i].data.results[j].actNote = oResponse.__batchResponses[i].data.results[j].NotingString;
                                                        }

                     }
                                                                      }
                                                                      else if (oResponse.__batchResponses[i].data.results.length > 0) {
                                                                      if (oResponse.__batchResponses[i].data.results[oResponse.__batchResponses[i].data.results.length - 1].ANotingString != "") {

                          var assistNoting = oResponse.__batchResponses[i].data.results[oResponse.__batchResponses[i].data.results.length - 1].ANotingString;
                          oControllerS3
                            .getView()
                            .byId(
                              "notingEditor")
                            .setValue(
                              assistNoting);
                           oResponse.__batchResponses[i].data.results
                    .splice(
                      oResponse.__batchResponses[i].data.results.length - 1,
                      1);
                                                                      controller.data.notes = oResponse.__batchResponses[i].data.results;
                                                                       for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                                                                        try{
                                                                         oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                                                          }catch(err){
                                                           oResponse.__batchResponses[i].data.results[j].actNote = oResponse.__batchResponses[i].data.results[j].NotingString;
                                                          }

                             //oControllerS3.getView().byId("notes").setContent(decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString));
                            }
                                                                      }
                                                                     else {
                          oControllerS3
                            .getView()
                            .byId(
                              "notingEditor")
                            .setValue(
                              "");
                          controller.data.notes = oResponse.__batchResponses[i].data.results;
                           for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                             try{
                             oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                                                                 }catch(err){
                                                                  oResponse.__batchResponses[i].data.results[j].actNote = oResponse.__batchResponses[i].data.results[j].NotingString;
                                                                 }

                             //oControllerS3.getView().byId("notes").setContent(decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString));
                            }
                         }
                                                                              }
                                                                     }
                                                                         else{
                                                                          sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                                          oResponse.__batchResponses[i].response.headers));
                                                                          oControllerS3.initFlag=false;
                                                                          return;
                                                                          }
                                                                     mparams = controller.data.dynamic; 
                                                                     controller.getView().byId("dynamicAttrForm").destroyContent();
                                                                     controller.dynUIAssistArr = createDynamicUI(mparams, controller,
                                                                                  controller.getView(), "dynamicAttrForm",
                                                                                  false);
                                                                     controller.getView().getModel("global").checkUpdate();
                                                                     controller.createFileResponse = controller.data.fileNumber;
                                                                     
                                                       }, function(oResponse) {
                                                              
                                                       }, false);

                                  },
                                  
                                  
                                  updateFile : function(eotValue){
                                     // var eotValue = '';
                                   if(eotValue == undefined){
                                    eotValue = '';
                                   }
                                      var oModel = new sap.ui.model.odata.ODataModel(
                                              serviceUrl);
                                oModel.setUseBatch(true);
// var result =
// oControllerS3.getView().byId("wftree").getModel("workflow").oData.nodes;
// oControllerS3.globalCounter = 0;
// oControllerS3.flatObj = new Array();
                                      var result = oControllerS3.flatObj;
// for ( var i = 0; i < result.length; ++i) {
// oControllerS3.convertToFlat(result, i, i + 1);
// }
                                    // read basic attr
                                        var obj = {};

                                        obj.PlanEndDate = oControllerS3.getView().byId(
                                                      "idDuedate").getValue();
                                        obj.Priority = oControllerS3.getView().byId(
                                                      "idPrioSelect").getSelectedItem().getKey();
                                        obj.CaseTitle = oControllerS3.getView().byId(
                                                      "idShortText").getValue();
                                        if(oControllerS3.getView().byId("descrEditor").getValue() == ""){
                                        obj.Description = "<p></p>";
                                        }else{
                                         obj.Description = encodeURIComponent(oControllerS3.getView().byId(
                                            "descrEditor").getValue());
                                        }
//                                        obj.Description = oControllerS3.getView().byId(
//                                              "descrEditor").getValue();
                                        obj.CaseGuid = oControllerS3.caseguid;
                                        // create batch operation
                                        var batchOp = oModel.createBatchOperation(
                                                                       "/FILE_BASIC_ES(ExtKey='',CaseGuid='" + oControllerS3.caseguid
                                                                                    + "',FileType='',TabType='"
                                                                                    + oControllerS3.fromTab + "',Wiid='',ISDAAK=false)", 'PUT',
                                                                       obj);

                                        // add batch operation
                                        oModel.addBatchChangeOperations([ batchOp ]);
// this.dynUIAssistArr=this.getView().getModel("global").oData.dynamic;
                                        // read dynamic attributes
                                        for ( var i = 0; i < this.dynUIAssistArr.length; ++i) {
                                               var value = "";
                                               switch (this.dynUIAssistArr[i].type) {
                                               case "IP":
                                                      value = sap.ui.getCore().byId(
                                                                    this.dynUIAssistArr[i].id).getValue();
                                                      break;
                                               case "F4":
                                                      value = sap.ui.getCore().byId(
                                                                    this.dynUIAssistArr[i].id).getValue();
                                                      break;
                                               case "DP":
                                                   value = sap.ui.getCore().byId(
                                                           this.dynUIAssistArr[i].id).getDateValue();
                                                if(value != null){
                                                 value = dateFormatter(value);
                                                }else{
                                                 value = "";
                                                }
                                                break;
                                               case "TP":
                                                      value = sap.ui.getCore().byId(
                                                                    this.dynUIAssistArr[i].id).getValue();
                                                      break;
                                               case "CB":
                                                      var t = sap.ui.getCore().byId(
                                                                    this.dynUIAssistArr[i].id).getState();
                                                      if(t){
                                                         value='X';
                                                      }else{
                                                         value="";
                                                      }
                                                      break;
                                               case "CU":
                                                      value = sap.ui.getCore().byId(
                                                                    this.dynUIAssistArr[i].id).getValue();
                                                      break;
                                               }

                                               // create batch operation
                                               var batchOp = oModel.createBatchOperation(
                                                             "/FILE_ATTR_ES(ID='"
                                                                             + this.dynUIAssistArr[i].id
                                                                             + "',TABTYPE='" + oControllerS3.fromTab
                                                                             + "')", 'PUT', {
                                                                    "ID" : this.dynUIAssistArr[i].id,
                                                                    "TYPE" : this.dynUIAssistArr[i].type,
                                                                    "VALUE" : value,
                                                                    "GUID" : oControllerS3.caseguid
                                                             });

                                               // add batch operation
                                               oModel.addBatchChangeOperations([ batchOp ]);

                                        }
                                        
                                     // create batch operation EOT
                                        var batchOp = oModel.createBatchOperation(
                                                      "/FILE_ATTR_ES(ID='" + "-1" /* this.dynUIAssistArr[i].id */
                                                                       + "',TABTYPE='" + oControllerS3.fromTab
                                                                       + "')", 'PUT', {
                                                             "ID" : 'EOT',
                                                             "FILETYPE" : '',// end of transfer
                                                             "GUID" : oControllerS3.caseguid,
                                                             "VALUE" : eotValue
                                                      });

                                        // add batch operation
                                        oModel.addBatchChangeOperations([ batchOp ]);
                                       
                                      //Saving Workflow
                                        if(oControllerS3.updateWorkflowFlag){
                                             for(var i=0;i<oControllerS3.flatObj.length;i++){
                                                    var op="";
                                                    if(i==oControllerS3.flatObj.length-1){
                                                           op='X';
                                                    }
                                            oModel.setUseBatch(true);
                                            // create batch operation
                                            var batchOp = oModel.createBatchOperation(
                                                          "/FILE_PROUTE_ES", 'POST',
                                                                        {
                                                                              "isParallel" : oControllerS3.flatObj[i].isParallel,
                                                                              "Activity" : oControllerS3.flatObj[i].Activity,
                                                                              "CaseGuid" : oControllerS3.caseguid,
                                                                              "OrgObj" : oControllerS3.flatObj[i].OrgObj,
                                                                              "WitemId" : '',
                                                                              "Agent" :oControllerS3.flatObj[i].Agent, 
                                                                              "op" : op,
//                                                                              "Stext" : oControllerS3.flatObj[i].Stext,
                                                                              "DueDays" : "0",
                                                                              "PosidLed" : "",
                                                                        });
                                            
                                            
                                            // add batch operation
                                            oModel.addBatchChangeOperations([ batchOp ]);
                                             }
                                        }
                                        
                                        
                                     
                                        
                                        
                                        // finally submit batch for both basic
          // and dynamic
                                        // attributes
                                        oModel
                                                      .submitBatch(
                                                                    function(oResponse, oData) {
                                                                    
                                                                     if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {
                                                                       var resObj = oResponse.__batchResponses[oResponse.__batchResponses.length - 1].__changeResponses[0]; // Response
                                                                                 sap.m.MessageToast
                                                                                               .show(oControllerS3.getView().getModel("i18n").getObject("SAVESUCCESS"));
                                                                                 oControllerS3.saveFlag=false;
                                                                                 oControllerS3.updateWorkflowFlag=false;
                                                                          } else if(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf("<severity>warning</severity>") != -1 || oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf('"severity":"warning"') != -1){
                                                                           sap.m.MessageBox.confirm(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                                             oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers),
                                                                          function(response) {
                                                if (response == "OK") {
                                                 oControllerS3.customBusyDialogOpen();
                                                 //eotValue = 'X';
                                                 oControllerS3.updateFile('X');

                                                }
                                                                              });
                                                                          }
                                              else {
                                                                                 sap.m.MessageBox
                                                                                               .alert(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                                                              oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers));
// return;
                                                                          }
// oControllerS3.filenumber = resObj.data.FILENUMBER;
// oControllerS3.fileid = resObj.data.FILEID;
// oControllerS3.caseguid = resObj.data.GUID;
// oControllerS3.digitalsign = resObj.DIGSIGNREQ;
                                                                          oControllerS3.customBusyDialogClose();
                                                                    }, function(oResponse) {
                                                                     oControllerS3.customBusyDialogClose();
                                                                    });

                                        // Saving Data ends

                                        },
                                  customBusyDialogOpen : function(busyText) {
                                                       if (!this._dialog) {

                                                              this._dialog = sap.ui.xmlfragment(
                                                                           "flm.fiori.view.busyDialog", this);
                                                              this.getView().addDependent(this._dialog);
                                                       }
                                                       if (busyText != null) {
                                                              this._dialog.setText(busyText);
                                                       } else {
                                                              this._dialog.setText("");
                                                       }

                                                       this._dialog.open();
                                                },

                                                customBusyDialogClose : function() {
                                                       // var dialog =
              // sap.ui.getCore().byId("idBusyDialog");
                                                       // jQuery.sap.delayedCall(2500,
        // this, function() {
                                                 this._dialog.close();
                                                       // });

                                                       // dialog.close();
                                                },
                                                
                                                onChangeFileAttribute : function(oEvent) {
                                                           oControllerS3.saveFlag = true;
                                                              },
                                                              
                                                              onParSelect : function(oEvent) {
                                                                     sap.ui.getCore().byId("idButtonAdd").setVisible(true);
                                                                     sap.ui.getCore().byId("idProcessorsTable").setVisible(
                                                                                  true);
                                                              },

                                                              onSeqSelect : function(oEvent) {
                                                                     sap.ui.getCore().byId("idButtonAdd").setVisible(false);
                                                                     sap.ui.getCore().byId("idProcessorsTable").setVisible(
                                                                                  false);
                                                              },
                                                              
                                                              onAddClick : function(oEvent) { // CHANGE
                                                                     
                                                                     var oTable = sap.ui.getCore().byId("idProcessorsTable");
                                                                     var processor = sap.ui.getCore().byId("idSelect1")
                                                                                  .getSelectedItem().getText();
                                                                     var sendTo = sap.ui.getCore().byId("idUsername")
                                                                                  .getValue();
                                                                     var agent = sap.ui.getCore().byId("idUsername")
                                                                                  .getName();
                                                                     var activity = sap.ui.getCore().byId("idSelect2")
                                                                                  .getSelectedItem().getText();
                                                                     var activityKey = sap.ui.getCore().byId("idSelect2")
                                                                                  .getSelectedItem().getKey();
                                                                     var processingDate = sap.ui.getCore().byId(
                                                                                  "idDatePickerSendTo").getValue();
                                                                     // var
                                                                     // processingTime=sap.ui.getCore().byId("idInputTime").getValue();
                                                                     var processingDay = sap.ui.getCore()
                                                                                  .byId("idInputDays").getValue();
                                                                     if ((sendTo == "" || activity == "" || processor == "")) {
                                                                           sap.m.MessageToast
                                                                                         .show(this.getView().getModel("i18n").getObject("MESSAGE_20"));
                                                                           return;
                                                                     }
                                                                     if (processingDate != "" && processingDay != "") {
                                                                           sap.m.MessageToast
                                                                                         .show(this.getView().getModel("i18n").getObject("MESSAGE_21"));
                                                                           return;
                                                                     }
                                                                     var oModel = oTable.getModel("dummy");
                                                                     oModel.getData().data.push({
                                                                           "Processor" : sap.ui.getCore().byId("idSelect1")
                                                                                         .getSelectedItem().getText(),
                                                                           "Name" : sap.ui.getCore().byId("idUsername")
                                                                                         .getValue(),
                                                                           "Agent" : sap.ui.getCore().byId("idUsername")
                                                                                         .getName(),
                                                                           "Activity" : sap.ui.getCore().byId("idSelect2")
                                                                                         .getSelectedItem().getKey(),
                                                                           "Actdc" : sap.ui.getCore().byId("idSelect2")
                                                                                         .getSelectedItem().getText(),
                                                                           "Date" : sap.ui.getCore()
                                                                                         .byId("idDatePickerSendTo").getValue(),
                                                                           "Days" : sap.ui.getCore().byId("idInputDays")
                                                                                         .getValue(),
                                                                           "position" : oControllerS3.gCounter++,
                                                                     });
                                                                     oModel.checkUpdate();

                                                              },
                                                              
                                                              trackedStateChange : function(oEvent) {
                                                                     
                                                                     
                                                                     if (this.getView().byId("idTrackFileSwitch").getState() == false) {
                                                                            oControllerS3.customBusyDialogOpen();
                                                                           var oModel = new sap.ui.model.json.JSONModel();
                                                                           oModel
                                                                                         .loadData(
                                                                                                       serviceUrl
                                                                                                                     + "/FILES_FI?param_1='UF'&param_2='"
                                                                                                                     + this.caseguid
                                                                                                                     + "'&param_3='"
                                                                                                                    + this.wiId
                                                                                                                     + "'&param_4='"
                                                                                                                     + this.fileid
                                                                                                                     + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                                                                                       null, false);
                                                                           if (oModel.getData().d.results.length == 0) {
                                                                                  // this.getView().byId("trackStatus").getModel("basic").getData().d.Track
                                                                                  // =
                     // false;
                                                                          this.getView().byId("idTrackFileSwitch").setTooltip(this.getView().getModel("i18n").getObject("OFF"));
                                                        this.getView().byId("idTrackFileSwitch").rerender();
                                                                                  sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_11"));
                                                                                  oControllerS3.customBusyDialogClose();
                                                                           } else if (oModel.getData().d.results[0].msg_type == 'E') {
                                                                                  sap.m.MessageBox
                                                                                  .alert(oModel.getData().d.results[0].msg_text);

                                                                           }
                                                                     } else if (this.getView().byId("idTrackFileSwitch")
                                                                                  .getState() == true) {
                                                                            oControllerS3.customBusyDialogOpen();
                                                                           var oModel = new sap.ui.model.json.JSONModel();
                                                                           oModel
                                                                                         .loadData(
                                                                                                       serviceUrl
                                                                                                                     + "/FILES_FI?param_1='TF'&param_2='"
                                                                                                                     + this.caseguid
                                                                                                                     + "'&param_3='"
                                                                                                                     + this.wiId
                                                                                                                     + "'&param_4='"
                                                                                                                     + this.fileid
                                                                                                                     + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                                                                                       null, false);
                                                                           if (oModel.getData().d.results.length == 0) {
                                                                                  // this.getView().byId("trackStatus").getModel("basic").getData().d.Track
                                                                                  // =
                     // true;
                                                                               this.getView().byId("idTrackFileSwitch").setTooltip(this.getView().getModel("i18n").getObject("ON"));
                                                          this.getView().byId("idTrackFileSwitch").rerender();
                                                                                  sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_43"));
                                                                                  oControllerS3.customBusyDialogClose();
                                                                           } else if (oModel.getData().d.results[0].msg_type == 'E') {
                                                                                  sap.m.MessageBox
                                                                                  .alert(oModel.getData().d.results[0].msg_text);
                                                                           }
                                                                     }
                                                              },
                                                              
                                                              confidentialStateChange : function(oEvent) {
                                                                  
                                                                  
                                                                  if (this.getView().byId("idConfidentialFileSwitch").getState() == false) {
                                                                         oControllerS3.customBusyDialogOpen();
                                                                        var oModel = new sap.ui.model.json.JSONModel();
                                                                        oModel
                                                                                      .loadData(
                                                                                                    serviceUrl
                                                                                                                  + "/FILES_FI?param_1='NC'&param_2='"
                                                                                                                  + this.caseguid
                                                                                                                  + "'&param_3=''&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                                                                                    null, false);
                                                                        if (oModel.getData().d.results.length == 0) {
                                                                               // this.getView().byId("trackStatus").getModel("basic").getData().d.Track
                                                                               // =
                     // false;
                                                                         this.getView().byId("idConfidentialFileSwitch").setTooltip(this.getView().getModel("i18n").getObject("OFF"));
                                                    this.getView().byId("idConfidentialFileSwitch").rerender();
                                                                               sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_69"));
                                                                               oControllerS3.customBusyDialogClose();
                                                                        } else if (oModel.getData().d.results[0].msg_type == 'E') {
                                                                               sap.m.MessageBox
                                                                               .alert(oModel.getData().d.results[0].msg_text);

                                                                        }
                                                                  } else if (this.getView().byId("idConfidentialFileSwitch")
                                                                               .getState() == true) {
                                                                         oControllerS3.customBusyDialogOpen();
                                                                        var oModel = new sap.ui.model.json.JSONModel();
                                                                        oModel
                                                                                      .loadData(
                                                                                                    serviceUrl
                                                                                                                  + "/FILES_FI?param_1='CN'&param_2='"
                                                                                                                  + this.caseguid
                                                                                                                  + "'&param_3=''&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
                                                                                                    null, false);
                                                                        if (oModel.getData().d.results.length == 0) {
                                                                               // this.getView().byId("trackStatus").getModel("basic").getData().d.Track
                                                                               // =
                     // true;
                                                                         this.getView().byId("idConfidentialFileSwitch").setTooltip(this.getView().getModel("i18n").getObject("ON"));
                                                    this.getView().byId("idConfidentialFileSwitch").rerender();
                                                                               sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_69"));
                                                                               oControllerS3.customBusyDialogClose();
                                                                        } else if (oModel.getData().d.results[0].msg_type == 'E') {
                                                                               sap.m.MessageBox
                                                                               .alert(oModel.getData().d.results[0].msg_text);
                                                                        }
                                                                  }
                                                           },
                                                              objectButtonPressed : function(oEvent) {
                                                                     // doctype=
                  // [{docType:"Purchase
                  // Order"},{docType:
                                                                     // "Purchase
                  // Requisition"},
                  // {docType:"Sales
                  // Order"}];

                                                                     if (!this._docTypeSelectDialog) {
                                                                           this._docTypeSelectDialog = sap.ui.xmlfragment(
                                                                                         "flm.fiori.view.documentTypeSelectDialog",
                                                                                         this);
                                                                           var docTypeModel = new sap.ui.model.json.JSONModel();
                                                                           docTypeModel
                                                                                         .loadData(serviceUrl
                                                                                                       + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and OtherF4 eq true and ID eq 'DT'");
                                                                            this._docTypeSelectDialog.setModel(docTypeModel,
                                                                                         "docType");
                                                                            this._docTypeSelectDialog.setModel(this.getView()
                                                                                         .getModel("i18n"), "i18n");
                                                                     } else {
                                                                            sap.ui.getCore().byId("docNumberId").setValue("");
                                                                            sap.ui.getCore().byId("docTypeSelect")
                                                                                         .setSelectedItem(
                                                                                                       sap.ui.getCore().byId(
                                                                                                                     "docTypeSelect")
                                                                                                                     .getFirstItem());
                                                                     }
                                                                     sap.ui.getCore().byId("attachmentTypeid").setValue(
                                                                                  oEvent.getSource().getId());
                                                                     oModel = new sap.ui.model.json.JSONModel();
                                                                     if (oEvent.getSource().getId() == "objectAction") {

                                                                           oModel.loadData(serviceUrl
                                                                                         + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and OtherF4 eq true and ID eq 'OO'",
                                                                                         null, false);
                                                                            sap.ui.getCore().byId("docTypeSelectId").setTitle(
                                                                                         oControllerS3.getView().getModel("i18n").getObject(
                                                                                                       "OBJECT"));
                                                                     } else if (oEvent.getSource().getId() == "reportAction") {

                                                                           oModel.loadData(serviceUrl
                                                                                         + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and OtherF4 eq true and ID eq 'RO'",
                                                                                         null, false);
                                                                            sap.ui.getCore().byId("docTypeSelectId").setTitle(
                                                                                         oControllerS3.getView().getModel("i18n").getObject(
                                                                                                       "REPORT"));
                                                                     }
                                                                     this._docTypeSelectDialog.setModel(oModel);
                                                                     // oModel.setData(doctype);
                                                                     this._docTypeSelectDialog.open();
                                                              },
                                                              
                                                              _handleDocSelectOk : function(oEvent) {

                                                             var doc_num = sap.ui.getCore().byId("docNumberId");

                                                for (var i = 0; i < oControllerS3.data.attachments.length; i++) {
                                                 if (doc_num.getValue() == oControllerS3.data.attachments[i].DocumentName) {
                                                  sap.m.MessageToast
                                                    .show(this.getView().getModel("i18n").getObject("MESSAGE_35"));
                                                  return;
                                                 }
                                                }
                                                                     var documentData = {
                                                                           "BorID" : null,
                                                                           "BorType" : null,
                                                                           "DocumentName" : null,
                                                                           "DocumentType" : null,
                                                                           "CreatedByName" : null,
                                                                           "CreatedOn" : null,
                                                                           "FileTitle" : null,
                                                                           "FileSizeDescr" : null,
                                                                           "ParentKey" : this.uploadNode.getBindingContext(
                                                                                         "global").getProperty("RowKey"),
                                                                           "IsAttachment" : false,
                                                                           "IsFile" : false,
                                                                           "IsObject" : false,
                                                                           "IsIpi" : false,
                                                                           "IsReport" : false,
                                                                           "ElementType" : null,
                                                                           "FileName" : null,
                                                                           "DocumentClass" : null,
                                                                           "AttachmentLoioID" : null,
                                                                           "FileSizeDescr" : null,
                                                                           "NotingEnabledRef" : true,
                                                                           "DeleteEnabledRef" : true,
                                                                           "Variant" : null,
                                                                     };

                                                                     var fileDetails = {
                                                                           "caseGuiId" : this.caseguid,
                                                                           "workItemId" : this.wiId,
                                                                           "fileId" : this.fileid,
                                                                     };

                                                                     var objDetails = {
                                                                           "objectType" : null,
                                                                           "elementType" : null,
                                                                           "attachmentType" : sap.ui.getCore().byId(
                                                                                         "attachmentTypeid").getValue(),// sap.ui.getCore().byId("docTypeSelectId").getTitle(),
                                                                     };
                                                                     var docObject = {};
                                                                     
                                                                     docObject.document = documentData;
                                                                     docObject.fileDetails = fileDetails;
                                                                     docObject.objectDetails = objDetails;
                                                                     docObject.event = oEvent;

                                                                     docObject.document.DocumentName = sap.ui.getCore()
                                                                                  .byId("docNumberId").getValue();

                                                                     if (docObject.document.DocumentName == ""
                                                                                  || sap.ui.getCore().byId("idDocTypeTable")
                                                                                                .getSelectedItem() == undefined) {
                                                                            sap.m.MessageToast.show(this.getView().getModel(
                                                                                         "i18n").getObject("enterdocumentnumber"));
                                                                           return;
                                                                     } else {
                                                                           docObject.document.DocumentType = sap.ui.getCore()
                                                                                         .byId("docTypeSelect").getSelectedKey();
                                                                           docObject.document.FileName = sap.ui.getCore()
                                                                                         .byId("docTypeSelect").getSelectedItem()
                                                                                         .getText();
                                                                            docObject.objectDetails.objectType = sap.ui
                                                                                         .getCore().byId("idDocTypeTable")
                                                                                         .getSelectedItem().getBindingContext()
                                                                                         .getObject().ResulltCol1;
                                                                            docObject.objectDetails.elementType = sap.ui
                                                                                         .getCore().byId("idDocTypeTable")
                                                                                         .getSelectedItem().getBindingContext()
                                                                                         .getObject().ResultCol3;
                                                                     }
                                                                     // closing the popup and calling the hook function
                                                                     this._docTypeSelectDialog.close();
                                                                     if (this.attachCustomObject) {
                                                    this.attachCustomObject(docObject);
                                                   }
                                                              },

                                                              _handleDocSelectCancel : function(oEvent) {
                                                                     this._docTypeSelectDialog.close();
                                                              },

                                                              // attach document in the tree in ui

                                                              _attachObjectUI : function(oDocument) {
                                                                     
                                                                     try {
                                                                            oControllerS3.getView().getModel("global")
                                                                                         .getData().attachments.push(oDocument);
                                                                            oControllerS3.getView().getModel("global")
                                                                                         .refresh();
                                                                     } catch (err) {
                                                                           return false;
                                                                     }
                                                                     var heading = oControllerS3.uploadNode
                     .getTitle().getText();
                                                                     var subHead1 = heading
                     .substring(
                       0,
                       heading
                         .lastIndexOf("("));
                                                                     var subHead2 = heading
                     .substring(
                       heading
                         .lastIndexOf("(") + 1,
                       heading
                         .lastIndexOf(")"));
                                                                     oControllerS3.uploadNode
                     .getTitle()
                     .setText(
                       subHead1
                         + " ("
                         + (++subHead2)
                         + ")");
                                                                     return true;
                                                              },
                                                              
                                                              toSearchView : function(oEvent) {


                                                 if (!oControllerS3.searchPopup) {
                                                  oControllerS3.searchPopup = sap.ui.xmlfragment(
                                                    "flm.fiori.view.searchDialog", oControllerS3);
                                                 }
                                                  oControllerS3.searchPopup.setModel(this.getView().getModel(
                                                    "i18n"), "i18n");
                                                  var oPrioModel = new sap.ui.model.json.JSONModel();
                                                  oPrioModel.setData(this.data.priority);
                                                  oControllerS3.searchPopup.setModel(oPrioModel, "priority");

                                                  oControllerS3.searchPopup.setModel(this
                                                    .initializeSearchHelp(this), "global");

                                                 oControllerS3.searchPopup.open();
                                                },

                                                onSearchDialogCloseButton : function(oEvent) {
                                                 this.searchPopup.close();
                                                },

                                                onAddSearch : function(oEvent) {

                                                 var fileNumber = oEvent.getParameters().listItem
                                                   .getBindingContext("global").getObject().PsReference;
                                                 if (this.getView().byId("idInputFileNumber").getValue() == fileNumber) {
                                                  sap.m.MessageBox
                                                    .alert(this.getView().getModel("i18n").getObject("MESSAGE_44"));
                                                  return;
                                                 } else {
                                                  sap.ui.getCore().byId("idFileNumber").setValue(
                                                    fileNumber);
                                                  this.searchPopup.close();
                                                 }
                                                },

                                                              
                                                              initializeSearchHelp : function(controller) {

                                                                     var srchData = {
                                                                           criteria : null,
                                                                           operators : null,
                                                                           searchData : null,
                                                                     };
                                                                     
                                                                    
                                                                     srchData.criteria = [
                    {
                     key : "CASE_TITLE",
                     title : this.getView().getModel("i18n")
                       .getObject("SUBJECT")
                    },
                    {
                     key : "PS_REFERENCE",
                     title : this.getView().getModel("i18n")
                       .getObject("FILENUMBER")
                    },
                    {
                     key : "CREATED_BY",
                     title : this.getView().getModel("i18n")
                       .getObject("CREATEDBY")
                    },
                    {
                     key : "CHANGED_BY",
                     title : this.getView().getModel("i18n")
                       .getObject("LASTCHANGEDBY")
                    },
                    {
                     key : "CLOSED_BY",
                     title : this.getView().getModel("i18n")
                       .getObject("CLOSEDBYUSER")
                    },
                    {
                     key : "CREATE_TIME",
                     title : this.getView().getModel("i18n")
                       .getObject("CREATEDON")
                    },
                    {
                     key : "EXT_KEY",
                     title : this.getView().getModel("i18n")
                       .getObject("FILEID")
                    },
                    {
                     key : "PLAN_END_DATE",
                     title : this.getView().getModel("i18n")
                       .getObject("DUEDATE")
                    },
                    {
                     key : "ARCHIVE",
                     title : this.getView().getModel("i18n")
                       .getObject("READFROMARCHIVE")
                    },
                    {
                     key : "STAT_ORDERNO",
                     title : this.getView().getModel("i18n")
                       .getObject("STATUS")
                    },
                    {
                     key : "SAP_FLM_PRIO",
                     title : this.getView().getModel("i18n")
                       .getObject("PRIORITY")
                    },
                    {
                     key : "FILE_TYPE",
                     title : this.getView().getModel("i18n")
                       .getObject("FILETYPE")
                    },
                    {
                     key : "ORG_UNIT",
                     title : this.getView().getModel("i18n")
                       .getObject("ORGANIZATIONGROUP")
                    }, ];

                                                                    srchData.operators = [
{
 criteria : "GEN1",
 opkey : "01",
 optext : this.getView().getModel("i18n")
   .getObject("IS")
},
{
 criteria : "GEN2",
 opkey : "05",
 optext : this.getView().getModel("i18n")
   .getObject("CONTAINS")
},
{
 criteria : "GEN2",
 opkey : "04",
 optext : this.getView().getModel("i18n")
   .getObject("STARTSWITH")
},
{
 criteria : "DATE",
 opkey : "11",
 optext : this.getView().getModel("i18n")
   .getObject("ISEARLIERTHAN")
},
{
 criteria : "DATE",
 opkey : "12",
 optext : this.getView().getModel("i18n")
   .getObject("ISLATERTHAN")
},
{
 criteria : "DATE",
 opkey : "21",
 optext : this.getView().getModel("i18n")
   .getObject("ISEARLIERTHANORON")
},
{
 criteria : "DATE",
 opkey : "22",
 optext : this.getView().getModel("i18n")
   .getObject("ISLATERTHANORON")
},
{
 criteria : "ISNOT",
 opkey : "02",
 optext : this.getView().getModel("i18n")
   .getObject("ISNOT")
} ];

                                                                     srchData.searchData = {
                                                                       criteria1 : "CASE_TITLE",
                                                        op1 : "01",
                                                        value1 : "",
                                                        criteria2 : "PS_REFERENCE",
                                                        op2 : "01",
                                                        value2 : "",
                                                        criteria3 : "CREATED_BY",
                                                        op3 : "01",
                                                        value3 : "",
                                                        criteria4 : "CHANGED_BY",
                                                        op4 : "01",
                                                        value4 : "",
                                                        criteria5 : "CLOSED_BY",
                                                        op5 : "01",
                                                        value5 : ""
                                                       };
                                                                   

                                                                     srchData.searchResult = null;
                                                                     var oSearchModel = new sap.ui.model.json.JSONModel();
                                                                     oSearchModel.setData(srchData);
                                                                     return oSearchModel;
                                                              },
                                                              onPressClear : function(oEvent) {
                                                sap.ui.getCore().byId("value1").setValue("");
                                                sap.ui.getCore().byId("value2").setValue("");
                                                sap.ui.getCore().byId("value3").setValue("");
                                                sap.ui.getCore().byId("value4").setValue("");
                                                sap.ui.getCore().byId("value5").setValue("");
                                                sap.ui.getCore().byId("value6").setValue("");
                                                /*sap.ui.getCore().byId("value7").setValue("");*/
                                                sap.ui.getCore().byId("value8").setValue("");
//                                                sap.ui.getCore().byId("value9").setState(false);
                                                sap.ui.getCore().byId("value10")
                                                  .setSelectedKey("SPACE");
                                                sap.ui.getCore().byId("value11")
                                                  .setSelectedKey("SPACE");
                                                sap.ui.getCore().byId("value12").setValue("");
                                                sap.ui.getCore().byId("value13").setValue("");

                                                sap.ui.getCore().byId("op1").setSelectedKey("01");
                                                sap.ui.getCore().byId("op2").setSelectedKey("01");
                                                sap.ui.getCore().byId("op3").setSelectedKey("01");
                                                sap.ui.getCore().byId("op4").setSelectedKey("01");
                                                sap.ui.getCore().byId("op5").setSelectedKey("01");
                                                sap.ui.getCore().byId("op6").setSelectedKey("01");
                                                /*sap.ui.getCore().byId("op7").setSelectedKey("01");*/
                                                sap.ui.getCore().byId("op8").setSelectedKey("11");
//                                                sap.ui.getCore().byId("op9").setSelectedKey("01");
                                                sap.ui.getCore().byId("op10").setSelectedKey("01");
                                                sap.ui.getCore().byId("op11").setSelectedKey("01");
                                                sap.ui.getCore().byId("op12").setSelectedKey("01");
                                                sap.ui.getCore().byId("op13").setSelectedKey("01");
                                                oEvent.getSource().getModel("global").oData.searchResult = null;
                                              // //
                // this.data.searchResults
                // =
                                              oEvent.getSource().getModel("global").checkUpdate();
                                               },

                                               onpressf4User : function(oEvent) {
                                                if (!this.f4popup) {
                                                 this.f4popup = sap.ui.xmlfragment(
                                                   "flm.fiori.view.dynamicF4popup", this);
                                                 // sap.ui.getCore().addDependent(this.f4popup);
                                                }

                                                oF4Texts = new sap.ui.model.json.JSONModel();
                                                var f4text = {
                                                 title : this.getView().getModel("i18n").getObject(
                                                   "USERS"),
                                                 id : oEvent.getSource().getId()
                                                };
                                                oF4Texts.setData(f4text);
                                                this.f4popup.setModel(oF4Texts, "dyntext");

                                                var oF4Model = new sap.ui.model.json.JSONModel();
                                                oF4Model
                                                  .loadData(
                                                    serviceUrl
                                                      + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq 'US' and WF eq true",
                                                    null, false);
                                                oF4Model.setData(oF4Model.oData.d.results);
                                                this.f4popup.setModel(oF4Model);
                                                this.f4popup.open();
                                               },

                                               onpressf4Filetype : function(oEvent) {
                                                if (!this.f4popup) {
                                                 this.f4popup = sap.ui.xmlfragment(
                                                   "flm.fiori.view.dynamicF4popup", this);
                                                 // sap.ui.getCore().addDependent(this.f4popup);
                                                }

                                                oF4Texts = new sap.ui.model.json.JSONModel();
                                                var f4text = {
                                                 title : this.getView().getModel("i18n").getObject(
                                                   "FILETYPE"),
                                                 id : oEvent.getSource().getId()
                                                };
                                                oF4Texts.setData(f4text);
                                                this.f4popup.setModel(oF4Texts, "dyntext");
                                                var oF4Model = new sap.ui.model.json.JSONModel();
                                                oF4Model
                                                  .loadData(
                                                    serviceUrl
                                                      + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq 'FT' and OtherF4 eq true",
                                                    null, false);
                                                oF4Model.setData(oF4Model.oData.d.results);
                                                this.f4popup.setModel(oF4Model);
                                                this.f4popup.open();
                                               },

                                               onpressf4Orgunit : function(oEvent) {
                                                if (!this.f4popup) {
                                                 this.f4popup = sap.ui.xmlfragment(
                                                   "flm.fiori.view.dynamicF4popup", this);
                                                 // sap.ui.getCore().addDependent(this.f4popup);
                                                }
                                                oF4Texts = new sap.ui.model.json.JSONModel();
                                                var f4text = {
                                                 title : this.getView().getModel("i18n").getObject(
                                                   "ORGANIZATIONGROUP"),
                                                 id : oEvent.getSource().getId()
                                                };
                                                oF4Texts.setData(f4text);
                                                this.f4popup.setModel(oF4Texts, "dyntext");
                                                var oF4Model = new sap.ui.model.json.JSONModel();
                                                oF4Model
                                                  .loadData(
                                                    serviceUrl
                                                      + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq 'OC' and OtherF4 eq true",
                                                    null, false);
                                                oF4Model.setData(oF4Model.oData.d.results);
                                                this.f4popup.setModel(oF4Model);
                                                this.f4popup.open();
                                               },
                                               /*
                * Redundant
                * function for
                * search
                */
                                               onPressSearch : function(oEvent) {

                                                var i = -1;
                                                var searchFields = new Array();
                                                if (sap.ui.getCore().byId("value1").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value1").getValue();
                                                 searchFields[i].op = sap.ui.getCore().byId("op1")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "CASE_TITLE";
                                                }
                                                if (sap.ui.getCore().byId("value2").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value2").getValue();
                                                 searchFields[i].op = sap.ui.getCore().byId("op2")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "PS_REFERENCE";
                                                }
                                                if (sap.ui.getCore().byId("value3").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value3").getName();
                                                 searchFields[i].op = sap.ui.getCore().byId("op3")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "CREATED_BY";
                                                }
                                                if (sap.ui.getCore().byId("value4").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value4").getName();
                                                 searchFields[i].op = sap.ui.getCore().byId("op4")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "CHANGED_BY";
                                                }
                                                if (sap.ui.getCore().byId("value5").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value5").getName();
                                                 searchFields[i].op = sap.ui.getCore().byId("op5")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "CLOSED_BY";
                                                }
                                                if (sap.ui.getCore().byId("value6").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value6").getValue();
                                                 searchFields[i].op = sap.ui.getCore().byId("op6")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "CREATE_TIME";
                                                }
                                                /*if (sap.ui.getCore().byId("value7").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value7").getValue();
                                                 searchFields[i].op = sap.ui.getCore().byId("op7")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "EXT_KEY";
                                                }*/
                                                if (sap.ui.getCore().byId("value8").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value8").getValue();
                                                 searchFields[i].op = sap.ui.getCore().byId("op8")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "PLAN_END_DATE";
                                                }
                                                /*if (sap.ui.getCore().byId("value9").getState() != false) {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value9").getState();
                                                 searchFields[i].op = sap.ui.getCore().byId("op9")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "ARCHIVE";
                                                }*/
                                                if (sap.ui.getCore().byId("value10").getSelectedKey() != "SPACE") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value10").getSelectedKey();
                                                 searchFields[i].op = sap.ui.getCore().byId("op10")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "STAT_ORDERNO";
                                                }

                                                if (sap.ui.getCore().byId("value11").getSelectedKey() != "SPACE") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value11").getSelectedKey();
                                                 searchFields[i].op = sap.ui.getCore().byId("op11")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "SAP_FLM_PRIO";
                                                }

                                                if (sap.ui.getCore().byId("value12").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value12").getValue();
                                                 searchFields[i].op = sap.ui.getCore().byId("op11")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "FILE_TYPE";
                                                }
                                                if (sap.ui.getCore().byId("value13").getValue() != "") {
                                                 i++;
                                                 searchFields[i] = {};
                                                 searchFields[i].value = sap.ui.getCore().byId(
                                                   "value13").getValue();
                                                 searchFields[i].op = sap.ui.getCore().byId("op13")
                                                   .getSelectedKey();
                                                 searchFields[i].criteria = "ORG_UNIT";
                                                }
                                                var criteria1 = "";
                                                var criteria2 = "";
                                                var criteria3 = "";
                                                var criteria4 = "";
                                                var criteria5 = "";

                                                var op1 = "";
                                                var op2 = "";
                                                var op3 = "";
                                                var op4 = "";
                                                var op5 = "";
                var obType = "";
                obType = "FILE";
                                                var value1 = "";
                                                var value2 = "";
                                                var value3 = "";
                                                var value4 = "";
                                                var value5 = "";
                                                var max_res = sap.ui.getCore().byId("noOfResults")
                                                  .getValue();
                                                if (searchFields.length > 5) {
                                                 sap.m.MessageToast.show(this.getView().getModel(
                                                   "i18n").getObject("MESSAGE_01"));
                                                } else if (searchFields.length == 0) {
                                                 sap.m.MessageToast.show(this.getView().getModel(
                                                   "i18n").getObject("MESSAGE_02"));
                                                } else {
                                                 for (var j = 0; j < searchFields.length; j++) {
                                                  if (j == 0) {
                                                   criteria1 = searchFields[j].criteria;
                                                   op1 = searchFields[j].op;
                                                   value1 = searchFields[j].value;
                                                  } else if (j == 1) {
                                                   criteria2 = searchFields[j].criteria;
                                                   op2 = searchFields[j].op;
                                                   value2 = searchFields[j].value;
                                                  } else if (j == 2) {
                                                   criteria3 = searchFields[j].criteria;
                                                   op3 = searchFields[j].op;
                                                   value3 = searchFields[j].value;
                                                  } else if (j == 3) {
                                                   criteria4 = searchFields[j].criteria;
                                                   op4 = searchFields[j].op;
                                                   value4 = searchFields[j].value;
                                                  } else if (j == 4) {
                                                   criteria5 = searchFields[j].criteria;
                                                   op5 = searchFields[j].op;
                                                   value5 = searchFields[j].value;
                                                  }

                                                 }
                                                 var osearchResultsModel = new sap.ui.model.json.JSONModel();
                                                 // osearchResultsModel
                                                 // .attachRequestCompleted(
                                                 // this,
                                                 // function(oEvent)
                 // {
                                                 // oEvent.getSource().getModel("global").oData.searchResult
                                                 // =
                 // osearchResultsModel.oData.d.results;
                                                 // //
                 // this.data.searchResults
                 // =
                                                 // oEvent.getSource().getModel("global").checkUpdate();
                                                 // oControllerS2.customBusyDialogClose();
                                                 // }, this);
                                                 // oControllerS2.customBusyDialogOpen();
                                                 osearchResultsModel.loadData(serviceUrl
                                                   + "/FILE_SRCH_FI?action='SR'&crit_1='"
                                                   + criteria1 + "'&crit_2='" + criteria2
                                                   + "'&crit_3='" + criteria3 + "'&crit_4='"
                                                   + criteria4 + "'&crit_5='" + criteria5
                                                   + "'&oper_1='" + op1 + "'&oper_2='" + op2
                                                   + "'&oper_3='" + op3 + "'&oper_4='" + op4
                                                   + "'&oper_5='" + op5 + "'&value_1='"
                                                   + encodeURIComponent(value1) + "'&value_2='" + encodeURIComponent(value2)
                                                   + "'&value_3='" + encodeURIComponent(value3) + "'&value_4='"
                                                   + encodeURIComponent(value4) + "'&value_5='" + encodeURIComponent(value5)
                                                   + "'&max_res='" + max_res + "'&is_type='" + obType + "'", null,
                                                   false);
                                                 // sap.ui.getCore().byId("idSearchTable").setModel(
                                                 // osearchResultsModel);
                                                 oEvent.getSource().getModel("global").oData.searchResult = osearchResultsModel.oData.d.results;

                                                 /* Setting decoded value for subject*/
                                               /*for (var j = 0; j < osearchResultsModel.oData.d.results.length; j++) {
                                                var subValue = decodeURIComponent(osearchResultsModel.oData.d.results[j].CaseTitle);
                                                osearchResultsModel.oData.d.results[j].CaseTitle = subValue;
                                               }*/
                                                 // //
                 // this.data.searchResults
                 // =
                                                 oEvent.getSource().getModel("global").checkUpdate();

                                                }

                                               },

                                               openBusinessCard : function(oEvent) {
                                                              if(oControllerS3.setCustomBusinessCard){
                                                               oControllerS3.setCustomBusinessCard(oControllerS3,oEvent);
                                                                }else{
                                                                       if (!oControllerS3._oBusinessCard) {
                                                                       oControllerS3._oBusinessCard = sap.ui.xmlfragment(
                                                                                     "flm.fiori.view.businessCard", oControllerS3);
                                                                }
                                                                // oControllerS3._oBusinessCard.setModel(oControllerS2.oTreeTable.getModel());
                                                                var contactModel = new sap.ui.model.json.JSONModel();
                                                                contactModel.setData(oEvent.getSource()
                                                                              .getBindingContext("workflow").getObject());
                                                                oControllerS3._oBusinessCard.setModel(contactModel);
                                                                oControllerS3._oBusinessCard.bindElement("/");
                                                                oControllerS3._oBusinessCard.openBy(oEvent.getSource());
                                                                }
                                                  },


                                               /*
                * Generic Code for
                * opening fragments
                */
                                             openDialog : function(sType) {
                                              if (!this[sType]) {
                                               this[sType] = sap.ui.xmlfragment("flm.fiori.view."
                                                 + sType, this // associate
                       // controller
                       // with
                                               // the
                 // fragment
                                               );
                                               this.getView().addDependent(this[sType]);
                                              }
                                              this[sType].open();
                                             },
                                             /*
                * Generic Code for
                * closing fragments
                */
                                             closeDialog : function(sType) {
                                              if (!this[sType]) {
                                               this[sType] = sap.ui.xmlfragment("flm.fiori.view."
                                                 + sType, this // associate
                       // controller
                       // with
                                               // the
                 // fragment
                                               );
                                               this.getView().addDependent(this[sType]);
                                              }
                                              this[sType].close();

                                             },

                                              // Send File Actions
                                             /*sendButtonPressed : function(oEvent) {
                                              if(!oControllerS3.saveFlag){}
                                              this.openDialog('confirmDialog');
                                             },*/
                                             // send file action
                                             sendButtonPressed : function(oEvent) {
                                              if(!oControllerS3.saveFlag){}
                                              sap.m.MessageBox.confirm(this.getView().getModel("i18n").getObject("MESSAGE_19"),
                                                function(response) {
                                                  if (response == "OK") {
//                                              oEvent.getSource().getParent().close();
                                                   oControllerS3.customBusyDialogOpen();

                                              //var assistFlag = this.oSource.getController().assistFlag;
                                              var assistFlag = oControllerS3.oRouter.getView("flm.fiori.view.S1").getController().assistFlag;
                                              if (assistFlag == true) {
                                               // this.assistNotButtonPressed();

                                               sap.m.MessageBox
                                                 .confirm(
                                                   this.getView().getModel("i18n").getObject("MESSAGE_26"),
                                                   function(response) {
                                                    if (response == "OK") {
                                                     // check for digital signature customization
                                                     if(oControllerS3.data.basic.DigSignReq || oControllerS3.createSignFlag){
                                                      if(oControllerS3.customDigitalSignData){
                                                                 /* var flag = oControllerS3.customDigitalSignData(oControllerS3.data);
                                                                  if(flag == "X"){
                                                     oControllerS3
                                                       .confirmSendFile(
                                                         oControllerS3.caseguid,
                                                         oControllerS3.fileid,
                                                         oControllerS3.fromTab);
                                                                  }*/
                                                       oControllerS3.customDigitalSignData(oControllerS3.data, jQuery.proxy(function() {
                                                        oControllerS3.confirmSendFile(oControllerS3.caseguid,
                                                          oControllerS3.fileid,
                                                          oControllerS3.fromTab);
                                                                    
                                                                    }, oControllerS3));
                                                      }else{
                                                       sap.m.MessageBox.alert(oControllerS3.getView().getModel("i18n").getObject("MESSAGE_73"));
                                                       oControllerS3
                                                       .customBusyDialogClose();
                                                      }
                                                     }else{
                                                      oControllerS3
                                                       .confirmSendFile(
                                                         oControllerS3.caseguid,
                                                         oControllerS3.fileid,
                                                         oControllerS3.fromTab);
                                                     }
                                                    } else {
                                                     oControllerS3
                                                       .customBusyDialogClose();
                                                    }
                                                   });

                                              } else {
                                               if(oControllerS3.data.basic.DigSignReq || oControllerS3.createSignFlag){
                              if(oControllerS3.customDigitalSignData){
                                         /* var flag = oControllerS3.customDigitalSignData(oControllerS3.data);
                                          if(flag == "X"){
                             oControllerS3
                               .confirmSendFile(
                                 oControllerS3.caseguid,
                                 oControllerS3.fileid,
                                 oControllerS3.fromTab);
                                          }*/
                               oControllerS3.customDigitalSignData(oControllerS3.data, jQuery.proxy(function() {
                                oControllerS3.confirmSendFile(oControllerS3.caseguid,
                                  oControllerS3.fileid,
                                  oControllerS3.fromTab);
                                            
                                            }, oControllerS3));
                              }else{
                               sap.m.MessageBox.alert(oControllerS3.getView().getModel("i18n").getObject("MESSAGE_73"));
                               oControllerS3
                               .customBusyDialogClose();
                              }
                                               }
                                               else{
                                                oControllerS3.confirmSendFile(oControllerS3.caseguid,oControllerS3.fileid,oControllerS3.fromTab);
                                               }
                                              }
                                                  }else{
                                                   oControllerS3.customBusyDialogClose();
                                                  }
                                                   });
                                             },

                                             confirmSendFile : function(caseguid, fileid, fromTab,
                                               isConfirmed) {

                                              if (isConfirmed == null) {
                                               isConfirmed = "";
                                              }
                                              var oModel = new sap.ui.model.json.JSONModel();

                                              oModel
                                                .attachRequestCompleted(
                                                  oControllerS3,
                                                  function(oEvent) {

                                                   oModel.detachRequestCompleted();

                                                   if (oModel.getData().d.results[0].msg_type == "C"
                                                     && oModel.getData().d.results[0].msg_id == 373) {
                                                    // oControllerS2.lastProcButtonPressed();
                                                    sap.m.MessageBox
                                                      .confirm(
                                                        oModel
                                                          .getData().d.results[0].msg_text,
                                                        function(
                                                          response) {
                                                         if (response == "OK") {
                                                          // check for digital signature customizationg
                                                          if(oControllerS3.data.basic.DigSignReq || oControllerS3.createSignFlag){
                                                           if(oControllerS3.customDigitalSignData){
                                                                      /* var flag = oControllerS3.customDigitalSignData(oControllerS3.data);
                                                                       if(flag == "X"){
                                                                        oControllerS3.confirmSendFile(caseguid,fileid,fromTab,"X");
                                                                       }*/
                                                            oControllerS3.customDigitalSignData(oControllerS3.data, jQuery.proxy(function() {
                                                                            oControllerS3.confirmSendFile(oControllerS3.caseguid,
                                                                              oControllerS3.fileid,
                                                                              oControllerS3.fromTab, "X");
                                                                                        
                                                                                        }, oControllerS3));
                                                           }
                                                           else{
                                                            sap.m.MessageBox.alert(oControllerS3.getView().getModel("i18n").getObject("MESSAGE_73"));
                                                            oControllerS3
                                                                        .customBusyDialogClose();
                                                           }
                                                          }else{
                                                           oControllerS3.confirmSendFile(caseguid,fileid,fromTab,"X");
                                                          }
                                                         } else {
                                                          oControllerS3
                                                            .customBusyDialogClose(oControllerS3);
                                                         }
                                                        });

                                                   } else if (oModel.getData().d.results[0].msg_type == "E") {
                                                    oControllerS3
                                                      .customBusyDialogClose(oControllerS3);
                                                    sap.m.MessageBox
                                                      .alert(oModel.getData().d.results[0].msg_text);
                                                   } else {

                                                    // delete the file from the tab


                                                    var oTableId = null;
                                                    var oEntitySet = null;

                                                     oTableId = "idDraftsTable";
                                                     oEntitySet = "/FILE_DRAFT_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";

                                                    var tempModel = oControllerS3.oRouter
                                                      .getView(
                                                        "flm.fiori.view.S1")
                                                      .byId(oTableId)
                                                      .getModel("files");

                                                    tempModel
                                                      .attachRequestCompleted(
                                                        oControllerS3,
                                                        function(oEvent) {
                                                         tempModel
                                                           .detachRequestCompleted();
                                                         if (tempModel.oData.d != undefined) {

                                                          /*for (var j = 0; j < tempModel.oData.d.results.length; j++) {
                                                           var subValue = decodeURIComponent(tempModel.oData.d.results[j].Subject);
                                                           tempModel.oData.d.results[j].Subject = subValue;
                                                          }*/
                                                          tempModel
                                                            .setData(tempModel.oData.d);
                                                          tempModel
                                                            .checkUpdate();
                                                          sap.m.MessageToast
                                                            .show(oModel
                                                              .getData().d.results[0].msg_text);
                                                         }
                                                         oControllerS3
                                                           .customBusyDialogClose(oControllerS3);
                                                         oControllerS3.oRouter
                                                           .getView(
                                                             "flm.fiori.view.S1")
                                                           .byId(
                                                             "sendAction")
                                                           .setEnabled(
                                                             false);
                                                         oControllerS3.oRouter
                                                           .getView(
                                                             "flm.fiori.view.S1")
                                                           .byId(
                                                             oTableId)
                                                           .removeSelections();
                                                         destroyDialogs(oControllerS3); //destroy all common fragments
                                                         oControllerS3.oRouter
                                                           .navTo("fullscreen");
                                                        },
                                                        oControllerS3);
                                                    tempModel.loadData(serviceUrl
                                                      + oEntitySet, null,
                                                      true);
                                                   }

                                                  }, oControllerS3);

                                              oModel
                                        .loadData(
                                          serviceUrl
                                            + "/FILES_FI?param_1='SE'&param_2='"
                                            + oControllerS3.caseguid
                                            + "'&param_3=''&param_4='"
                                            + oControllerS3.fileid
                                            + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
                                            + oControllerS3.fromTab
                                            + "'&param_8=''&param_9=''&param_10=''",
                                          null, false);

                                             },

                                            /* onDialogOkButton : function(oEvent) {
                                              this.closeDialog('confirmDialog');
                                              oControllerS3.customBusyDialogOpen();
                                              var assistFlag = this.oSource.getController().assistFlag;

                                              if (assistFlag == true) {
                                               sap.m.MessageBox
                                         .confirm(
                                           this.getView().getModel("i18n").getObject("MESSAGE_26"),
                                           function(response) {
                                            if (response == "OK") {

                                             var oModel = new sap.ui.model.json.JSONModel();
                                                                  oModel
                                                            .loadData(
                                                              serviceUrl
                                                                + "/FILES_FI?param_1='SE'&param_2='"
                                                                + oControllerS3.caseguid
                                                                + "'&param_3=''&param_4='"
                                                                + oControllerS3.fileid
                                                                + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
                                                                + oControllerS3.fromTab
                                                                + "'&param_8=''&param_9=''&param_10=''",
                                                              null, false);

                                                                  if(oModel.getData().d.results[0].msg_type == "S"){
                                                                   var oTableId = null;
                                                    var oEntitySet = null;

                                                     oTableId = "idDraftsTable";
                                                     oEntitySet = "/FILE_DRAFT_ES";

                                                    var tempModel = oControllerS3.oRouter
                                                      .getView(
                                                        "flm.fiori.view.S1")
                                                      .byId(oTableId)
                                                      .getModel("files");
                                                    tempModel
                                                      .attachRequestCompleted(
                                                        oControllerS3,
                                                        function(oEvent) {
                                                         destroyDialogs(oControllerS3);
                                                         tempModel
                                                           .detachRequestCompleted();
                                                         if (tempModel.oData.d != undefined) {
                                                          tempModel
                                                            .setData(tempModel.oData.d);
                                                          tempModel
                                                            .checkUpdate();
                                                          sap.m.MessageToast
                                                            .show(oModel
                                                              .getData().d.results[0].msg_text);
                                                         }
                                                         oControllerS3
                                                           .customBusyDialogClose();
                                                         oControllerS3.oRouter
                                                           .getView(
                                                             "flm.fiori.view.S1")
                                                           .byId(
                                                             "sendAction")
                                                           .setEnabled(
                                                             false);
                                                         oControllerS3.oRouter
                                                           .getView(
                                                             "flm.fiori.view.S1")
                                                           .byId(
                                                             oTableId)
                                                           .removeSelections();
                                                         oControllerS3.oRouter
                                                           .navTo("fullscreen");
                                                        },
                                                        oControllerS3);
                                                    tempModel.loadData(serviceUrl
                                                      + oEntitySet, null,
                                                      true);


                    // sap.m.MessageToast.show(oModel.getData().d.results[0].msg_text);
                    // oControllerS3.customBusyDialogClose();
                    // oControllerS3.oRouter.navTo("fullscreen");
                                               }else if (oModel.getData().d.results[0].msg_type == "E") {
                                                    oControllerS3
                                              .customBusyDialogClose();
                                                     sap.m.MessageBox
                                              .alert(oModel.getData().d.results[0].msg_text);
                                                                  }
                                              }
                                           }


                                             },*/

                                            /* closeButtonPressed : function(oEvent) {

                                                     oControllerS3.openDialog('closeFileDialog');

                                             },

                                             // event handler for
               // closing the file
                                             onCloseButtonPressedOk : function(oEvent) {

                                              this.closeDialog('closeFileDialog');
                                              this.customBusyDialogOpen();
                                              var oModel = new sap.ui.model.json.JSONModel();

                                               oModel
                                                 .loadData(
                                                   serviceUrl
                                                     + "/FILES_FI?param_1='CF'&param_2='"
                                                     + oControllerS3.caseguid
                                                     + "'&param_3=''&param_4='"
                                                     + oControllerS3.fileid
                                                     + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
                                                     + oControllerS3.fromTab
                                                     + "'&param_8=''&param_9=''&param_10=''",
                                                   null, false);
                                               if(oModel.getData().d.results[0].msg_type == "S"){
                                                var oTableId = null;
                                    var oEntitySet = null;

                                     oTableId = "idDraftsTable";
                                     oEntitySet = "/FILE_DRAFT_ES";

                                    var tempModel = oControllerS3.oRouter
                                      .getView(
                                        "flm.fiori.view.S1")
                                      .byId(oTableId)
                                      .getModel("files");
                                    tempModel
                                      .attachRequestCompleted(
                                        oControllerS3,
                                        function(oEvent) {
                                         destroyDialogs(oControllerS3);
                                         tempModel
                                           .detachRequestCompleted();
                                         if (tempModel.oData.d != undefined) {
                                          tempModel
                                            .setData(tempModel.oData.d);
                                          tempModel
                                            .checkUpdate();
                                          sap.m.MessageToast
                                            .show(oModel
                                              .getData().d.results[0].msg_text);
                                         }
                                         oControllerS3
                                           .customBusyDialogClose();
                                         oControllerS3.oRouter
                                           .getView(
                                             "flm.fiori.view.S1")
                                           .byId(
                                             "sendAction")
                                           .setEnabled(
                                             false);
                                         oControllerS3.oRouter
                                           .getView(
                                             "flm.fiori.view.S1")
                                           .byId(
                                             oTableId)
                                           .removeSelections();
                                         oControllerS3.oRouter
                                           .navTo("fullscreen");
                                        },
                                        oControllerS3);
                                    tempModel.loadData(serviceUrl
                                      + oEntitySet, null,
                                      true);
// sap.m.MessageToast.show(oModel.getData().d.results[0].msg_text);
// oControllerS3.customBusyDialogClose();
// oControllerS3.oRouter.navTo("fullscreen");
                                                  }else if (oModel.getData().d.results[0].msg_type == "E") {
                                    oControllerS3
                              .customBusyDialogClose();
                                     sap.m.MessageBox
                              .alert(oModel.getData().d.results[0].msg_text);
                                                  }

                                             },

                                             onCloseButtonPressedCancel : function(oEvent) {
                                              this.closeDialog('closeFileDialog');
                                             },*/

                                             // Close File Actions
                                             /*closeButtonPressed : function(oEvent) {

                                              var assistFlag = this.oRouter.getView("flm.fiori.view.S1").getController().assistFlag;

                                              if (assistFlag == true) {
                                               // this.assistNotButtonPressed();

                                               sap.m.MessageBox
                                                 .confirm(
                                                   this.getView().getModel("i18n").getObject("MESSAGE_26"),
                                                   function(response) {
                                                    if (response == "OK") {
                                                     oControllerS3.openDialog('closeFileDialog');
                                                    } else {
                                                     oControllerS3
                                                       .customBusyDialogClose();
                                                    }
                                                   });
                                              }
                                              else{
                                               oControllerS3.openDialog('closeFileDialog');
                                              }

                                             },*/

                                             // event handler for closing the file
                                             closeButtonPressed : function(oEvent) {

                                              var oTableId = null;
                            var oEntitySet = null;

                             oTableId = "idDraftsTable";
                             oEntitySet = "/FILE_DRAFT_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
                             sap.m.MessageBox.confirm(this.getView().getModel("i18n").getObject("MESSAGE_45"),
                               function(response) {
                                 if (response == "OK") {
                                  var assistFlag = oControllerS3.oRouter.getView("flm.fiori.view.S1").getController().assistFlag;
                             if (assistFlag == true) {
                              sap.m.MessageBox.confirm(
                                oControllerS3.getView().getModel("i18n").getObject("MESSAGE_26"),
                                  function(response) {
                                   if (response == "OK") {
                                              if (oTableId != null) {
                                               oControllerS3.customBusyDialogOpen();

                                               var oModel = new sap.ui.model.json.JSONModel();// oControllerS2.oRouter.getView("flm.fiori.view.S1").byId(oTableId).getModel("files");
                                               var oTable = oControllerS3.oRouter.getView(
                                                 "flm.fiori.view.S1").byId(oTableId);
                                               oModel
                                                 .attachRequestCompleted(
                                                   this,
                                                   function(oEvent) {

                                                    oModel.detachRequestCompleted();
                                                    // delete the file from the tab
                                                    var tempArr = oTable
                                                      .getModel("files").oData.results;
                                                    var i = 0, j = -1;
                                                    while (i < tempArr.length) {
                                                     if (tempArr[i].CaseGuid == oControllerS3.caseguid) {
                                                      j = i;
                                                      break;
                                                     }
                                                     i++;
                                                    }
                                                    if (j != -1) {
                                                     oTable.removeSelections();
                                                     tempArr.splice(j, 1);
                                                     oTable.getModel("files").oData.__count--;
                                                     oTable.getModel("files")
                                                       .checkUpdate();
                                                    }

                                                    sap.m.MessageToast
                                                      .show(oControllerS3.getView()
                                                        .getModel(
                                                          "i18n")
                                                        .getObject(
                                                          "FILECLOSED"));
                                                    oControllerS3.customBusyDialogClose();
                                                    oControllerS3.oRouter.getView(
                                                      "flm.fiori.view.S1")
                                                      .byId("closeAction")
                                                      .setEnabled(false);
                                                    oControllerS3.oRouter.getView(
                                                      "flm.fiori.view.S1")
                                                      .byId("sendAction")
                                                      .setEnabled(false);
                                                    oTable.removeSelections();
                                                    destroyDialogs(oControllerS3); //destroy all common fragments
                                                    oControllerS3.oRouter.navTo("fullscreen");
                                                   }, this);
                                               // Failure
                                               oModel.attachRequestFailed(this, function(oEvent) {
                                                oModel.detachRequestCompleted();
                                                oModel.detachRequestFailed();
                                                sap.m.MessageBox.alert(oControllerS3.getView().getModel(
                                                  "i18n").getObject("MESSAGE_27"));
                                                oControllerS3.customBusyDialogClose();
                                               }, this);

                                               oModel
                                                 .loadData(
                                                   serviceUrl
                                             + "/FILES_FI?param_1='CF'&param_2='"
                                             + oControllerS3.caseguid
                                             + "'&param_3=''&param_4='"
                                             + oControllerS3.fileid
                                             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
                                             + oControllerS3.fromTab
                                             + "'&param_8=''&param_9=''&param_10=''",
                                           null, true);
                                              }else {
                                               oControllerS3.customBusyDialogClose();
                                           }
                                                }});
                                          }else {
                                           if (oTableId != null) {
                                            oControllerS3.customBusyDialogOpen();

                                               var oModel = new sap.ui.model.json.JSONModel();// oControllerS2.oRouter.getView("flm.fiori.view.S1").byId(oTableId).getModel("files");
                                               var oTable = oControllerS3.oRouter.getView(
                                                 "flm.fiori.view.S1").byId(oTableId);
                                               oModel
                                                 .attachRequestCompleted(
                                                   this,
                                                   function(oEvent) {

                                                    oModel.detachRequestCompleted();
                                                    // delete the file from the tab
                                                    var tempArr = oTable
                                                      .getModel("files").oData.results;
                                                    var i = 0, j = -1;
                                                    while (i < tempArr.length) {
                                                     if (tempArr[i].CaseGuid == oControllerS3.caseguid) {
                                                      j = i;
                                                      break;
                                                     }
                                                     i++;
                                                    }
                                                    if (j != -1) {
                                                     oTable.removeSelections();
                                                     tempArr.splice(j, 1);
                                                     oTable.getModel("files").oData.__count--;
                                                     oTable.getModel("files")
                                                       .checkUpdate();
                                                    }

                                                    sap.m.MessageToast
                                                      .show(oControllerS3.getView()
                                                        .getModel(
                                                          "i18n")
                                                        .getObject(
                                                          "FILECLOSED"));
                                                    oControllerS3.customBusyDialogClose();
                                                    oControllerS3.oRouter.getView(
                                                      "flm.fiori.view.S1")
                                                      .byId("closeAction")
                                                      .setEnabled(false);
                                                    oControllerS3.oRouter.getView(
                                                      "flm.fiori.view.S1")
                                                      .byId("sendAction")
                                                      .setEnabled(false);
                                                    oTable.removeSelections();
                                                    destroyDialogs(oControllerS3); //destroy all common fragments
                                                    oControllerS3.oRouter.navTo("fullscreen");
                                                   }, this);
                                               // Failure
                                               oModel.attachRequestFailed(this, function(oEvent) {
                                                oModel.detachRequestCompleted();
                                                oModel.detachRequestFailed();
                                                sap.m.MessageBox.alert(this.getView().getModel(
                                                  "i18n").getObject("MESSAGE_27"));
                                                oControllerS3.customBusyDialogClose();
                                               }, this);

                                               oModel
                                                 .loadData(
                                                   serviceUrl
                                             + "/FILES_FI?param_1='CF'&param_2='"
                                             + oControllerS3.caseguid
                                             + "'&param_3=''&param_4='"
                                             + oControllerS3.fileid
                                             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
                                             + oControllerS3.fromTab
                                             + "'&param_8=''&param_9=''&param_10=''",
                                           null, true);
                                           }else {
                                            oControllerS3.customBusyDialogClose();
                                            }
                                         }
                                       }
                                      });
                                             },

                                             onCloseButtonPressedCancel : function(oEvent) {
                                              this.closeDialog('closeFileDialog');
                                             },
                                                             
                                             onDeleteWorkflowSelect : function(oEvent){
                                              var rightTree = sap.ui.getCore().byId("rightTree");
                                                                rightTree.rerender();
                                                                var rightIndices = rightTree.getSelectedIndices();
//                                                                var rightIndex = rightTree.getSelectedIndex()-1;
                                                                if (rightIndices.length==0) {
                                                                       alert(this.getView().getModel("i18n").getObject("MESSAGE_16"));
                                                                }
                                                                else{
                                                                 var data = rightTree.getModel().oData.results;
                                                                 for(var i=rightIndices.length-1;i>=0;i--){
                                                                 if(rightIndices[i]==0){
                                                                  continue;
                                                                 }else{
                                                                  data[0].nodes.splice(rightIndices[i]-1,1);
                                                                 }
                                                                 }
                                                                    rightTree.getModel().checkUpdate();
                                                                    sap.ui.getCore().byId("rightTree").setSelectedIndex(0);
                                                                    rightTree.rerender();
                                                                   }
                                                                rightTree.setSelectedIndex(0);
                                                                for(var i=0;i<sap.ui.getCore().byId("rightTree").getModel().getData().results.length;i++){   
                                                                    if(sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Sequence" || sap.ui.getCore().byId("rightTree").getRows()[i].getBindingContext().getObject().Type=="Parallel"){
                                                                        sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[2].setEnabled(false);
                                                                        sap.ui.getCore().byId("rightTree").getRows()[i].getCells()[3].setEnabled(false);
                                                                       }
                                                                   }
                                                                return;
                                             },

                                             subDetailsPressed : function(oEvent){
                                              if (!this.privateDetailOpen) {
                                               this.privateDetailOpen = sap.ui.xmlfragment(
                                                 "flm.fiori.view.privateDetails", this);
                                              }
                                              var detailsModel = new sap.ui.model.json.JSONModel();
                                              detailsModel.setData(oEvent.getSource()
                                                .getBindingContext("global").getObject());
                                              this.privateDetailOpen.setModel(detailsModel);
                                              this.privateDetailOpen.bindElement("/");
                                              this.privateDetailOpen.openBy(oEvent.getSource());
                                             },

                                             raiseFlag : function(oEvent){
                                              sap.m.MessageToast
                                              .show(oControllerS3.getView().getModel("i18n").getObject("MESSAGE_57"));
                                              oEvent.getSource().setValue("");
                                             },
                                                             
                                                           loadRemainingTree : function(oEvent){
                                                           
                                                            var nodeParams=oEvent.getSource().getParent().getBindingContext().getObject();
                                                            var oTable=sap.ui.getCore().byId("leftTree");
                                                            if(nodeParams.Otype.length<2){
                                                             nodeParams.Otype+=' ';
                                                            }
                                                            nodeParams.OobjId=nodeParams.Otype+nodeParams.Objid;
                                                            nodeParams.Level="";
                                                            var result=oControllerS3.leftTreeNodes;
                                                            var oModel = new sap.ui.model.json.JSONModel();
                                                            oModel.attachRequestCompleted(oControllerS3,function(oEvent){
                                                             if(oEvent.mParameters.errorobject){
                                                              oModel.detachRequestCompleted();
                                                                    sap.m.MessageBox.alert(getErrorJson(oEvent.mParameters.errorobject.responseText));
                                 return;
                                                             }
                                                               },oControllerS3);
                                                            oModel.loadData(serviceUrl
                                                                       + "/ORGU_MEM_ETSet?$filter=OobjId eq '"
                                                                       + nodeParams.OobjId + "' and LevelDesc eq '"+nodeParams.LevelDesc+"'",
                                                                       null, false);
                                                            try{
                                                            result=result.concat(oModel.getData().d.results);
                                                            }
                                                            catch(err){
                                                             
                                                            }
                                                            oControllerS3.leftTreeNodes=result;
                                                               // /////////////////
                                                                                 var obj = {
                                                                                         "nodes" : [],
                                                                                         "Label" : "Sequence"
                                                                                  };
                                                                                  for ( var i = 0; i < result.length; ++i) {
                                                                                         result[i].__metadata = null;
                                                                                         var levels = result[i].LevelDesc.split("_");

                                                                                         for ( var k = 0; k < levels.length; ++k) {
                                                                                                levels[k] = parseInt(levels[k]) - 1;
                                                                                         }

                                                                                         var tempObj = obj;

                                                                                         for ( var j = 0; j < levels.length - 2; ++j) {
                                                                                                tempObj = tempObj.nodes[levels[j]];
                                                                                         }

                                                                                         if (tempObj.nodes[levels[j]] == undefined) {
                                                                                                result[i].nodes = [];
                                                                                                tempObj.nodes[levels[j]] = result[i];
                                                                                                continue;
                                                                                         }

                                                                                         result[i].nodes = [];
                                                                                         tempObj.nodes[levels[j]].nodes.push(result[i]);
                                                                                  }

                                                                                  oModel.setData(obj);
                                                                                 // ////////////////

// oModel.setData(result);

                                                                                 oTable.setModel(oModel); // set
                           // model
                           // to
                                                                                                                                 // Table*/
                                                                                 
                                                                                 oTable.bindRows("/");
                                                                                 for(var i=0;i<result.length;i++){
                                                                                  oTable.expand(i);
                                                                                 }
                                                           },
                                                           
                                                           onPressClearTree : function(oEvent){
                                                            var oTable=sap.ui.getCore().byId("rightTree");
                                                            var oModel = new sap.ui.model.json.JSONModel();
                                                               oModel.setData({
                                                                      "results" : [ {
                                                                             "Type" : "Sequence",
                                                                             "Text" : "Sequence",
                                                                             "Activity" : "SPACE",
                                                                             "nodes" : []
                                                                      } ]
                                                               });
                                                               oTable.setModel(oModel);
                                                           },
                                                           
                                                           continueAfterSave : function(actionId) {

                                             if (actionId == "navButtonPress") {
                                              oControllerS3.navBack();
                                             }  else if (actionId == "idPrint1") {
                                           oControllerS3.printWorkflowAction();
                                          } else if (actionId == "idPrint2") {
                                           oControllerS3.printNotingPrivateAction();
                                          } else if (actionId == "idPrint3") {
                                           oControllerS3.printNotingAction();
                                          } /*else if (actionId.indexOf("idButtonSend")!=-1) {
                                              oControllerS3.sendButtonPressed();
                                             }*/ else if (actionId == "sendAction") {
                                           oControllerS3.sendButtonPressed();
                                          }else if(actionId == "shareAction"){
                                              oControllerS3.shareDraftActionOpen();
                                             }
                                            },

                                            invokeForSave : function(oEvent) {
                                             var actionId = "";
                                             if (oEvent.getId() == "navButtonPress") {
                                              actionId = oEvent.getId();
                                             } else {
                                              actionId = oEvent.getSource().getId();
                                             }
                                             if (oControllerS3.saveFlag) {
                                              if(actionId.indexOf("idButtonSend")!=-1){
                                            sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_64"));
                                            return;
                                           }
                                           else{
                                              sap.m.MessageBox
                                                .confirm(
                                                  this.getView().getModel("i18n").getObject("MESSAGE_74"),
                                                  function(response) {
                                                   if (response == "OK") {
//                                                    oControllerS3.saveButtonPressed();
                                                    oControllerS3.continueAfterSave(actionId);
                                                    oControllerS3.saveFlag = false;
//                                                    oControllerS3.flatObj=undefined;
                                                   } else {
//                                                    oControllerS3.continueAfterSave(actionId);
//                                                    oControllerS3.saveFlag = false;
//                                                    oControllerS3.flatObj=undefined;
                                                    return;
                                                   }
                                                  });
                                           }
                                             } else {
                                              oControllerS3.continueAfterSave(actionId);
                                             }
                                            },

                                            printActionsOpen : function(oEvent) {
                                          var oButton = oEvent.getSource();
                                          if (!this._printActionSheet) {
                                           this._printActionSheet = sap.ui.xmlfragment(
                                             "flm.fiori.view.printActionButtons", this);
                                           this.getView().addDependent(this._printActionSheet);
                                          }
                                          jQuery.sap.delayedCall(0, this, function() {
                                           this._printActionSheet.openBy(oButton);
                                          });
                                         },

                                            printWorkflowAction : function(oEvent) {
                                          window
                                            .open(serviceUrl
                                              + "/FILE_DOC_ES(Guid='"
                                              + this.caseguid
                                              + "',DocumentNumber='',DocumentName='',Version='',PhysVersion='')/$value");


                                         },
                                         printNotingPrivateAction : function(oEvent) {
                                          // var str_pdf;

                                          var oModel = new sap.ui.model.json.JSONModel();
                                          oModel.loadData(serviceUrl
                                            + "/FILE_DOC_FI?param_1='PN'&param_2='"
                                            + this.caseguid + "'&param_3='" + this.fileid
                                            + "'&param_4=''&param_5=''", null, false);
                                          if (oModel.getData().d.results[0].FileType == "text/html") {

                                           var newWindow = window.open("Notings.html",
                                             "mywin", '');
                                           try{
                                           newWindow.document
                                             .write(decodeURIComponent(oModel.getData().d.results[0].FileContent));
                                           }catch(err){
                                            newWindow.document
                                            .write(oModel.getData().d.results[0].FileContent);
                                           }

                                           // .open("data:text/html," +
                                           // oModel.getData().d.results[0].FileContent);
                                           // + encodeURIComponent(oModel
                                           // .getData().d.results[0].FileContent));
                                          }
                                         },
                                         printNotingAction : function(oEvent) {
                                          // var str_pdf;

                                          var oModel = new sap.ui.model.json.JSONModel();
                                          oModel.loadData(serviceUrl
                                            + "/FILE_DOC_FI?param_1='PY'&param_2='"
                                            + this.caseguid + "'&param_3='" + this.fileid
                                            + "'&param_4=''&param_5=''", null, false);
                                          if (oModel.getData().d.results[0].FileType == "text/html") {
//                                           window
//                                             .open("data:text/html,"
//                                               + encodeURIComponent(oModel
//                                                 .getData().d.results[0].FileContent));
                                           var newWindow = window.open("Notings.html",
                                             "mywin", '');
                                           try{
                                           newWindow.document
                                             .write(decodeURIComponent(oModel.getData().d.results[0].FileContent));
                                           }catch(err){
                                            newWindow.document
                                            .write(oModel.getData().d.results[0].FileContent);
                                           }
                                          }
                                         },
                                         shareDraftActionOpen : function(oEvent){
                                          //this.openDialog('shareFileAttributes');
                                          if(this.getView().byId("notingEditor").getValue() ==""){
                                        sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_66"));
                                        return;
                                       }
                                          if (!oControllerS3.shareAttrDialog) {
                                           oControllerS3.shareAttrDialog = sap.ui.xmlfragment(
                                            "flm.fiori.view.shareFileAttributes", oControllerS3);
                                          }
                                          oControllerS3.shareAttrDialog.open();
                                         },
                                         shareAttributesCloseAction : function(oEvent) {
                                          sap.ui.getCore().byId("userValueInput").setValue("");
                                          sap.ui.getCore().byId("attribute").setState(false);
                                          sap.ui.getCore().byId("document").setState(false);
                                          sap.ui.getCore().byId("noting").setState(false);
                                          sap.ui.getCore().byId("workflow").setState(false);

                                          //this.closeDialog('shareFileAttributes');

                                          oControllerS3.shareAttrDialog.close();
                                         },
                                         shareAttributesOkAction : function(oEvent) {
                                          if (sap.ui.getCore().byId("userValueInput").getValue() == "") {
                                           sap.m.MessageToast
                                             .show(this.getView().getModel("i18n").getObject("MESSAGE_42"));
                                           return;
                                          }


                                          var value6 = '';
                                          var value7 = '';
                                          var value8 = '';
                                          var value9 = '';
                                          var value10 = '';
                                          var noteInput = this.getView().byId("notingEditor")
                                            .getValue();

                                          //Changes to be made, replace function import with create_entity
//                                          noteInput = noteInput.replace(/&nbsp;/g," ");
                                          if (noteInput != '') {
                                           value6 = noteInput;
                                          }

                                          var inputValue = sap.ui.getCore()
                                            .byId("userValueInput").getName();

                                          var docChecked = sap.ui.getCore().byId("document")
                                            .getState();
                                          if (docChecked == true) {
                                           value7 = 'X';
                                          }
                                          var attChecked = sap.ui.getCore().byId("attribute")
                                            .getState();
                                          if (attChecked == true) {
                                           value8 = 'X';
                                          }
                                          var notChecked = sap.ui.getCore().byId("noting")
                                            .getState();
                                          if (notChecked == true) {
                                           value9 = 'X';
                                          }
                                          var wfChecked = sap.ui.getCore().byId("workflow")
                                            .getState();
                                          if (wfChecked == true) {
                                           value10 = 'X';
                                          }
//                                          var oModel = new sap.ui.model.json.JSONModel();
                                          var oModel = this.getView().getModel();
                                          var newNoting = this.getView().byId("notingEditor")
                                          .getValue();// oEvent.getSource().getBindingContext().getObject();
                                          var fiString="SF,"+this.caseguid+","+000000000000+","+this.fileid+","+inputValue+","+","+value7+","+value8+","+value9+","+value10;
                                          var newNotingData = {
                                            TabType : this.fromTab,
                                            Textid : "",
                                            Wiid : "",
                                            CaseGuid : this.caseguid,
                                            NotingString : "",
                                            ANotingString : newNoting,
                                            SNotingString : "",
                                            PAgent : "",
                                            Photourl : fiString
                                          };
                                          this.customBusyDialogOpen();
                                          oModel
                                          .create(
                                            "/FILE_NOTING_ES",
                                            newNotingData,
                                            {
                                             success : function(oResponse) {

                                              oControllerS3.getView().byId(
                                              "notingEditor")
                                              .setValue("");
                                              //oControllerS3.closeDialog('shareFileAttributes');
                                              //oControllerS3.getView().byId("shareDraftAction").setEnabled(false);
                                              oControllerS3.shareAttrDialog.close();
                                              oControllerS3.oRouter.getView(
                                              "flm.fiori.view.S1")
                                              .byId("idDraftsTable")
                                              .removeSelections();
                                              oControllerS3.oRouter.getView(
                                              "flm.fiori.view.S1")
                                              .byId("sendAction")
                                              .setEnabled(false);
                                              oControllerS3.oRouter.getView(
                                              "flm.fiori.view.S1")
                                              .byId("closeAction")
                                              .setEnabled(false);
                                              destroyDialogs(oControllerS3); //destroy all common fragments
                                              oControllerS3.oRouter
                                              .navTo("fullscreen");
                                              sap.m.MessageToast
                                              .show(oControllerS3.getView().getModel("i18n").getObject("MESSAGE_65"));
                                              oControllerS3.customBusyDialogClose();
                                             },

                                             async : false
                                            });
                                          sap.ui.getCore().byId("userValueInput").setValue("");
                                          sap.ui.getCore().byId("attribute").setState(false);
                                          sap.ui.getCore().byId("document").setState(false);
                                          sap.ui.getCore().byId("noting").setState(false);
                                          sap.ui.getCore().byId("workflow").setState(false);
                                         },

                                         onPressHelpValue : function(oEvent) {
                                          if (!oControllerS3._oDynamicF4Dialog) {
                                           oControllerS3._oDynamicF4Dialog = sap.ui
                                             .xmlfragment(
                                               "flm.fiori.view.dynamicF4popup",
                                               oControllerS3);
                                          }
                                          oF4Texts = new sap.ui.model.json.JSONModel();
                                          var f4text = {
                                           title : this.getView().getModel("i18n").getObject("USER"),
                                           id : oEvent.getSource().getId()
                                          };
                                          oF4Texts.setData(f4text);
                                          oControllerS3._oDynamicF4Dialog.setModel(oF4Texts,
                                            "dyntext");

                                          var oF4Model = new sap.ui.model.json.JSONModel();
                                          oF4Model
                                            .loadData(
                                              serviceUrl
                                                + "/FILE_F4_ES?$filter=CaseGuid eq '"
                                                                                         + this.caseguid
                                                                                         + "' and ID eq 'US' and WF eq true",
                                              null, false);
                                          oF4Model.setData(oF4Model.oData.d.results);
                                          oControllerS3._oDynamicF4Dialog.setModel(oF4Model);
                                          oControllerS3._oDynamicF4Dialog.open();
                                         },
                                         sendOptionsOpen : function(oEvent) {
                                          var oButton = oEvent.getSource();
                                          //if (!this._sendActionSheet) {
                                           if (!oControllerS3._sendActionSheet || oControllerS3._sendActionSheet.getButtons().length == 0){
                                           this._sendActionSheet = sap.ui.xmlfragment(
                                             "flm.fiori.view.sendButton", this);
                                           this.getView().addDependent(this._sendActionSheet);
                                          }
                                          jQuery.sap.delayedCall(0, this, function() {
                                           this._sendActionSheet.openBy(oButton);
                                          });
                                         },
                                           
                                         onChangeDateTimeInDynamicUI : function(oEvent) {
                                          oControllerS3.saveFlag = true;
                                          if(oEvent.getSource().getValue()!="" && oEvent.getSource().getEditable()){
                                          sap.ui.getCore().byId(oEvent.getSource().getId()+"Clear").setVisible(true);
                                          }else{
                                          sap.ui.getCore().byId(oEvent.getSource().getId()+"Clear").setVisible(false);
                                          }  

                                         },      

                                         workflowOptionsOpen : function(oEvent) {
                                          var oButton = oEvent.getSource();
                                          //if (!this._workflowActionSheet) {
                                           if (!oControllerS3._workflowActionSheet || oControllerS3._workflowActionSheet.getButtons().length == 0){
                                           this._workflowActionSheet = sap.ui.xmlfragment(
                                             "flm.fiori.view.addNewWorkflow", this);
                                           this.getView().addDependent(this._workflowActionSheet);
                                          }
                                          jQuery.sap.delayedCall(0, this, function() {
                                           this._workflowActionSheet.openBy(oButton);
                                          });
                                         },

                                         onDeleteSelect : function(oEvent){
                                                         if(oControllerS3.getView().byId("wftree").getSelectedIndex()==-1){
                                                          sap.m.MessageBox.alert(oControllerS3.getView().getModel("i18n").getObject("MESSAGE76"));
                                                          return;
                                                         }
                                          sap.m.MessageBox.confirm(this.getView().getModel("i18n").getObject("MESSAGE_92"),
                                                           function(response) {
                                 if (response == "OK") {
                                  oControllerS3.customBusyDialogOpen();
                                                                     var selectedNodes=oControllerS3.byId("wftree").getSelectedIndices();
                                                                     for(var i=selectedNodes.length-1;i>=0;i--){
                                                      var currNode = oControllerS3.byId("wftree").getContextByIndex(
                                                        selectedNodes[i])
                                                        .getObject();
                                                                  oControllerS3.deleteCurrentNode(currNode);
                                                      }
                                                      oControllerS3.loadTreeTable();
                                                oControllerS3.byId("wftree").setSelectedIndex(-1);
                                 }
                                 else{
                                  oControllerS3.customBusyDialogClose();
                                  return;
                                 }
                                                               });
                                                        },

                                                        deleteCurrentNode : function(currNode){
                                                         var oModel = oControllerS3.getView().getModel();
                                                         if(currNode.isSpecial=="X"){
                                                          for(var i=0;i<currNode.nodes.length;i++){
                                                          if(currNode.nodes[i].uiDeleted!='X'){
                                                          oControllerS3.deleteCurrentNode(currNode.nodes[i]);
                                                          }
                                                          }
                                                         }else{
                                          oModel.remove("/FILE_PROUTE_ES(Posid='"
                                            + currNode.Posid + "',CaseGuid='"
                                            + oControllerS3.caseguid + "',WitemId='')", {
                                           success : function(oResponse) {

                                            currNode.uiDeleted="X"; //To prevent multiple deletion in case of parallel block
                                            oControllerS3.customBusyDialogClose();
                                           },
                                           error : function(oResponse) {
                                            oControllerS3.customBusyDialogClose();
                                           },
                                           async : false,
                                          });
                                                         }
                                                        },

                                                        onRowSelectionChange : function(oEvent){
                                                         if (!oControllerS3._workflowActionSheet || oControllerS3._workflowActionSheet.getButtons().length == 0){
                                           this._workflowActionSheet = sap.ui.xmlfragment(
                                             "flm.fiori.view.addNewWorkflow", this);
                                           this.getView().addDependent(this._workflowActionSheet);
                                          }
                                                         if(oControllerS3.byId("wftree").getSelectedIndex()==-1){
                                                          oControllerS3.byId("idDeleteButton").setEnabled(false);
                                                             sap.ui.getCore().byId("addInParallel").setEnabled(false);
                                                          oControllerS3.byId("idAddNewWorkflowButton").setEnabled(true);

                                                         }else if(oControllerS3.byId("wftree").getSelectedIndices().length>1){
                                                          oControllerS3.byId("idDeleteButton").setEnabled(true);
                                                          oControllerS3.byId("idAddNewWorkflowButton").setEnabled(false);
                                                         }else{
                                                          oControllerS3.byId("idAddNewWorkflowButton").setEnabled(true);
                                                          oControllerS3.byId("idDeleteButton").setEnabled(true);
                                                             sap.ui.getCore().byId("addInParallel").setEnabled(true);
                                                         }
                                                         var lmod = this.getView().byId("wftree").getModel("workflow").oData;
                                                         if(lmod.nodes[0].isParallel=="")
                                                         {sap.ui.getCore().byId("addInParallel").setEnabled(false);}
                                                        },
                                                        
                                                        onCreateWFRowSelectionChange : function(oEvent){
                                                         if(sap.ui.getCore().byId("rightTree").getSelectedIndex()==-1){
                                                             sap.ui.getCore().byId("idAddProcessorButton").setEnabled(false);
                                                             sap.ui.getCore().byId("idDeleteProcessorButton").setEnabled(false);
                                                             sap.ui.getCore().byId("idClearTreeButton").setEnabled(false);
                                                         }else if(sap.ui.getCore().byId("rightTree").getSelectedIndex()==0){
                                                          sap.ui.getCore().byId("idAddProcessorButton").setEnabled(true);
                                                             sap.ui.getCore().byId("idDeleteProcessorButton").setEnabled(false);
                                                         }else{
                                                          sap.ui.getCore().byId("idAddProcessorButton").setEnabled(true);
                                                             sap.ui.getCore().byId("idDeleteProcessorButton").setEnabled(true);
                                                             sap.ui.getCore().byId("idClearTreeButton").setEnabled(true);
                                                         }
                                                        },
                                                        clearDateTime : function(oEvent){
                                                         if(oEvent.getSource().getId()=="idOrgUnitClear"){
                                                          sap.ui.getCore().byId("idOrgUnit").setValue("");
                                                          sap.ui.getCore().byId("leftTree").setModel(new sap.ui.model.json.JSONModel());
                                                          sap.ui.getCore().byId("idOrgUnitClear").setVisible(false);
                                                          sap.ui.getCore().byId("leftTree").setSelectedIndex(-1);
                                                         }else if(oEvent.getSource().getId()=="idFactoryCalendarClear"){
                                                          sap.ui.getCore().byId("idFactoryCalendar").setValue("");
                                                          sap.ui.getCore().byId("idFactoryCalendarClear").setVisible(false);
                                                         }
                                                        },
                                                        
                                                        /*onTreeCellClicked : function(oEvent){
                                                         if(window.event.ctrlKey){
                                                          sap.ui.getCore().byId("leftTree").getSelectedIndices().splice(0,0,oEvent.getParameter("rowIndex"));
                                                         }else{
                                                          sap.ui.getCore().byId("leftTree").setSelectedIndex(oEvent.getParameter("rowIndex"));
                                                         }
                                                         sap.ui.getCore().byId("leftTree").refreshRows();
                                                        }*/
                                                              });