/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("sap.ca.ui.message.message");

//var oControllerS4 = null;
var archiveFlag = false;
sap.ca.scfld.md.controller.BaseFullscreenController
  .extend(
    "flm.fiori.view.S8",
    {

     data : {
      priority : null,
      criteria : null,
      operators : null,
      searchData : null,
      searchResults : null,
       },


     linkPress : false,

     onInit : function() {
      serviceUrl = this.getView().getModel().sServiceUrl;
      if(sap.ui.getCore().getModel("i18n") == undefined){
       sap.ui.getCore().setModel(this.getView().getModel("i18n"),"i18n");
      }
      this.getView().addEventDelegate({

                            onBeforeShow : jQuery.proxy(function(evt) {

                                   this.onBeforeShow(evt);

                            }, this)

      });
      //oControllerS4 = this;

      this.mGroupFunctions = {
        PriorityText : function(oContext) {
         var name = oContext.getProperty("PriorityText");
         return {
          key : name,
          text : name
         };
        },
        CreatedByFname : function(oContext) {
         var name = oContext.getProperty("CreatedByFname");
         return {
          key : name,
          text : name
         };
        },
        CaseTypeDescr : function(oContext) {
         var name = oContext.getProperty("CaseTypeDescr");
         return {
          key : name,
          text : name
         };
        },
       };
      this._oTPS = new sap.m.TablePersoController({

       table : this.getView().byId("idSearchTable"),
       persoService : flm.fiori.utils.inboxPersonalDialog

      }).activate();
      if (!this.f4popup) {
       this.f4popup = sap.ui.xmlfragment(
         "flm.fiori.view.dynamicF4popup", this);
       // this.getView().addDependent(this.f4popup);
      }

      var oPriorityModel = new sap.ui.model.json.JSONModel();
      oPriorityModel.loadData(serviceUrl
        + "/FILE_F4_ES?$filter=ID eq 'PRIO'", null,
        false);

      this.data.priority = oPriorityModel.oData.d.results;
      this.data.criteria = [
        {
         key : "CASE_TITLE",
         title : this.getView().getModel("i18n")
           .getObject("SUBJECT")
        },
        {
         key : "DAAK_TYPE",
         title : this.getView().getModel("i18n")
           .getObject("FILENUMBER")
        },
        {
         key : "CREATED_BY",
         title : this.getView().getModel("i18n")
           .getObject("CREATEDBY")
        },
        {
         key : "CHANGED_BY",
         title : this.getView().getModel("i18n")
           .getObject("LASTCHANGEDBY")
        },
        {
         key : "CLOSED_BY",
         title : this.getView().getModel("i18n")
           .getObject("CLOSEDBYUSER")
        },
        {
         key : "CREATE_TIME",
         title : this.getView().getModel("i18n")
           .getObject("CREATEDON")
        },
        /*{
         key : "EXT_KEY",
         title : this.getView().getModel("i18n")
           .getObject("FILEID")
        },*/
        {
         key : "PLAN_END_DATE",
         title : this.getView().getModel("i18n")
           .getObject("DUEDATE")
        },
        {
         key : "ARCHIVE",
         title : this.getView().getModel("i18n")
           .getObject("READFROMARCHIVE")
        },
        {
         key : "STAT_ORDERNO",
         title : this.getView().getModel("i18n")
           .getObject("STATUS")
        },
        {
         key : "SAP_FLM_PRIO",
         title : this.getView().getModel("i18n")
           .getObject("PRIORITY")
        },
        {
         key : "FILE_TYPE",
         title : this.getView().getModel("i18n")
           .getObject("FILETYPE")
        },
        {
         key : "ORG_UNIT",
         title : this.getView().getModel("i18n")
           .getObject("ORGANIZATIONGROUP")
        }, ];

      this.data.operators = [
        {
         criteria : "GEN1",
         opkey : "01",
         optext : this.getView().getModel("i18n")
           .getObject("IS")
        },
        {
         criteria : "GEN2",
         opkey : "05",
         optext : this.getView().getModel("i18n")
           .getObject("CONTAINS")
        },
        {
         criteria : "GEN2",
         opkey : "04",
         optext : this.getView().getModel("i18n")
           .getObject("STARTSWITH")
        },
        {
         criteria : "DATE",
         opkey : "11",
         optext : this.getView().getModel("i18n")
           .getObject("ISEARLIERTHAN")
        },
        {
         criteria : "DATE",
         opkey : "12",
         optext : this.getView().getModel("i18n")
           .getObject("ISLATERTHAN")
        },
        {
         criteria : "DATE",
         opkey : "21",
         optext : this.getView().getModel("i18n")
           .getObject("ISEARLIERTHANORON")
        },
        {
         criteria : "DATE",
         opkey : "22",
         optext : this.getView().getModel("i18n")
           .getObject("ISLATERTHANORON")
        },
        {
         criteria : "ISNOT",
         opkey : "02",
         optext : this.getView().getModel("i18n")
           .getObject("ISNOT")
        } ];

      this.data.searchData = {
       criteria1 : "CASE_TITLE",
       op1 : "01",
       value1 : "",
       criteria2 : "DAAK_TYPE",
       op2 : "01",
       value2 : "",
       criteria3 : "CREATED_BY",
       op3 : "01",
       value3 : "",
       criteria4 : "CHANGED_BY",
       op4 : "01",
       value4 : "",
       criteria5 : "CLOSED_BY",
       op5 : "01",
       value5 : ""
      };
      var searchDaakModel = new sap.ui.model.json.JSONModel();
      searchDaakModel.setData(this.data);
      this.getView().setModel(searchDaakModel, "searchDaak");
      if(this.customInitializeDaakSearchData){
                            this.customInitializeDaakSearchData(this);
      }

     },

     onBeforeShow: function(evt){
      if(evt.fromId.indexOf("xmlview2") > -1){
       this.getView().byId("value1").setValue("");
       this.getView().byId("value2").setValue("");
       this.getView().byId("value3").setValue("");
       this.getView().byId("value4").setValue("");
       this.getView().byId("value5").setValue("");
       this.getView().byId("value6").setValue("");
//       this.getView().byId("value7").setValue("");
       this.getView().byId("value8").setValue("");
       /*this.getView().byId("value9").setState(false);
       this.getView().byId("value10").setSelectedKey("SPACE");
       this.getView().byId("value11").setSelectedKey("SPACE");
       this.getView().byId("value12").setValue("");
       this.getView().byId("value13").setValue("");*/

       this.getView().byId("op1").setSelectedKey("01");
       this.getView().byId("op2").setSelectedKey("01");
       this.getView().byId("op3").setSelectedKey("01");
       this.getView().byId("op4").setSelectedKey("01");
       this.getView().byId("op5").setSelectedKey("01");
       this.getView().byId("op6").setSelectedKey("01");
//       this.getView().byId("op7").setSelectedKey("01");
       this.getView().byId("op8").setSelectedKey("11");
       this.getView().byId("op9").setSelectedKey("01");
       this.getView().byId("op10").setSelectedKey("01");
       /*this.getView().byId("op11").setSelectedKey("01");
       this.getView().byId("op12").setSelectedKey("01");
       this.getView().byId("op13").setSelectedKey("01");*/

       this.data.searchResults = null;
       this.getView().getModel("searchDaak").checkUpdate();
      }
     },

     onpressf4User : function(oEvent) {
      oF4Texts = new sap.ui.model.json.JSONModel();
      var f4text = {
       title : this.getView().getModel("i18n").getObject(
         "USERS"),
       id : oEvent.getSource().getId()
      };
      oF4Texts.setData(f4text);
      this.f4popup.setModel(oF4Texts, "dyntext");

      var oF4Model = new sap.ui.model.json.JSONModel();
      oF4Model
        .loadData(
          serviceUrl
            + "/FILE_F4_ES?$filter=ID eq 'US' and WF eq true",
          null, false);
      oF4Model.setData(oF4Model.oData.d.results);
      this.f4popup.setModel(oF4Model);
      this.f4popup.open();
     },

     onpressRecievedMode : function(oEvent) {
      oF4Texts = new sap.ui.model.json.JSONModel();
      var f4text = {
       title : this.getView().getModel("i18n").getObject(
         "RECIEVED_MODE"),
       id : oEvent.getSource().getId()
      };
      oF4Texts.setData(f4text);
      this.f4popup.setModel(oF4Texts, "dyntext");

      var oF4Model = new sap.ui.model.json.JSONModel();
      oF4Model
        .loadData(
          serviceUrl
            + "/FILE_F4_ES?$filter=ID eq 'RM' and OtherF4 eq true",
          null, false);
      oF4Model.setData(oF4Model.oData.d.results);
      this.f4popup.setModel(oF4Model);
      this.f4popup.open();
     },

     onpressf4Filetype : function(oEvent) {
      oF4Texts = new sap.ui.model.json.JSONModel();
      var f4text = {
       title : this.getView().getModel("i18n").getObject(
         "FILETYPE"),
       id : oEvent.getSource().getId()
      };
      oF4Texts.setData(f4text);
      this.f4popup.setModel(oF4Texts, "dyntext");
      var oF4Model = new sap.ui.model.json.JSONModel();
      oF4Model
        .loadData(
          serviceUrl
            + "/FILE_F4_ES?$filter=ID eq 'IT' and OtherF4 eq true",
          null, false);
      oF4Model.setData(oF4Model.oData.d.results);
      this.f4popup.setModel(oF4Model);
      this.f4popup.open();
     },

     onpressf4Orgunit : function(oEvent) {
      oF4Texts = new sap.ui.model.json.JSONModel();
      var f4text = {
       title : this.getView().getModel("i18n").getObject(
         "ORGANIZATIONGROUP"),
       id : oEvent.getSource().getId()
      };
      oF4Texts.setData(f4text);
      this.f4popup.setModel(oF4Texts, "dyntext");
      var oF4Model = new sap.ui.model.json.JSONModel();
      oF4Model
        .loadData(
          serviceUrl
            + "/FILE_F4_ES?$filter=ID eq 'OC' and OtherF4 eq true",
          null, false);
      oF4Model.setData(oF4Model.oData.d.results);
      this.f4popup.setModel(oF4Model);
      this.f4popup.open();
     },

     _handleF4HelpSearch1 : function(evt) {

      var sValue = evt.getParameter("value");
      var oFilter = new sap.ui.model.Filter("ResulltCol1",
        sap.ui.model.FilterOperator.Contains, sValue);
      var oFilter1 = new sap.ui.model.Filter("ResultCol2",
        sap.ui.model.FilterOperator.Contains, sValue);
      var oFilter2 = new sap.ui.model.Filter("ResultCol3",
        sap.ui.model.FilterOperator.Contains, sValue);
      evt.getSource().getBinding("items").filter(
        new sap.ui.model.Filter([ oFilter, oFilter1,
          oFilter2 ]), "OR");
     },

//     _handleF4HelpClose1 : function(evt) {
//
//      var oSelectedItem = evt.getParameter("selectedItem");
//      if (oSelectedItem) {
//       var oInput = this.getView().byId(
//         evt.getSource().getModel("dyntext")
//           .getData().id); // get the id and
//       // place it here
//       oInput.setValue(oSelectedItem.getDescription()
//         + " " + oSelectedItem.getTitle());
//       oInput.setName(oSelectedItem.getBindingContext()
//         .getObject().ResultCol3);
//      }
//      evt.getSource().getBinding("items").filter([]);
//      this.f4popup.getModel().destroy();
//      this.f4popup.getModel("dyntext").destroy();
//     },

_handleF4HelpClose1 : function(evt) { // CHANGE

      var oSelectedItem = evt.getParameter("selectedItem");
      var id = evt.getSource().getModel("dyntext").getData().id;
      var oInput;
      if (oSelectedItem) {
       if (sap.ui.getCore().byId(id) != undefined) {
        oInput = sap.ui.getCore().byId(
          evt.getSource().getModel("dyntext")
            .getData().id);

       } else {
        oInput = this.getView().byId(
          evt.getSource().getModel("dyntext")
            .getData().id);
       }

       if (oSelectedItem.getBindingContext()
         .getObject().ResultCol3.substr(0, 2) == "US") {
        oInput
          .setName(oSelectedItem
            .getBindingContext()
            .getObject().ResultCol3);

        oInput
          .setValue(oSelectedItem
            .getBindingContext()
            .getObject().ResultCol2
            + " "
            + oSelectedItem
              .getBindingContext()
              .getObject().ResulltCol1);
       } else {
        oInput
          .setName(oSelectedItem
            .getBindingContext()
            .getObject().ResultCol3);

        oInput
          .setValue(oSelectedItem
            .getBindingContext()
            .getObject().ResulltCol1);
       }
      }

      evt.getSource().getBinding("items").filter([]);
     },

     onPressClear : function(oEvent) {
      this.getView().byId("value1").setValue("");
      this.getView().byId("value2").setValue("");
      this.getView().byId("value3").setValue("");
      this.getView().byId("value4").setValue("");
      this.getView().byId("value5").setValue("");
      this.getView().byId("value6").setValue("");
      this.getView().byId("value7").setValue("");
      this.getView().byId("value8").setValue("");
      this.getView().byId("value9").setValue("");
      this.getView().byId("value10").setValue("");
      this.getView().byId("value11").setValue("");
/*      this.getView().byId("value12").setValue("");
      this.getView().byId("value13").setValue("");*/

      this.getView().byId("op1").setSelectedKey("01");
      this.getView().byId("op2").setSelectedKey("01");
      this.getView().byId("op3").setSelectedKey("01");
      this.getView().byId("op4").setSelectedKey("01");
      this.getView().byId("op5").setSelectedKey("01");
      this.getView().byId("op6").setSelectedKey("01");
      this.getView().byId("op7").setSelectedKey("01");
      this.getView().byId("op8").setSelectedKey("01");
      this.getView().byId("op9").setSelectedKey("01");
      this.getView().byId("op10").setSelectedKey("01");
      this.getView().byId("op11").setSelectedKey("01");
/*      this.getView().byId("op12").setSelectedKey("01");
      this.getView().byId("op13").setSelectedKey("01");*/

      this.data.searchResults = null;
      this.getView().getModel("searchDaak").checkUpdate();
     },

     onPressDaakSearch : function(oEvent) {

      var i = -1;
      var searchFields = new Array();
      if (this.getView().byId("value1").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value1").getValue();
       searchFields[i].op = this.getView().byId("op1")
         .getSelectedKey();
       searchFields[i].criteria = "CASE_TITLE";
      }
      if (this.getView().byId("value2").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value2").getValue();
       searchFields[i].op = this.getView().byId("op2")
         .getSelectedKey();
       searchFields[i].criteria = "DAAK_TYPE";
      }
      if (this.getView().byId("value3").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value3").getValue();
       searchFields[i].op = this.getView().byId("op3")
         .getSelectedKey();
       searchFields[i].criteria = "REF_NUMBER";
      }
      if (this.getView().byId("value4").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value4").getName();
       searchFields[i].op = this.getView().byId("op4")
         .getSelectedKey();
       searchFields[i].criteria = "CREATED_BY";
      }
      if (this.getView().byId("value5").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value5").getName();
       searchFields[i].op = this.getView().byId("op5")
         .getSelectedKey();
       searchFields[i].criteria = "CLOSED_BY";
      }
      if (this.getView().byId("value6").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value6").getValue();
       searchFields[i].op = this.getView().byId("op6")
         .getSelectedKey();
       searchFields[i].criteria = "CREATE_TIME";
      }
      if (this.getView().byId("value7").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value7").getValue();
       searchFields[i].op = this.getView().byId("op7")
         .getSelectedKey();
       searchFields[i].criteria = "DAAK_NUMBER";
      }
      if (this.getView().byId("value8").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value8").getValue();
       searchFields[i].op = this.getView().byId("op8")
         .getSelectedKey();
       searchFields[i].criteria = "RECIEVED_DATE";
      }
      if (this.getView().byId("value9").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value9").getValue();
       searchFields[i].op = this.getView().byId("op9")
         .getSelectedKey();
       searchFields[i].criteria = "LETTER_DATE";
      }
      if (this.getView().byId("value10").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value10").getValue();
       searchFields[i].op = this.getView().byId("op10")
         .getSelectedKey();
       searchFields[i].criteria = "RECEIVED_MODE";
      }

      if (this.getView().byId("value11").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value11").getValue();
       searchFields[i].op = this.getView().byId("op11")
         .getSelectedKey();
       searchFields[i].criteria = "RECP_NAME";
      }

      /*if (this.getView().byId("value12").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value12").getValue();
       searchFields[i].op = this.getView().byId("op11")
         .getSelectedKey();
       searchFields[i].criteria = "FILE_TYPE";
      }
      if (this.getView().byId("value13").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = this.getView().byId(
         "value13").getValue();
       searchFields[i].op = this.getView().byId("op13")
         .getSelectedKey();
       searchFields[i].criteria = "ORG_UNIT";
      }*/
      var criteria1 = "";
      var criteria2 = "";
      var criteria3 = "";
      var criteria4 = "";
      var criteria5 = "";

      var op1 = "";
      var op2 = "";
      var op3 = "";
      var op4 = "";
      var op5 = "";

      var value1 = "";
      var value2 = "";
      var value3 = "";
      var value4 = "";
      var value5 = "";
      var max_res = this.getView().byId("resultCount")
        .getValue();
      if (searchFields.length > 5) {
       sap.m.MessageToast.show(this.getView().getModel(
         "i18n").getObject("MESSAGE_01"));
      } else if (searchFields.length == 0) {
       sap.m.MessageToast.show(this.getView().getModel(
         "i18n").getObject("MESSAGE_02"));
      } else {
       for (var j = 0; j < searchFields.length; j++) {
        if (j == 0) {
         criteria1 = searchFields[j].criteria;
         op1 = searchFields[j].op;
         value1 = searchFields[j].value;
        } else if (j == 1) {
         criteria2 = searchFields[j].criteria;
         op2 = searchFields[j].op;
         value2 = searchFields[j].value;
        } else if (j == 2) {
         criteria3 = searchFields[j].criteria;
         op3 = searchFields[j].op;
         value3 = searchFields[j].value;
        } else if (j == 3) {
         criteria4 = searchFields[j].criteria;
         op4 = searchFields[j].op;
         value4 = searchFields[j].value;
        } else if (j == 4) {
         criteria5 = searchFields[j].criteria;
         op5 = searchFields[j].op;
         value5 = searchFields[j].value;
        }

       }
       var osearchResultsModel = new sap.ui.model.json.JSONModel();
       this.busyDialogOpen();
       // this.getView().setBusy(true);
       osearchResultsModel
         .attachRequestCompleted(
           this,
           function(oEvent) {

            this.data.searchResults = osearchResultsModel.oData.d.results;
            /* Setting decoded value for subject*/
            /*for (var j = 0; j < osearchResultsModel.oData.d.results.length; j++) {
             var subValue = decodeURIComponent(osearchResultsModel.oData.d.results[j].CaseTitle);
             osearchResultsModel.oData.d.results[j].CaseTitle = subValue;
            }*/
            for (var j = 0; j < osearchResultsModel.oData.d.results.length; j++) {
             var afterSplit = osearchResultsModel.oData.d.results[j].PlanEndDate.split(".");
               var newDate = new Date(afterSplit[2], afterSplit[1]-1, afterSplit[0]);
               osearchResultsModel.oData.d.results[j].dueDate = newDate;
            }

            for (var j = 0; j < osearchResultsModel.oData.d.results.length; j++) {
             var firstSplit = osearchResultsModel.oData.d.results[j].CreateTime.split(" ");
             var secondSplit = firstSplit[0].split(".");
               var newDate = new Date(secondSplit[2], secondSplit[1]-1, secondSplit[0]);
               osearchResultsModel.oData.d.results[j].crDate = newDate;
            }
            this.getView().getModel(
              "searchDaak")
              .checkUpdate();
            // this.getView().setBusy(false);
            this.busyDialogClose();
           }, this);
       osearchResultsModel
         .loadData(
           serviceUrl
             + "/FILE_SRCH_FI?action='SI'&crit_1='"
             + criteria1 + "'&crit_2='"
             + criteria2 + "'&crit_3='"
             + criteria3 + "'&crit_4='"
             + criteria4 + "'&crit_5='"
             + criteria5 + "'&oper_1='"
             + op1 + "'&oper_2='" + op2
             + "'&oper_3='" + op3
             + "'&oper_4='" + op4
             + "'&oper_5='" + op5
             + "'&value_1='" + encodeURIComponent(value1)
             + "'&value_2='" + encodeURIComponent(value2)
             + "'&value_3='" + encodeURIComponent(value3)
             + "'&value_4='" + encodeURIComponent(value4)
             + "'&value_5='" + encodeURIComponent(value5)
             + "'&max_res='" + max_res
             + "'&is_type=''", null, true);

      }
      // this.getView().byId("idSearchTable").setBusy(false);
     },
     /* Navigating back to Intray */
     navToFirstPage : function(oEvent) {
      this.oRouter.navTo("fullscreen");
     },

     /* Navigating to display file */
     navToDetailsPage : function(oEvent) {

      if (this.linkPress) {
       // navigation should not be done when link is
       // clicked
       this.linkPress = false;
       return;
      }
      if(this.getView().byId("value9").getState() == true){
       archiveFlag = true;
       var archModel = new sap.ui.model.json.JSONModel();
       archModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='AR'&param_2='"
             + oEvent.getParameters().listItem
               .getBindingContext("searchDaak")
               .getObject().CaseGuid
             + "'&param_3='"
             + oEvent.getParameters().listItem
               .getBindingContext("searchDaak")
               .getObject().Wfpthid
             + "'&param_4='" 
             + oEvent.getParameters().listItem
             .getBindingContext("searchDaak")
             .getObject().PsReference
               + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
           null, false);
       if (archModel.getData().d.results.length == 0) {
        this.oRouter
          .navTo(
            "subscreen",
            {
             caseguid : oEvent
               .getParameters().listItem
               .getBindingContext("searchDaak")
               .getObject().CaseGuid,
             fileid : oEvent.getParameters().listItem
               .getBindingContext("searchDaak")
               .getObject().ExtKey,
             wiId : oEvent.getParameters().listItem
               .getBindingContext("searchDaak")
               .getObject().WiID
            });
       } else if (archModel.getData().d.results[0].msg_type == "E") {
        sap.m.MessageBox
          .alert(archModel.getData().d.results[0].msg_text);
        return;
       }
      }
      else{
       var authModel = new sap.ui.model.json.JSONModel();

      authModel
        .loadData(
          serviceUrl
            + "/FILES_FI?param_1='OD'&param_2='"
            + oEvent.getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().CaseGuid
            + "'&param_3='"
            + oEvent.getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().Wfpthid
            + "'&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
          null, false);
      if (authModel.getData().d.results.length == 0) {
       this.oRouter
         .navTo(
           "subscreen",
           {
            caseguid : oEvent
              .getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().CaseGuid,
            fileid : oEvent.getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().ExtKey,
            wiId : oEvent.getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().WiID
           });
      } else if (authModel.getData().d.results[0].msg_type == "E") {
       sap.m.MessageBox
         .alert(authModel.getData().d.results[0].msg_text);
       return;
      }
      }
     },

     onProcessorLinkClick : function(oEvent) {

      this.linkPress = true;

      if (!this.processorNames) {
       this.processorNames = sap.ui.xmlfragment(
         "flm.fiori.view.processorsList", this);
      }

      var Pathid = oEvent.getSource().getParent()
        .getBindingContext("searchDaak").getObject().Wfpthid;

      var oModel = new sap.ui.model.json.JSONModel();
      oModel.loadData(serviceUrl
        + "/FILE_SENT_FI?param_1='MP'&param_2='"
        + Pathid + "'&param_3=''", null, false);
      this.processorNames.setModel(oModel, "sentModelDetail");
      this.processorNames.openBy(oEvent.getSource());

     },
     onSentProcessorsListAction : function(oEvent) {
      oEvent.getSource().getParent().getParent().destroy();

     },

     busyDialogOpen : function(busyText) {
      if (!this._busyDialog) {

       this._dialog = sap.ui.xmlfragment(
         "flm.fiori.view.busyDialog", this);
      }
      if (busyText != null) {
       this._dialog.setText(busyText);
      } else {
       this._dialog.setText("");
      }

      this._dialog.open();
     },

     busyDialogClose : function() {
      this._dialog.close();
     },
     raiseFlag : function(oEvent){
      sap.m.MessageToast
      .show(this.getView().getModel("i18n").getObject("MESSAGE_57"));
      oEvent.getSource().setValue("");
     },

     onResultSearch : function(oEvnt) {
      var sQuery = oEvnt.getSource().getValue();
      var oTable = this.getView().byId("idSearchTable");
      var oBinding = oTable.getBinding("items");
      if (sQuery && sQuery.length > 0) {
       oBinding.filter(new sap.ui.model.Filter([
         new sap.ui.model.Filter("CreatedByFname",
           "Contains", sQuery),
         new sap.ui.model.Filter("PsReference",
           "Contains", sQuery),
         new sap.ui.model.Filter("CaseTitle",
           "Contains", sQuery),
         new sap.ui.model.Filter("Status",
           "Contains", sQuery),
         new sap.ui.model.Filter("PriorityText",
           "Contains", sQuery),
         new sap.ui.model.Filter("CaseTypeDescr",
           "Contains", sQuery),
         new sap.ui.model.Filter("AgentFullname",
           "Contains", sQuery),
         new sap.ui.model.Filter("CreateTime",
           "Contains", sQuery),
         new sap.ui.model.Filter("DateRecieved",
           "Contains", sQuery),
         new sap.ui.model.Filter("Actdc",
           "Contains", sQuery), ], "OR"));

      }else{
       oBinding.filter(new sap.ui.model.Filter("CreatedByFname",
         "Contains", ""));
      }
     },
     handleSearchFilter: function(oEvent) {

      this._oDialog = sap.ui.xmlfragment(
        "flm.fiori.view.searchFilterDialog", this);

      this._oDialog.open();
     },
     handleSearchPersonalization : function(oEvent) {
      this._oTPS.openDialog();
     },
     handleSearchSettings : function(oEvent) {

      var oView = this.getView();
      var oTable = oView.byId("idSearchTable");

      var mParams = oEvent.getParameters();
      var oBinding = oTable.getBinding("items");

      var aSorters = [];
      if (mParams.groupItem) {
       var sPath = mParams.groupItem.getKey();
       var bDescending = mParams.groupDescending;
       var vGroup = this.mGroupFunctions[sPath];
       aSorters.push(new sap.ui.model.Sorter(sPath,
         bDescending, vGroup));
      }
      var sPath = mParams.sortItem.getKey();
         var bDescending = mParams.sortDescending;
         aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
         oBinding.sort(aSorters);
      var aFilters = [];

      jQuery.each(mParams.filterItems, function(i, oItem) {
       var sPath = oItem.getKey();
       if (sPath != 'query_filter_files') {
        var oFilter = new sap.ui.model.Filter(sPath,
          sap.ui.model.FilterOperator.EQ, true);
        aFilters.push(oFilter);
       }

      });

      oBinding.filter(aFilters);
     },

     onSelectDaak : function(oEvent) {

      if (this.linkPress) {
       // navigation should not be done when link is
       // clicked
       this.linkPress = false;
       return;
      }
      /*if(this.getView().byId("value9").getState() == true){
       archiveFlag = true;
       var archModel = new sap.ui.model.json.JSONModel();
       archModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='AR'&param_2='"
             + oEvent.getParameters().listItem
               .getBindingContext("searchFile")
               .getObject().CaseGuid
             + "'&param_3='"
             + oEvent.getParameters().listItem
               .getBindingContext("searchFile")
               .getObject().Wfpthid
             + "'&param_4='" 
             + oEvent.getParameters().listItem
             .getBindingContext("searchFile")
             .getObject().PsReference
               + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
           null, false);
       if (archModel.getData().d.results.length == 0) {
        this.oRouter
          .navTo(
            "subscreen",
            {
             caseguid : oEvent
               .getParameters().listItem
               .getBindingContext("searchFile")
               .getObject().CaseGuid,
             fileid : oEvent.getParameters().listItem
               .getBindingContext("searchFile")
               .getObject().ExtKey,
             wiId : oEvent.getParameters().listItem
               .getBindingContext("searchFile")
               .getObject().WiID
            });
       } else if (archModel.getData().d.results[0].msg_type == "E") {
        sap.m.MessageBox
          .alert(archModel.getData().d.results[0].msg_text);
        return;
       }
      }
      else{*/
       var authModel = new sap.ui.model.json.JSONModel();

      authModel
        .loadData(
          serviceUrl
            + "/FILES_FI?param_1='OD'&param_2='"
            + oEvent.getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().CaseGuid
            + "'&param_3='"
            + oEvent.getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().Wfpthid
            + "'&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
          null, false);
      if (authModel.getData().d.results.length == 0) {
       this.oRouter
         .navTo(
           "daakdocscreen",
           {
            caseguid : oEvent
              .getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().CaseGuid,
            fileid : oEvent.getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().ExtKey,
            wiId : oEvent.getParameters().listItem
              .getBindingContext("searchDaak")
              .getObject().WiID
           });
      } else if (authModel.getData().d.results[0].msg_type == "E") {
       sap.m.MessageBox
         .alert(authModel.getData().d.results[0].msg_text);
       return;
      }
//      }
     },

    });