/*
 * Copyright (C) 2009-2014 SAP SE or an SAP affiliate company. All rights reserved
 */
jQuery.sap.require("sap.ca.scfld.md.controller.BaseFullscreenController");
jQuery.sap.require("flm.fiori.utils.inboxPersonalDialog");
jQuery.sap.require("sap.ca.ui.model.format.DateFormat");
jQuery.sap.require("flm.fiori.utils.dynamicUIAssist");
jQuery.sap.require("flm.fiori.utils.utilities");
jQuery.sap.require("sap.ca.ui.model.format.FileSizeFormat");
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require("sap.ui.thirdparty.sinon");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.ca.ui.quickoverview.Quickoverview");
jQuery.sap.require("flm.fiori.utils.formatter");
jQuery.sap.require("flm.fiori.utils.validator");
jQuery.sap.require("flm.fiori.utils.BASE64Util");
//sap.ui.richtexteditor.TinyMCELicense = "sap.only";
var oControllerS2 = null;

sap.ca.scfld.md.controller.BaseFullscreenController
  .extend(
    "flm.fiori.view.S2",
    {
     data : {
      priority : null,
      basic : null,
      dynamic : null,
      notings : null,
      folders : null,
      documents : null,
      receiverType : null,
      workflow : null,
      attributeHistory : null,
      buttons : null,
      searchResult : null,
     },
     // controller level variables for hiding the tab
     oControllerS3 : undefined,
     showAttributes : true,
     saveFlag : false,
     gCounter : null,
     showDocuments : true,
     showNotings : true,
     showWorkflow : true,
     oSource : undefined,
     fromSamePath : false,
     navBackArr : [],
     caseguid : null,
     fileid : null,
     wiId : null,
     fromTab : null,
     oTreeTable : null,
     link : null,
     documentId : null, // to fetch id of file clicked in
     i18 : null,
     oActionsModel : null,
     uploadNode : null, // node to which file is to be attached
     isAttachment : null,
     isFile : null,
     isReport : null,
     isObject : null,
     isIpi : null,
     dynUIAssistArr : undefined,
     flatTreeTableData : null,
     oSequenceSend : undefined,
     saveFlag : false,
     notingEditFlag : false,
     digSigNeeded : false,
     fromSearch : false,
     S3flag : false,
     navFlag : false,
     workflowAdminAuthorization : false,
     workflowParallelEnabled : false,
     // navBackFlag : false,

     // Initialization function
                    onInit : function() {

                           sap.ui.richtexteditor.TinyMCELicense = "sap.only";
                           serviceUrl = this.getView().getModel().sServiceUrl;
                           if(sap.ui.getCore().getModel("i18n") == undefined){
                                  sap.ui.getCore().setModel(this.getView().getModel("i18n"),"i18n");
                           }
                           oControllerS2 = this;
                           var globalModal = new sap.ui.model.json.JSONModel();
                           globalModal.setData(this.data);
                           this.getView().setModel(globalModal, "global");

                           // add event handler for on before show event
                           this.getView().addEventDelegate({

                                  onBeforeShow : jQuery.proxy(function(evt) {

                                        this.onBeforeShow(evt);

                                  }, this)

                           });

                           this.oRouter
                                        .attachRouteMatched(
                                                      function(oEvent) {
                                                            
                                                             oControllerS2 = this; 
                                                            if (oEvent.getParameter("name") == "subscreen") {
                                                                   this.caseguid = oEvent
                                                                                .getParameter("arguments").caseguid;

                                                                   this.fileid = oEvent
                                                                                .getParameter("arguments").fileid;

                                                                   this.wiId = oEvent
                                                                                .getParameter("arguments").wiId;

                                                                   
                                                                   if (this.fromSamePath) {
                                                                          oControllerS2
                                                                                       .onBeforeShow({
                                                                                              "from" : oControllerS2
                                                                                                           .getView()
                                                                                       });
                                                                   }
                                                            }
                                                      }, this);

                           this.i18 = this.getView().getModel("i18n");

                           /* Tree table for Workflow */
                           this.oTreeTable = this.getView().byId("wftree");
//                           this.oTreeTable.setSelectionMode("None");
           var oLink = new sap.m.Link({
                  text : "{Fullname}",
                  press : oControllerS2.openBusinessCard,
                  enabled : {
                      "parts" : [ 'isSpecial'],
                      "formatter" : flm.fiori.utils.formatter.linkEnabled
                  },
                  emphasized : {
                      "parts" : [ 'isSpecial'],
                      "formatter" : flm.fiori.utils.formatter.linkEmphasized
                  },
           });
           var oSpace1 = new sap.ui.core.HTML({
                  content : "<span>&nbsp;&nbsp;</span>"
           });
           var oSpace2 = new sap.ui.core.HTML({
                  content : "<span>&nbsp;&nbsp;</span>"
           });
           var oIcon1 = new sap.ui.core.Icon(
                         {
                                size : "1rem",
                                src : {
                                       "parts" : [ 'Nodetype' ],
                                       "formatter" : flm.fiori.utils.formatter.treeTableFlowIcon
                                },
                                color : "#5C85FF"
                         });
           
           var oIcon2 = new sap.ui.core.Icon(
                         {
                                size : "1rem",
                                src : {
                                       "parts" : [ 'Pospast' , 'isSpecial' ],
                                       "formatter" : flm.fiori.utils.formatter.treeTableIcon
                                },
                                color : {
                                       "parts" : [ 'Pospast','SubstRsn','AdminRsn' ],
                                       "formatter" : flm.fiori.utils.formatter.treeTableIconColor
                                }
                         });
           
           this.oLayout = new sap.ui.layout.HorizontalLayout(
                         "Layout1", {
                                content : [ oIcon1,oSpace1,oIcon2,oSpace2,oLink ]
                         });


                           this.oTreeTable.addColumn(new sap.ui.table.Column({
                                  label : this.getView().getModel("i18n").getObject("PROCESSORS"),
                                  template : this.oLayout,
                                  width : "30rem"
                           }));
                           this.oTreeTable.addColumn(new sap.ui.table.Column({
                                  label : this.getView().getModel("i18n").getObject("ACTIVITY"),
                                  template : "Actdc",
                                  width : "20rem"
                           }));
                           this.oTreeTable.addColumn(new sap.ui.table.Column({
                                  label : this.getView().getModel("i18n").getObject("START_DATE"),
                                  template : "Creadate",
                                  width : "15rem"
                           }));
                           this.oTreeTable.addColumn(new sap.ui.table.Column({
                                  label : this.getView().getModel("i18n").getObject("END_DATE"),
                                  template : "Enddate",
                                  width : "15rem"
                           }));
                           this.oTreeTable.addColumn(new sap.ui.table.Column({
                                  label : this.getView().getModel("i18n").getObject("STATUS"),
                                  template : "Statustext",
                                  width : "20rem"
                           }));

                           /* Workflow ends here */
                           
                           oControllerS2.byId("comments").setLayoutData(new sap.ui.layout.ResponsiveFlowLayoutData({linebreak:true}));
                           if(this.customInitializeData){
                this.customInitializeData(this);
         }
                           
//code for fixing rte bug
                           
                            if (sap.ui.version.indexOf("1.20.") == 0) {
                                  jQuery.sap.require("sap.ui.richtexteditor.RichTextEditor");
                                  sap.ui.richtexteditor.RichTextEditor.prototype.exitTinyMCE = function(){
                                    this.bExiting = true;
                                    if (window.tinymce) {
                                     tinymce.execCommand('mceRemoveControl', false, this.textAreaId);
                                    }
                                    sap.ui.getCore().getEventBus().unsubscribe("sap.ui",
                                        "__preserveContent", this._tinyMCEPreserveHandler);
                                    sap.ui.getCore().getEventBus().unsubscribe("sap.ui",
                                        "__beforePopupClose", this._tinyMCEPreserveHandler);
                                  };
                                  }
                    },



     onBeforeShow : function(oEvent) {

      this.oSource = oEvent.from;
      this.byId("fileDescription").setContent();
      // Bydefault authorization will not be available.
      // Authorization initialized during workflow
      // initialization
      this.workflowAdminAuthorization = false;
      this.workflowParallelEnabled = false;
      this.byId("wftree").setSelectedIndex(-1);
      this.byId("idDeleteButton").setEnabled(false);
      this.byId("idAddInWorkflow").setEnabled(false);
      this.gCounter = 0;
      var tabId = null;
      this.showAttributes = true;
      this.showDocuments = true;
      this.showNotings = true;
      this.showWorkflow = true;
      this.fromFileSearch = false;
      this.fromDocSearch = false;
      this.S3flag = false;
      this.navFlag = false;
      var fromtabPrev = this.fromTab;
      this.getView().byId("commenteditor").setValue("");
      if (this.oSource.sId == "__page0") {
       // throw a busy indicator
       this.getView().removeAllContent();
       this.getView().byId("fileDetails")._navBtn
         .setVisible(false);
       this.getView().byId("fileHeader").setVisible(false);
       this.getView().byId("TAB_CONTAINER_FILE")
         .setVisible(false);
       this.getView().byId("idFooterBar")
         .removeContentRight();
       this
         .customBusyDialogOpen(this.getView().getModel("i18n").getObject("OPEN_FILE_NOTIFICATION"));
       return;
      }
      if (this.fromSamePath) {
       if (this.navBackArr.length == 0) {
        switch (this.fromTab) {
        case "INTRAY":
         tabId = "file";
         break;
        case "DRAFT":
         tabId = "draft";
         break;
        case "ASSISTANT":
         tabId = "assistant";
         break;
        case "SUBSTITUTE":
         tabId = "substitute";
         break;
        case "CABINET":
         tabId = "cabinet";
         break;
        case "TRACK":
         tabId = "track";
         break;
        }
        this.fromSamePath = false;
       } else {
        tabId = "document";
       }
      }
      // set busy indicator
      this.customBusyDialogOpen();
      if (this.oSource.sId != "__page0") {
       if (this.oSource.getControllerName() == "flm.fiori.view.S1") {
        tabId = oEvent.from.byId("TAB_CONTAINER")
          .getSelectedKey();
       } else if (this.oSource.getControllerName() == "flm.fiori.view.S4") {

        tabId = "search";
        this.fromFileSearch = true;
        this.fromTab = "SEARCH";
       }else if (this.oSource.getControllerName() == "flm.fiori.view.S5") {

        tabId = "document";
        this.fromDocSearch = true;
        this.fromTab = "SEARCHDOC";
       }
        else if (this.oSource.getControllerName() == "flm.fiori.view.S3") {

        tabId = "document";
        this.S3flag = true;
        this.fromTab = "CREATE";
       }

       //this.getView().byId("duedateText").setEnabled(true);
       //this.getView().byId("idSubject").setEnabled(true);
       switch (tabId) {
       case "file":
        this.fromTab = "INTRAY";
        archiveFlag = false;
        this.showAttributes = true; // this.oSource.getController().attSection;
        this.showDocuments = true; // this.oSource.getController().docSection;
        this.showNotings = true;// this.oSource.getController().noteSection;
        this.showWorkflow = true;// this.oSource.getController().workflowTab;
        this.getView().byId("newNotingAction")
          .setVisible(true);
        this.getView().byId("notingFullAction")
          .setVisible(true);
        this.getView().byId("descrTabsPanel")
          .setVisible(true);
        this.getView().byId("privateLabel").setVisible(
          true);
        this.getView().byId("receiverTypeSelect")
          .setVisible(true);
        this.getView().byId("nameInput").setVisible(
          true);
        this.getView().byId("notePostAction")
          .setVisible(true);
        // this.getView().byId("notePostAction").setEnabled(true);
        this.getView().byId("noteSaveAction")
          .setVisible(false);
        this.getView().byId("idAddInWorkflow")
          .setVisible(true);
//        this.getView().byId("idUndoButton").setVisible(
//          true);
        this.getView().byId("idDeleteButton").setVisible(
          true);
        this.getView().byId("notesSection").setVisible(
          true);
        this.getView().byId("notePanel").setVisible(true);
        break;

       case "draft":
        this.fromTab = "DRAFT";
        archiveFlag = false;
        this.getView().byId("newNotingAction")
          .setVisible(true);
        this.getView().byId("notingFullAction")
          .setVisible(true);
        this.getView().byId("privateLabel").setVisible(
          true);
        this.getView().byId("receiverTypeSelect")
          .setVisible(true);
        this.getView().byId("nameInput").setVisible(
          true);
        this.getView().byId("notePostAction")
          .setVisible(true);
        this.getView().byId("noteSaveAction")
          .setVisible(false);
        this.getView().byId("commenteditor").setValue(
          '');
        this.getView().byId("descrTabsPanel")
          .setVisible(false);
        this.getView().byId("activityLabel")
          .setVisible(false);
        this.getView().byId("activityText").setVisible(
          false);
        this.getView().byId("send2assistLabel")
          .setVisible(false);
        this.getView().byId("send2assistText")
          .setVisible(false);
//        this.getView().byId("idAddInWorkflow")
//          .setVisible(true);
//        this.getView().byId("idUndoButton").setVisible(
//          true);
        this.getView().byId("notesSection").setVisible(
          true);
        this.getView().byId("notePanel").setVisible(true);
        break;
       case "assistant":

        this.fromTab = "ASSISTANT";
        archiveFlag = false;
        this.showAttributes = this.oSource
          .getController().attSection;
        this.showDocuments = this.oSource
          .getController().docSection;
        this.showNotings = this.oSource.getController().noteSection;
        this.showWorkflow = this.oSource
          .getController().workflowTab;
        this.getView().byId("descrTabsPanel")
          .setVisible(true);
        this.getView().byId("privateLabel").setVisible(
          false);
        this.getView().byId("receiverTypeSelect")
          .setVisible(false);
        this.getView().byId("nameInput").setVisible(
          false);
        this.getView().byId("notePostAction")
          .setVisible(false);
        this
          .getView()
          .byId("noteEditLink")
          .setVisible(
            flm.fiori.utils.formatter
              .enableLinkStatus(oControllerS2.fromTab));
        this.getView().byId("noteSaveAction")
          .setVisible(true);
        this.getView().byId("newNotingAction")
          .setVisible(false);
        this.getView().byId("idAddInWorkflow")
          .setVisible(false);
//        this.getView().byId("idUndoButton").setVisible(
//          false);
        this.getView().byId("idDeleteButton").setVisible(
          false);
        this.getView().byId("notesSection").setVisible(
          true);
        break;
       case "substitute":
        this.fromTab = "SUBSTITUTE";
        archiveFlag = false;
        this.getView().byId("newNotingAction")
          .setVisible(true);
        this.getView().byId("notingFullAction")
          .setVisible(true);
        this.getView().byId("privateLabel").setVisible(
          true);
        this.getView().byId("receiverTypeSelect")
          .setVisible(true);
        this.getView().byId("nameInput").setVisible(
          true);
        this.getView().byId("notePostAction")
          .setVisible(true);
        this.getView().byId("noteSaveAction")
          .setVisible(false);
        this.getView().byId("descrTabsPanel")
          .setVisible(true);
        this.getView().byId("commenteditor").setValue(
          '');
        this.getView().byId("notesSection").setVisible(
          true);
        this.getView().byId("notePanel").setVisible(true);
        this.getView().byId("idDeleteButton").setVisible(
          true);
        break;

       case "cabinet":
        this.fromTab = "CABINET";
        archiveFlag = false;
        this.getView().byId("newNotingAction")
          .setVisible(false);
        this.getView().byId("notingFullAction")
          .setVisible(false);
        this.getView().byId("descrTabsPanel")
          .setVisible(true);
        this.getView().byId("commenteditor").setValue(
          '');
        this.getView().byId("privateLabel").setVisible(
          false);
        this.getView().byId("receiverTypeSelect")
          .setVisible(false);
        this.getView().byId("nameInput").setVisible(
          false);
        this.getView().byId("notePostAction")
          .setVisible(false);
        this
          .getView()
          .byId("noteEditLink")
          .setVisible(
            flm.fiori.utils.formatter
              .enableLinkStatus(oControllerS2.fromTab));
        this.getView().byId("idAddInWorkflow")
          .setVisible(false);
//        this.getView().byId("idUndoButton").setVisible(
//          false);
        this.getView().byId("idDeleteButton").setVisible(
          false);
        this.getView().byId("notesSection").setVisible(
          true);
        break;
       case "track":
        this.fromTab = "TRACK";
        archiveFlag = false;
        this.showAttributes = false;
        this.showDocuments = false;
        this.showNotings = false;
        this.getView().byId("notesSection").setVisible(
          false);
        this.getView().byId("idDeleteButton").setVisible(
          false);
        this.getView().byId("idAddInWorkflow")
          .setVisible(false);
//        this.getView().byId("idUndoButton").setVisible(
//          false);
        break;

       case "document":
        this.fromTab = "DOCUMENT";
        archiveFlag = false;
        this.getView().byId("receiverTypeSelect")
          .setVisible(false);
        this.getView().byId("nameInput").setVisible(
          false);
        this.getView().byId("notePostAction")
          .setVisible(false);
        this.getView().byId("noteEditLink").setVisible(
          false);
        this.getView().byId("idAddInWorkflow")
          .setVisible(false);
//        this.getView().byId("idUndoButton").setVisible(
//          false);
        this.getView().byId("privateLabel").setVisible(
          false);
        this.getView().byId("notesSection").setVisible(
          true);
        this.getView().byId("notePanel").setVisible(
          false);
//        this.getView().byId("duedateText").setEnabled(
//          false);
//        this.getView().byId("idSubject").setEnabled(
//          false);
        this.getView().byId("idDeleteButton").setVisible(
          false);
        break;
       case "search":
        this.fromTab = "SEARCH";
        this.getView().byId("receiverTypeSelect")
          .setVisible(false);
        this.getView().byId("nameInput").setVisible(
          false);
        this.getView().byId("notePostAction")
          .setVisible(false);
        this.getView().byId("noteEditLink").setVisible(
          false);
        this.getView().byId("idAddInWorkflow")
          .setVisible(false);
        this.getView().byId("idUndoButton").setVisible(
          false);
        this.getView().byId("privateLabel").setVisible(
          false);
        this.getView().byId("notesSection").setVisible(
          true);
        this.getView().byId("notePanel").setVisible(
          false);
        this.getView().byId("idDeleteButton").setVisible(
          false);
       }
      }

      this.data.basic = null;
      this.data.dynamic = null;
      this.data.documents = null;
      this.data.folders = null;
      this.data.notings = null;
      this.data.buttons = null;
      this.data.attributeHistory = null;
      this.data.workflow = null;

      // if the file is opened from other screen then only it
      // needs to be editable
      var oModel = this.getView().getModel();
      var batchOp = null;
//      if (this.fromTab != "DOCUMENT") {
//       batchOp = oModel
//         .createBatchOperation(
//           "/FILES_FI?param_1='CI'&param_2='"
//             + this.caseguid
//             + "'&param_3='"
//             + this.wiId
//             + "'&param_4='"
//             + this.fileid
//             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
//             + this.fromTab
//             + "'&param_8=''&param_9=''&param_10=''",
//           'GET');
//
//       oModel.addBatchReadOperations([ batchOp ]);
//      }

      // fetch priority list
      if (this.data.priority == null) {
       batchOp = oModel
         .createBatchOperation(
           "/FILE_F4_ES?$filter=CaseGuid+eq+'"
             + this.caseguid
             + "'+and+ID+eq+'PRIO'+and+FileID+eq+'"
             + this.fileid + "'", 'GET');

       oModel.addBatchReadOperations([ batchOp ]);
      }

      // basic details
      if (this.data.basic == null) {
       if(archiveFlag == true){
        batchOp = oModel.createBatchOperation(
          "/FILE_BASIC_ES(CaseGuid='" + this.caseguid
            + "',TabType='" + this.fromTab
            + "',FileType='ARCH',ExtKey='"
            + this.fileid + "',Wiid='"
            + this.wiId + "',ISDAAK=false)", 'GET');
       }else{
       batchOp = oModel.createBatchOperation(
         "/FILE_BASIC_ES(CaseGuid='" + this.caseguid
           + "',TabType='" + this.fromTab
           + "',FileType='',ExtKey='"
           + this.fileid + "',Wiid='"
           + this.wiId + "',ISDAAK=false)", 'GET');
       }
       oModel.addBatchReadOperations([ batchOp ]);
      }
      // dynamic attributes
      if (this.data.dynamic == null
        && this.showAttributes == true) {
       if(archiveFlag == true){
       batchOp = oModel.createBatchOperation(
         "/FILE_ATTR_ES?$filter=GUID+eq+'"
           + this.caseguid
           + "'+and+TABTYPE+eq+'"
           + this.fromTab
           + "'+and+FILEID+eq+'ARCHIVE'+and+ISDAAK+eq+false", 'GET');
       }else{
        batchOp = oModel.createBatchOperation(
          "/FILE_ATTR_ES?$filter=GUID+eq+'"
            + this.caseguid
            + "'+and+TABTYPE+eq+'"
            + this.fromTab
            + "'+and+FILEID+eq+'" + this.fileid
            + "'+and+ISDAAK+eq+false", 'GET');
       }
       oModel.addBatchReadOperations([ batchOp ]);
      }

      /* Setting Visibility for Buttons */
      if (this.data.buttons == null) {
       batchOp = oModel.createBatchOperation(
         "/FILE_BUTTONS_ES(GUID='" + this.caseguid
           + "',TABTYPE='" + this.fromTab
           + "',FILEID='" + this.fileid
           + "',FILETYPE='',WIID='" + this.wiId + "',ISDAAK=false)", 'GET');
       oModel.addBatchReadOperations([ batchOp ]);
      }

      // submit the batch and store the results
      oModel
        .submitBatch(
          function(oResponse, oData) {
           if(oControllerS2.navFlag){
            return;
           }
           var i = 0;
//           if (oControllerS2.fromTab != "DOCUMENT") {
//            i++;
//           }
           if (oControllerS2.data.priority == null) {
            if(oResponse.__batchResponses[i].data != undefined){
            oControllerS2.data.priority = oResponse.__batchResponses[i].data.results;
            }else{
             sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
             return;
            }
            i++;
           }
           if (oControllerS2.data.basic == null) {
             if(oResponse.__batchResponses[i].data != undefined){
              oControllerS2.data.basic = oResponse.__batchResponses[i].data;
              oControllerS2.digSigNeeded = oResponse.__batchResponses[i].data.DigSignReq;

              /*try{
               oControllerS2.byId("idSubject").setText(decodeURIComponent(oControllerS2.data.basic.CaseTitle));
               }catch(err){
                oControllerS2.byId("idSubject").setText(oControllerS2.data.basic.CaseTitle);
               }*/

              try{
              oControllerS2.byId("fileDescription").setContent(decodeURIComponent(oControllerS2.data.basic.Description));
              }catch(err){
               oControllerS2.byId("fileDescription").setContent(oControllerS2.data.basic.Description);
              }
             }else{
              sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
              return;
             }
             i++;
           }
           if (oControllerS2.data.dynamic == null
             && oControllerS2.showAttributes == true) {
            if(oResponse.__batchResponses[i].data != undefined){
             oControllerS2.data.dynamic = oResponse.__batchResponses[i].data.results;
            }else{
             sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
             return;
            }
            i++;
           }
           if (oControllerS2.data.buttons == null) {
            if(oResponse.__batchResponses[i].data != undefined){
            oControllerS2.data.buttons = oResponse.__batchResponses[i].data;
            if(oResponse.__batchResponses[i].data.ISPRINT == true){
             oControllerS2.getView().byId("printAction").setVisible(true);
            }else{
             oControllerS2.getView().byId("printAction").setVisible(false);
            }
            if(oResponse.__batchResponses[i].data.ISSAVE == true){
             oControllerS2.getView().byId("saveAction").setVisible(true);
            }else{
             oControllerS2.getView().byId("saveAction").setVisible(false);
            }
            if(oResponse.__batchResponses[i].data.ISMOVECAB == true){
             oControllerS2.getView().byId("moveToCabinetAction").setVisible(true);
            }else{
             oControllerS2.getView().byId("moveToCabinetAction").setVisible(false);
            }
            if(oResponse.__batchResponses[i].data.ISSEND == true || oResponse.__batchResponses[i].data.ISSHARE == true || oResponse.__batchResponses[i].data.ISOFSENDBACK == true){
             oControllerS2.getView().byId("sendFileAction").setVisible(true);
            }else{
             oControllerS2.getView().byId("sendFileAction").setVisible(false);
            }
            if(oResponse.__batchResponses[i].data.ISSEARCHSEND == true){
             oControllerS2.getView().byId("sendSearchAction").setVisible(true);
            }else{
             oControllerS2.getView().byId("sendSearchAction").setVisible(false);
            }
            if(oResponse.__batchResponses[i].data.ISCLOSE == true){
             oControllerS2.getView().byId("closeFileAction").setVisible(true);
            }else{
             oControllerS2.getView().byId("closeFileAction").setVisible(false);
            }
            if(oResponse.__batchResponses[i].data.ISMOVEINTRAY == true){
             oControllerS2.getView().byId("moveToIntrayAction").setVisible(true);
            }else{
             oControllerS2.getView().byId("moveToIntrayAction").setVisible(false);
            }
            if(oResponse.__batchResponses[i].data.ISSENDBACK == true){
             oControllerS2.getView().byId("sendBackToAction").setVisible(true);
            }else{
             oControllerS2.getView().byId("sendBackToAction").setVisible(false);
            }
            }
            else if(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers) == "Resource not found for segment 'FILE_BUTTONS_ET'."){
             oControllerS2.getView().byId("printAction").setVisible(false);
             oControllerS2.getView().byId("saveAction").setVisible(false);
             oControllerS2.getView().byId("moveToCabinetAction").setVisible(false);
             oControllerS2.getView().byId("sendFileAction").setVisible(false);
             oControllerS2.getView().byId("sendSearchAction").setVisible(false);
             oControllerS2.getView().byId("closeFileAction").setVisible(false);
             oControllerS2.getView().byId("moveToIntrayAction").setVisible(false);
             oControllerS2.getView().byId("sendBackToAction").setVisible(false);
//
//             oControllerS2.getView().byId("moveToIntrayAction").rerender();
//             oControllerS2.getView().byId("closeFileAction").rerender();
//             oControllerS2.getView().byId("sendSearchAction").rerender();
//             oControllerS2.getView().byId("sendFileAction").rerender();
//             oControllerS2.getView().byId("moveToCabinetAction").rerender();
//             oControllerS2.getView().byId("saveAction").rerender();
//             oControllerS2.getView().byId("printAction").rerender();
//             oControllerS2.getView().byId("sendBackToAction").rerender();
            }
            else{
             sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
             return;
            }
            i++;
           }

           if (oControllerS2.showAttributes) {
            var mparams = oControllerS2.data.dynamic;
            oControllerS2.getView().byId(
              "dynamicAttrForm")
              .destroyContent();
            if (oControllerS2.fromTab == "DOCUMENT" || oControllerS2.fromTab == "SEARCH" ) {
             oControllerS2.dynUIAssistArr = createDynamicUI(
               mparams,
               oControllerS2,
               oControllerS2
                 .getView(),
               "dynamicAttrForm",
               true);
            } else {
             oControllerS2.dynUIAssistArr = createDynamicUI(
               mparams,
               oControllerS2,
               oControllerS2
                 .getView(),
               "dynamicAttrForm",
               false);
            }

           } else if (!oControllerS2.showAttributes) {
            oControllerS2.getView().byId(
              "dynamicAttrForm")
              .destroyContent();
           }

           oControllerS2
             .initializeAttributes(oControllerS2);

           oControllerS2.getView().getModel(
             "global").checkUpdate();

           oControllerS2.byId("fileHeader").rerender();

           oControllerS2
             .customBusyDialogClose();

          }, function(oResponse) {

          }, true);

      if (this.showWorkflow == false) {
       this.getView().byId("workflowTab")
         .setVisible(false);
      } else {
       this.getView().byId("workflowTab").setVisible(true);
      }

      if (this.showDocuments == true) {
       this.getView().byId("idVboxPanel").setVisible(true);
      } else {
       this.getView().byId("idVboxPanel")
         .setVisible(false);
      }

      if (this.showNotings == true) {
       this.getView().byId("noteList").setVisible(true);
      } else {
       this.getView().byId("noteList").setVisible(false);
      }

      if (this.getView().byId("TAB_CONTAINER_FILE")
        .getSelectedKey() != "Info") {
       this.getView().byId("TAB_CONTAINER_FILE")
         .setSelectedKey("Info");
      }

     },

     // ///////////////////////////////////////////
     // On selecting the tab load corresponding model of the tab

     onTabSelect : function(oEvent) {

      var oModel = oControllerS2.getView().getModel();
      oModel.clearBatch();
      var batchOp = null;
      var temp = null;
      switch (oEvent.getParameters().selectedKey) {
      case "notes":
       oControllerS2.getView().byId("receiverTypeSelect")
         .setSelectedItem("SPACE");

       /*
        * Check if notings are necessary and make a call
        * accordingly
        */
       if (this.data.notings == null) {
        oControllerS2.byId("commenteditor").setValue("");
        var wfInfoVal;
        if (this.oSource.getController().wfInfo == undefined) {
         wfInfoVal = '';
        } else {
         wfInfoVal = this.oSource.getController().wfInfo
           .replace(/ /g, "***");
        }
        if(archiveFlag == true){
        batchOp = oModel.createBatchOperation(
          "/FILE_NOTING_ES?$filter=TabType+eq+'"
            + this.fromTab
            + "'+and+CaseGuid+eq+'"
            + this.caseguid
            + "'+and+Wiid+eq+'" + this.wiId
            + "'+and+Wfinfo+eq+'ARCHIVE'", 'GET');
        }else{
         batchOp = oModel.createBatchOperation(
           "/FILE_NOTING_ES?$filter=TabType+eq+'"
             + this.fromTab
             + "'+and+CaseGuid+eq+'"
             + this.caseguid
             + "'+and+Wiid+eq+'" + this.wiId
             + "'+and+Wfinfo+eq+'"
             + wfInfoVal + "'", 'GET');
        }
        oModel.addBatchReadOperations([ batchOp ]);

        // Setting model for private noting receiver

        if (this.data.receiverType == null) {
         batchOp = oModel
           .createBatchOperation(
             "/FILE_F4_ES?$filter=CaseGuid+eq+'"
             + this.caseguid
             + "'+and+OtherF4+eq+true+and+ID+eq+'WC'",
             'GET');
         oModel.addBatchReadOperations([ batchOp ]);

        }
        temp = "X";
       }

       if (this.data.folders == null
         && this.showDocuments == true) {
        if(archiveFlag == true){
        batchOp = oModel
          .createBatchOperation(
            "/FILE_DOC_FI?param_1='FS'&param_2='"
              + this.caseguid
              + "'&param_3='ARCHIVE'&param_4=''&param_5=''",
            'GET');
        }else{
         batchOp = oModel
         .createBatchOperation(
           "/FILE_DOC_FI?param_1='FS'&param_2='"
             + this.caseguid
             + "'&param_3=''&param_4=''&param_5=''",
           'GET');
        }
        oModel.addBatchReadOperations([ batchOp ]);
        temp = "X";
       }

       if (this.data.documents == null
         && this.showDocuments == true) {
        if(archiveFlag == true){
        batchOp = oModel
          .createBatchOperation(
            "/FILE_DOCUM_ES?$filter=Guid+eq+'"
              + this.caseguid
              + "'+and+TabType+eq+'INTRAY'+and+Wiid+eq+'"
              + this.wiId
              + "'+and+FileID+eq+'ARCHIVE'",
            'GET');
        }
        else{
         batchOp = oModel
         .createBatchOperation(
           "/FILE_DOCUM_ES?$filter=Guid+eq+'"
             + this.caseguid
             + "'+and+TabType+eq+'INTRAY'+and+Wiid+eq+'"
             + this.wiId
             + "'+and+FileID+eq+'"
             + this.fileid + "'",
           'GET');
        }
        oModel.addBatchReadOperations([ batchOp ]);
        temp = "X";
       }
       // batch request submission
       if (temp == "X") {
        oControllerS2.byId("idNotingsGrid").setBusy(
          true);
        oModel
          .submitBatch(
            function(oResponse, oData) {

             var i = 0;
             if (oControllerS2.data.notings == null) {

              if (oControllerS2.showNotings == true) {
               // oControllerS2.data.notings
               // =
               // oResponse.__batchResponses[i].data.results;

               if (oResponse.__batchResponses[i].message == undefined) {
                if (oResponse.__batchResponses[i].data.results.length > 0) {
                if (oResponse.__batchResponses[i].data.results[oResponse.__batchResponses[i].data.results.length - 1].ANotingString != "") {
                 if (oControllerS2.fromTab == "INTRAY"
                   || oControllerS2.fromTab == "ASSISTANT") {
                  var assistNoting = oResponse.__batchResponses[i].data.results[oResponse.__batchResponses[i].data.results.length - 1].ANotingString;
                  oControllerS2.getView().byId("commenteditor").setValue(assistNoting);
                  oControllerS2.getView().byId("commenteditor").reinitialize();
                 }
                 oResponse.__batchResponses[i].data.results
                   .splice(
                     oResponse.__batchResponses[i].data.results.length - 1,
                     1);

                 oControllerS2.data.notings = oResponse.__batchResponses[i].data.results;
                  for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                   try{
                    oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                    }catch(err){
                     oResponse.__batchResponses[i].data.results[j].actNote = oResponse.__batchResponses[i].data.results[j].NotingString;
                    }

                      }
                }
                 else {
                 oControllerS2
                   .getView()
                   .byId(
                     "commenteditor")
                   .setValue(
                     "");
                 oControllerS2.data.notings = oResponse.__batchResponses[i].data.results;
                 for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                   try{
                    oResponse.__batchResponses[i].data.results[j].actNote = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].NotingString);
                    }catch(err){
                     oResponse.__batchResponses[i].data.results[j].actNote = oResponse.__batchResponses[i].data.results[j].NotingString;
                    }

                     }
                }
                }

               }else{
                sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
                return;
               }
              }
              if (oControllerS2.fromTab == "ASSISTANT"
                && oControllerS2.showNotings == false) {
               if (oResponse.__batchResponses[i].message == undefined) {
                if (oResponse.__batchResponses[i].data.results.length > 0) {
                if (oResponse.__batchResponses[i].data.results[oResponse.__batchResponses[i].data.results.length - 1].ANotingString != "") {

                 var assistNoting = oResponse.__batchResponses[i].data.results[oResponse.__batchResponses[i].data.results.length - 1].ANotingString;
                 oControllerS2
                   .getView()
                   .byId(
                     "commenteditor")
                   .setValue(
                     assistNoting);
                }
               }
              }
              }
              i++;
             }
             if (oControllerS2.data.receiverType == null
               && oControllerS2.showNotings == true) {
              if(oResponse.__batchResponses[i].message == undefined){
               oControllerS2.data.receiverType = oResponse.__batchResponses[i].data.results;
              }
              i++;

             }
             if (oControllerS2.data.folders == null
               && oControllerS2.showDocuments == true) {
              if(oResponse.__batchResponses[i].message == undefined){

               oControllerS2.data.folders = oResponse.__batchResponses[i].data.results;
              }else{
               sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
               return;
              }
              i++;
             }
             if (oControllerS2.data.documents == null
               && oControllerS2.showDocuments == true) {

              if(oResponse.__batchResponses[i].message == undefined){
               oControllerS2.data.documents = oResponse.__batchResponses[i].data.results;
               /*for (var j = 0; j < oResponse.__batchResponses[i].data.results.length; j++) {
                var subValue = decodeURIComponent(oResponse.__batchResponses[i].data.results[j].FileTitle);
                oResponse.__batchResponses[i].data.results[j].FileTitle = subValue;
              }*/
              }else{
               sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,oResponse.__batchResponses[i].response.headers));
               return;
              }
              i++;
             }
             oControllerS2.getView()
               .getModel("global")
               .checkUpdate();
             if (oControllerS2.showNotings == true) {
              oControllerS2
                .initializeNotings(oControllerS2);
              //oControllerS2.getView().byId("noteEditLink").setVisible(flm.fiori.utils.formatter.editNoteEnabledState(oControllerS2.fromTab));
             }
             // end of batch
             if (oControllerS2.showDocuments == true) {
              oControllerS2
                .initializeDocuments(oControllerS2);
             }

             oControllerS2.getView()
               .getModel("global")
               .checkUpdate();

             oControllerS2.byId(
               "idNotingsGrid")
               .setBusy(false);

            }, function(oResponse) {

            }, true);
       }
       break;
      // if (oControllerS2.showNotings == true) {
      // oControllerS2.initializeNotings(oControllerS2);
      // }
      // // end of batch
      // if (oControllerS2.showDocuments == true) {
      // oControllerS2
      // .initializeDocuments(oControllerS2);
      // }

      case "attribute":
       if (this.data.attributeHistory == null
         && this.showAttributes == true) {
        oControllerS2.byId("idAttributesTable")
          .setBusy(true);
        var attrHistoryModel = new sap.ui.model.json.JSONModel();
        attrHistoryModel
          .attachRequestCompleted(
            this,
            function(oEvent) {

             attrHistoryModel
               .detachRequestCompleted();
             if(attrHistoryModel.oData.d.results.length > 0){
              oControllerS2.data.attributeHistory = attrHistoryModel.oData.d.results;
              oControllerS2.getView()
                .getModel("global")
                .checkUpdate();
             }
             oControllerS2
               .byId(
                 "idAttributesTable")
               .setBusy(false);
            }, this);
        attrHistoryModel
          .loadData(
            serviceUrl
              + "/FI_RESPONSE_ES?$filter=Caseguid eq '"
              + this.caseguid + "' and TabType eq '"+this.fromTab+"'",
            null, true);

       }
       break;

       // workflow tab
       // workflow tab
      case "workflow":

       if (this.data.workflow == null
         && this.showWorkflow == true) {
        oControllerS2.byId("idWorkflowGrid").setBusy(
          true);
        // load the service and set the model
        oWorkflowModel = new sap.ui.model.json.JSONModel();
        oWorkflowModel
          .attachRequestCompleted(
            this,
            function(oEvent) {

             oWorkflowModel
               .detachRequestCompleted();
             oControllerS2.data.workflow = oWorkflowModel.oData.d.results;
             oControllerS2.getView()
               .getModel("global")
               .checkUpdate();
             oControllerS2.byId(
               "idWorkflowGrid")
               .setBusy(false);
             oControllerS2
               .initializeWorkflow(oControllerS2);
             oControllerS2.getView()
               .getModel("global")
               .checkUpdate();
            }, this);
        if(archiveFlag == true){
        oWorkflowModel
          .loadData(
            serviceUrl
              + "/FILE_PROUTE_ES?$filter=CaseGuid eq '"
              + this.caseguid + + "' and TabType eq '"+this.fromTab+"' and WitemId eq 'ARCHIVE'",
            null, true);
        }else{
         oWorkflowModel
         .loadData(
           serviceUrl
             + "/FILE_PROUTE_ES?$filter=CaseGuid eq '"
             + this.caseguid + + "' and TabType eq '"+this.fromTab+"' and WitemId eq '"+this.wiId+"'",
           null, true);
        }
       }
       break;
      }
     },     // start of initialization functions for tabs

     initializeAttributes : function(controller) {

      if (controller.showAttributes == true) {
       controller.getView().byId("attributesHistory")
         .setVisible(true);

      } else {
       controller.getView().byId("attributesHistory")
         .setVisible(false);
      }
     },

     initializeNotings : function(controller) {

      this.getView().byId("noteEditAction").setVisible(false);
      if (oControllerS2.fromTab == "ASSISTANT") {
       this.getView().byId("notePostAction").setVisible(
         false);
      }
      if (oControllerS2.fromTab == "CABINET") {
       this.getView().byId("notePostAction").setVisible(
         false);
       this.getView().byId("noteSaveAction").setVisible(
         false);
      }

     },

     initializeDocuments : function(controller) {
      if (controller.data.folders != null
        || controller.data.documents != null) {

       controller
         .getView()
         .byId("idListPanel")
         .bindAggregation(
           "items",
           "global>/folders",
           function(a, b) {

            var list = new sap.m.List()
              .setModel(
                controller
                  .getView()
                  .getModel(
                    "global"),
                "global");
            var listItem = new sap.m.CustomListItem(
              {});

            // LIST ATTRIBUTES STARTS
            var oIcon = new sap.ui.core.Icon(
              {
               src : "sap-icon://create",
               size : "1rem"
              });
            var fbox = new sap.m.FlexBox({
             width : "100%"
            });
            var fbox1 = new sap.m.FlexBox({
             alignItems : "Start",
             justifyContent : "Start",
             width : "5%"
            });
            var fbox2 = new sap.m.FlexBox({
             alignItems : "Start",
             justifyContent : "Start",
             width : "80%"
            });
            var fbox3 = new sap.m.FlexBox({
             alignItems : "Start",
             justifyContent : "End",
             width : "15%"
            });
            var vbox = new sap.m.VBox({});
            vbox
              .addItem(new sap.m.Link(
                {
                 text : "{global>DocumentName}",
                 press : oControllerS2.onLinkPress,
//                 enabled : flm.fiori.utils.formatter
//                   .enabledStatus(oControllerS2.fromTab)

                }).addStyleClass("docLink"));
            vbox
              .addItem(new sap.m.Text(
                {
                 "text" : {
                  "parts" : ['global>CreatedByName',
                    'global>CreatedOn' ],

                  "formatter" : flm.fiori.utils.formatter.documentRow1
                 }
                // str1
                }).addStyleClass("docDetails"));
            vbox
              .addItem(new sap.m.Text(
                {
                 text : {
                  "parts" : [
                    'global>IsAttachment',
                    'global>IsFile',
                    'global>IsDaak',
                    'global>IsObject',
                    'global>IsReport',
                    'global>FileSizeDescr',
                    'global>FileTitle',
                    'global>FileName' ],

                  "formatter" : flm.fiori.utils.formatter.documentRow2
                 }
                // str2
                }).addStyleClass("docDetails"));
            fbox1.addItem(oIcon);
            fbox2.addItem(vbox);
            var hbox = new sap.m.HBox({});
            hbox
              .addItem(new sap.m.Link(
                {
                 visible : "{global>NotingEnabledRef}",
                 text : oControllerS2.getView().getModel("i18n").getObject("ADD_TO_NOTING"),
                 press : oControllerS2.addHyperlinkClick,
                 enabled : flm.fiori.utils.formatter
                   .enabledStatus(oControllerS2.fromTab)

                }).addStyleClass("docLink"));
            hbox
              .addItem(new sap.ui.core.HTML(
                {
                 visible : "{global>NotingEnabledRef}",
                 content : "<span>&nbsp&nbsp&nbsp&nbsp;</span>"
                }).addStyleClass("docLink"));
            hbox
              .addItem(new sap.m.Link(
                {
                 visible : "{global>IsAttachment}",
                 text : oControllerS2.getView().getModel("i18n").getObject("ATTACH_NEW_VERSION"),
                 press : oControllerS2.attachNewVersion,
                 enabled : flm.fiori.utils.formatter
                   .enabledStatus(oControllerS2.fromTab)
                }).addStyleClass("docLink"));
            vbox.addItem(hbox);

            var deleteIconVisibility;
            if (oControllerS2.fromTab == "DOCUMENT"
              || oControllerS2.fromTab == "ASSISTANT"
              || oControllerS2.fromTab == "SEARCH") {
             deleteIconVisibility = flm.fiori.utils.formatter
               .enabledStatus(oControllerS2.fromTab);
            } else {
             deleteIconVisibility = "{global>DeleteEnabledRef}";
            }
            fbox3
              .addItem(new sap.ui.core.Icon(
                {
                 visible : deleteIconVisibility,
                 src : "sap-icon://delete",
                 size : "1rem",
                 tooltip : "Delete attachment",
                 press : oControllerS2.confirmDelete,
                // enabled :
                // flm.fiori.utils.formatter.enabledStatus(oControllerS2.fromTab)
                })
                .addStyleClass("panelButton"));
            fbox.addItem(fbox1);
            fbox.addItem(fbox2);
            fbox.addItem(fbox3);
            listItem.addContent(fbox);
            // LIST ATTRIBUTES ENDS

            list.bindAggregation("items",
              "global>/documents",
              listItem);

            list
              .getBinding("items")
              .filter(
                new sap.ui.model.Filter(
                  "ParentKey",
                  sap.ui.model.FilterOperator.EQ,
                  b
                    .getObject()["RowKey"]));
            var panel = new sap.ui.commons.Panel(
              {
               showCollapseIcon : true,
               collapsed : true
              });
            var oButton = new sap.ui.core.Icon(
              {
               src : "sap-icon://attachment",
               size : "1rem",
               tooltip : "Add New Document",
               press : oControllerS2.uploadActionsOpen,
               visible : flm.fiori.utils.formatter
                 .enabledStatus(oControllerS2.fromTab)
              });
            oButton
              .addStyleClass("panelAddButton");
            panel.addContent(oButton);
            panel.addContent(list);
            return new sap.m.CustomListItem()
              .addContent(panel
                .setText(b
                  .getObject()["DocumentName"]
                  + " ("
                  + list
                    .getItems().length
                  + ")"));
           });
      }
     },

     changeLevels : function(result,currLabel,prevLabel,t){ //recursive function to change levels for adding special node
                     
                     var l=1;
                     for(var i=t+1;i<result.length;i++){
                      if(result[i].Label.slice(0,-2) == prevLabel && result[i].Label.length==prevLabel.length+2){
                       var tempLabel=result[i].Label;
                       result[i].Label = currLabel+"_"+(l++);
                          oControllerS2.changeLevels(result,result[i].Label,tempLabel,i); 
                      }
                      /*else if(result[i].Label.slice(0,-1) == currLabel.slice(0,-1)){
                            prevLabel = result[i].Label;
                       result[i].Label = currLabel+"_"+(l++);
                          oControllerS3.changeLevels(result,result[i].Label,prevLabel,i); 
                      }*/
                     }
                    },

     initializeWorkflow : function(controller) { // CHANGE
      var oTreeTable = controller.getView().byId("wftree");
      var result = controller.data.workflow;
      if (result.length > 0) {
       if (result[0].IsSuperUser) {
        oControllerS2.workflowAdminAuthorization = true;
       }
       if (result[0].AddParallel){
        oControllerS2.workflowParallelEnabled = true;
       }

//       if (result[0].op == 'X') {
////        oControllerS2.getView().byId("idUndoButton")
////          .setEnabled(false);
//        oControllerS2.getView().byId("idAddInWorkflow")
//          .setEnabled(false);
//       } else {
////        oControllerS2.getView().byId("idUndoButton")
////          .setEnabled(false);
//        oControllerS2.getView().byId("idAddInWorkflow")
//          .setEnabled(true);
//       }
      }
      oControllerS2.flatTreeTableData = result;
      for (var i = 0; i < result.length; i++) {
       if (result[i].PosidWiid == oControllerS2.wiId) {
        oControllerS2.wftreeIndex = i;
        break;
       }

      }
      //Replace '_' with '0' for sorting purpose
                        for(var i=0;i<result.length;i++){
                         result[i].sortIndex=result[i].Label.split('_').join('0');
                        }
                      //To sort the workflow for adding special nodes
                        result.sort(function(a, b){ 
                         return a.sortIndex-b.sortIndex;
                        });
      var obj = {
       "nodes" : [],
       "Label" : "Sequence"
      };                        

      for (var i = 0; i < result.length; ++i) {
       result[i].__metadata = null;
       if(result[i].Nodetype=="PB"){
                              result[i].Nodetype="PB*";
                              var spclNode = {
                                   "nodes" : [],
                                   "Fullname" : "Parallel Steps",
                                   "Label" : result[i].Label,
                                   "Posid" : result[i].Posid,
                                   "Parentid" : result[i].Parentid,
                                   "Nodetype" : "P",
                                   "isParallel" : "X",
                                   "isSpecial" : "X",
                                   "Enddate" : result[i].Enddate,
                                   "Creadate" : result[i].Creadate,
                                 };

                              result.splice(i,0,spclNode);
                              var t=i+1,l=0,prevLabel;
                              //Till the whole parallel block is found
                              while(result[t].Nodetype!="PE"){ 
                               //All children sequence nodes will be handled by the changeLevel function
                               if(result[t].Nodetype!="S"){ 
                               prevLabel = result[t].Label;
                               result[t].Label = result[i].Label+"_"+(++l);
                               oControllerS2.changeLevels(result,result[t].Label,prevLabel,t);
                               }
                               t++;
                              }
                              prevLabel = result[t].Label;
                              result[t].Label = result[i].Label+"_"+(++l);
                              oControllerS2.changeLevels(result,result[t].Label,prevLabel,t);
                             }
       var levels = result[i].Label.split("_");

       for (var k = 0; k < levels.length; ++k) {
        levels[k] = parseInt(levels[k]) - 1;
       }

       var tempObj = obj;

       for (var j = 0; j < levels.length - 2; ++j) {
        tempObj = tempObj.nodes[levels[j]];
       }

       if (tempObj.nodes[levels[j]] == undefined) {
        result[i].nodes = [];
        tempObj.nodes[levels[j]] = result[i];
        continue;
       }

       result[i].nodes = [];
       tempObj.nodes[levels[j]].nodes.push(result[i]);
      }

      var selectedNodeData=oTreeTable.getContextByIndex(oTreeTable.getSelectedIndex());
      oTreeModel = new sap.ui.model.json.JSONModel();
      oTreeModel.setData(obj);

      oTreeTable.setModel(oTreeModel); // set model to
      // Table*/

      oTreeTable.bindRows("/");
      oTreeTable.setExpandFirstLevel(true);
      if(selectedNodeData){
                            var sndPath = selectedNodeData.getPath().split('/');
                            var expandIndex=parseInt(sndPath[2]);
                            for(var i=4;i<sndPath.length;i+=2){
                             oTreeTable.expand(expandIndex);
                             expandIndex+=parseInt(sndPath[i])+1;
                            }
                        }
     },

     /* Generic Code for opening fragments */
     openDialog : function(sType) {
      if (!this[sType]) {
       this[sType] = sap.ui.xmlfragment("flm.fiori.view."
         + sType, this // associate controller with
       // the fragment
       );
       this.getView().addDependent(this[sType]);
      }
      this[sType].open();
     },
     /* Generic Code for closing fragments */
     closeDialog : function(sType) {
      if (!this[sType]) {
       this[sType] = sap.ui.xmlfragment("flm.fiori.view."
         + sType, this // associate controller with
       // the fragment
       );
       this.getView().addDependent(this[sType]);
      }
      this[sType].close();

     },

     sendToButtonPressed : function(oEvent) {
      if(oControllerS2.oSequenceSend==undefined){
      oControllerS2.oSequenceSend = sap.ui.xmlfragment("flm.fiori.view.sendTo",
        this);
     }
     oControllerS2.oSequenceSend.open();
      var oTable = sap.ui.getCore().byId("idProcessorsTable");
      var oModel = new sap.ui.model.json.JSONModel({
       "data" : []
      });
      oTable.setModel(oModel, "dummy");

     },

     onParSelect : function(oEvent) {
      sap.ui.getCore().byId("idButtonAdd").setVisible(true);
      sap.ui.getCore().byId("idProcessorsTable").setVisible(
        true);
     },

     onSeqSelect : function(oEvent) {
      sap.ui.getCore().byId("idButtonAdd").setVisible(false);
      sap.ui.getCore().byId("idProcessorsTable").setVisible(
        false);
     },

     onAddClick : function(oEvent) { // CHANGE

      var oTable = sap.ui.getCore().byId("idProcessorsTable");
      var processor = sap.ui.getCore().byId("idSelect1")
        .getSelectedItem().getText();
      var sendTo = sap.ui.getCore().byId("idUsername")
        .getValue();
      var agent = sap.ui.getCore().byId("idUsername")
        .getName();
      var activity = sap.ui.getCore().byId("idSelect2")
        .getSelectedItem().getText();
      var activityKey = sap.ui.getCore().byId("idSelect2")
        .getSelectedItem().getKey();
      var processingDate = "";
      if (sap.ui.getCore().byId(
      "idDatePickerSendTo").getValue() !=""){
       processingDate = sap.ui.getCore().byId(
       "idDatePickerSendTo").getValue();
      }
      var processingDay = sap.ui.getCore()
        .byId("idInputDays").getValue();
      if ((sendTo == "" || activity == "" || processor == "")) {
       sap.m.MessageToast.show(this.getView().getModel(
         "i18n").getObject("MESSAGE_20"));
       return;
      }
      if (processingDate != "" && processingDay != "") {
       sap.m.MessageToast.show(this.getView().getModel(
         "i18n").getObject("MESSAGE_21"));
       return;
      }
      var oModel = oTable.getModel("dummy");
      oModel.getData().data.push({
       "Processor" : sap.ui.getCore().byId("idSelect1")
         .getSelectedItem().getText(),
       "Name" : sap.ui.getCore().byId("idUsername")
         .getValue(),
       "Agent" : sap.ui.getCore().byId("idUsername")
         .getName(),
       "Activity" : sap.ui.getCore().byId("idSelect2")
         .getSelectedItem().getKey(),
       "Actdc" : sap.ui.getCore().byId("idSelect2")
         .getSelectedItem().getText(),
       "Date" : sap.ui.getCore()
         .byId("idDatePickerSendTo").getValue(),
       "Days" : sap.ui.getCore().byId("idInputDays")
         .getValue(),
       "position" : oControllerS2.gCounter++,
      });
      oModel.checkUpdate();

      //Resetting the fields
      sap.ui.getCore().byId("idUsername").setValue("");
      sap.ui.getCore().byId("idUsername").setName("");
      sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
      sap.ui.getCore().byId("idInputDays").setValue("");
      sap.ui.getCore().byId("idSelect2").setSelectedKey();
     },

     sendActionsOpen : function(oEvent) {
      var oButton = oEvent.getSource();
      //if (!this._sendActionSheet) {
       if (!oControllerS2._sendActionSheet || oControllerS2._sendActionSheet.getButtons().length == 0){
       this._sendActionSheet = sap.ui.xmlfragment(
         "flm.fiori.view.sendButton", this);
       this.getView().addDependent(this._sendActionSheet);
      }
      jQuery.sap.delayedCall(0, this, function() {
       this._sendActionSheet.openBy(oButton);
      });
     },

     printActionsOpen : function(oEvent) {
      var oButton = oEvent.getSource();
      if (!this._printActionSheet) {
       this._printActionSheet = sap.ui.xmlfragment(
         "flm.fiori.view.printActionButtons", this);
       this.getView().addDependent(this._printActionSheet);
      }
      jQuery.sap.delayedCall(0, this, function() {
       this._printActionSheet.openBy(oButton);
      });
     },

     handleValueHelp : function(oEvent) {
      oControllerS2.customBusyDialogOpen("");
      if (!oControllerS2._oDynamicF4Dialog) {
       oControllerS2._oDynamicF4Dialog = sap.ui
         .xmlfragment(
           "flm.fiori.view.dynamicF4popup",
           oControllerS2);

      }
      var f4text = null;
      oF4Texts = new sap.ui.model.json.JSONModel();
      var otypeModel = new sap.ui.model.json.JSONModel();
      if (oEvent.getSource().getId().indexOf("idUsername")!=-1) {
       f4text = {

        title : sap.ui.getCore().byId("idSelect1")
          .getSelectedItem().getText(),

        id : "idUsername",
       };
       if (sap.ui.getCore().byId("idSelect1").getSelectedKey() != 'SPACE') {
                             otypeModel.attachRequestCompleted(oControllerS2,function(oEvent){
                              otypeModel.setData(otypeModel.oData.d.results);
                              oControllerS2._oDynamicF4Dialog.setModel(otypeModel);
                                  oControllerS2.customBusyDialogClose();
                                  otypeModel.detachRequestCompleted();
                                  },oControllerS2);
                             otypeModel.loadData(serviceUrl
                                             + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and ID eq '"
                                             + sap.ui.getCore().byId("idSelect1").getSelectedKey()
                                             + "' and WF eq true", null, false);
                                
                            }
                            oControllerS2._oDynamicF4Dialog.setModel(otypeModel);
      } else if (oEvent.getSource().getId().indexOf("nameInput")!=-1) {
       f4text = {

        title : this.getView().byId(
          "receiverTypeSelect").getSelectedItem()
          .getText(),

        id : "nameInput",

       };
       if (oControllerS2.getView().byId("receiverTypeSelect").getSelectedKey() != 'SPACE') {
                             otypeModel.attachRequestCompleted(oControllerS2,function(oEvent){
                              otypeModel.setData(otypeModel.oData.d.results);
                              oControllerS2._oDynamicF4Dialog.setModel(otypeModel);
                                  oControllerS2.customBusyDialogClose();
                                  otypeModel.detachRequestCompleted();
                                  },oControllerS2);
                                otypeModel.loadData(serviceUrl
                                             + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and ID eq '"
                                             + oControllerS2.getView().byId("receiverTypeSelect").getSelectedKey()
                                             + "' and WF eq true", null, false);
                                }
                            oControllerS2._oDynamicF4Dialog.setModel(otypeModel);
      }  else if (oEvent.getSource().getId().indexOf("idProcessorName")!=-1) {
       f4text = {

         title : sap.ui.getCore().byId("idProcessorSelect")
           .getSelectedItem().getText(),

         id : "idProcessorName",
        };
        if (sap.ui.getCore().byId("idProcessorSelect").getSelectedKey() != 'SPACE') {
                              otypeModel.attachRequestCompleted(oControllerS2,function(oEvent){
                               otypeModel.setData(otypeModel.oData.d.results);
                               oControllerS2._oDynamicF4Dialog.setModel(otypeModel);
                                   oControllerS2.customBusyDialogClose();
                                   otypeModel.detachRequestCompleted();
                                   },oControllerS2);
                              otypeModel.loadData(serviceUrl
                                              + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and ID eq '"
                                              + sap.ui.getCore().byId("idProcessorSelect").getSelectedKey()
                                              + "' and WF eq true", null, false);
                                 
                             }
                             oControllerS2._oDynamicF4Dialog.setModel(otypeModel);
       } else {
       f4text = {
        title : this.getView().getModel("i18n").getObject("USER"),
        id : oEvent.getSource().getId(),
       };
      }

      oF4Texts.setData(f4text);

      oControllerS2._oDynamicF4Dialog.setModel(

      oF4Texts, "dyntext");
      oControllerS2.customBusyDialogClose();
      // open value help dialog
      oControllerS2._oDynamicF4Dialog.open();
     },

     _handleValueHelpClose : function(evt) {
      evt.getSource().getBinding("items").filter([]);
     },

     /* Send Back Action */
     sendBackToButtonPressed : function(oEvent) {
      this.openDialog('sendBackAssistDialog');
     },

     onSendBackOkButton : function(oEvent) {

      this.customBusyDialogOpen();
      var sentById = this.oSource.getController().sentById;
      var oModel = new sap.ui.model.json.JSONModel();

      oModel
        .attachRequestCompleted(
          oEvent,
          function(oEvt) {
           oModel.detachRequestCompleted();

           if (oModel.getData().d.results[0].msg_type == "S") {

            var tempModel = this.oRouter
              .getView(
                "flm.fiori.view.S1")
              .byId(
                "idAssistantTable")
              .getModel("files");

            var tempArr = tempModel.oData.results;
            var oTable = this.oRouter
              .getView(
                "flm.fiori.view.S1")
              .byId(
                "idAssistantTable");
            var i = 0, j = -1;
            while (i < tempArr.length) {
             if (tempArr[i].CaseGuid == oControllerS2.caseguid) {
              j = i;
              break;
             }
             i++;
            }
            if (j != -1) {
             oTable.removeSelections();
             tempArr.splice(j, 1);
             tempModel.oData.__count--;
             tempModel.checkUpdate();
            }

            this
              .closeDialog('sendBackAssistDialog');
            this.customBusyDialogClose();
            this.oRouter.getView(
              "flm.fiori.view.S1")
              .byId("sendBackAction")
              .setEnabled(false);
            this.oRouter
              .getView(
                "flm.fiori.view.S1")
              .byId(
                "idAssistantTable")
              .removeSelections();
            destroyDialogs(oControllerS2); //destroy all common fragments
            this.oRouter
              .navTo("fullscreen");
            sap.m.MessageToast
              .show(oModel.getData().d.results[0].msg_text);

           } else {
            sap.m.MessageBox
              .alert(oModel.getData().d.results[0].msg_text);
           }
           ;

          }, oControllerS2);

      oModel
        .loadData(
          serviceUrl
            + "/FILES_FI?param_1='SB'&param_2='"
            + this.caseguid
            + "'&param_3='"
            + sentById
            + "'&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
          null, false);
     },

     onSendBackCloseButton : function(oEvent) {
      this.closeDialog('sendBackAssistDialog');
     },

     // //For Edited Notings
     onNoteEditButtonPressed : function(evt) { // CHANGED
      // notingEditFlag = true;
      var SignedTxt = "";
      // digital signing of code
      if (oControllerS2.getView().byId("commenteditor")
        .getValue() == "") {
       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_24"));
       return;
      }
      if (oControllerS2.digSigNeeded) {
       var crc = 0;
       var htmContent = "";
       var x = this.getView().byId("commenteditor")
         .getValue();
       x = "Digital Signature"; // SHOULD BE CHANGED
       var htmlContent = Base64.encode(x);

       try {
        htmContent = "<SAPSignIn><format>PKCS7</format><onlysig>X</onlysig><onlyvalid>X</onlyvalid><document type=&#34;HTM&#34;>"
          + htmlContent
          + "</document></SAPSignIn>";
        crc = SAPSign.SignDoc(htmContent, "EXT", "B64",
          "", "");

       } catch (err) {

       }
       ;
       SignedTxt = SAPSign.signature;
       SAPSign.signature = "";
       if (crc != 0) {
        sap.m.MessageBox.alert(SignedTxt);
        return;
       }
       // end of digital signing
      }

      if (this.getView().byId("commenteditor").getModel()
        .getData().Notingid != undefined) {
       if (this.getView().byId("commenteditor").getModel()
         .getData().NoteFlag) {
        if (oControllerS2.getView().byId("nameInput")
          .getValue() == "") {
         sap.m.MessageBox
           .alert(this.getView().getModel("i18n").getObject("MESSAGE_22"));
         return;
        }
       }
       var remarkTo = "";
       var bPrivate;
       if (this.getView().byId("receiverTypeSelect")
         .getSelectedItem().getText() == ""
         || !this.getView().byId(
           "receiverTypeSelect").getEnabled()) {
        bPrivate = "0002";
       } else {

        if (this.getView().byId("nameInput").getValue() == ''
          || !this.getView().byId("nameInput")
            .getEnabled()) {
         sap.m.MessageBox
           .alert(this.getView().getModel("i18n").getObject("MESSAGE_23"));
         return;
        } else {
         bPrivate = "0004";
         remarkTo = this.getView().byId("nameInput")
           .getName();
        }

       }

       var editedContent = {
        TabType : oControllerS2.fromTab,
        Textid : bPrivate,
        Wiid : oControllerS2.wiId,
        CaseGuid : oControllerS2.caseguid,
        NotingString : encodeURIComponent(oControllerS2.getView().byId(
          "commenteditor").getValue()),
        SNotingString : SignedTxt,
        PAgent : remarkTo,
        Notingid : oControllerS2.getView().byId(
          "commenteditor").getModel().getData().Notingid
       };
       var updateModel = this.getView().getModel();
       // create batch operation
       // updateModel.clearBatch();
       var batchOp = updateModel.createBatchOperation(
         "/FILE_NOTING_ES(Notingid='"
           + oControllerS2.getView().byId(
             "commenteditor").getModel()
             .getData().Notingid + "')",
         'PUT', editedContent);
       // add batch operation
       updateModel.addBatchChangeOperations([ batchOp ]);
       var batchOp = updateModel.createBatchOperation(
         "/FILE_NOTING_ES(Notingid='"
           + oControllerS2.getView().byId(
             "commenteditor").getModel()
             .getData().Notingid + "')",
         "GET");
       // add batch operation
       updateModel.addBatchReadOperations([ batchOp ]);


       // finally submit batch for both basic and dynamic
       // attributes
       this.customBusyDialogOpen("");
       updateModel
         .submitBatch(
           function(oResponse, oData) {

            var notingList = oControllerS2
              .getView().byId(
                "noteList")
              .getModel("global")
              .getData().notings;
            if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {
            for (var i = 0; i < notingList.length; i++) {
             if (notingList[i].Notingid == oResponse.__batchResponses[1].data.Notingid) {
              try{
               notingList[i].actNote = decodeURIComponent(oResponse.__batchResponses[1].data.NotingString);
               }catch(err){
                notingList[i].actNote = oResponse.__batchResponses[1].data.NotingString;
               }

              notingList[i].Createdate = oResponse.__batchResponses[1].data.Createdate;
              notingList[i].Rmrkto = oResponse.__batchResponses[1].data.Rmrkto;
              oControllerS2
                .getView()
                .byId(
                  "noteList")
                .getModel(
                  "global")
                .checkUpdate();
              break;
             }
            }
             }
                                                else{
              sap.m.MessageBox.alert(getErrorMessage(oResponse.__batchResponses[i].response.body,
                oResponse.__batchResponses[i].response.headers));
              return;
             }

            oControllerS2
              .customBusyDialogClose();
           }, function(oResponse) {

           }, true);
       this.getView().byId(
       "commenteditor")
       .setValue("");

       this.getView().byId(
       "nameInput").setValue(
       "");
       this.getView().byId(
       "commenteditor")
       .getModel().destroy();

      }
      this.getView().byId("noteEditAction").setVisible(false);
      this.getView().byId("notePostAction").setVisible(true);

      // Enable the reciever type and name field
      this.getView().byId("nameInput").setEnabled(true);
      this.getView().byId("receiverTypeSelect").setEnabled(
        true);
      this.getView().byId("receiverTypeSelect")
      .setSelectedKey("SPACE");
     },
     /* Posting New Noting */
     onPostButtonPressed : function(evt) {
      // notingEditFlag = false;

      if (oControllerS2.getView().byId("commenteditor")
        .getValue() == "") {
       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_24"));
       return;
      }
      var crc = 0;
      var htmContent = "";
      var SignedTxt = "";
      var x = this.getView().byId("commenteditor").getValue();
      /*var cert1 = "<object id='applet' name='_enc_applet' classid='clsid:8AD9C840-044E-11D1-B3E9-00805F499D93' alt='Java Runtime Environment is not working on your system' border=0 height=90 width=500 >"
                + "<param name='java_code' value='com.ncode.ctrl.pki.PKICtrl.class'>"
                +"<param name='java_archive' value='nCodePKICtrl3.jar'>"
                +"<param name='type' value='application/x-java-applet;'>"
       +"<param name='ServerDate' value='08/05/2014'>"
       +"<param name='ShowCertDialog' value='true'>"
       +"<param name='debug' value='false'>"
       +"<param name='serialNo' value=''>"
       +"<param name='thumbPrint' value=''>"
       +"<param name='strPubKey' value=''>"
       +"<param name='checkTimeDiff' value=''>"
       +"<param name='formId' value=''>"
       +"<param name='MAYSCRIPT' value='true'>"
       +"<comment>"
       +"<applet name='_enc_applet' alt='Java Runtime Environment is not working on your system' border=0 java_archive='nCodePKICtrl3.jar' java_code='com.ncode.ctrl.pki.PKICtrl.class' height=90 archive='nCodePKICtrl3.jar' code='com.ncode.ctrl.pki.PKICtrl.class' width=500 type='MIME_type' mayscript='mayscript' >"
       +"<param name='ServerDate' value='08/05/2014'>"
       +"<param name='ShowCertDialog' value='true'>"
       +"<param name='debug' value='false'>"
       +"<param name='serialNo' value=''>"
       +"<param name='checkTimeDiff' value=''>"
       +"<param name='thumbPrint' value=''>"
       +"<param name='strPubKey' value=''>"
       +"<param name='formId' value=''>"
       +"</applet>"
       +"</comment>"
       +"</object>";
      $("body").append(cert1);*/

      //var signedContent = signText(x);
      // x=oControllerS2.cleanBody(x);
      x = "Digital Signature"; // SHOULD BE CHANGED
      var htmlContent = Base64.encode(x);

      try {
       // htmContent =
       // "<SAPSignIn><format>PKCS7</format><onlysig>X</onlysig><onlyvalid>X</onlyvalid><document
       // type=&#34;HTM&#34;>"
       htmContent = "<SAPSignIn><format>PKCS7</format><document type=&#34;HTM&#34;>"
         + htmlContent + "</document></SAPSignIn>";
       crc = SAPSign.SignDoc(htmContent, "EXT", "B64", "",
         "");

      } catch (err) {

      }
      ;
      SignedTxt = SAPSign.signature;
      SAPSign.signature = "";
      if (crc != 0) {
       sap.m.MessageBox.alert(SignedTxt);
       return;
      }
      var newNoting = this.getView().byId("commenteditor")
        .getValue();// oEvent.getSource().getBindingContext().getObject();
      var remarkTo = "";
      var bPrivate;
      if (this.getView().byId("receiverTypeSelect")
        .getSelectedItem().getText() == "") {
       bPrivate = "0002";
      } else {
       if (this.getView().byId("nameInput").getValue() == '') {
        sap.m.MessageBox
          .alert(this.getView().getModel("i18n").getObject("MESSAGE_23"));
        return;
       } else {
        bPrivate = "0004";
        remarkTo = this.getView().byId("nameInput")
          .getName();
       }
      }
      var newNotingData = {
       TabType : this.fromTab,
       Textid : bPrivate,
       Wiid : this.wiId,
       CaseGuid : this.caseguid,
       NotingString : encodeURIComponent(newNoting),
       SNotingString : SignedTxt,
       //SNotingString : signedContent,
       PAgent : remarkTo
      };
      this.customBusyDialogOpen();
      var ocrModel = this.getView().getModel();
      ocrModel
        .create(
          "/FILE_NOTING_ES",
          newNotingData,
          {
           success : function(oResponse) {

            var noteListModel = oControllerS2
              .getView().byId(
                "noteList")
              .getModel("global").oData.notings;
            if (noteListModel == null) {
             noteListModel = [ oResponse ];
             try{
              oResponse.actNote = decodeURIComponent(oResponse.NotingString);
              }catch(err){
               oResponse.actNote = oResponse.NotingString;
              }

             oControllerS2.data.notings = noteListModel;
             oControllerS2.getView()
               .getModel("global")
               .checkUpdate();
            } else {
             noteListModel.splice(0, 0,
               oResponse);
             try{
              oResponse.actNote = decodeURIComponent(oResponse.NotingString);
              }catch(err){
               oResponse.actNote = oResponse.NotingString;
              }
             oControllerS2.getView()
               .getModel("global")
               .refresh();
            }
            oControllerS2
              .customBusyDialogClose();
           },
           error : function(oResponse) {
            sap.m.MessageBox.alert(getErrorJson(oResponse.response.body));
            oControllerS2.customBusyDialogClose();
           },


           async : true
          });
      this.getView().byId("commenteditor").setValue("");
      this.getView().byId("commenteditor").reinitialize();

      this.getView().byId("nameInput").setValue("");

      // Enable the reciever type and name field
      this.getView().byId("nameInput").setEnabled(true);
      this.getView().byId("receiverTypeSelect").setEnabled(
        true);
      this.getView().byId("receiverTypeSelect")
      .setSelectedKey("SPACE");
     },

     // //For notings post

     // ///Notings Edit

     noteEditPressed : function(oEvent) {
      // notingEditFlag = true;
      this.getView().byId("notePostAction").setVisible(false);
      this.getView().byId("noteEditAction").setVisible(true);
      oControllerS2.getView().byId("commenteditor").rerender();
      var clickedNote = oEvent.getSource().getParent()
        .getParent().getParent().getParent()
        .getParent().getBindingContext("global")
        .getObject();
      if (!clickedNote.NoteFlag) {
       oControllerS2.getView().byId("nameInput")
         .setEnabled(false);
       oControllerS2.getView().byId("receiverTypeSelect")
         .setSelectedKey("SPACE");
       oControllerS2.getView().byId("receiverTypeSelect")
         .setEnabled(false);
      } else {
       oControllerS2.getView().byId("nameInput")
         .setEnabled(true);
       oControllerS2.getView().byId("receiverTypeSelect")
         .setEnabled(true);
      }
      var tempModel = new sap.ui.model.json.JSONModel();
      tempModel.setData(oEvent.getSource().getParent()
        .getParent().getItems()[0].getBindingContext(
        "global").getObject());
      this.getView().byId("commenteditor")
        .setModel(tempModel);
      this.getView().byId("commenteditor").setValue( 
        oEvent.getSource().getParent().getParent()
          .getItems()[0].getContent());
      sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_59"));
     },
     // ///Notings Edit ends
     /* Assistant Noting Save Action */
     onSaveButtonPressed : function(oEvent) {

      var assistNoting = this.getView().byId("commenteditor")
        .getValue();// oEvent.getSource().getBindingContext().getObject();

      var assistNotingData = {
       TabType : "ASSISTANT",
       Textid : "0003",
       Wiid : this.wiId,
       CaseGuid : this.caseguid,
       NotingString : assistNoting,
       Wfinfo : this.oSource.getController().wfInfo
      };

      var ocrModel = new sap.ui.model.odata.ODataModel(
        serviceUrl, true);
      ocrModel.create("/FILE_NOTING_ES", assistNotingData);

      sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_25"));

     },

     // //For new noting clear data
     newNotingActionPressed : function(oEvent) {

      this.getView().byId("noteEditAction").setVisible(false);
      this.getView().byId("notePostAction").setVisible(true);
      this.getView().byId("nameInput").setEnabled(true);
      this.getView().byId("receiverTypeSelect").setEnabled(
        true);
      this.getView().byId("commenteditor").setValue("");
      this.getView().byId("nameInput").setValue("");
      this.getView().byId("receiverTypeSelect")
        .setSelectedKey("SPACE");

     },
     // Send File Actions
     /*sendFileButtonPressed : function(oEvent) {
      this.openDialog('confirmDialog');
     },*/
     // send file action
     sendFileButtonPressed : function(oEvent) {
      sap.m.MessageBox.confirm(this.getView().getModel("i18n").getObject("MESSAGE_19"),
        function(response) {
          if (response == "OK") {
//      oEvent.getSource().getParent().close();
           oControllerS2.customBusyDialogOpen();


      var assistFlag = oControllerS2.oSource.getController().assistFlag;

      if (assistFlag == true) {
       // this.assistNotButtonPressed();

       sap.m.MessageBox
         .confirm(
           oControllerS2.getView().getModel("i18n").getObject("MESSAGE_26"),
           function(response) {
            if (response == "OK") {
             // check for digital signature customizationg
             if(oControllerS2.digSigNeeded){
              if(oControllerS2.customDigitalSignData){
                        /*  var flag = oControllerS2.customDigitalSignData(oControllerS2.data);
                          if(flag == "X"){
             oControllerS2
               .confirmSendFile(
                 oControllerS2.caseguid,
                 oControllerS2.wiId,
                 oControllerS2.fileid,
                 oControllerS2.fromTab);
                          }*/
               oControllerS2.customDigitalSignData(oControllerS2.data, jQuery.proxy(function() {
                oControllerS2.confirmSendFile(oControllerS2.caseguid,
                  oControllerS2.wiId,
                  oControllerS2.fileid,
                  oControllerS2.fromTab);
                            
                            }, oControllerS2));
              }else{
               sap.m.MessageBox.alert(oControllerS2.getView().getModel("i18n").getObject("MESSAGE_73"));
               oControllerS2
               .customBusyDialogClose();
               }
             }else{
              oControllerS2
              .confirmSendFile(
                oControllerS2.caseguid,
                oControllerS2.wiId,
                oControllerS2.fileid,
                oControllerS2.fromTab);
             }
            } else {
             oControllerS2
               .customBusyDialogClose();
            }
           });

      } else {
       if(oControllerS2.digSigNeeded){
        if(oControllerS2.customDigitalSignData){
                    /*var flag = oControllerS2.customDigitalSignData(oControllerS2.data);
                    if(flag == "X"){
       oControllerS2
         .confirmSendFile(
           oControllerS2.caseguid,
           oControllerS2.wiId,
           oControllerS2.fileid,
           oControllerS2.fromTab);
                    }*/
         oControllerS2.customDigitalSignData(oControllerS2.data, jQuery.proxy(function() {
          oControllerS2.confirmSendFile(oControllerS2.caseguid,
            oControllerS2.wiId,
            oControllerS2.fileid,
            oControllerS2.fromTab);
                      
                      }, oControllerS2));
        }else{
         sap.m.MessageBox.alert(oControllerS2.getView().getModel("i18n").getObject("MESSAGE_73"));
         oControllerS2
         .customBusyDialogClose();
        }
       }else{
        oControllerS2
        .confirmSendFile(
          oControllerS2.caseguid,
          oControllerS2.wiId,
          oControllerS2.fileid,
          oControllerS2.fromTab);
       }
      }

          }else{

       oControllerS2.customBusyDialogClose();
      }
       });


     },

     confirmSendFile : function(caseguid, wiId, fileid, fromTab,
       isConfirmed) {

      if (isConfirmed == null) {
       isConfirmed = "";
      }
      // check for digital signature customizationg
      /*if(oControllerS2.digSigNeeded){
       if(oControllerS2.customDigitalSignData){
                   var flag = oControllerS2.customDigitalSignData(oControllerS2.data);
                   
                   switch ( flag ){
                   case "X":
                    oControllerS2.confirmSendFile(oControllerS2.caseguid,
           oControllerS2.wiId, oControllerS2.fileid,
           oControllerS2.fromTab);
                    return;
                    break;
                    
                   case "Y":
                    // popup that sending the file failed as dig signing is failed
                   // sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_70"));
                    oControllerS2.confirmSendFile(oControllerS2.caseguid,
           oControllerS2.wiId, oControllerS2.fileid,
           oControllerS2.fromTab);
                    return;
                    break;
                    
                   case "Z" : 
                    // Dig sign failed but do u still want to send ??
                    sap.m.MessageBox.confirm(this.getView().getModel("i18n").getObject("MESSAGE_71"),
           function(response) {
            if (response != "OK") {
             return;
            } 
           });
                    oControllerS2.confirmSendFile(oControllerS2.caseguid,
           oControllerS2.wiId, oControllerS2.fileid,
           oControllerS2.fromTab);
                    return;
                    break;
                   } 
       }
      }*/

      var oModel = new sap.ui.model.json.JSONModel();

      oModel
        .attachRequestCompleted(
          oControllerS2,
          function(oEvent) {

           oModel.detachRequestCompleted();

           if (oModel.getData().d.results[0].msg_type == "C"
             && oModel.getData().d.results[0].msg_id == 373) {
            // oControllerS2.lastProcButtonPressed();
            sap.m.MessageBox
              .confirm(
                oModel
                  .getData().d.results[0].msg_text,
                function(
                  response) {
                 if (response == "OK") {
                  // check for digital signature customizationg
                  if(oControllerS2.digSigNeeded){
                   if(oControllerS2.customDigitalSignData){
                              /* var flag = oControllerS2.customDigitalSignData(oControllerS2.data);
                               if(flag == "X"){
                              
                  oControllerS2.confirmSendFile(
                      caseguid,
                      wiId,
                      fileid,
                      fromTab,
                      "X");
                               }*/
                    oControllerS2.customDigitalSignData(oControllerS2.data, jQuery.proxy(function() {
                     oControllerS2.confirmSendFile(caseguid,
                       wiId,
                       fileid,
                       fromTab,
                       "X");
                                 
                                 }, oControllerS2));
                   }
                   else{
                    sap.m.MessageBox.alert(oControllerS2.getView().getModel("i18n").getObject("MESSAGE_73"));
                    oControllerS2
                    .customBusyDialogClose(oControllerS2);
                   }
                  }else{
                   oControllerS2.confirmSendFile(
                     caseguid,
                     wiId,
                     fileid,
                     fromTab,
                     "X");
                  }

                 } else {
                  oControllerS2
                    .customBusyDialogClose(oControllerS2);
                 }
                });

           } else if (oModel.getData().d.results[0].msg_type == "E") {
            oControllerS2
              .customBusyDialogClose(oControllerS2);
            sap.m.MessageBox
              .alert(oModel.getData().d.results[0].msg_text);
           } else {

            // delete the file from the tab
            var oTableId = null;
            var oEntitySet = null;
            switch (oControllerS2.fromTab) {
            case "INTRAY":
             oTableId = "idFilesTable";
             oEntitySet = "/FILE_INTRAY_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
             break;

            case "DRAFT":
             oTableId = "idDraftsTable";
             oEntitySet = "/FILE_DRAFT_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
             break;

            case "SUBSTITUTE":
             oTableId = "idSubstituteTable";
             oEntitySet = "/FILE_SUBST_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
             break;
            }
            var tempModel = oControllerS2.oRouter
              .getView(
                "flm.fiori.view.S1")
              .byId(oTableId)
              .getModel("files");
            tempModel
              .attachRequestCompleted(
                oControllerS2,
                function(oEvent) {
                 tempModel
                   .detachRequestCompleted();
                 if (tempModel.oData.d != undefined) {
                  tempModel
                    .setData(tempModel.oData.d);
                  tempModel
                    .checkUpdate();
                  sap.m.MessageToast
                    .show(oModel
                      .getData().d.results[0].msg_text);
                 }
                 oControllerS2
                   .customBusyDialogClose(oControllerS2);
                 oControllerS2.oRouter
                   .getView(
                     "flm.fiori.view.S1")
                   .byId(
                     "sendAction")
                   .setEnabled(
                     false);
                 oControllerS2.oRouter
                   .getView(
                     "flm.fiori.view.S1")
                   .byId(
                     oTableId)
                   .removeSelections();
                 destroyDialogs(oControllerS2); //destroy all common fragments
                 oControllerS2.oRouter
                   .navTo("fullscreen");
                },
                oControllerS2);
            tempModel.loadData(serviceUrl
              + oEntitySet, null,
              true);
           }

          }, oControllerS2);

      oModel
        .loadData(
          serviceUrl
            + "/FILES_FI?param_1='SE'&param_2='"
            + caseguid
            + "'&param_3='"
            + wiId
            + "'&param_4='"
            + fileid
            + "'&param_5=''&check_1='"
            + isConfirmed
            + "'&check_2=''&check_3=''&param_6=''&param_7='"
            + fromTab
            + "'&param_8=''&param_9=''&param_10=''",
          null, false);

     },

     // Close File Actions
     /*closeFileButtonPressed : function(oEvent) {

      var assistFlag = this.oSource.getController().assistFlag;

      if (assistFlag == true) {
       // this.assistNotButtonPressed();

       sap.m.MessageBox
         .confirm(
           this.getView().getModel("i18n").getObject("MESSAGE_26"),
           function(response) {
            if (response == "OK") {
             oControllerS2.openDialog('closeFileDialog');
            } else {
             oControllerS2
               .customBusyDialogClose();
            }
           });
      }
      else{
       oControllerS2.openDialog('closeFileDialog');
      }

     },*/
     closeSharedDialog : function(oEvent) {
      this.openDialog('closeSharedConfirmDialog');
     },

     // event handler for closing the file
     closeFileButtonPressed : function(oEvent) {

      var oTableId = null;
      var oEntitySet = null;

      switch (this.fromTab) {

      case "INTRAY":
       oTableId = "idFilesTable";
       oEntitySet = "/FILE_INTRAY_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
       break;
      case "DRAFT":
       oTableId = "idDraftsTable";
       oEntitySet = "/FILE_DRAFT_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
       break;
      case "SUBSTITUTE":
       oTableId = "idSubstituteTable";
       oEntitySet = "/FILE_SUBST_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
       break;

      }
      sap.m.MessageBox.confirm(this.getView().getModel("i18n").getObject("MESSAGE_45"),
        function(response) {
          if (response == "OK") {
      var assistFlag = oControllerS2.oSource.getController().assistFlag;
      if (assistFlag == true) {
       sap.m.MessageBox.confirm(
         oControllerS2.getView().getModel("i18n").getObject("MESSAGE_26"),
           function(response) {
            if (response == "OK") {
      if (oTableId != null) {
       oControllerS2.customBusyDialogOpen();

       var oModel = new sap.ui.model.json.JSONModel();// oControllerS2.oRouter.getView("flm.fiori.view.S1").byId(oTableId).getModel("files");
       var oTable = oControllerS2.oRouter.getView(
         "flm.fiori.view.S1").byId(oTableId);
       oModel
         .attachRequestCompleted(
           this,
           function(oEvent) {

            oModel.detachRequestCompleted();
            // delete the file from the tab
            var tempArr = oTable
              .getModel("files").oData.results;
            var i = 0, j = -1;
            while (i < tempArr.length) {
             if (tempArr[i].CaseGuid == oControllerS2.caseguid) {
              j = i;
              break;
             }
             i++;
            }
            if (j != -1) {
             oTable.removeSelections();
             tempArr.splice(j, 1);
             oTable.getModel("files").oData.__count--;
             oTable.getModel("files")
               .checkUpdate();
            }

            sap.m.MessageToast
              .show(oControllerS2.getView()
                .getModel(
                  "i18n")
                .getObject(
                  "FILECLOSED"));
            oControllerS2.customBusyDialogClose();
            oControllerS2.oRouter.getView(
              "flm.fiori.view.S1")
              .byId("closeAction")
              .setEnabled(false);
            oControllerS2.oRouter.getView(
              "flm.fiori.view.S1")
              .byId("sendAction")
              .setEnabled(false);
            oTable.removeSelections();
            destroyDialogs(oControllerS2); //destroy all common fragments
            oControllerS2.oRouter
              .navTo("fullscreen");
           }, this);
       // Failure
       oModel.attachRequestFailed(this, function(oEvent) {
        oModel.detachRequestCompleted();
        oModel.detachRequestFailed();
        sap.m.MessageBox.alert(oControllerS2.getView().getModel(
          "i18n").getObject("MESSAGE_27"));
        oControllerS2.customBusyDialogClose();
       }, this);

       oModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='CF'&param_2='"
             + oControllerS2.caseguid
             + "'&param_3='"
             + oControllerS2.wiId
             + "'&param_4='"
             + oControllerS2.fileid
             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
             + oControllerS2.fromTab
             + "'&param_8=''&param_9=''&param_10=''",
           null, true);
      }else {
       oControllerS2.customBusyDialogClose();
       }
            }});
      }else {
       if (oTableId != null) {
        oControllerS2.customBusyDialogOpen();

        var oModel = new sap.ui.model.json.JSONModel();// oControllerS2.oRouter.getView("flm.fiori.view.S1").byId(oTableId).getModel("files");
        var oTable = oControllerS2.oRouter.getView(
          "flm.fiori.view.S1").byId(oTableId);
        oModel
          .attachRequestCompleted(
            this,
            function(oEvent) {

             oModel.detachRequestCompleted();
             // delete the file from the tab
             var tempArr = oTable
               .getModel("files").oData.results;
             var i = 0, j = -1;
             while (i < tempArr.length) {
              if (tempArr[i].CaseGuid == oControllerS2.caseguid) {
               j = i;
               break;
              }
              i++;
             }
             if (j != -1) {
              oTable.removeSelections();
              tempArr.splice(j, 1);
              oTable.getModel("files").oData.__count--;
              oTable.getModel("files")
                .checkUpdate();
             }

             sap.m.MessageToast
               .show(oControllerS2.getView()
                 .getModel(
                   "i18n")
                 .getObject(
                   "FILECLOSED"));
             oControllerS2.customBusyDialogClose();
             oControllerS2.oRouter.getView(
               "flm.fiori.view.S1")
               .byId("closeAction")
               .setEnabled(false);
             oControllerS2.oRouter.getView(
               "flm.fiori.view.S1")
               .byId("sendAction")
               .setEnabled(false);
             oTable.removeSelections();
             destroyDialogs(oControllerS2); //destroy all common fragments
             oControllerS2.oRouter
               .navTo("fullscreen");
            }, this);
        // Failure
        oModel.attachRequestFailed(this, function(oEvent) {
         oModel.detachRequestCompleted();
         oModel.detachRequestFailed();
         sap.m.MessageBox.alert(this.getView().getModel(
           "i18n").getObject("MESSAGE_27"));
         oControllerS2.customBusyDialogClose();
        }, this);

        oModel
          .loadData(
            serviceUrl
              + "/FILES_FI?param_1='CF'&param_2='"
              + oControllerS2.caseguid
              + "'&param_3='"
              + oControllerS2.wiId
              + "'&param_4='"
              + oControllerS2.fileid
              + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
              + oControllerS2.fromTab
              + "'&param_8=''&param_9=''&param_10=''",
            null, true);
       }else {
        oControllerS2.customBusyDialogClose();
        }
     }
   }
  });
 },

     onCloseButtonPressedCancel : function(oEvent) {
      this.closeDialog('closeFileDialog');
     },
     onCloseSharedOk : function(oEvent) {
      this.closeDialog('closeFileDialog');
      var oModel = new sap.ui.model.json.JSONModel();
      oModel
        .loadData(
          serviceUrl
            + "/FILES_FI?param_1='CF'&param_2='"
            + this.caseguid
            + "'&param_3='"
            + this.wiId
            + "'&param_4='"
            + this.fileid
            + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='INTRAY'&param_8=''&param_9=''&param_10=''",
          null, false);
      if (oModel.getData().d.results[0].msg_type == "S") {
       sap.m.MessageToast
         .show(oModel.getData().d.results[0].msg_text);
       oControllerS2.oRouter.getView("flm.fiori.view.S1")
         .byId("closeAction").setEnabled(false);
       oControllerS2.oRouter.getView("flm.fiori.view.S1")
         .byId("sendAction").setEnabled(false);
       oControllerS2.oRouter.getView("flm.fiori.view.S1")
         .byId("idFilesTable").removeSelections();
       destroyDialogs(oControllerS2); //destroy all common fragments
       this.oRouter.navTo("fullscreen");
       var tempModel = new sap.ui.model.json.JSONModel();
       tempModel = this.oRouter.getView(
         "flm.fiori.view.S1").byId("idFilesTable")
         .getModel("files");
       tempModel.loadData(serviceUrl + "/FILE_INTRAY_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'",
         null, false);
       tempModel.setData(tempModel.oData.d);
       tempModel.checkUpdate();

      } else if (oModel.getData().d.results[0].msg_type == "E") {
       sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);

      }
      ;

      this.closeDialog('closeSharedConfirmDialog');

     },

     onCloseSharedCancel : function(oEvent) {
      this.closeDialog('closeSharedConfirmDialog');
     },
     // Move To Cabinet Actions
     moveToCabinetButtonPressed : function(oEvent) {

      var assistFlag = this.oSource.getController().assistFlag;
      if (assistFlag == true) {
       this.cabinetSharedDialogOpen();
      } else {
       if (!this.oMoveToCabinet) {
        this.oMoveToCabinet = sap.ui.xmlfragment(
          "flm.fiori.view.moveToCabinet", this);
       }
       sap.ui.getCore().byId("datePick").setValue("");
       this.oMoveToCabinet.open();
      }
     },

     onResubDateCloseButton : function(oEvent) {
      sap.ui.getCore().byId("datePick").setValue("");
      oEvent.getSource().getParent().close();
     },
     cabinetSharedDialogOpen : function(oEvent) {
      this.openDialog('moveCabinSharedDialog');
     },

     onCabinetSharedCancel : function(oEvent) {
      this.closeDialog('moveCabinSharedDialog');
     },
     // /***Code Changes to be made-Start***///
     onResubDateOkButton : function(oEvent) {
      this.customBusyDialogOpen();

      var date = new Date();

      if ((date.getMonth() + 1) < 10) {
       month = "0" + (date.getMonth() + 1);
      } else {
       month = date.getMonth() + 1;
      }
      if ((date.getDate()) < 10) {
       day = "0" + (date.getDate());
      } else {
       day = date.getDate();
      }
      var year = date.getFullYear();
      var dateMonth = month+day;
      var currentDate = year + dateMonth;
      var resubDate = sap.ui.getCore().byId("datePick")
        .getValue();
      if (resubDate == "") {
       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_28"));
       this.customBusyDialogClose();

      } else if (resubDate <= currentDate) {
       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_29"));
       this.customBusyDialogClose();

      } else {

       var oModel = new sap.ui.model.json.JSONModel();
       oModel
         .attachRequestCompleted(
           oEvent,
           function(oEvt) {

            oModel.detachRequestCompleted();
            if (oModel.getData().d.results[0].msg_type == "S") {
             var tempModel = this.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId(
                 "idFilesTable")
               .getModel("files");
             var tempArr = tempModel.oData.results;
             var i = 0, j = -1, file = null;
             while (i < tempArr.length) {
              if (tempArr[i].CaseGuid == oControllerS2.caseguid) {
               j = i;
               break;
              }
              i++;
             }
             if (j != -1) {
              this.oRouter
                .getView(
                  "flm.fiori.view.S1")
                .byId(
                  "idFilesTable")
                .removeSelections();
              file = tempArr.splice(
                j, 1);
              tempModel.oData.__count--;
              tempModel.checkUpdate();
             }
             if (file != null) {
              var tempModel = this.oRouter
                .getView(
                  "flm.fiori.view.S1")
                .byId(
                  "idCabinetTable")
                .getModel(
                  "files");
              var tempArr = tempModel.oData.results;

              file[0].Readmail = "sap-icon://email";
              tempArr.splice(0, 0,
                file[0]);
              tempModel.oData.__count++;
              tempDate = sap.ui.getCore().byId("datePick").getDateValue();
                function pad(s) {
                 return (s < 10) ? '0' + s : s; 
                 }
              tempModel.oData.results[0].Rdate = [pad(tempDate.getDate()),pad(tempDate.getMonth()+1),tempDate.getFullYear()].join('.');
              tempModel.checkUpdate();
             }
             oControllerS2
               .customBusyDialogClose();
             oControllerS2.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId("closeAction")
               .setEnabled(false);
             oControllerS2.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId("sendAction")
               .setEnabled(false);
             oControllerS2.oRouter
               .getView(
                 "flm.fiori.view.S1")
               .byId(
                 "idFilesTable")
               .removeSelections();
             destroyDialogs(oControllerS2); //destroy all common fragments
             oControllerS2.oRouter
               .navTo("fullscreen");
             if (oModel.getData().d.results[0].msg_type == "S") {
              sap.m.MessageToast
                .show(oModel
                  .getData().d.results[0].msg_text);
             } else {
              sap.m.MessageToast
                .show(oModel
                  .getData().d.results[0].msg_text);
             }

            } else {
             sap.m.MessageBox
               .alert(oModel
                 .getData().d.results[0].msg_text);
             this
               .customBusyDialogClose();
            }

           }, oControllerS2);
       oModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='MC'&param_2='"
             + this.caseguid
             + "'&param_3='"
             + this.wiId
             + "'&param_4='"
             + this.fileid
             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='INTRAY'&param_8='"
             + resubDate
             + "'&param_9=''&param_10=''",
           null, true);
      }
     },

     onCabinetSharedOk : function(oEvent) {
      this.closeDialog('moveCabinSharedDialog');
      if (!this.oMoveToCabinet) {
       this.oMoveToCabinet = sap.ui.xmlfragment(
         "flm.fiori.view.moveToCabinet", this);
      }
      this.oMoveToCabinet.open();

     },

     handleF4Help : function(oEvent) {
      mparams = oControllerS2.data.dynamic;
      for (var i = 0; i < mparams.length; i++) {
       if (mparams[i].ID == oEvent.getSource().getId()) {

        if (!oControllerS2._oDynamicF4Dialog) {
         oControllerS2._oDynamicF4Dialog = sap.ui
           .xmlfragment(
             "flm.fiori.view.dynamicF4popup",
             oControllerS2);

        }
        var oF4Model = null;
        var path = null;
        if (mparams[i].F4HELP_VALUES != null
          && mparams[i].F4HELP_VALUES != undefined
          && mparams[i].F4HELP_VALUES != "") {
         f4array = getF4Array(mparams[i].F4HELP_VALUES);
         oF4Model = new sap.ui.model.json.JSONModel();
         oF4Model.setData(f4array);
        } else {

         oF4Model = new sap.ui.model.json.JSONModel();

         oF4Model
           .loadData(serviceUrl
             + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and ID eq '"
             + mparams[i].ID
             + "' and FileID eq '"
             + this.fileid + "'");
         oF4Model.setData(oF4Model.oData.d.results);
        }
        oControllerS2._oDynamicF4Dialog
          .setModel(oF4Model);

        oF4Texts = new sap.ui.model.json.JSONModel();
        var f4text = {
         title : mparams[i].F4_TITLE,
         id : mparams[i].ID,
         path : path,
         isTable : mparams[i].ISTABLE
        };
        oF4Texts.setData(f4text);
        oControllerS2._oDynamicF4Dialog.setModel(
          oF4Texts, "dyntext");
       }
      }
      oControllerS2._oDynamicF4Dialog.open();
     },

     _handleF4HelpSearch1 : function(evt) {

      var sValue = evt.getParameter("value");
      var oFilter = new sap.ui.model.Filter("ResulltCol1",
        sap.ui.model.FilterOperator.Contains, sValue);
      var oFilter1 = new sap.ui.model.Filter("ResultCol2",
        sap.ui.model.FilterOperator.Contains, sValue);
      var oFilter2 = new sap.ui.model.Filter("ResultCol3",
        sap.ui.model.FilterOperator.Contains, sValue);
      evt.getSource().getBinding("items").filter(
        new sap.ui.model.Filter([ oFilter,oFilter1, oFilter2 ],
          "OR"));
      var res = evt.getSource().getBinding("items").filter(new sap.ui.model.Filter([ oFilter,oFilter1, oFilter2 ],"OR"));
      if(res.iLength == 0 && oF4Texts.getData().isTable =="X"){
       var resModel = new sap.ui.model.json.JSONModel();
       resModel
         .loadData(
           serviceUrl
             + "/FILE_F4_ES?$filter=CaseGuid eq '"+this.caseguid+"' and FileID eq '"+oF4Texts.getData().id+"' and OtherF4 eq " +
               "true and ID eq 'VH' and ResulltCol1 eq '"+sValue+"'",
           null, false);
       resModel.setData(resModel.oData.d.results);
       oControllerS2._oDynamicF4Dialog.setModel(resModel);


      }
     },

     _handleF4HelpClose1 : function(evt) { // CHANGE

      var oSelectedItem = evt.getParameter("selectedItem");
      var id = evt.getSource().getModel("dyntext").getData().id;
      var oInput;
      if (oSelectedItem) {
       if (sap.ui.getCore().byId(id) != undefined) {
        oInput = sap.ui.getCore().byId(
          evt.getSource().getModel("dyntext")
            .getData().id);

       } else {
        oInput = this.getView().byId(
          evt.getSource().getModel("dyntext")
            .getData().id);
       }
       ;
       if (id == "idUsername" || id == "nameInput" || id == "userValueInput" || id == "idProcessorName") {
        if (oSelectedItem.getBindingContext()
          .getObject().ResultCol3.substr(0, 2) == "US") {
         oInput
           .setName(oSelectedItem
             .getBindingContext()
             .getObject().ResultCol3);

         oInput
           .setValue(oSelectedItem
             .getBindingContext()
             .getObject().ResultCol2
             + " "
             + oSelectedItem
               .getBindingContext()
               .getObject().ResulltCol1);
        } else {
         oInput
           .setName(oSelectedItem
             .getBindingContext()
             .getObject().ResultCol3);

         oInput
           .setValue(oSelectedItem
             .getBindingContext()
             .getObject().ResulltCol1);
        }
       }

//       else if (this.getView().byId("receiverTypeSelect")
//         .getSelectedKey() == "US") {
//        oInput
//          .setName(oSelectedItem
//            .getBindingContext()
//            .getObject().ResultCol3);
//
//        oInput
//          .setValue(oSelectedItem
//            .getBindingContext()
//            .getObject().ResultCol2
//            + " "
//            + oSelectedItem
//              .getBindingContext()
//              .getObject().ResulltCol1);
//       } 
       else {
        oInput
          .setName(oSelectedItem
            .getBindingContext()
            .getObject().ResultCol3);

        oInput
          .setValue(oSelectedItem
            .getBindingContext()
            .getObject().ResulltCol1);
        oControllerS2.onChangeFileAttribute();
       }
      }
      evt.getSource().getBinding("items").filter([]);
      // this._oDynamicF4Dialog.getModel().destroy();
      // this._oDynamicF4Dialog.getModel("dyntext").destroy();
     },

     continueAfterSave : function(actionId) {

      if (actionId == "navButtonPress") {
       oControllerS2.navToBackPage();
      } else if (actionId == "idPrint1") {
       oControllerS2.printWorkflowAction();
      } else if (actionId == "idPrint2") {
       oControllerS2.printNotingPrivateAction();
      } else if (actionId == "idPrint3") {
       oControllerS2.printNotingAction();
      } else if (actionId == "sendAction") {
       oControllerS2.sendFileButtonPressed();
      } else if (actionId == "shareAction") {
       if(oControllerS2.byId("commenteditor").getValue()==""){
        sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_66"));
        return;
       }
       oControllerS2.shareButtonPressed();
      } else if (actionId.indexOf("moveToCabinetAction") != -1) {
       oControllerS2.moveToCabinetButtonPressed();
      } else if (actionId.indexOf("closeFileAction") != -1) {
       oControllerS2.closeFileButtonPressed();
      } else if (actionId == "sendPreviousAction") {
       oControllerS2.sendPreviousButtonPressed();
      }
     },

invokeForSave : function(oEvent) {

      var actionId = "";
      if (oEvent.getId() == "navButtonPress") {
       actionId = oEvent.getId();
      } else {
       actionId = oEvent.getSource().getId();
      }
      if (oControllerS2.saveFlag) {
       if(actionId == "sendAction"){
        sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_64"));
        return;
       }
       else{
       sap.m.MessageBox
         .confirm(
           this.getView().getModel("i18n").getObject("MESSAGE_74"),
           function(response) {
            if (response == "OK") {
//             oControllerS2.saveButtonPressed();
             oControllerS2.continueAfterSave(actionId);
             oControllerS2.saveFlag = false;
//             oControllerS2.flatObj=undefined;
            } else {
//             oControllerS2.continueAfterSave(actionId);
//             oControllerS2.saveFlag = false;
//             oControllerS2.flatObj = undefined;
             return;
            }
           });
       }
      } else {
       oControllerS2.continueAfterSave(actionId);
      }
     },
     // Move to Intray Action

     // Move to Intray Action

     navToBackPage : function(oEvent) {
      oControllerS2.navFlag=true;
      oControllerS2.flatObj=null;
      this.getView().byId("idListPanel").destroyItems();
      this.getView().byId("dynamicAttrForm").destroyContent();
//      if(oControllerS3){
//       if(oControllerS3.navBackArr){
//        oControllerS2.navBackArr.push(oControllerS3.navBackArr[0]);
//       }
//      }

      try{
       if(oControllerS3){
        if(oControllerS3.navBackArrS3.length!=0)
         this.S3flag = true;
       }
      }catch(err){
       this.S3flag = false;
      }
      if(oControllerS2.navBackArr.length == 1 && !this.S3flag){

       this.getView().byId("notePanel").setVisible(true);
       this.getView().byId("privateLabel")
         .setVisible(true);
       this.getView().byId("receiverTypeSelect")
         .setVisible(true);
       this.getView().byId("nameInput").setVisible(true);
       this.getView().byId("notePostAction").setVisible(
         true);
       //this.oRouter.navTo("fullscreen");
       var paramPop = oControllerS2.navBackArr.pop();
       this.fromTab = paramPop.fromTab;
       this.oRouter.navTo("subscreen", {
        caseguid : paramPop.caseguid,
        fileid : paramPop.fileid,
        wiId : paramPop.wiId,
       }, true);

      }else 
       if (oControllerS2.navBackArr.length > 1) {

       var paramPop = oControllerS2.navBackArr.pop();
       this.fromTab = paramPop.fromTab;
       this.oRouter.navTo("subscreen", {
        caseguid : paramPop.caseguid,
        fileid : paramPop.fileid,
        wiId : paramPop.wiId,
       }, true);
       this.getView().byId("notePanel").setVisible(false);
       this.getView().byId("privateLabel")
         .setVisible(false);
       this.getView().byId("receiverTypeSelect")
         .setVisible(false);
       this.getView().byId("nameInput").setVisible(false);
       this.getView().byId("notePostAction").setVisible(
         false);


      } else if (this.fromFileSearch) {

       this.getView().byId("notePanel").setVisible(true);
       this.getView().byId("privateLabel")
         .setVisible(true);
       this.getView().byId("receiverTypeSelect")
         .setVisible(true);
       this.getView().byId("nameInput").setVisible(true);
       this.getView().byId("notePostAction").setVisible(
         true);
       archiveFlag = false;
       this.oRouter.navTo("searchscreen");
      } else if(this.fromDocSearch){

       this.getView().byId("notePanel").setVisible(true);
       this.getView().byId("privateLabel")
         .setVisible(true);
       this.getView().byId("receiverTypeSelect")
         .setVisible(true);
       this.getView().byId("nameInput").setVisible(true);
       this.getView().byId("notePostAction").setVisible(
         true);

       this.oRouter.navTo("docscreen");

      }else if(this.S3flag){

       if (oControllerS2.navBackArr.length == 1) {

        var paramPop = oControllerS2.navBackArr.pop();
        this.fromTab = paramPop.fromTab;
        this.oRouter.navTo("subscreen", {
         caseguid : paramPop.caseguid,
         fileid : paramPop.fileid,
         wiId : paramPop.wiId,
        }, true);
        this.getView().byId("notePanel").setVisible(false);
        this.getView().byId("privateLabel")
          .setVisible(false);
        this.getView().byId("receiverTypeSelect")
          .setVisible(false);
        this.getView().byId("nameInput").setVisible(false);
        this.getView().byId("notePostAction").setVisible(
          false);
        }
       else if(oControllerS3.navBackArrS3.length != 0){

       var paramPop = oControllerS3.navBackArrS3.pop();
       this.fromTab = paramPop.fromTab;
       oControllerS3.caseguid = paramPop.caseguid;
       oControllerS3.fileid = paramPop.fileid;
       this.oRouter.navTo("myscreen");
       }
       else{
         destroyDialogs(oControllerS2);
        this.oRouter.navTo("fullscreen");
       }
//       this.getView().byId("notePanel").setVisible(true);
//       this.getView().byId("privateLabel")
//         .setVisible(true);
//       this.getView().byId("receiverTypeSelect")
//         .setVisible(true);
//       this.getView().byId("nameInput").setVisible(true);
//       this.getView().byId("notePostAction").setVisible(
//         true);

      }else {
        destroyDialogs(oControllerS2);
                   var oTable = null;
                               var oTab = null;
                               if (oControllerS1.getView().byId("TAB_CONTAINER")
                                            .getSelectedKey() == "file") {
                                      oTable = oControllerS1.getView().byId("idFilesTable");
                                      oTab = "/FILE_INTRAY_ES?$filter=Filetype eq '"+oControllerS1.objectType+"'";
                               } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                            .getSelectedKey() == "draft") {
                                      oTable = oControllerS1.getView().byId("idDraftsTable");
                                      oTab = "/FILE_DRAFT_ES?$filter=Filetype eq '"+oControllerS1.objectType+"'";
                               } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                            .getSelectedKey() == "cabinet") {
                                      oTable = oControllerS1.getView().byId("idCabinetTable");
                                      oTab = "/FILE_CABIN_ES?$filter=Filetype eq '"+oControllerS1.objectType+"'";
                               } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                            .getSelectedKey() == "substitute") {
                                      oTable = oControllerS1.getView().byId("idSubstituteTable");
                                      oTab = "/FILE_SUBST_ES?$filter=Filetype eq '"+oControllerS1.objectType+"'";
                               } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                            .getSelectedKey() == "assistant") {
                                      oTable = oControllerS1.getView().byId("idAssistantTable");
                                      oTab = "/FILE_ASSIT_ES";
                               } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                            .getSelectedKey() == "sent") {
                                      oTable = oControllerS1.getView().byId("idSentFilesTable");
                                      oTab = "/FILE_SENT_ES?$filter=Subject eq '"+oControllerS1.objectType+"'";
                               } else if (oControllerS1.getView().byId("TAB_CONTAINER")
                                            .getSelectedKey() == "track") {
                                      oTable = oControllerS1.getView().byId("idTrackFilesTable");
                                      oTab = "/FILE_TRACK_ES?$filter=CaseType eq '"+oControllerS1.objectType+"'";
                               }
                               if (oTab != null && oTable != null) {
                                      oTable.setBusy(true);
                                      oTable.removeSelections();
                                      var oTabModel = new sap.ui.model.json.JSONModel();
                                      // success
                                      oTabModel.attachRequestCompleted(oEvent, function(
                                                   oEvent) {
                                            
                                             oTabModel.detachRequestCompleted();
                                             oTabModel.detachRequestFailed();
                                            if (oTabModel.oData.d != undefined) {
                                                   oModel = oTable.getModel("files");
                                                   
                                                   oModel.setData(oTabModel.oData.d);
                                                   
//                                                   sap.m.MessageToast.show(oControllerS1.getView()
//                                                                 .getModel("i18n").getObject(
//                                                                              "DATAREFRESHED"));
                                            }
                                            oTable.setBusy(false);
                                      });
                                      // Failure
                                      oTabModel.attachRequestFailed(oControllerS1,
                                                   function(oEvent) {
                                                          oTabModel.detachRequestCompleted();
                                                          oTabModel.detachRequestFailed();
//                                                          sap.m.MessageBox.alert(oControllerS1.getView()
//                                                                       .getModel("i18n").getObject(
//                                                                                    "DATAREFRESHFAILED"));
                                                          oTable.setBusy(false);
                                                   }, oControllerS1);
                                      oTabModel.loadData(serviceUrl + oTab, null, true);

                               } else {
//                                      sap.m.MessageBox.alert(oControllerS1.getView().getModel(
//                                                   "i18n").getObject("DATAREFRESHFAILED"));
                               }

                        
       this.oRouter.navTo("fullscreen");

      }
     },

     onFileAttachCloseButton : function(oEvent) {
      this.detailsPopup.close();
     },

     onLinkPress : function(oEvent) {

      oControllerS2.customBusyDialogOpen();
      var temp = oEvent.getSource().getParent().getParent()
        .getParent().getParent().getBindingContext(
          "global");
      oControllerS2.documentId = oEvent.getSource().getModel(
        "global").getObject(temp.getPath());

      // if(oControllerS2.documentId<gResponse.length){
      var isAttachment = oControllerS2.documentId.IsAttachment;

      if (isAttachment) {

       oModel = new sap.ui.model.json.JSONModel();
       oModel.loadData(serviceUrl
         + "/FILE_DOC_FI?param_1='AV'&param_2='"
         + oControllerS2.caseguid + "'&param_3='"
         + oControllerS2.fileid + "'&param_4='"
         + encodeURIComponent(oControllerS2.documentId.DocumentName)
         + "'&param_5=''", null, false);

       if(oModel.getData().d.results[0].msg_type=='E'){
        sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
        oControllerS2.customBusyDialogClose();
        return;
       }


       if (oModel.oData.d.results.length > 1) {
        if(!oControllerS2.oVersion){
         oControllerS2.oVersion = sap.ui.xmlfragment(
          "flm.fiori.view.attachmentVersion",
          oControllerS2);
        }
        oControllerS2.oVersion.open();
        sap.ui.getCore().byId("idButtonAddLink")
          .setVisible(false);
        sap.ui.getCore().byId("idCli")
          .setType("Active");
        var oTable = sap.ui.getCore().byId(
          "idVersionsTable");
        oTable.setModel(oModel, "versionModelDetail");
       } else {
        if (oEvent.getSource().getBindingContext(
          "global").getObject().IsAttachment) {
         var v = 1;
         oModel = new sap.ui.model.json.JSONModel();
         // success
         oModel
           .attachRequestCompleted(
             this,
             function(oEvent) {
              oModel
                .detachRequestCompleted();
              if (oModel.getData().d.results[0].msg_type != "E") {
               if (oModel
                 .getData().d.results[0].Url != "") {
                window
                  .open(oModel
                    .getData().d.results[0].Url);
               }
              } else {
               sap.m.MessageToast
                 .show(oModel
                   .getData().d.results[0].msg_text);
              }

              oControllerS2
                .customBusyDialogClose();

             }, this);
         // Failure
         oModel.attachRequestFailed(this, function(
           oEvent) {

          oControllerS2.customBusyDialogClose();
          oModel.detachRequestCompleted();
          oModel.detachRequestFailed();
         }, this);
         oModel
           .loadData(
             serviceUrl
               + "/FILE_DOC_FI?param_1='AU'&param_2='"
               + v
               + "'&param_3='"
               + oControllerS2.documentId.AttachmentLoioID
               + "'&param_4='"
               + oControllerS2.documentId.DocumentClass
               + "'&param_5=''",
             null, false);
         // var url = oModel.oData.d.results[0].Url;
         // window.open(url);
         // oControllerS2.customBusyDialogClose();
        }
       }

      } else if (oControllerS2.documentId.IsFile) {


       if (oEvent.getSource().getBindingContext("global")
         .getObject().CaseGuid != oControllerS2.caseguid) {

        // check for authorization to display the file
        var authModel = new sap.ui.model.json.JSONModel();
        authModel
          .loadData(
            serviceUrl
              + "/FILES_FI?param_1='OA'&param_2='"
              + oEvent
                .getSource()
                .getBindingContext(
                  "global")
                .getObject().CaseGuid
              + "'&param_3=''&param_4='"+ oControllerS2.caseguid +"'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
            null, false);

        if (authModel.getData().d.results.length == 0) {
         oControllerS2.navBackArr.push({
          caseguid : oControllerS2.caseguid,
          fileid : oControllerS2.fileid,
          wiId : oControllerS2.wiId,
          fromTab : oControllerS2.fromTab,
         });
         oControllerS2.fromSamePath = true;
         oControllerS2.fromTab = "DOCUMENT";
         oControllerS2.customBusyDialogOpen();
         oControllerS2.oRouter.navTo("subscreen", {
          caseguid : oEvent.getSource()
            .getBindingContext("global")
            .getObject().CaseGuid,
          fileid : oEvent.getSource()
            .getBindingContext("global")
            .getObject().FileID,
          wiId : "0"
         });

        } else if (authModel.getData().d.results[0].msg_type == "E") {
         sap.m.MessageBox
           .alert(authModel.getData().d.results[0].msg_text);
         oControllerS2.customBusyDialogClose();
         return;
        }
       }

      } else if (oControllerS2.documentId.IsIpi) {
       /*if (oEvent.getSource().getBindingContext(
       "global").getObject().IsAttachment) {
      var v = 1;*/
      oModel = new sap.ui.model.json.JSONModel();
      // success
      oModel
        .attachRequestCompleted(
          this,
          function(oEvent) {
           oModel
             .detachRequestCompleted();
           if (oModel.getData().d.results[0].msg_type != "E") {
            if (oModel
              .getData().d.results[0].Url != "") {
             window
               .open(oModel
                 .getData().d.results[0].Url);
            }
           } else {
            sap.m.MessageToast
              .show(oModel
                .getData().d.results[0].msg_text);
           }

           oControllerS2
             .customBusyDialogClose();

          }, this);
      // Failure
      oModel.attachRequestFailed(this, function(
        oEvent) {

       oControllerS2.customBusyDialogClose();
       oModel.detachRequestCompleted();
       oModel.detachRequestFailed();
      }, this);
      oModel
        .loadData(
          serviceUrl
            + "/FILE_DOC_FI?param_1='DU'&param_2='"
            + encodeURIComponent(oControllerS2.documentId.DocumentName)
            + "'&param_3=''&param_4=''&param_5=''",
          null, false);
      // var url = oModel.oData.d.results[0].Url;
      // window.open(url);
      // oControllerS2.customBusyDialogClose();
     //}
      }else if (oControllerS2.documentId.IsDaak) {
       if (oEvent.getSource().getBindingContext("global")
        .getObject().CaseGuid != oControllerS2.caseguid) {

       // check for authorization to display the file
       var authModel = new sap.ui.model.json.JSONModel();
       authModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='OA'&param_2='"
             + oEvent
               .getSource()
               .getBindingContext(
                 "global")
               .getObject().CaseGuid
             + "'&param_3=''&param_4='"+ oControllerS2.caseguid +"'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
           null, false);

       if (authModel.getData().d.results.length == 0) {
        oControllerS2.navBackArr.push({
         caseguid : oControllerS2.caseguid,
         fileid : oControllerS2.fileid,
         wiId : oControllerS2.wiId,
         fromTab : oControllerS2.fromTab,
        });
        oControllerS2.fromSamePath = true;
        oControllerS2.fromTab = "DOCUMENT";
        oControllerS2.customBusyDialogOpen();
        destroyDialogs(oControllerS2);
        oControllerS2.oRouter.navTo("daakdocscreen", {
         caseguid : oEvent.getSource()
           .getBindingContext("global")
           .getObject().CaseGuid,
        });
        }
       }
      }else {
         oModel = new sap.ui.model.json.JSONModel();
       // success
       oModel
         .attachRequestCompleted(
           this,
           function(oEvent) {
            oModel.detachRequestCompleted();
            if (oModel.getData().d.results[0].msg_type != "E") {
             if (oModel.getData().d.results[0].Url != "") {
              window
                .open(oModel
                  .getData().d.results[0].Url);
             }
            } else {
             sap.m.MessageBox.alert(oModel
                 .getData().d.results[0].msg_text);
            }

            oControllerS2
              .customBusyDialogClose();

           }, this);

       if (oControllerS2.documentId.IsObject) {

        oModel.loadData(serviceUrl
          + "/FILE_DOC_FI?param_1='OB'&param_2='"
          + oControllerS2.documentId.BorID
          + "'&param_3='"
          + oControllerS2.documentId.ElementType
          + "'&param_4='"
          + oControllerS2.documentId.BorType
          + "'&param_5=''", null, true);

       } else if (oControllerS2.documentId.IsReport) {

        oModel
          .loadData(
            serviceUrl
              + "/FILE_DOC_FI?param_1='OR'&param_2='"
              + oControllerS2.documentId.Variant
              + "'&param_3='"
              + oControllerS2.documentId.ElementType
              + "'&param_4=''&param_5=''",
            null, true);
       }

      }

     },

     downloadAttachment : function(oEvent) {

      oControllerS2.customBusyDialogOpen();

      var v = 1;
      oModel = new sap.ui.model.json.JSONModel();
//      var hyperText = null;
//      var temp = true;
//
//      // check if it is from version dialog
//      try {
//       var temp2 = oEvent.getSource().getCells();
//      } catch (err) {
//       temp = false;
//      }

//      if (temp) {
       v = oEvent.getSource().getCells()[0].getText();
       oControllerS2.customBusyDialogOpen();
       oModel.loadData(serviceUrl
         + "/FILE_DOC_FI?param_1='AU'&param_2='" + v
         + "'&param_3='"
         + oControllerS2.documentId.AttachmentLoioID
         + "'&param_4='"
         + oControllerS2.documentId.DocumentClass
         + "'&param_5=''", null, false);
//      } 
       if(oModel.getData().d.results[0].msg_type=='E'){
        sap.m.MessageBox.alert(oModel.getData().d.results[0].msg_text);
        oControllerS2.customBusyDialogClose();
        return;
        }

      var url = oModel.oData.d.results[0].Url;

      window.open(url);// window.open(url);
      oControllerS2.customBusyDialogClose();
     },

     onDialogCloseButton : function(oEvent) {
      this.customBusyDialogClose();
      if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
       oEvent.getSource().getParent().close();
      } else {
       oEvent.getSource().getParent().getParent().close();
      }

     },


     onDialogCloseButtonF4 : function(oEvent) {
      this.customBusyDialogClose();
      if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
       oEvent.getSource().getParent().close();
      } else {
       oEvent.getSource().getParent().getParent().close();
      }

     },

     onVersionDialogCloseAction : function(oEvent) {

      sap.ui.getCore().byId("idCli").destroy();
      oEvent.getSource().getParent().getParent()
        .destroyContent();
      if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
       oEvent.getSource().getParent().close();
      } else {
       oEvent.getSource().getParent().getParent().close();
      }
      oControllerS2.customBusyDialogClose();
     },

     addHyperlinkClick : function(oEvent) {

      var temp = oEvent.getSource().getParent().getParent()
        .getParent().getParent().getBindingContext(
          "global");
      oControllerS2.documentId = oEvent.getSource().getModel(
        "global").getObject(temp.getPath());

      if (oEvent.getSource().getBindingContext("global")
        .getObject().IsAttachment) {
       // if attachment then check for versions
       oControllerS2.customBusyDialogOpen();
       oModel = new sap.ui.model.json.JSONModel();
       // oModel.attachRequestCompleted(
       // oEvent,
       // function(evt) {
       // oModel.detachRequestCompleted();
       // if (oModel.oData.d.results.length > 1) {
       // if(!oControllerS2.oVersion){
       // oControllerS2.oVersion = sap.ui.xmlfragment(
       // "flm.fiori.view.attachmentVersion",
       // oControllerS2);
       // }
       // oControllerS2.oVersion.open();
       // sap.ui.getCore().byId("idButtonAddLink")
       // .setVisible(true);
       // sap.ui.getCore().byId("idCli").setType(
       // "Inactive");
       // var oTable = sap.ui.getCore().byId(
       // "idVersionsTable");
       // oTable.setModel(oModel, "versionModelDetail");
       // } else {
       // oControllerS2.attachHyperlink(oEvent);
       // }
       // }, oControllerS2);
       // oModel.attachRequestFailed(
       // oControllerS2,
       // function(oEvent) {
       // oModel.detachRequestFailed();
       // oControllerS2.customBusyDialogClose();
       // }, oControllerS2);

       oControllerS2.customBusyDialogOpen();
       oModel.loadData(serviceUrl
         + "/FILE_DOC_FI?param_1='AV'&param_2='"
         + oControllerS2.caseguid + "'&param_3='"
         + oControllerS2.fileid + "'&param_4='"
         + encodeURIComponent(oControllerS2.documentId.DocumentName)
         + "'&param_5=''", null, false);

       if (oModel.oData.d.results.length > 1) {
        if(!oControllerS2.oVersion){
        oControllerS2.oVersion = sap.ui.xmlfragment(
          "flm.fiori.view.attachmentVersion",
          oControllerS2);
        }
        oControllerS2.oVersion.open();
        sap.ui.getCore().byId("idButtonAddLink")
          .setVisible(true);
        sap.ui.getCore().byId("idCli").setType(
          "Inactive");
        var oTable = sap.ui.getCore().byId(
          "idVersionsTable");
        oTable.setModel(oModel, "versionModelDetail");
       } else {
        oControllerS2.customBusyDialogOpen();
        oControllerS2.attachHyperlink(oEvent);
       }

      } else {
       // directly add the hyperlink
       oControllerS2.customBusyDialogOpen();
       oControllerS2.attachHyperlink(oEvent);
      }

      // oControllerS2.customBusyDialogClose();
     },

     attachHyperlink : function(oEvent) {

      var v = 1;
      oModel = new sap.ui.model.json.JSONModel();
      var hyperText = null;
      var temp = true;

      try {
       var temp2 = oEvent.getSource().getParent()
         .getCells();
      } catch (err) {
       temp = false;
      }

      // success
      oModel.attachRequestCompleted(this, function(oEvent) {
       oModel.detachRequestCompleted();
       hyperText = oControllerS2.documentId.DocumentName;

       var e = oControllerS2.getView().byId(
         "commenteditor");

       var link=oModel.oData.d.results[0].Url;
                            link=link.split('?');
                            if(link[0].indexOf("ContentServer.dll")!=-1){
                             if(link[1]){
                                    link[1]=link[1].replace(/\(/g,"%28");
                                    link[1]=link[1].replace(/\)/g,"%29");
                                    link=link[0]+"?"+link[1];
                                    }
                                    else{
                                     link=link[0];
                                    }
                            }
                            else if(link[0].indexOf("sap/bc/gui/sap/its")!=-1){
                             if(link[1]){
                                    link[1]=link[1].replace(/\=/g,"%3D");
                                    link[1]=link[1].replace(/\=/g,"%3D");
                                    link=link[0]+"?"+link[1];
                                    }
                                    else{
                                     link=link[0];
                                    } 
                            }
                            e.setValue(e.getValue() +" "+ "<p><a href='"
                                    + link
                                    + "' target='_blank'>" + hyperText + "</a></p>");
       e.reinitialize();
       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_31"));

       // if (temp) {
       // oControllerS2.customBusyDialogClose();
       // }
       oControllerS2.customBusyDialogClose();

      }, this);

      oControllerS2.customBusyDialogOpen();
      if (temp) {
       v = oEvent.getSource().getParent().getCells()[0]
         .getText();
       oModel.loadData(serviceUrl
         + "/FILE_DOC_FI?param_1='AU'&param_2='" + v
         + "'&param_3='"
         + oControllerS2.documentId.AttachmentLoioID
         + "'&param_4='"
         + oControllerS2.documentId.DocumentClass
         + "'&param_5=''", null, true);
      } else {
       if (oEvent.getSource().getBindingContext("global")
         .getObject().IsAttachment) {
        oModel
          .loadData(
            serviceUrl
              + "/FILE_DOC_FI?param_1='AU'&param_2='"
              + v
              + "'&param_3='"
              + oControllerS2.documentId.AttachmentLoioID
              + "'&param_4='"
              + oControllerS2.documentId.DocumentClass
              + "'&param_5=''", null,
            true);
       } else if (oControllerS2.documentId.IsObject) {

        oModel.loadData(serviceUrl
          + "/FILE_DOC_FI?param_1='OB'&param_2='"
          + oControllerS2.documentId.BorID
          + "'&param_3='"
          + oControllerS2.documentId.ElementType
          + "'&param_4='"
          + oControllerS2.documentId.BorType
          + "'&param_5=''", null, true);

       } else if (oControllerS2.documentId.IsReport) {

        oModel
          .loadData(
            serviceUrl
              + "/FILE_DOC_FI?param_1='OR'&param_2='"
              + oControllerS2.documentId.Variant
              + "'&param_3='"
              + oControllerS2.documentId.ElementType
              + "'&param_4=''&param_5=''",
            null, true);
       }else if (oControllerS2.documentId.IsIpi) {

        oModel
          .loadData(
            serviceUrl
              + "/FILE_DOC_FI?param_1='DU'&param_2='"
              + encodeURIComponent(oControllerS2.documentId.DocumentName)
              + "'&param_3=''&param_4=''&param_5=''",
            null, true);
       }
      }

     },

     confirmDelete : function(evt) {

      var oItem = evt.getSource();
      if (oItem.getBindingContext("global").getObject().DeleteEnabledRef
        && oItem.getBindingContext("global")
          .getObject().NotingEnabledRef) {
       sap.m.MessageBox
         .confirm(
           oControllerS2.getView().getModel("i18n").getObject("MESSAGE_32"),
           function(response) {
            if (response == "OK") {
             oControllerS2
               .deleteAttachment(
                 evt, oItem);
            } else {
             return;
            }
           });
      } else {

       sap.m.MessageBox.confirm(
         oControllerS2.getView().getModel("i18n").getObject("MESSAGE_33"),
         function(response) {
          if (response == "OK") {
           oControllerS2.deleteAttachment(evt,
             oItem);
          } else {
           return;
          }
         });
       // oControllerS2.deleteAttachment(evt,oItem);
      }
     },

     deleteAttachment : function(oEvent, oItem) {

      oControllerS2.customBusyDialogOpen();

      // var temp = oEvent.getSource()
      // .getParent().getParent().getParent()
      // .getParent().getBindingContext("global");

      var temp = oItem.getBindingContext("global");
      oControllerS2.documentId = oItem.getModel("global")
        .getObject(temp.getPath());

      oModel = new sap.ui.model.json.JSONModel();
      oModel
        .attachRequestCompleted(
          oEvent,
          function(oEvent) {

           oModel.detachRequestCompleted();
           var err = oModel.oData.d.results[0];
           if (err != undefined
             && err.msg_type == 'E') {
            sap.m.MessageBox
              .alert(err.msg_text);
            // sap.m.MessageToast.show(err.msg_text);
           } else {

            var deleteNode = oItem
              .getParent()
              .getParent()
              .getParent()
              .getParent()
              .getParent().getId();
            // oEvent.getSource().getParent().getParent().getParent().destroy();
            for (var i = 0; i < oControllerS2
              .getView().getModel(
                "global")
              .getData().documents.length; i++) {
             if (oItem
               .getBindingContext(
                 "global")
               .getProperty(
                 "DocumentName") == oControllerS2
               .getView()
               .getModel("global")
               .getData().documents[i].DocumentName) {
              oControllerS2
                .getView()
                .getModel(
                  "global")
                .getData().documents
                .splice(i, 1);
              break;
             }
            }
            oControllerS2.getView()
              .getModel("global")
              .refresh();
            var heading = sap.ui.getCore()
              .byId(deleteNode)
              .getTitle().getText();
            var subHead1 = heading
              .substring(
                0,
                heading
                  .lastIndexOf("("));
            var subHead2 = heading
              .substring(
                heading
                  .lastIndexOf("(") + 1,
                heading
                  .lastIndexOf(")"));
            sap.ui
              .getCore()
              .byId(deleteNode)
              .getTitle()
              .setText(
                subHead1
                  + " ("
                  + (--subHead2)
                  + ")");

            sap.m.MessageToast
              .show(this.getView().getModel("i18n").getObject("MESSAGE_34"));
           }

           oControllerS2
             .customBusyDialogClose();

          }, oControllerS2);
      // if(oControllerS2.documentId<gResponse.length){
      if (oControllerS2.documentId.IsAttachment) {
       oModel.loadData(serviceUrl
         + "/FILE_DOC_FI?param_1='DA'&param_2='"
         + oControllerS2.caseguid + "'&param_3='"
         + encodeURIComponent(oControllerS2.documentId.DocumentName)
         + "'&param_4='"
         + oControllerS2.documentId.DocumentType
         + "'&param_5=''", null, true);
      } else if (oControllerS2.documentId.IsFile
        || oControllerS2.documentId.IsObject
        || oControllerS2.documentId.IsReport) {
       oModel.loadData(serviceUrl
         + "/FILE_DOC_FI?param_1='DO'&param_2='"
         + oControllerS2.caseguid + "'&param_3='"
         + encodeURIComponent(oControllerS2.documentId.DocumentName)
         + "'&param_4='"
         + oControllerS2.documentId.CaseGuid
         + "'&param_5='" + oControllerS2.wiId + "'",
         null, true);
      }else if (oControllerS2.documentId.IsIpi) {
       oModel.loadData(serviceUrl
         + "/FILE_DOC_FI?param_1='DD'&param_2='"
         + oControllerS2.caseguid + "'&param_3='"
         + encodeURIComponent(oControllerS2.documentId.DocumentName)
         + "'&param_4='"
         + oControllerS2.wiId
         + "'&param_5=''",
         null, true);
      }

     },

     uploadActionsOpen : function(oEvent) {


      var oButton = oEvent.getSource();
      oControllerS2.uploadNode = this.getParent();
      if (!oControllerS2._uploadActionSheet || oControllerS2._uploadActionSheet.getButtons().length == 0) {
       oControllerS2._uploadActionSheet = sap.ui
         .xmlfragment("flm.fiori.view.uploadButton",
           oControllerS2);
       oControllerS2.getView().addDependent(
         oControllerS2._uploadActionSheet);
       // oControllerS2._uploadActionSheet.setModel(
       // oControllerS2.getView().getModel(global),
       // "global");
      }
      jQuery.sap.delayedCall(0, this, function() {
       oControllerS2._uploadActionSheet.openBy(oButton);
      });
     },

     attachmentButtonPressed : function(oEvent) {
      oControllerS2.isAttachment = true;
      oControllerS2.isFile = false;
      oControllerS2.isReport = false;
      oControllerS2.isObject = false;
      oControllerS2.isIPI = false;
      //this.attachmentDialog = null;
      if (!oControllerS2.attachmentDialog) {
       oControllerS2.attachmentDialog = sap.ui.xmlfragment(
        "flm.fiori.view.attachment", oControllerS2);
      }
      sap.ui.getCore().byId("idDocNumber").setValue("");
      sap.ui.getCore().byId("idFileUpload").setValue("");
      sap.ui.getCore().byId("idKey1").setValue("");
      sap.ui.getCore().byId("idKey2").setValue("");
      sap.ui.getCore().byId("idKey3").setValue("");
      sap.ui.getCore().byId("idKey4").setValue("");
      sap.ui.getCore().byId("idKey5").setValue("");
      var docType = sap.ui.getCore().byId("idDocumentType");
      var ddModel = new sap.ui.model.json.JSONModel();
      ddModel
        .loadData(serviceUrl
          + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and OtherF4 eq true and ID eq 'DT'");
      docType.setModel(ddModel);

      oControllerS2.attachmentDialog.open();
     },

     fileButtonPressed : function(oEvent) {
      oControllerS2.isAttachment = false;
      oControllerS2.isFile = true;
      oControllerS2.isReport = false;
      oControllerS2.isObject = false;
      oControllerS2.isIPI = false;
      if (!oControllerS2.fileDialog) {
       oControllerS2.fileDialog = sap.ui.xmlfragment(
         "flm.fiori.view.file", oControllerS2);
      }
      sap.ui.getCore().byId("idFileNumber").setValue("");
      oControllerS2.fileDialog.open();
     },

     attachNewVersion : function(oEvent) {

      if(!oControllerS2.versionDialog) {
       oControllerS2.versionDialog = sap.ui.xmlfragment(
         "flm.fiori.view.newVersion", oControllerS2);
      }
      sap.ui.getCore().byId("idFileUploaderNV").setValue("");
      sap.ui.getCore().byId("idKey1NV").setValue("");
      sap.ui.getCore().byId("idKey2NV").setValue("");
      sap.ui.getCore().byId("idKey3NV").setValue("");
      sap.ui.getCore().byId("idKey4NV").setValue("");
      sap.ui.getCore().byId("idKey5NV").setValue("");
      oControllerS2.documentId = oEvent.getSource()
        .getParent().getParent().getParent()
        .getParent().getBindingContext("global");

      oModel = new sap.ui.model.json.JSONModel();

      // success
      oModel.attachRequestCompleted(this, function(oEvent) {
       oModel.detachRequestCompleted();
       var keys = oModel.oData.d.results[0];
       sap.ui.getCore().byId("idKey1NV").setValue(
         keys.Keyword1);
       sap.ui.getCore().byId("idKey2NV").setValue(
         keys.Keyword2);
       sap.ui.getCore().byId("idKey3NV").setValue(
         keys.Keyword3);
       sap.ui.getCore().byId("idKey4NV").setValue(
         keys.Keyword4);
       sap.ui.getCore().byId("idKey5NV").setValue(
         keys.Keyword5);
       oControllerS2.customBusyDialogClose();
       oControllerS2.versionDialog.open();

      }, oControllerS2);

      // if(oControllerS2.documentId<gResponse.length){
      oControllerS2.customBusyDialogOpen();
      oModel.loadData(serviceUrl
        + "/FILE_DOC_FI?param_1='NV'&param_2='"
        + oControllerS2.caseguid
        + "'&param_3='"
        + encodeURIComponent(oControllerS2.documentId
          .getProperty("DocumentName"))
        + "'&param_4=''&param_5=''", null, true);

     },


     onCloseButton : function(oEvent) {
      if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
       oEvent.getSource().getParent().close();
      } else {
       oEvent.getSource().getParent().getParent().close();
      }

     },

     onOkButton : function(oEvent) {

      var i = 0, doc_num, flag = false;
      if (oControllerS2.isFile) {
       doc_num = sap.ui.getCore().byId("idFileNumber");
      } else if (oControllerS2.isAttachment) {
       doc_num = sap.ui.getCore().byId("idDocNumber");
      }else if (oControllerS2.isObject) {
       doc_num = sap.ui.getCore().byId("docNumberId");
      } 

      for (i = 0; i < oControllerS2.getView().getModel(
        "global").getData().documents.length; i++) {
       // if(!isFile && (gResponse[i].IsAttachment ||
       // gResponse[i].IsObject || gResponse[i].IsReport)){
       if (doc_num.getValue() == oControllerS2.getView()
         .getModel("global").getData().documents[i].DocumentName) {
        sap.m.MessageToast
          .show(this.getView().getModel("i18n").getObject("MESSAGE_35"));
        flag = true;
        break;
       }
       // }
      }

      if (oControllerS2.isAttachment && !flag) {
       var doc_num = sap.ui.getCore().byId("idDocNumber")
         .getValue();
       var doc_type = sap.ui.getCore().byId(
         "idDocumentType").getSelectedItem()
         .getKey();
       var oFUploader = sap.ui.getCore().byId(
         "idFileUpload");
       oFUploader.setUploadUrl("/sap/bc/doc_upload");
//        oFUploader.setUploadUrl("proxy/https/ldcixka.wdf.sap.corp:44318/sap/bc/doc_upload"); 
        if (doc_num.match(/\s/g)){
         sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_72"));
         return;
        }
       if (oFUploader.getValue() == "" || doc_num == ""
         || doc_type == "") {
        sap.m.MessageToast
          .show(this.getView().getModel("i18n").getObject("MESSAGE_36"));
       } else if (doc_num.length > 60) {
        sap.m.MessageToast
          .show(this.getView().getModel("i18n").getObject("MESSAGE_37"));
        return;
       } 
       else {
        var par_id = oControllerS2.uploadNode
          .getBindingContext("global")
          .getProperty("RowKey"); // PARENTKEY
        var wf_id = oControllerS2.wiId; // WIID
        var key_1 = sap.ui.getCore().byId("idKey1")
          .getValue();
        var key_2 = sap.ui.getCore().byId("idKey2")
          .getValue();
        var key_3 = sap.ui.getCore().byId("idKey3")
          .getValue();
        var key_4 = sap.ui.getCore().byId("idKey4")
          .getValue();
        var key_5 = sap.ui.getCore().byId("idKey5")
          .getValue();
        var sInfo = '[{"CASE_GUID":"'
          + oControllerS2.caseguid
          + '","PAR_ID":"' + par_id
          + '","WF_ID":"' + wf_id
          + '","DOC_NUM":"' + doc_num
          + '","DOC_TYPE":"' + doc_type
          + '","KEY_1":"' + key_1 + '","KEY_2":"'
          + key_2 + '","KEY_3":"' + key_3
          + '","KEY_4":"' + key_4 + '","KEY_5":"'
          + key_5 + '"}]';
        sap.ui.getCore().byId("idAttachmentDialog").close();
        oFUploader.setAdditionalData(sInfo);
        oControllerS2.customBusyDialogOpen();
        oFUploader.attachUploadComplete(oControllerS2,
          function(oEvent) {
           oControllerS2
             .customBusyDialogClose();
          }, oControllerS2);
        oFUploader.upload();
       }
      } else if (oControllerS2.isFile && !flag) {
       var today = new Date();
       var file_name = sap.ui.getCore().byId(
         "idFileNumber").getValue();
       if (file_name == "") {
        sap.m.MessageBox
        .alert(this.getView().getModel("i18n").getObject("MESSAGE_36"));
        return;
       }
       if (this.getView().byId("fileHeader").getTitle() == file_name) {
        sap.m.MessageBox
          .alert(this.getView().getModel("i18n").getObject("MESSAGE_44"));
        return;
       }else {

        oModel = new sap.ui.model.json.JSONModel();
        oModel
          .attachRequestCompleted(
            oEvent,
            function(oEvt) {
             oModel
               .detachRequestCompleted();
             var fileUploadResponse = oModel.oData.d.results[0];
             if (fileUploadResponse.msg_type != "E") {
              var doc_num = file_name;

              var vData = {
               "CaseGuid" : fileUploadResponse.CaseGuid,
               "Wiid" : fileUploadResponse.Wiid,
               "FileID" : fileUploadResponse.FileID,
               "DocumentName" : decodeURIComponent(doc_num),
               "DocumentType" : "FIL",
               "FileName" : "File",
               "CreatedByName" : fileUploadResponse.CreatedByName,
               "CreatedOn" : fileUploadResponse.CreatedOn,
               "FileTitle" : fileUploadResponse.FileTitle,//decodeURIComponent(fileUploadResponse.FileTitle),
               "FileSizeDescr" : fileUploadResponse.FileSize,
               "DocumentClass" : fileUploadResponse.DocClass,
               "AttachmentLoioID" : fileUploadResponse.DocGuid,
               "ParentKey" : oControllerS2.uploadNode
                 .getBindingContext(
                   "global")
                 .getProperty(
                   "RowKey"),
               "IsAttachment" : oControllerS2.isAttachment,
               "IsFile" : oControllerS2.isFile,
               "IsObject" : oControllerS2.isObject,
               "IsIpi" : oControllerS2.isIpi,
               "IsReport" : oControllerS2.isReport,
               "DeleteEnabledRef" : true,
               "NotingEnabledRef" : false,
              };

              oControllerS2.data.documents
                .push(vData);
              oControllerS2
                .getView()
                .getModel(
                  "global")
                .checkUpdate();
              sap.m.MessageToast
                .show(this.getView().getModel("i18n").getObject("MESSAGE_38"));
              sap.ui.getCore().byId(
                "idFileDialog")
                .close();
              var heading = oControllerS2.uploadNode
                .getTitle()
                .getText();
              var subHead1 = heading
                .substring(
                  0,
                  heading
                    .lastIndexOf("("));
              var subHead2 = heading
                .substring(
                  heading
                    .lastIndexOf("(") + 1,
                  heading
                    .lastIndexOf(")"));
              oControllerS2.uploadNode
                .getTitle()
                .setText(
                  subHead1
                    + " ("
                    + (++subHead2)
                    + ")");
             } else {
              sap.m.MessageBox
                .alert(fileUploadResponse.msg_text);
             }
             oControllerS2
               .customBusyDialogClose();

            }, oControllerS2);
        oControllerS2.customBusyDialogOpen();
        oModel.loadData(serviceUrl
          + "/FILE_DOC_FI?param_1='AF'&param_2='"
          + oControllerS2.caseguid
          + "'&param_3='"
          + encodeURIComponent(file_name)
          + "'&param_4='"
          + oControllerS2.wiId
          + "'&param_5='"
          + oControllerS2.uploadNode
            .getBindingContext("global")
            .getProperty("RowKey") + "'",
          null, true);

       }
      }
     },

     onUploadComplete : function(oEvent) {

      var today = new Date();
      var sResponse = oEvent.getParameter("response");
      var resToken = sResponse.split(',');
      var fileAttr = new Array();
      var nameVal, statusMsg = "", statusIcon = null;
      for (var i = 0; i < resToken.length; ++i) {
       nameVal = resToken[i].split('::');
       fileAttr[nameVal[0]] = nameVal[1];
      }
      if (fileAttr["Status"] == "Successful") {
       var doc_num = sap.ui.getCore().byId("idDocNumber")
         .getValue();
       var doc_type = sap.ui.getCore().byId(
         "idDocumentType").getSelectedItem();
       var vData = {
        "DocumentName" : doc_num,
        "DocumentType" : doc_type.getKey(),
        "FileName" : doc_type.getText(),
        "CreatedByName" : fileAttr["UploadedBy"],
        "CreatedOn" : fileAttr["CreatedOn"]/*today.toLocaleDateString()
          .replace("/", ".").replace("/", ".")
          + " "
          + today.toTimeString().substr(0, 8)*/,
        "FileTitle" : fileAttr["AttachmentName"],
        "FileSizeDescr" : fileAttr["FileSize"],
        "DocumentClass" : fileAttr["DocClass"],
        "AttachmentLoioID" : fileAttr["DocGuid"],
        "ParentKey" : oControllerS2.uploadNode
          .getBindingContext("global")
          .getProperty("RowKey"),
        "IsAttachment" : oControllerS2.isAttachment,
        "IsFile" : oControllerS2.isFile,
        "IsObject" : oControllerS2.isObject,
        "IsIpi" : oControllerS2.isIpi,
        "IsReport" : oControllerS2.isReport,
        "DeleteEnabledRef" : true,
        "NotingEnabledRef" : true,
       };

       oControllerS2.getView().getModel("global")
         .getData().documents.push(vData);
       oControllerS2.getView().getModel("global")
         .refresh();
       sap.m.MessageToast
         .show(this.getView().getModel("i18n").getObject("MESSAGE_38"));
       sap.ui.getCore().byId("idAttachmentDialog")
         .close();
       var heading = oControllerS2.uploadNode.getTitle()
         .getText();
       var subHead1 = heading.substring(0, heading
         .lastIndexOf("("));
       var subHead2 = heading.substring(heading
         .lastIndexOf("(") + 1, heading
         .lastIndexOf(")"));
       oControllerS2.uploadNode.getTitle().setText(
         subHead1 + " (" + (++subHead2) + ")");

      } else {
       sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_39"));
       // sap.m.MessageToast.show("Error Uploading File");
      }
      oControllerS2.customBusyDialogClose();
     },

     onNVOkButton : function(oEvent) {

      oControllerS2.customBusyDialogOpen();
      oControllerS2.versionDialog.close();
      // oEvent.getSource().getParent().getParent().close();
      var i = 0;
      var doc_num, doc_type, doc_class, doc_guid;
      doc_num = oControllerS2.documentId
        .getProperty("DocumentName");
      doc_type = oControllerS2.documentId
        .getProperty("DocumentType");
      doc_class = oControllerS2.documentId
        .getProperty("DocumentClass");
      doc_guid = oControllerS2.documentId
        .getProperty("AttachmentLoioID");
      var oFUploader = sap.ui.getCore().byId(
        "idFileUploaderNV");
      if (oFUploader.getValue() == "") {
       sap.m.MessageBox.alert(this.getView().getModel("i18n").getObject("MESSAGE_36"));
       return;
     } 
      oFUploader.setUploadUrl("/sap/bc/doc_upload");
//       oFUploader.setUploadUrl("proxy/https/ldcixka.wdf.sap.corp:44318/sap/bc/doc_upload");

      var par_id = oControllerS2.uploadNode; // PARENTKEY
      var wf_id = oControllerS2.wiId; // WIID
      var key_1 = sap.ui.getCore().byId("idKey1NV")
        .getValue();
      var key_2 = sap.ui.getCore().byId("idKey2NV")
        .getValue();
      var key_3 = sap.ui.getCore().byId("idKey3NV")
        .getValue();
      var key_4 = sap.ui.getCore().byId("idKey4NV")
        .getValue();
      var key_5 = sap.ui.getCore().byId("idKey5NV")
        .getValue();
      var sInfo = '[{"CASE_GUID":"' + oControllerS2.caseguid
        + '","PAR_ID":"' + par_id + '","WF_ID":"'
        + wf_id + '","DOC_CLASS":"' + doc_class
        + '","DOC_GUID":"' + doc_guid + '","DOC_NUM":"'
        + doc_num + '","DOC_TYPE":"' + doc_type
        + '","KEY_1":"' + key_1 + '","KEY_2":"' + key_2
        + '","KEY_3":"' + key_3 + '","KEY_4":"' + key_4
        + '","KEY_5":"' + key_5 + '"}]';

      oFUploader.setAdditionalData(sInfo);
      oFUploader.attachUploadComplete(oControllerS2,
        function(oEvent) {
         oControllerS2.customBusyDialogClose();
        }, oControllerS2);
      oFUploader.upload();
      // oControllerS2.customBusyDialogClose();
     },

     onUploadCompleteNV : function(oEvent) // uploading new
     // version
     {

      oControllerS2.customBusyDialogOpen();
      var sResponse = oEvent.getParameter("response");
      var resToken = sResponse.split(',');
      var fileAttr = new Array();
      var nameVal, statusMsg = "", statusIcon = null;
      for (var i = 0; i < resToken.length; ++i) {
       nameVal = resToken[i].split(':');
       fileAttr[nameVal[0]] = nameVal[1];
      }
      if (fileAttr["Status"] == "Successful") {
       sap.m.MessageToast
         .show(this.getView().getModel("i18n").getObject("MESSAGE_40"));
       oControllerS2.documentId.getObject().DeleteEnabledRef = false;
       oControllerS2.getView().getModel("global")
         .checkUpdate();
       sap.ui.getCore().byId("idNewVersionUpload")
         .close();
      } else {
       sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_41"));
      }
      oControllerS2.customBusyDialogClose();
     },

     onChangeTypeSelection : function(oEvent) {
//       oControllerS2.customBusyDialogOpen("");
      if (!oControllerS2._oDynamicF4Dialog) {
       oControllerS2._oDynamicF4Dialog = sap.ui
         .xmlfragment(
           "flm.fiori.view.dynamicF4popup",
           oControllerS2);

      }
      if (sap.ui.getCore().byId("idUsername") != undefined) {
       sap.ui.getCore().byId("idUsername").setValue("");
      }
      if (sap.ui.getCore().byId("idProcessorName") != undefined) {
       sap.ui.getCore().byId("idProcessorName").setValue("");
      }
      var otypeModel = new sap.ui.model.json.JSONModel();

//      if (oEvent.getSource().getSelectedKey() != 'SPACE') {
//
//       otypeModel.attachRequestCompleted(this, function(
//         oEvent) {
//        otypeModel.detachRequestCompleted();
//        otypeModel.setData(otypeModel.oData.d.results);
//        oControllerS2.customBusyDialogClose();
//       }, this);
//       oControllerS2.customBusyDialogOpen();
//       otypeModel.loadData(serviceUrl
//         + "/FILE_F4_ES?$filter=ID eq '"
//         + oEvent.getSource().getSelectedKey()
//         + "' and WF eq true", null, true);
//      }

      var otextModel = new sap.ui.model.json.JSONModel();
      var otext = {
       title : oEvent.getSource().getSelectedItem()
         .getText(),
       id : "nameInput",
      };
      otextModel.setData(otext);
      oControllerS2._oDynamicF4Dialog.setModel(otextModel,
        "dyntext");
      oControllerS2._oDynamicF4Dialog.setModel(otypeModel);
      oControllerS2.getView().byId("nameInput").setValue("");

     },
     // //For new noting clear data
     printWorkflowAction : function(oEvent) {
      window
        .open(serviceUrl
          + "/FILE_DOC_ES(Guid='"
          + this.caseguid
          + "',DocumentNumber='',DocumentName='',Version='',PhysVersion='')/$value");


     },
     printNotingPrivateAction : function(oEvent) {
      // var str_pdf;

      var oModel = new sap.ui.model.json.JSONModel();
      oModel.loadData(serviceUrl
        + "/FILE_DOC_FI?param_1='PN'&param_2='"
        + this.caseguid + "'&param_3='" + this.fileid
        + "'&param_4='"+this.wiId+"'&param_5=''", null, false);
      if (oModel.getData().d.results[0].FileType == "text/html") {

       var newWindow = window.open("Notings.html",
         "mywin", '');
       try{
       newWindow.document
         .write(decodeURIComponent(oModel.getData().d.results[0].FileContent));
       }catch(err){
        newWindow.document
        .write(oModel.getData().d.results[0].FileContent);
       }

       // .open("data:text/html," +
       // oModel.getData().d.results[0].FileContent);
       // + encodeURIComponent(oModel
       // .getData().d.results[0].FileContent));
      }
     },
     printNotingAction : function(oEvent) {
      // var str_pdf;

      var oModel = new sap.ui.model.json.JSONModel();
      oModel.loadData(serviceUrl
        + "/FILE_DOC_FI?param_1='PY'&param_2='"
        + this.caseguid + "'&param_3='" + this.fileid
        + "'&param_4='"+this.wiId+"'&param_5=''", null, false);
      if (oModel.getData().d.results[0].FileType == "text/html") {
//       window
//         .open("data:text/html,"
//           + encodeURIComponent(oModel
//             .getData().d.results[0].FileContent));
       var newWindow = window.open("Notings.html",
         "mywin", '');
       try{
       newWindow.document
         .write(decodeURIComponent(oModel.getData().d.results[0].FileContent));
       }catch(err){
        newWindow.document
        .write(oModel.getData().d.results[0].FileContent);
       }
      }
     },

     // Move to Intray Action
     moveToIntrayButtonPressed : function(oEvent) {

      var oModel = new sap.ui.model.json.JSONModel();
      oModel
        .attachRequestCompleted(
          oEvent,
          function(oEvent) {

           oModel.detachRequestCompleted();
           var tempModel = this.oRouter
             .getView(
               "flm.fiori.view.S1")
             .byId("idCabinetTable")
             .getModel("files");
           var tempArr = tempModel.oData.results;
           var i = 0, j = -1, file = null;
           while (i < tempArr.length) {
            if (tempArr[i].CaseGuid == oControllerS2.caseguid) {
             j = i;
             break;
            }
            i++;
           }
           if (j != -1) {
            this.oRouter.getView(
              "flm.fiori.view.S1")
              .byId("idCabinetTable")
              .removeSelections();
            file = tempArr.splice(j, 1);
            tempModel.oData.__count--;
            tempModel.checkUpdate();
           }
           if (file != null) {
            var tempModel = this.oRouter
              .getView(
                "flm.fiori.view.S1")
              .byId("idFilesTable")
              .getModel("files");
            var tempArr = tempModel.oData.results;

            file[0].Readmail = "sap-icon://email";
            tempArr.splice(0, 0, file[0]);
            tempModel.oData.__count++;
            tempModel.checkUpdate();
           }
           oControllerS2
             .customBusyDialogClose();
           this.oRouter.getView(
           "flm.fiori.view.S1").byId(
           "moveIntrayAction").setEnabled(
           false);
           this.oRouter.getView(
             "flm.fiori.view.S1").byId(
             "sendAction").setEnabled(
             false);
           this.oRouter.getView(
             "flm.fiori.view.S1").byId(
             "closeAction").setEnabled(
             false);
           this.oRouter.getView(
             "flm.fiori.view.S1").byId(
             "idFilesTable")
             .removeSelections();
           this.oRouter.getView(
           "flm.fiori.view.S1").byId(
           "idCabinetTable")
           .removeSelections();
           destroyDialogs(oControllerS2); //destroy all common fragments
           oControllerS2.oRouter
             .navTo("fullscreen");
           if (oModel.getData().d.results[0].msg_type == "S") {
            sap.m.MessageToast
              .show(oModel.getData().d.results[0].msg_text);
           } else {
            sap.m.MessageToast
              .show(oModel.getData().d.results[0].msg_text);
           }
          }, oControllerS2);

      this.customBusyDialogOpen();
      oModel
        .loadData(
          serviceUrl
            + "/FILES_FI?param_1='MI'&param_2='"
            + this.caseguid
            + "'&param_3='"
            + this.wiId
            + "'&param_4='"
            + this.fileid
            + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
          null, true);
     },

     // //Share File Action
     shareButtonPressed : function(oEvent) {
      //this.openDialog('shareFileAttributes');
      if (!oControllerS2.shareAttrDialog) {
       oControllerS2.shareAttrDialog = sap.ui.xmlfragment(
        "flm.fiori.view.shareFileAttributes", oControllerS2);
      }
      oControllerS2.shareAttrDialog.open();
     },
     shareAttributesCloseAction : function(oEvent) {
      sap.ui.getCore().byId("userValueInput").setValue("");
      sap.ui.getCore().byId("attribute").setState(false);
      sap.ui.getCore().byId("document").setState(false);
      sap.ui.getCore().byId("noting").setState(false);
      sap.ui.getCore().byId("workflow").setState(false);

      //this.closeDialog('shareFileAttributes');

      oControllerS2.shareAttrDialog.close();
     },
     shareAttributesOkAction : function(oEvent) {
      if (sap.ui.getCore().byId("userValueInput").getValue() == "") {
       sap.m.MessageToast
         .show(this.getView().getModel("i18n").getObject("MESSAGE_42"));
       return;
      }

      var value6 = '';
      var value7 = '';
      var value8 = '';
      var value9 = '';
      var value10 = '';
      var noteInput = this.getView().byId("commenteditor")
        .getValue();
      //Changes to be made, replace function import with create_entity
//      noteInput = noteInput.replace(/&nbsp;/g," ");
      if (noteInput != '') {
       value6 = noteInput;
      }

      var inputValue = sap.ui.getCore()
        .byId("userValueInput").getName();

      var docChecked = sap.ui.getCore().byId("document")
        .getState();
      if (docChecked == true) {
       value7 = 'X';
      }
      var attChecked = sap.ui.getCore().byId("attribute")
        .getState();
      if (attChecked == true) {
       value8 = 'X';
      }
      var notChecked = sap.ui.getCore().byId("noting")
        .getState();
      if (notChecked == true) {
       value9 = 'X';
      }
      var wfChecked = sap.ui.getCore().byId("workflow")
        .getState();
      if (wfChecked == true) {
       value10 = 'X';
      }
//      var oModel = new sap.ui.model.json.JSONModel();
      var oModel = this.getView().getModel();
      var newNoting = this.getView().byId("commenteditor")
      .getValue();// oEvent.getSource().getBindingContext().getObject();
      var fiString="SF,"+this.caseguid+","+this.wiId+","+this.fileid+","+inputValue+","+","+value7+","+value8+","+value9+","+value10;
      var newNotingData = {
        TabType : this.fromTab,
        Textid : "",
        Wiid : "",
        CaseGuid : this.caseguid,
        NotingString : "",
        ANotingString : newNoting,
        SNotingString : "",
        PAgent : "",
        Photourl : fiString
      };
      this.customBusyDialogOpen();
      oModel
      .create(
        "/FILE_NOTING_ES",
        newNotingData,
        {
         success : function(oResponse) {

          oControllerS2.getView().byId(
          "commenteditor")
          .setValue("");
          //oControllerS2.closeDialog('shareFileAttributes');

          oControllerS2.shareAttrDialog.close();
          oControllerS2.oRouter.getView(
          "flm.fiori.view.S1")
          .byId("idFilesTable")
          .removeSelections();
          oControllerS2.oRouter.getView(
          "flm.fiori.view.S1")
          .byId("sendAction")
          .setEnabled(false);
          oControllerS2.oRouter.getView(
          "flm.fiori.view.S1")
          .byId("closeAction")
          .setEnabled(false);
          destroyDialogs(oControllerS2); //destroy all common fragments
          oControllerS2.oRouter
          .navTo("fullscreen");
          sap.m.MessageToast
          .show(oControllerS2.getView().getModel("i18n").getObject("MESSAGE_65"));
         },

         async : false
        });
      sap.ui.getCore().byId("userValueInput").setValue("");
      sap.ui.getCore().byId("attribute").setState(false);
      sap.ui.getCore().byId("document").setState(false);
      sap.ui.getCore().byId("noting").setState(false);
      sap.ui.getCore().byId("workflow").setState(false);
     },

     /*Sending back to previous processor */
     sendPreviousButtonPressed : function(oEvent){
      this.customBusyDialogOpen();
      sap.m.MessageBox
      .confirm(
        this.getView().getModel("i18n").getObject("MESSAGE_75"),
        function(oResponse){
         if (oResponse == "OK") {
          var assistFlag = oControllerS2.oSource.getController().assistFlag;

          if (assistFlag == true) {
           // this.assistNotButtonPressed();

           sap.m.MessageBox
             .confirm(
               oControllerS2.getView().getModel("i18n").getObject("MESSAGE_26"),
               function(response) {
                if (response == "OK") {
                 // check for digital signature customizationg
                 if(oControllerS2.digSigNeeded){
                  if(oControllerS2.customDigitalSignData){
                           /*   var flag = oControllerS2.customDigitalSignData(oControllerS2.data);
                              if(flag == "X"){
                 oControllerS2
                   .confirmSendBackFile(
                     oControllerS2.caseguid,
                     oControllerS2.wiId,
                     oControllerS2.fileid,
                     oControllerS2.fromTab);
                              }*/
                   oControllerS2.customDigitalSignData(oControllerS2.data, jQuery.proxy(function() {
                    oControllerS2.confirmSendBackFile(oControllerS2.caseguid,
                      oControllerS2.wiId,
                      oControllerS2.fileid,
                      oControllerS2.fromTab);
                                
                                }, oControllerS2));
                  }else{
                   sap.m.MessageBox.alert(oControllerS2.getView().getModel("i18n").getObject("MESSAGE_73"));
                   oControllerS2
                   .customBusyDialogClose();
                   }
                 }else{
                  oControllerS2
                  .confirmSendBackFile(
                    oControllerS2.caseguid,
                    oControllerS2.wiId,
                    oControllerS2.fileid,
                    oControllerS2.fromTab);
                 }
                } else {
                 oControllerS2
                   .customBusyDialogClose();
                }
               });

          } else {
           if(oControllerS2.digSigNeeded){
            if(oControllerS2.customDigitalSignData){
                      /*  var flag = oControllerS2.customDigitalSignData(oControllerS2.data);
                        if(flag == "X"){
           oControllerS2
             .confirmSendBackFile(
               oControllerS2.caseguid,
               oControllerS2.wiId,
               oControllerS2.fileid,
               oControllerS2.fromTab);
                        }*/
             oControllerS2.customDigitalSignData(oControllerS2.data, jQuery.proxy(function() {
              oControllerS2.confirmSendBackFile(oControllerS2.caseguid,
                oControllerS2.wiId,
                oControllerS2.fileid,
                oControllerS2.fromTab);
                          
                          }, oControllerS2));
            }else{
             sap.m.MessageBox.alert(oControllerS2.getView().getModel("i18n").getObject("MESSAGE_73"));
             oControllerS2
             .customBusyDialogClose();
            }
           }else{
            oControllerS2
            .confirmSendBackFile(
              oControllerS2.caseguid,
              oControllerS2.wiId,
              oControllerS2.fileid,
              oControllerS2.fromTab);
           }
          }
         }else{
          oControllerS2
          .customBusyDialogClose();
         }
        });

     },


    confirmSendBackFile : function(caseguid, wiId, fileid, fromTab) {
     var oModel = new sap.ui.model.json.JSONModel();

     oModel
       .attachRequestCompleted(
         oControllerS2,
         function(oEvent) {

          oModel.detachRequestCompleted();

          if (oModel.getData().d.results[0].msg_type == "E") {
           oControllerS2
             .customBusyDialogClose(oControllerS2);
           sap.m.MessageBox
             .alert(oModel.getData().d.results[0].msg_text);
          } else {

           // delete the file from the tab
           var oTableId = null;
           var oEntitySet = null;
           switch (oControllerS2.fromTab) {
           case "INTRAY":
            oTableId = "idFilesTable";
            oEntitySet = "/FILE_INTRAY_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
            break;

           case "SUBSTITUTE":
            oTableId = "idSubstituteTable";
            oEntitySet = "/FILE_SUBST_ES?$filter=Filetype+eq+'"+oControllerS1.objectType+"'";
            break;
           }
           var tempModel = oControllerS2.oRouter
             .getView(
               "flm.fiori.view.S1")
             .byId(oTableId)
             .getModel("files");
           tempModel
             .attachRequestCompleted(
               oControllerS2,
               function(oEvent) {
                tempModel
                  .detachRequestCompleted();
                if (tempModel.oData.d != undefined) {
                 tempModel
                   .setData(tempModel.oData.d);
                 tempModel
                   .checkUpdate();
                 sap.m.MessageToast
                   .show(oModel
                     .getData().d.results[0].msg_text);
                }
                oControllerS2
                  .customBusyDialogClose(oControllerS2);

                oControllerS2.oRouter
                  .getView(
                    "flm.fiori.view.S1")
                  .byId(
                    oTableId)
                  .removeSelections();
                destroyDialogs(oControllerS2); //destroy all common fragments
                oControllerS2.oRouter
                  .navTo("fullscreen");
               },
               oControllerS2);
           tempModel.loadData(serviceUrl
             + oEntitySet, null,
             true);
          }

         }, oControllerS2);

     oModel
       .loadData(
         serviceUrl
           + "/FILES_FI?param_1='OS'&param_2='"
           + caseguid
           + "'&param_3='"
           + wiId
           + "'&param_4='"
           + fileid
           + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7='"
           + fromTab
           + "'&param_8=''&param_9=''&param_10=''",
         null, false);

    },

     // Full screen editor for Notings
     fullscreenNotingPressed : function(oEvent) {
      if (!oControllerS2._oFullScreenDialog1) {
       oControllerS2._oFullScreenDialog1 = sap.ui
         .xmlfragment(
           "flm.fiori.view.notingFullView",
           oControllerS2);
      }

      oControllerS2._oFullScreenDialog1.getContent()[0]
        .setValue(this.getView().byId("commenteditor")
          .getValue());
      oControllerS2._oFullScreenDialog1.open();
     },

     notingFullScreenCloseButton : function(oEvent) {
      this.getView().byId("commenteditor")
        .setValue(
          oControllerS2._oFullScreenDialog1
            .getContent()[0].getValue());
      oControllerS2._oFullScreenDialog1.close();
      // oControllerS2._oFullScreenDialog1.destroy();
     },

     notingFullScreenCancelButton : function(oEvent) {
      sap.ui.getCore().byId("notingFullEditor")
        .setValue(
          this.getView().byId("commenteditor")
            .getValue());
      oControllerS2._oFullScreenDialog1.close();
      // oControllerS2._oFullScreenDialog1.destroy();
     },
     customBusyDialogOpen : function(busyText) {
      if (busyText != null) {
       if (!this._dialog) {

        this._dialog = sap.ui.xmlfragment(
          "flm.fiori.view.busyDialog", this);
        this.getView().addDependent(this._dialog);
       }
       this._dialog.setText(busyText);
       this._dialog.open();
      } else {
//       this._dialog.setText("");
       this.byId("fileDetails").setBusy(true);
       this.byId("idFooterBar").setBusy(true);
      }
     },

     customBusyDialogClose : function() {
      // var dialog = sap.ui.getCore().byId("idBusyDialog");
      // jQuery.sap.delayedCall(2500, this, function() {
      if (this._dialog) {
       this._dialog.close();
      }
       this.byId("fileDetails").setBusy(false);
       this.byId("idFooterBar").setBusy(false);
      // });

      // dialog.close();
     },

     // For File tracking status change
     trackedStateChange : function(oEvent) {


      if (this.getView().byId("trackStatus").getState() == false) {
       oControllerS2.customBusyDialogOpen();
       var oModel = new sap.ui.model.json.JSONModel();
       oModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='UF'&param_2='"
             + this.caseguid
             + "'&param_3='"
             + this.wiId
             + "'&param_4='"
             + this.fileid
             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
           null, false);
       if (oModel.getData().d.results.length == 0) {
        // this.getView().byId("trackStatus").getModel("basic").getData().d.Track
        // = false;
        this.getView().byId("trackStatus").setTooltip(this.getView().getModel("i18n").getObject("OFF"));
        this.getView().byId("trackStatus").rerender();
        sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_11"));
        oControllerS2.customBusyDialogClose();
       } else if (oModel.getData().d.results[0].msg_type == 'E') {
        sap.m.MessageBox
        .alert(oModel.getData().d.results[0].msg_text);

       }
      } else if (this.getView().byId("trackStatus")
        .getState() == true) {
       oControllerS2.customBusyDialogOpen();
       var oModel = new sap.ui.model.json.JSONModel();
       oModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='TF'&param_2='"
             + this.caseguid
             + "'&param_3='"
             + this.wiId
             + "'&param_4='"
             + this.fileid
             + "'&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
           null, false);
       if (oModel.getData().d.results.length == 0) {
        // this.getView().byId("trackStatus").getModel("basic").getData().d.Track
        // = true;
        this.getView().byId("trackStatus").setTooltip(this.getView().getModel("i18n").getObject("ON"));
        this.getView().byId("trackStatus").rerender();
        sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_43"));
        oControllerS2.customBusyDialogClose();
       } else if (oModel.getData().d.results[0].msg_type == 'E') {
        sap.m.MessageBox
        .alert(oModel.getData().d.results[0].msg_text);
       }
      }
     },

     // For Confidentiality status change
     confidentialStateChange : function(oEvent) {


      if (this.getView().byId("confidentialStatus").getState() == false) {
       oControllerS2.customBusyDialogOpen();
       var oModel = new sap.ui.model.json.JSONModel();
       oModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='NC'&param_2='"
             + this.caseguid
             + "'&param_3=''&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
           null, false);
       if (oModel.getData().d.results.length == 0) {
        // this.getView().byId("trackStatus").getModel("basic").getData().d.Track
        // = false;
        this.getView().byId("confidentialStatus").setTooltip(this.getView().getModel("i18n").getObject("OFF"));
        this.getView().byId("confidentialStatus").rerender();
        sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_69"));
        oControllerS2.customBusyDialogClose();
       } else if (oModel.getData().d.results[0].msg_type == 'E') {
        sap.m.MessageBox
        .alert(oModel.getData().d.results[0].msg_text);

       }
      } else if (this.getView().byId("confidentialStatus")
        .getState() == true) {
       oControllerS2.customBusyDialogOpen();
       var oModel = new sap.ui.model.json.JSONModel();
       oModel
         .loadData(
           serviceUrl
             + "/FILES_FI?param_1='CN'&param_2='"
             + this.caseguid
             + "'&param_3=''&param_4=''&param_5=''&check_1=''&check_2=''&check_3=''&param_6=''&param_7=''&param_8=''&param_9=''&param_10=''",
           null, false);
       if (oModel.getData().d.results.length == 0) {
        // this.getView().byId("trackStatus").getModel("basic").getData().d.Track
        // = true;
        this.getView().byId("confidentialStatus").setTooltip(this.getView().getModel("i18n").getObject("ON"));
        this.getView().byId("confidentialStatus").rerender();
        sap.m.MessageToast.show(this.getView().getModel("i18n").getObject("MESSAGE_69"));
        oControllerS2.customBusyDialogClose();
       } else if (oModel.getData().d.results[0].msg_type == 'E') {
        sap.m.MessageBox
        .alert(oModel.getData().d.results[0].msg_text);
       }
      }
     },

     toSearchView : function(oEvent) {


      if (!oControllerS2.searchPopup) {
       oControllerS2.searchPopup = sap.ui.xmlfragment(
         "flm.fiori.view.searchDialog", oControllerS2);
      }
       oControllerS2.searchPopup.setModel(this.getView().getModel(
         "i18n"), "i18n");
       var oPrioModel = new sap.ui.model.json.JSONModel();
       oPrioModel.setData(this.data.priority);
       oControllerS2.searchPopup.setModel(oPrioModel, "priority");

       oControllerS2.searchPopup.setModel(this
         .initializeSearchHelp(this), "global");

      oControllerS2.searchPopup.open();
     },

     onSearchDialogCloseButton : function(oEvent) {
//      sap.ui.getCore().byId("searchTemplate").setType(
//        "Navigation");
      this.searchPopup.close();
     },

     onAddSearch : function(oEvent) {

      var fileNumber = oEvent.getParameters().listItem
        .getBindingContext("global").getObject().PsReference;
      if (this.getView().byId("fileHeader").getTitle() == fileNumber) {
       sap.m.MessageBox
         .alert(this.getView().getModel("i18n").getObject("MESSAGE_44"));
       return;
      } else {
       sap.ui.getCore().byId("idFileNumber").setValue(
         fileNumber);
       this.searchPopup.close();
      }
     },
     /* Redundant function for search */
     onPressSearch : function(oEvent) {

      var i = -1;
      var searchFields = new Array();
      if (sap.ui.getCore().byId("value1").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value1").getValue();
       searchFields[i].op = sap.ui.getCore().byId("op1")
         .getSelectedKey();
       searchFields[i].criteria = "CASE_TITLE";
      }
      if (sap.ui.getCore().byId("value2").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value2").getValue();
       searchFields[i].op = sap.ui.getCore().byId("op2")
         .getSelectedKey();
       searchFields[i].criteria = "PS_REFERENCE";
      }
      if (sap.ui.getCore().byId("value3").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value3").getName();
       searchFields[i].op = sap.ui.getCore().byId("op3")
         .getSelectedKey();
       searchFields[i].criteria = "CREATED_BY";
      }
      if (sap.ui.getCore().byId("value4").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value4").getName();
       searchFields[i].op = sap.ui.getCore().byId("op4")
         .getSelectedKey();
       searchFields[i].criteria = "CHANGED_BY";
      }
      if (sap.ui.getCore().byId("value5").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value5").getName();
       searchFields[i].op = sap.ui.getCore().byId("op5")
         .getSelectedKey();
       searchFields[i].criteria = "CLOSED_BY";
      }
      if (sap.ui.getCore().byId("value6").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value6").getValue();
       searchFields[i].op = sap.ui.getCore().byId("op6")
         .getSelectedKey();
       searchFields[i].criteria = "CREATE_TIME";
      }
      /*if (sap.ui.getCore().byId("value7").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value7").getValue();
       searchFields[i].op = sap.ui.getCore().byId("op7")
         .getSelectedKey();
       searchFields[i].criteria = "EXT_KEY";
      }*/
      if (sap.ui.getCore().byId("value8").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value8").getValue();
       searchFields[i].op = sap.ui.getCore().byId("op8")
         .getSelectedKey();
       searchFields[i].criteria = "PLAN_END_DATE";
      }
      /*if (sap.ui.getCore().byId("value9").getState() != false) {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value9").getState();
       searchFields[i].op = sap.ui.getCore().byId("op9")
         .getSelectedKey();
       searchFields[i].criteria = "ARCHIVE";
      }*/
      if (sap.ui.getCore().byId("value10").getSelectedKey() != "SPACE") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value10").getSelectedKey();
       searchFields[i].op = sap.ui.getCore().byId("op10")
         .getSelectedKey();
       searchFields[i].criteria = "STAT_ORDERNO";
      }

      if (sap.ui.getCore().byId("value11").getSelectedKey() != "SPACE") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value11").getSelectedKey();
       searchFields[i].op = sap.ui.getCore().byId("op11")
         .getSelectedKey();
       searchFields[i].criteria = "SAP_FLM_PRIO";
      }

      if (sap.ui.getCore().byId("value12").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value12").getValue();
       searchFields[i].op = sap.ui.getCore().byId("op11")
         .getSelectedKey();
       searchFields[i].criteria = "FILE_TYPE";
      }
      if (sap.ui.getCore().byId("value13").getValue() != "") {
       i++;
       searchFields[i] = {};
       searchFields[i].value = sap.ui.getCore().byId(
         "value13").getValue();
       searchFields[i].op = sap.ui.getCore().byId("op13")
         .getSelectedKey();
       searchFields[i].criteria = "ORG_UNIT";
      }
      var criteria1 = "";
      var criteria2 = "";
      var criteria3 = "";
      var criteria4 = "";
      var criteria5 = "";

      var op1 = "";
      var op2 = "";
      var op3 = "";
      var op4 = "";
      var op5 = "";
      var obType = "";
       obType = "FILE";
      var value1 = "";
      var value2 = "";
      var value3 = "";
      var value4 = "";
      var value5 = "";
      var max_res = sap.ui.getCore().byId("noOfResults")
        .getValue();
      if (searchFields.length > 5) {
       sap.m.MessageToast.show(this.getView().getModel(
         "i18n").getObject("MESSAGE_01"));
      } else if (searchFields.length == 0) {
       sap.m.MessageToast.show(this.getView().getModel(
         "i18n").getObject("MESSAGE_02"));
      } else {
       for (var j = 0; j < searchFields.length; j++) {
        if (j == 0) {
         criteria1 = searchFields[j].criteria;
         op1 = searchFields[j].op;
         value1 = searchFields[j].value;
        } else if (j == 1) {
         criteria2 = searchFields[j].criteria;
         op2 = searchFields[j].op;
         value2 = searchFields[j].value;
        } else if (j == 2) {
         criteria3 = searchFields[j].criteria;
         op3 = searchFields[j].op;
         value3 = searchFields[j].value;
        } else if (j == 3) {
         criteria4 = searchFields[j].criteria;
         op4 = searchFields[j].op;
         value4 = searchFields[j].value;
        } else if (j == 4) {
         criteria5 = searchFields[j].criteria;
         op5 = searchFields[j].op;
         value5 = searchFields[j].value;
        }

       }
       var osearchResultsModel = new sap.ui.model.json.JSONModel();
       osearchResultsModel.loadData(serviceUrl
         + "/FILE_SRCH_FI?action='SR'&crit_1='"
         + criteria1 + "'&crit_2='" + criteria2
         + "'&crit_3='" + criteria3 + "'&crit_4='"
         + criteria4 + "'&crit_5='" + criteria5
         + "'&oper_1='" + op1 + "'&oper_2='" + op2
         + "'&oper_3='" + op3 + "'&oper_4='" + op4
         + "'&oper_5='" + op5 + "'&value_1='"
         + encodeURIComponent(value1) + "'&value_2='" + encodeURIComponent(value2)
         + "'&value_3='" + encodeURIComponent(value3) + "'&value_4='"
         + encodeURIComponent(value4) + "'&value_5='" + encodeURIComponent(value5)
         + "'&max_res='" + max_res + "'&is_type='" + obType + "'", null,
         false);
       // sap.ui.getCore().byId("idSearchTable").setModel(
       // osearchResultsModel);
       oEvent.getSource().getModel("global").oData.searchResult = osearchResultsModel.oData.d.results;
       /* Setting decoded value for subject*/
       /*for (var j = 0; j < osearchResultsModel.oData.d.results.length; j++) {
        var subValue = decodeURIComponent(osearchResultsModel.oData.d.results[j].CaseTitle);
        osearchResultsModel.oData.d.results[j].CaseTitle = subValue;
       }*/
       // // this.data.searchResults =
       oEvent.getSource().getModel("global").checkUpdate();
       //sap.ui.getCore().byId("idSearchTable").bindItems(osearchResultsModel.oData.d.results);

      }

     },
     onPressClear : function(oEvent) {
      sap.ui.getCore().byId("value1").setValue("");
      sap.ui.getCore().byId("value2").setValue("");
      sap.ui.getCore().byId("value3").setValue("");
      sap.ui.getCore().byId("value4").setValue("");
      sap.ui.getCore().byId("value5").setValue("");
      sap.ui.getCore().byId("value6").setValue("");
      /*sap.ui.getCore().byId("value7").setValue("");*/
      sap.ui.getCore().byId("value8").setValue("");
//      sap.ui.getCore().byId("value9").setState(false);
      sap.ui.getCore().byId("value10")
        .setSelectedKey("SPACE");
      sap.ui.getCore().byId("value11")
        .setSelectedKey("SPACE");
      sap.ui.getCore().byId("value12").setValue("");
      sap.ui.getCore().byId("value13").setValue("");

      sap.ui.getCore().byId("op1").setSelectedKey("01");
      sap.ui.getCore().byId("op2").setSelectedKey("01");
      sap.ui.getCore().byId("op3").setSelectedKey("01");
      sap.ui.getCore().byId("op4").setSelectedKey("01");
      sap.ui.getCore().byId("op5").setSelectedKey("01");
      sap.ui.getCore().byId("op6").setSelectedKey("01");
     /* sap.ui.getCore().byId("op7").setSelectedKey("01");*/
      sap.ui.getCore().byId("op8").setSelectedKey("11");
//      sap.ui.getCore().byId("op9").setSelectedKey("01");
      sap.ui.getCore().byId("op10").setSelectedKey("01");
      sap.ui.getCore().byId("op11").setSelectedKey("01");
      sap.ui.getCore().byId("op12").setSelectedKey("01");
      sap.ui.getCore().byId("op13").setSelectedKey("01");

      oEvent.getSource().getModel("global").oData.searchResult = null;
      // // this.data.searchResults =
      oEvent.getSource().getModel("global").checkUpdate();
     },

     onpressf4User : function(oEvent) {
      if (!this.f4popup) {
       this.f4popup = sap.ui.xmlfragment(
         "flm.fiori.view.dynamicF4popup", this);
       // sap.ui.getCore().addDependent(this.f4popup);
      }

      oF4Texts = new sap.ui.model.json.JSONModel();
      var f4text = {
       title : this.getView().getModel("i18n").getObject(
         "USERS"),
       id : oEvent.getSource().getId()
      };
      oF4Texts.setData(f4text);
      this.f4popup.setModel(oF4Texts, "dyntext");

      var oF4Model = new sap.ui.model.json.JSONModel();
      oF4Model
        .loadData(
          serviceUrl
            + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and ID eq 'US' and WF eq true",
          null, false);
      oF4Model.setData(oF4Model.oData.d.results);
      this.f4popup.setModel(oF4Model);
      this.f4popup.open();
     },

     onpressf4Filetype : function(oEvent) {
      if (!this.f4popup) {
       this.f4popup = sap.ui.xmlfragment(
         "flm.fiori.view.dynamicF4popup", this);
       // sap.ui.getCore().addDependent(this.f4popup);
      }

      oF4Texts = new sap.ui.model.json.JSONModel();
      var f4text = {
       title : this.getView().getModel("i18n").getObject(
         "FILETYPE"),
       id : oEvent.getSource().getId()
      };
      oF4Texts.setData(f4text);
      this.f4popup.setModel(oF4Texts, "dyntext");
      var oF4Model = new sap.ui.model.json.JSONModel();
      oF4Model
        .loadData(
          serviceUrl
            + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and ID eq 'FT' and OtherF4 eq true",
          null, false);
      oF4Model.setData(oF4Model.oData.d.results);
      this.f4popup.setModel(oF4Model);
      this.f4popup.open();
     },

     onpressf4Orgunit : function(oEvent) {
      if (!this.f4popup) {
       this.f4popup = sap.ui.xmlfragment(
         "flm.fiori.view.dynamicF4popup", this);
       // sap.ui.getCore().addDependent(this.f4popup);
      }
      oF4Texts = new sap.ui.model.json.JSONModel();
      var f4text = {
       title : this.getView().getModel("i18n").getObject(
         "ORGANIZATIONGROUP"),
       id : oEvent.getSource().getId()
      };
      oF4Texts.setData(f4text);
      this.f4popup.setModel(oF4Texts, "dyntext");
      var oF4Model = new sap.ui.model.json.JSONModel();
      oF4Model
        .loadData(
          serviceUrl
            + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and ID eq 'OC' and OtherF4 eq true",
          null, false);
      oF4Model.setData(oF4Model.oData.d.results);
      this.f4popup.setModel(oF4Model);
      this.f4popup.open();
     },

     // handleItemSelectionChange : function(oEvent) {
     // sap.ui.getCore().byId("addAction").setEnabled(true);
     // this.tableItemSelected = true;
     // },
     handleItemSelectionChange : function(oEvent) {
      sap.ui.getCore().byId("addAction").setEnabled(true);
      this.tableItemSelected = true;
     },

     onAddWorkflowSelect : function(oEvent) { // CHANGE add to
      // global
      // variables
      // also

      if (oControllerS2.oSequenceSend == undefined) {
       oControllerS2.oSequenceSend = sap.ui.xmlfragment(
         "flm.fiori.view.sendTo", oControllerS2);

       var select1 = sap.ui.getCore().byId("idSelect1");
       var select1Model = new sap.ui.model.json.JSONModel({});
       select1Model
         .loadData(serviceUrl
           + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and OtherF4 eq true and ID eq 'WC'");
       select1.setModel(select1Model, "processorType");
       var select2 = sap.ui.getCore().byId("idSelect2");
       var select2Model = new sap.ui.model.json.JSONModel({});
       select2Model
         .loadData(serviceUrl
           + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and OtherF4 eq true and ID eq 'AC'");
       select2.setModel(select2Model, "activity");
      }
       // modify UI of popup depending upon the scenario
       var currNode = oControllerS2.byId("wftree").getContextByIndex(
         oControllerS2.byId("wftree").getSelectedIndex())
         .getObject();

       if(oControllerS2.workflowAdminAuthorization){
        oControllerS2.resetWorkflowPopup(oControllerS2);
        if(currNode.Creadate!=""){
         sap.ui.getCore().byId("idParallelRadioButton").setVisible(false);
        }else{
         sap.ui.getCore().byId("idParallelRadioButton").setVisible(true);
        }
       }else if(currNode.IsDelete){
        oControllerS2.resetWorkflowPopup(oControllerS2,"PAR");
       }else{
        oControllerS2.resetWorkflowPopup(oControllerS2,"SEQ");
       }

      oControllerS2.oSequenceSend.open();
     },

     onWorkflowOkPress : function(oEvent) { // CHANGE

      oControllerS2.flatObj = new Array();
      if (sap.ui.getCore().byId("idSequenceRadioButton")
        .getSelected() == true) {
       // var
       var processor = sap.ui.getCore().byId("idSelect1")
         .getSelectedItem().getText();
       var sendTo = sap.ui.getCore().byId("idUsername")
         .getValue();
       var agent = sap.ui.getCore().byId("idUsername")
         .getName();
       var activity = sap.ui.getCore().byId("idSelect2")
         .getSelectedItem().getText();
       var activityKey = sap.ui.getCore()
         .byId("idSelect2").getSelectedItem()
         .getKey();
       var processingDate = sap.ui.getCore().byId(
         "idDatePickerSendTo").getValue();
       // var
       // processingTime=sap.ui.getCore().byId("idInputTime").getValue();
       var processingDay = sap.ui.getCore().byId(
         "idInputDays").getValue();
       if ((sendTo == "" || activity == "" || processor == "")) {
        sap.m.MessageToast
          .show(this.getView().getModel(
          "i18n").getObject("MESSAGE_48"));
        return;
       }
       if (processingDate != "" && processingDay != "") {
        sap.ui.getCore().byId("idDatePickerSendTo").setValue("");

                                sap.ui.getCore().byId("idInputDays").setValue("");

                                sap.m.MessageBox.alert(this.getView().getModel(

                                                "i18n").getObject("MESSAGE_21"));
                                return;
       }
       oControllerS2.saveFlag = true;
       var nodeType = "S";
       var newObj = {
         "Actdc" : activity,
         "Activity" : activityKey,
         "Agent" : agent,
         "Nodetype" : nodeType,
         "Fullname" : sendTo,
         "PosidLed" : processingDate,
         "DueDays" : processingDay,
         "Statustext" : "Not Yet Started",
         "nodes" : []
        };
       oControllerS2.flatObj[0] = newObj;

       oControllerS2.addSequence(newObj);
      } else if (sap.ui.getCore().byId(
        "idParallelRadioButton").getSelected() == true) {

       var parList = sap.ui.getCore().byId(
         "idProcessorsTable").getModel("dummy")
         .getData().data;
       for (var i = 0; i < parList.length; i++) {
        var sendTo = parList[i].Name;
        var activity = parList[i].Actdc;
        var processingDate = parList[i].Date;
        // var
        // processingTime=parList[i].getCells()[4].getText();
        var processingDay = parList[i].Days;
        var agent = parList[i].Agent;
        var activityKey = parList[i].Activity;
        var nodeType = "P";
        var newObj = {
          "Actdc" : activity,
          "Activity" : activityKey,
          "Agent" : agent,
          "Nodetype" : nodeType,
          "Fullname" : sendTo,
          "PosidLed" : processingDate,
          "DueDays" : processingDay,
          "Statustext" : "Not Yet Started",
          "isParallel" : 'X',
          "nodes" : []
         };
        oControllerS2.flatObj[i] = newObj;
        oControllerS2.addParallel(newObj);
       }
      }
      // oEvent.getSource().getParent().getParent().close();
      sap.ui.getCore().byId("idUsername").setValue("");
                        sap.ui.getCore().byId("idSelect1").getSelectedItem().setText("");
                        sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
                        sap.ui.getCore().byId("idInputDays").setValue("");
      if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
       oEvent.getSource().getParent().close();
      } else {
       oEvent.getSource().getParent().getParent().close();
      }
     },

     addSequence : function(newObj) {

      // var newObj = {"Fullname": "Vinay", "Nodetype": "S",
      // "nodes": []};

      var wftree = this.getView().byId("wftree");

      // rerender trees
      wftree.rerender();

      // step1: figure out the parent object's node array
      var levels = oControllerS2.flatTreeTableData[oControllerS2.wftreeIndex].Label; // wftree.getRows()[oControllerS2.wftreeIndex].getBindingContext().getPath().split("/");
      levels = levels.split("_");
      var path = "";
      for (var i = 0; i < levels.length; ++i) {
       levels[i] = parseInt(levels[i]) - 1;
       path += "/nodes/" + levels[i];
      }

      levels = path.split("/");

      // remove first element - coz its ""
      levels.splice(0, 2);

      for (var i = 0; i < levels.length; ++i) {

       levels[i] = parseInt(levels[i]);

       ++i; // coz we dont need to convert "nodes" to
       // int
      }

      var data = wftree.getModel().oData.nodes;
      var obj = data;

      for (var i = 0; i < levels.length - 1; ++i) {
       obj = obj[levels[i]].nodes;
       ++i;
      }

      // step2: insert it just below the person if he is in
      // sequence
      if (obj[levels[i]].Nodetype == "S") {
       obj.splice(levels[i] + 1, 0, newObj);
      } else {
       if (obj[levels[i]].nodes == undefined) {
        obj[levels[i]].nodes = [ newObj ];
       } else {
        obj[levels[i]].nodes.push(newObj);
       }
      }

      wftree.getModel().checkUpdate();

      wftree.rerender();

      this.getView().byId("idAddInWorkflow")
        .setEnabled(false);
      this.getView().byId("idUndoButton").setEnabled(true);
      return;

     },

     addParallel : function(newObj) {


      // var newObj = {"Fullname": "Vinay", "Nodetype": "P",
      // "nodes": []};

      var wftree = this.getView().byId("wftree");

      // rerender trees
      wftree.rerender();

      // step1: figure out the parent object's node array
      var levels = oControllerS2.flatTreeTableData[oControllerS2.wftreeIndex].Label; // wftree.getRows()[oControllerS2.wftreeIndex].getBindingContext().getPath().split("/");
      levels = levels.split("_");
      var path = "";
      for (var i = 0; i < levels.length; ++i) {
       levels[i] = parseInt(levels[i]) - 1;
       path += "/nodes/" + levels[i];
      }

      levels = path.split("/");

      // remove first element - coz its ""
      levels.splice(0, 2);

      for (var i = 0; i < levels.length; ++i) {

       levels[i] = parseInt(levels[i]);

       ++i; // coz we dont need to convert "nodes" to
       // int
      }

      var data = wftree.getModel().oData.nodes;
      var obj = data;

      for (var i = 0; i < levels.length - 1; ++i) {
       obj = obj[levels[i]].nodes;
       ++i;
      }

      // step2: insert it under the current processor node..
      if (obj[levels[i]].Nodetype == "S") {
       obj.splice(levels[i] + 1, 0, newObj);
      } else {
       if (obj[levels[i]].nodes == undefined) {
        obj[levels[i]].nodes = [ newObj ];
       } else {
        obj[levels[i]].nodes.push(newObj);
       }
      }

      wftree.getModel().checkUpdate();

      wftree.rerender();

      this.getView().byId("idAddInWorkflow")
        .setEnabled(false);
      this.getView().byId("idUndoButton").setEnabled(true);
      return;

     },
     onSendToDialogCloseButton : function(oEvent) {
      sap.ui.getCore().byId("idUsername").setValue("");
      sap.ui.getCore().byId("idSelect1").setSelectedKey("SPACE");
                        sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
                        sap.ui.getCore().byId("idInputDays").setValue("");
      if (oEvent.getSource().getParent().getMetadata()._sClassName == "sap.m.Dialog") {
       oEvent.getSource().getParent().close();
      } else {
       oEvent.getSource().getParent().getParent().close();
      }
     },

     onUndoSelect : function() {
      oControllerS2.saveFlag = false;
      this.getView().byId("idAddInWorkflow").setEnabled(true);
      // oControllerS2.loadTreeTable();
      oControllerS2.initializeWorkflow(oControllerS2);
      this.getView().byId("idUndoButton").setEnabled(false);
     },

     // this function is called when user wants to add object or
     // report kind of documents

     objectButtonPressed : function(oEvent) {
      // doctype= [{docType:"Purchase Order"},{docType:
      // "Purchase Requisition"}, {docType:"Sales Order"}];
      oControllerS2.isAttachment = false;
      oControllerS2.isFile = false;
      oControllerS2.isReport = false;
      oControllerS2.isObject = true;
      oControllerS2.isIPI = false;
      if (!this._docTypeSelectDialog) {
       this._docTypeSelectDialog = sap.ui.xmlfragment(
         "flm.fiori.view.documentTypeSelectDialog",
         this);
       var docTypeModel = new sap.ui.model.json.JSONModel();
       docTypeModel
         .loadData(serviceUrl
           + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and OtherF4 eq true and ID eq 'DT'");
       this._docTypeSelectDialog.setModel(docTypeModel,
         "docType");
       this._docTypeSelectDialog.setModel(this.getView()
         .getModel("i18n"), "i18n");
      } else {
       sap.ui.getCore().byId("docNumberId").setValue("");
       sap.ui.getCore().byId("docTypeSelect")
         .setSelectedItem(
           sap.ui.getCore().byId(
             "docTypeSelect")
             .getFirstItem());
      }
      sap.ui.getCore().byId("attachmentTypeid").setValue(
        oEvent.getSource().getId());
      oModel = new sap.ui.model.json.JSONModel();
      if (oEvent.getSource().getId() == "objectAction") {

       oModel.loadData(serviceUrl
         + "/FILE_F4_ES?$filter=CaseGuid eq '"
         + this.caseguid
         + "' and OtherF4 eq true and ID eq 'OO'",
         null, false);
       sap.ui.getCore().byId("docTypeSelectId").setTitle(
         this.getView().getModel("i18n").getObject(
           "object"));
      } else if (oEvent.getSource().getId() == "reportAction") {

       oModel.loadData(serviceUrl
         + "/FILE_F4_ES?$filter=CaseGuid eq '"
         + this.caseguid
         + "' and OtherF4 eq true and ID eq 'RO'",
         null, false);
       sap.ui.getCore().byId("docTypeSelectId").setTitle(
         this.getView().getModel("i18n").getObject(
           "report"));
      }
      this._docTypeSelectDialog.setModel(oModel);
      // oModel.setData(doctype);
      this._docTypeSelectDialog.open();
     },

     // Function for selecting document type and entering
     // document number
     _handleDocSelectOk : function(oEvent) {
      if (oControllerS2.isObject) {
       doc_num = sap.ui.getCore().byId("docNumberId");
      } 

      for (i = 0; i < oControllerS2.getView().getModel(
        "global").getData().documents.length; i++) {
       // if(!isFile && (gResponse[i].IsAttachment ||
       // gResponse[i].IsObject || gResponse[i].IsReport)){
       if (doc_num.getValue() == oControllerS2.getView()
         .getModel("global").getData().documents[i].DocumentName) {
        sap.m.MessageToast
          .show(this.getView().getModel("i18n").getObject("MESSAGE_35"));
        return;
       }
       // }
      }
      var documentData = {
       "BorID" : null,
       "BorType" : null,
       "DocumentName" : null,
       "DocumentType" : null,
       "CreatedByName" : null,
       "CreatedOn" : null,
       "FileTitle" : null,
       "FileSizeDescr" : null,
       "ParentKey" : this.uploadNode.getBindingContext(
         "global").getProperty("RowKey"),
       "IsAttachment" : false,
       "IsFile" : false,
       "IsObject" : false,
       "IsIpi" : false,
       "IsReport" : false,
       "ElementType" : null,
       "FileName" : null,
       "DocumentClass" : null,
       "AttachmentLoioID" : null,
       "FileSizeDescr" : null,
       "NotingEnabledRef" : true,
       "DeleteEnabledRef" : true,
       "Variant" : null,
      };

      var fileDetails = {
       "caseGuiId" : this.caseguid,
       "workItemId" : this.wiId,
       "fileId" : this.fileid,
      };

      var objDetails = {
       "objectType" : null,
       "elementType" : null,
       "attachmentType" : sap.ui.getCore().byId(
         "attachmentTypeid").getValue(),// sap.ui.getCore().byId("docTypeSelectId").getTitle(),
      };
      var docObject = {};

      docObject.document = documentData;
      docObject.fileDetails = fileDetails;
      docObject.objectDetails = objDetails;
      docObject.event = oEvent;

      docObject.document.DocumentName = sap.ui.getCore()
        .byId("docNumberId").getValue();

      if (docObject.document.DocumentName == ""
        || sap.ui.getCore().byId("idDocTypeTable")
          .getSelectedItem() == undefined) {
       sap.m.MessageToast.show(this.getView().getModel(
         "i18n").getObject("ENTER_DOCUMENT_NUMBER"));
       return;
      } else {
       docObject.document.DocumentType = sap.ui.getCore()
         .byId("docTypeSelect").getSelectedKey();
       docObject.document.FileName = sap.ui.getCore()
         .byId("docTypeSelect").getSelectedItem()
         .getText();
       docObject.objectDetails.objectType = sap.ui
         .getCore().byId("idDocTypeTable")
         .getSelectedItem().getBindingContext()
         .getObject().ResulltCol1;
       docObject.objectDetails.elementType = sap.ui
         .getCore().byId("idDocTypeTable")
         .getSelectedItem().getBindingContext()
         .getObject().ResultCol3;
      }
      // closing the popup and calling the hook function
      this._docTypeSelectDialog.close();
      if (this.attachCustomObject) {
       this.attachCustomObject(docObject);
      }
     },

     _handleDocSelectCancel : function(oEvent) {
      this._docTypeSelectDialog.close();
     },

     // attach document in the tree in ui

     _attachObjectUI : function(oDocument) {

      try {
       oControllerS2.getView().getModel("global")
         .getData().documents.push(oDocument);
       oControllerS2.getView().getModel("global")
         .refresh();
      } catch (err) {
       return false;
      }
      var heading = oControllerS2.uploadNode
      .getTitle()
      .getText();
      var subHead1 = heading
      .substring(
        0,
        heading
          .lastIndexOf("("));
      var subHead2 = heading
      .substring(
        heading
          .lastIndexOf("(") + 1,
        heading
          .lastIndexOf(")"));
      oControllerS2.uploadNode
      .getTitle()
      .setText(
        subHead1
          + " ("
          + (++subHead2)
          + ")");
      return true;
     },

     // date formatting function

     _dateFormatter : function(oDate) {

      if (oDate == null) {
       oDate = new Date();
      }
      var year = oDate.getFullYear();
      var month = null;
      var date = null;
      if ((oDate.getMonth() + 1) < 10) {
       month = "0" + (oDate.getMonth() + 1);
      } else {
       month = oDate.getMonth() + 1;
      }
      if ((oDate.getDate()) < 10) {
       date = "0" + (oDate.getDate());
      } else {
       date = oDate.getDate();
      }

      return year.toString().concat(month, date);

     },

     checkForWorkflowChange : function(oEvent){
      var basicAttr = jQuery.extend(true,{},this.getView().getModel("global").oData.basic);

      // set some attributes which are missing
      basicAttr.CaseGuid = this.caseguid;

      basicAttr.TabType = this.getView().byId(
        "TAB_CONTAINER_FILE").getSelectedKey();
      basicAttr.Wiid = this.wiId;
      var date=basicAttr.PlanEndDate.substr(6,4)+basicAttr.PlanEndDate.substr(3,2)+basicAttr.PlanEndDate.substr(0,2);
      basicAttr.PlanEndDate=date;

       var validationControls = new Array();
          validationControls.push(this.getView().byId(
                            "prioSelect"));
          var mparams = oControllerS2.data.dynamic;
          for ( var i = 0; i < mparams.length; i++) {
           if (mparams[i].MANDATORY == true) {
            validationControls.push(sap.ui.getCore().byId(
                                          mparams[i].ID));
           }
           if(mparams[i].CURR_ID!=""){
            if(sap.ui.getCore().byId(mparams[i].ID).getValue()!="" && sap.ui.getCore().byId(mparams[i].ID).getValue()!="0.000"){ 
             validationControls.push(sap.ui.getCore().byId(
               mparams[i].CURR_ID));
            }
           }
          }
          var f = validateInput(oControllerS2, validationControls);
          if (f) {
           f.focus(true);
           return;// Break
          } else {
           // Continue
          }
          if(oControllerS2.flatObj != undefined){
           sap.m.MessageBox
           .confirm(
        this.getView().getModel("i18n").getObject("MESSAGE_18"),
        function(response) {
         if (response == "OK") {
          oControllerS2.saveButtonPressed();
         } else {
          return ;
         }
        });
      }
      else{
       oControllerS2.saveButtonPressed();
      }
     },

     // saving basic and dynamic attributes --->update action
     saveButtonPressed : function(eotValue) {
      //var eotValue = '';
      if(eotValue == undefined){
       eotValue = '';
                     }
      // read basic attributes

      var basicAttr = jQuery.extend(true,{},this.getView().getModel("global").oData.basic);

      // set some attributes which are missing
      basicAttr.CaseGuid = this.caseguid;

      basicAttr.TabType = this.getView().byId(
        "TAB_CONTAINER_FILE").getSelectedKey();
      basicAttr.Wiid = this.wiId;
      var date=basicAttr.PlanEndDate.substr(6,4)+basicAttr.PlanEndDate.substr(3,2)+basicAttr.PlanEndDate.substr(0,2);
      basicAttr.PlanEndDate=date;
//
//       var validationControls = new Array();
//          validationControls.push(this.getView().byId(
//                            "prioSelect"));
//          var mparams = oControllerS2.data.dynamic;
//              for ( var i = 0; i < mparams.length; i++) {
//                     if (mparams[i].MANDATORY == true) {
//                            validationControls.push(sap.ui.getCore().byId(
//                                          mparams[i].ID));
//                     }
//                     if(mparams[i].CURR_ID!=""){
//                      if(sap.ui.getCore().byId(mparams[i].ID).getValue()!="" && sap.ui.getCore().byId(mparams[i].ID).getValue()!="0.000"){ 
//                       
//                      validationControls.push(sap.ui.getCore().byId(
//                                 mparams[i].CURR_ID));
//                      }
//                     }
//              }
//              var f = validateInput(oControllerS2, validationControls);
//              if (f) {
//                     f.focus(true);
//                     return;// Break
//              } else {
//                     // Continue
//              }

      // create a model
      var oModel = this.getView().getModel();

      // set batch use as true
      oModel.setUseBatch(true);
      // create batch operation
      var batchOp = oModel.createBatchOperation(
        "/FILE_BASIC_ES(ExtKey='" + basicAttr.ExtKey
          + "',CaseGuid='" + basicAttr.CaseGuid
          + "',FileType='',TabType='"
          + basicAttr.TabType + "',Wiid='"
          + basicAttr.Wiid + "',ISDAAK=false)", 'PUT',
        basicAttr);

      // add batch operation
      oModel.addBatchChangeOperations([ batchOp ]);
      // this.dynUIAssistArr=this.getView().getModel("global").oData.dynamic;
      // read dynamic attributes
      for (var i = 0; i < this.dynUIAssistArr.length; ++i) {
       var value = "";
       switch (this.dynUIAssistArr[i].type) {
       case "IP":
        value = sap.ui.getCore().byId(
          this.dynUIAssistArr[i].id).getValue();
        break;
       case "F4":
        value = sap.ui.getCore().byId(
          this.dynUIAssistArr[i].id).getValue();
        break;
       case "DP":
        if (sap.ui.getCore()
          .byId(this.dynUIAssistArr[i].id)
          .getDateValue() != null){
         value = this._dateFormatter(sap.ui.getCore()
           .byId(this.dynUIAssistArr[i].id)
           .getDateValue());
        }else{
         value = "";
        }

        // sap.ui.getCore().byId(
        // this.dynUIAssistArr[i].id).getValue();
        break;
       case "TP":
        value = (sap.ui.getCore().byId(
          this.dynUIAssistArr[i].id).getValue()
          .replace(/[^a-z0-9\s]/gi, '')).replace(
          " ", "");

        break;
       case "CB":
        if (sap.ui.getCore().byId(
          this.dynUIAssistArr[i].id).getState()) {
         value = "X";
        } else {
         value = "";
        }
        break;
       case "CU":
        value = sap.ui.getCore().byId(
          this.dynUIAssistArr[i].id).getValue();
        break;
       }

       // create batch operation
       var batchOp = oModel.createBatchOperation(
         "/FILE_ATTR_ES(ID='"
           + this.dynUIAssistArr[i].id
           + "',TABTYPE='" + basicAttr.TabType
           + "')", 'PUT', {
          "ID" : this.dynUIAssistArr[i].id,
          "TYPE" : this.dynUIAssistArr[i].type,
          "VALUE" : value,
          "GUID" : this.caseguid
         });

       // add batch operation
       oModel.addBatchChangeOperations([ batchOp ]);

      }

      if (oControllerS2.flatObj != undefined) {
       // workflow save batch operation
       var updatedWorkflow = this.getView().getModel(
         "global").oData.workflow;
       if (updatedWorkflow != null) {
        // set some attributes which are missing
        updatedWorkflow.CaseGuid = this.caseguid;

        updatedWorkflow.TabType = this.getView().byId(
          "TAB_CONTAINER_FILE").getSelectedKey();
        updatedWorkflow.Wiid = this.wiId;

        // create a model
        var result = oControllerS2.getView().byId(
          "wftree").getModel().getData().nodes;
        // oControllerS2.flatObj=new Array();
        // oControllerS2.globalCounter=0;
        // for(var i=0;i<result.length;i++){
        // oControllerS2.convertToFlatWorkflow(result,i,(i+1));
        // }

        for (var i = 0; i < oControllerS2.flatObj.length; i++) {
         var oModel = this.getView().getModel();
         var op="";
         var isParallel="";
         if(i==oControllerS2.flatObj.length-1){
          op='X';
         }
         if(oControllerS2.flatObj[i].Nodetype=='P'){
          isParallel='X';
         }


         // set batch use as true
         oModel.setUseBatch(true);
         // create batch operation
         var batchOp = oModel
           .createBatchOperation(
             "/FILE_PROUTE_ES(WitemId='"
               + updatedWorkflow.Wiid
               + "',CaseGuid='"
               + updatedWorkflow.CaseGuid
               + "',Posid='')",
             'PUT',
             {
              "isParallel" : isParallel,
              "Nodetype" : oControllerS2.flatObj[i].Nodetype,
              "op" : op,
              "Statustext" : oControllerS2.flatObj[i].Statustext,
              "Actdc" : oControllerS2.flatObj[i].Actdc,
              "Activity" : oControllerS2.flatObj[i].Activity,
              "CaseGuid" : updatedWorkflow.CaseGuid,
              "WitemId" : updatedWorkflow.Wiid,
              "Agent" : oControllerS2.flatObj[i].Agent,
             });

         // add batch operation
         oModel
           .addBatchChangeOperations([ batchOp ]);
        }
       }
      }
      // create batch operation
      var batchOp = oModel.createBatchOperation(
        "/FILE_ATTR_ES(ID='" + "-1" /* this.dynUIAssistArr[i].id */
          + "',TABTYPE='" + basicAttr.TabType
          + "')", 'PUT', {
         "ID" : 'EOT', // end of transfer
         "GUID" : oControllerS2.caseguid,
         "VALUE" : eotValue
        });

      // add batch operation
      oModel.addBatchChangeOperations([ batchOp ]);


      // finally submit batch for both basic and dynamic
      // attributes
      oControllerS2.customBusyDialogOpen();
      oModel
        .submitBatch(
          function(oResponse, oData) {

           oControllerS2.saveFlag = false;
           if (oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message == undefined) {
            if (oControllerS2.flatObj != undefined){
             oControllerS2.getView().byId(
               "idAddInWorkflow")
               .setEnabled(false);
             oControllerS2.getView().byId(
               "idUndoButton").setEnabled(
               false);
             }
            oControllerS2.flatObj=undefined;
            sap.m.MessageToast
              .show(oControllerS2
                .getView()
                .getModel(
                  "i18n")
                .getObject(
                  "SAVESUCCESS"));
            oControllerS2
              .getView()
              .byId("prioText")
              .setText(
                oControllerS2
                  .getView()
                  .byId(
                    "prioSelect")
                  .getSelectedItem()
                  .getText());

           } else if(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf("<severity>warning</severity>") != -1 || oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body.indexOf('"severity":"warning"') != -1 ){
                                             sap.m.MessageBox.confirm(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,
                                                oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers),
                                             function(response) {
                   if (response == "OK") {
                    oControllerS2.customBusyDialogOpen();
                    //eotValue = 'X';
                    oControllerS2.saveButtonPressed('X');

                   }
                                                 });
                                             }
           else {
//            sap.m.MessageBox
//              .alert(oControllerS2
//                .getView()
//                .getModel(
//                  "i18n")
//                .getObject(
//                  "SAVEFAILURE")
//                + " "
//                + oResponse.__batchResponses[oResponse.__batchResponses.length - 1].message);

            sap.m.MessageBox
            .alert(getErrorMessage(oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.body,oResponse.__batchResponses[oResponse.__batchResponses.length - 1].response.headers));

           }
           oControllerS2
             .customBusyDialogClose();
          }, function(oResponse) {

           oControllerS2
             .customBusyDialogClose();
          });

      // 
      // var result =
      // oControllerS2.getView().byId("wftree").getModel().getData().nodes;
      // oControllerS2.flatObj=new Array();
      // oControllerS2.globalCounter=0;
      // for(var i=0;i<result.length;i++){
      // oControllerS2.convertToFlatWorkflow(result,i,(i+1));
      // }

     },

     // Recursive function for creating flat workflow
     convertToFlatWorkflow : function(result, i, level) {

      result[i].Label = level.toString();
      result[i].Actdc = oControllerS2.getView()
        .byId("wftree").getRows()[i].getCells()[1]
        .getText();

      if (result[i].Type == "P") {
       result[i].isParallel = true;
      } else {
       result[i].isParallel = "";
      }

      oControllerS2.flatObj[oControllerS2.globalCounter] = result[i];
      oControllerS2.globalCounter++;
      // }

      for (var j = 0; j < result[i].nodes.length; j++) {
       oControllerS2.convertToFlatWorkflow(
         result[i].nodes, j, result[i].Label + "_"
           + (j + 1));
      }
     },

     /* Open business card in workflow */
     openBusinessCard : function(oEvent) {

       if(oControllerS2.setCustomBusinessCard){
                            oControllerS2.setCustomBusinessCard(oControllerS2,oEvent);
       }else{
        if (!oControllerS2._oBusinessCard) {
             oControllerS2._oBusinessCard = sap.ui.xmlfragment(
               "flm.fiori.view.businessCard", oControllerS2);
            }
            // oControllerS2._oBusinessCard.setModel(oControllerS2.oTreeTable.getModel());
            var contactModel = new sap.ui.model.json.JSONModel();
            contactModel.setData(oEvent.getSource()
              .getBindingContext().getObject());
            oControllerS2._oBusinessCard.setModel(contactModel);
            oControllerS2._oBusinessCard.bindElement("/");
            oControllerS2._oBusinessCard.openBy(oEvent.getSource());
       }
     },
     /* Send section from search */
     sendFromSearchActionOpen : function(oEvent) {
      if (!this._sendSameUser) {
       this._sendSameUser = sap.ui.xmlfragment(
         "flm.fiori.view.searchSend", this);
      }
      sap.ui.getCore().byId("idProcessorName").setValue("");
      sap.ui.getCore().byId("idProcDate").setValue("");
      sap.ui.getCore().byId("idProcDays").setValue("");
      sap.ui.getCore().byId("sendCommentEditor").setValue("");
      var procSelect = sap.ui.getCore().byId("idProcessorSelect");
      var procSelectModel = new sap.ui.model.json.JSONModel({});
      procSelectModel
        .loadData(serviceUrl
          + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and OtherF4 eq true and ID eq 'WC'");
      procSelect.setModel(procSelectModel, "procType");
      var select2 = sap.ui.getCore().byId("idActivitySelect");
      var select2Model = new sap.ui.model.json.JSONModel({});
      select2Model
        .loadData(serviceUrl
          + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and OtherF4 eq true and ID eq 'AC'");
      select2.setModel(select2Model, "actvt");
      this._sendSameUser.open();
     },

     searchSendActionPress : function(oEvent) {
      var agentName = sap.ui.getCore().byId("idProcessorName").getName();
      var procDays = sap.ui.getCore().byId("idProcDays")
        .getValue();
      if (sap.ui.getCore().byId("idActivitySelect")
        .getSelectedKey() == " ") {
       sap.m.MessageBox
         .alert(this.getView().getModel("i18n").getObject("MESSAGE_47"));
       return;
      } else {
       var activity = sap.ui.getCore().byId(
         "idActivitySelect").getSelectedKey();
      }
      var date = new Date();

      if ((date.getMonth() + 1) < 10) {
       month = "0" + (date.getMonth() + 1);
      } else {
       month = date.getMonth() + 1;
      }
      var currentDate = date.getFullYear()+ "/" + month + "/"+ date.getDate();
      var procDate = sap.ui.getCore().byId("idProcDate")
        .getValue();
      var pDate = procDate.replace("/", "").replace("/", "");
      if (procDate == null) {
       sap.m.MessageToast
         .show(this.getView().getModel("i18n").getObject("MESSAGE_28"));

      } else if (procDate <= currentDate) {
       sap.m.MessageToast
         .show(this.getView().getModel("i18n").getObject("MESSAGE_29"));
      }
      var comment = sap.ui.getCore().byId("sendCommentEditor").getValue();
      if(comment == ""){
       sap.m.MessageBox.alert(this.getView()
         .getModel("i18n").getObject(
           "MESSAGE_36"));
      }
      if (procDate != "" && procDays != "") {

       sap.m.MessageToast
         .show(this.getView().getModel("i18n").getObject("MESSAGE_46"));

       return;

      } else
       var oModel = new sap.ui.model.json.JSONModel();
      oModel
        .loadData(
          serviceUrl
            + "/FILES_FI?param_1='SS'&param_2='"
            + this.caseguid
            + "'&param_3='"
            + activity
            + "'&param_4='"
            + pDate
            + "'&param_5='"
            + procDays
            + "'&check_1=''&check_2=''&check_3=''&param_6='"+agentName+"'&param_7='"+comment+"'&param_8=''&param_9=''&param_10=''",
          null, false);
      if (oModel.getData().d.results[0].msg_type == "S") {
       sap.m.MessageToast
         .show(oModel.getData().d.results[0].msg_text);
      } else {
       sap.m.MessageToast
         .show(oModel.getData().d.results[0].msg_text);
       return;
      }
      this._sendSameUser.close();
      this.oRouter.navTo("searchscreen");
      ;
     },

     onSendSearchCloseButton : function(oEvent) {
      this._sendSameUser.close();
     },
     /*sendConfirmActionPress : function(oEvent) {
      if (!this._sendSameUser) {
       this._sendSameUser = sap.ui.xmlfragment(
         "flm.fiori.view.searchSend", this);
      }
      var selectActivity = sap.ui.getCore().byId(
        "idActivitySelect");
      var selectActivityModel = new sap.ui.model.json.JSONModel(
        {});
      selectActivityModel
        .loadData(serviceUrl
          + "/FILE_F4_ES?$filter=OtherF4 eq true and ID eq 'AC'");
      selectActivity.setModel(selectActivityModel);
      this._sendSameUser.open();

      this.closeDialog('sendSameUserMessage');
     },
     sendConfirmClosePress : function(oEvent) {
      this.closeDialog('sendSameUserMessage');
     },*/
     // /***Code Changes to be made-End***///

     onPressHelpValue : function(oEvent) {
      if (!oControllerS2._oDynamicF4Dialog) {
       oControllerS2._oDynamicF4Dialog = sap.ui
         .xmlfragment(
           "flm.fiori.view.dynamicF4popup",
           oControllerS2);
      }
      oF4Texts = new sap.ui.model.json.JSONModel();
      var f4text = {
       title : this.getView().getModel("i18n").getObject("USER"),
       id : oEvent.getSource().getId()
      };
      oF4Texts.setData(f4text);
      oControllerS2._oDynamicF4Dialog.setModel(oF4Texts,
        "dyntext");

      var oF4Model = new sap.ui.model.json.JSONModel();
      oF4Model
        .loadData(
          serviceUrl
            + "/FILE_F4_ES?$filter=CaseGuid eq '"
             + this.caseguid
             + "' and ID eq 'US' and WF eq true",
          null, false);
      oF4Model.setData(oF4Model.oData.d.results);
      oControllerS2._oDynamicF4Dialog.setModel(oF4Model);
      oControllerS2._oDynamicF4Dialog.open();
     },

     handleValueHelpSearch : function(evt) {

      var sValue = evt.getParameter("value");
      var oFilter = new sap.ui.model.Filter("ResulltCol1",
        sap.ui.model.FilterOperator.Contains, sValue);
      var oFilter1 = new sap.ui.model.Filter("ResultCol2",
        sap.ui.model.FilterOperator.Contains, sValue);
      var oFilter2 = new sap.ui.model.Filter("ResultCol3",
        sap.ui.model.FilterOperator.Contains, sValue);
      evt.getSource().getBinding("items").filter(
        new sap.ui.model.Filter([ oFilter, oFilter1,
          oFilter2 ]), "OR");
     },

     handleValueHelpConfirm : function(evt) {

      var oSelectedItem = evt.getParameter("selectedItem");
      if (oSelectedItem) {
       // var oInput =
       // sap.ui.getCore().byId("userValueInput"); // get
       // the id and
       // place it here
       // var oInput = this.getView().byId(
       // evt.getSource().getModel("dyntext")
       // .getData().id);

       var oInput = sap.ui.getCore().byId(
         evt.getSource().getModel("valueHelpText")
           .getData().id);
       oInput.setValue(oSelectedItem.getDescription()
         + " " + oSelectedItem.getTitle());
       oInput.setName(oSelectedItem.getBindingContext()
         .getObject().ResultCol3);
      }
      evt.getSource().getBinding("items").filter([]);
      this.valueHelpDialogOpen.getModel().destroy();
      this.valueHelpDialogOpen.getModel("valueHelpText")
        .destroy();
     },

     initializeSearchHelp : function(controller) {

      var srchData = {
       criteria : null,
       operators : null,
       searchData : null,
      };

      srchData.criteria = [
         {
          key : "CASE_TITLE",
          title : this.getView().getModel("i18n")
            .getObject("SUBJECT")
         },
         {
          key : "PS_REFERENCE",
          title : this.getView().getModel("i18n")
            .getObject("FILENUMBER")
         },
         {
          key : "CREATED_BY",
          title : this.getView().getModel("i18n")
            .getObject("CREATEDBY")
         },
         {
          key : "CHANGED_BY",
          title : this.getView().getModel("i18n")
            .getObject("LASTCHANGEDBY")
         },
         {
          key : "CLOSED_BY",
          title : this.getView().getModel("i18n")
            .getObject("CLOSEDBYUSER")
         },
         {
          key : "CREATE_TIME",
          title : this.getView().getModel("i18n")
            .getObject("CREATEDON")
         },
         /*{
          key : "EXT_KEY",
          title : this.getView().getModel("i18n")
            .getObject("FILEID")
         },*/
         {
          key : "PLAN_END_DATE",
          title : this.getView().getModel("i18n")
            .getObject("DUEDATE")
         },
         {
          key : "ARCHIVE",
          title : this.getView().getModel("i18n")
            .getObject("READFROMARCHIVE")
         },
         {
          key : "STAT_ORDERNO",
          title : this.getView().getModel("i18n")
            .getObject("STATUS")
         },
         {
          key : "SAP_FLM_PRIO",
          title : this.getView().getModel("i18n")
            .getObject("PRIORITY")
         },
         {
          key : "FILE_TYPE",
          title : this.getView().getModel("i18n")
            .getObject("FILETYPE")
         },
         {
          key : "ORG_UNIT",
          title : this.getView().getModel("i18n")
            .getObject("ORGANIZATIONGROUP")
         }, ];

      srchData.operators = [
        {
         criteria : "GEN1",
         opkey : "01",
         optext : this.getView().getModel("i18n")
           .getObject("IS")
        },
        {
         criteria : "GEN2",
         opkey : "05",
         optext : this.getView().getModel("i18n")
           .getObject("CONTAINS")
        },
        {
         criteria : "GEN2",
         opkey : "04",
         optext : this.getView().getModel("i18n")
           .getObject("STARTSWITH")
        },
        {
         criteria : "DATE",
         opkey : "11",
         optext : this.getView().getModel("i18n")
           .getObject("ISEARLIERTHAN")
        },
        {
         criteria : "DATE",
         opkey : "12",
         optext : this.getView().getModel("i18n")
           .getObject("ISLATERTHAN")
        },
        {
         criteria : "DATE",
         opkey : "21",
         optext : this.getView().getModel("i18n")
           .getObject("ISEARLIERTHANORON")
        },
        {
         criteria : "DATE",
         opkey : "22",
         optext : this.getView().getModel("i18n")
           .getObject("ISLATERTHANORON")
        },
        {
         criteria : "ISNOT",
         opkey : "02",
         optext : this.getView().getModel("i18n")
           .getObject("ISNOT")
        } ];

      srchData.searchData = {
       criteria1 : "CASE_TITLE",
       op1 : "01",
       value1 : "",
       criteria2 : "PS_REFERENCE",
       op2 : "01",
       value2 : "",
       criteria3 : "CREATED_BY",
       op3 : "01",
       value3 : "",
       criteria4 : "CHANGED_BY",
       op4 : "01",
       value4 : "",
       criteria5 : "CLOSED_BY",
       op5 : "01",
       value5 : ""
      };

      srchData.searchResult = null;
      var oSearchModel = new sap.ui.model.json.JSONModel();
      oSearchModel.setData(srchData);
      return oSearchModel;
     },

     downloadURL : function downloadURL(url) {
      var hiddenIFrameID = 'hiddenDownloader', iframe = document
        .getElementById(hiddenIFrameID);
      if (iframe === null) {
       iframe = document.createElement('iframe');
       iframe.id = hiddenIFrameID;
       iframe.style.display = 'none';
       document.body.appendChild(iframe);
      }
      iframe.src = url;
     },

     handleDeleteProcessor : function(evt) { // ADD CHANGE
      var oTable = sap.ui.getCore().byId("idProcessorsTable");
      // var
      // i=evt.getParameter("listItem").getBindingContext("dummy").getObject().position;
      for (var i = 0; i < oTable.getItems().length; i++) {
       if (evt.getParameter("listItem").getBindingContext(
         "dummy").getObject().position == oTable
         .getItems()[i].getBindingContext("dummy")
         .getObject().position) {
        evt.getSource().getModel("dummy").oData.data
          .splice(i, 1);
        break;
       }
      }

      evt.getSource().getModel("dummy").checkUpdate();
     },

     onChangeFileAttribute : function(oEvent) {
      oControllerS2.saveFlag = true;
     },

     getErrorMessage: function(messageString){
      var msgObj = eval("(" + messageString + ")");
      var message = msgObj.error.message.value;
      return message;
     },
     subDetailsPressed : function(oEvent){

      if (!this.privateDetailOpen) {
       this.privateDetailOpen = sap.ui.xmlfragment(
         "flm.fiori.view.privateDetails", this);
      }
      var detailsModel = new sap.ui.model.json.JSONModel();
      detailsModel.setData(oEvent.getSource()
        .getBindingContext("global").getObject());
      this.privateDetailOpen.setModel(detailsModel);
      this.privateDetailOpen.bindElement("/");
      this.privateDetailOpen.openBy(oEvent.getSource());
     },

     raiseFlag : function(oEvent){

      sap.m.MessageToast
      .show(oControllerS2.getView().getModel("i18n").getObject("MESSAGE_57"));
      oEvent.getSource().setValue("");
     },

     onDeleteSelect : function(oEvent){
                     if(oControllerS2.getView().byId("wftree").getSelectedIndex()==-1){
                      sap.m.MessageBox.alert(oControllerS2.getView().getModel("i18n").getObject("MESSAGE76"));
                      return;
                     }
      sap.m.MessageBox.confirm("Are you sure, you want to delete the processor?",
                       function(response) {
         if (response == "OK") {
          oControllerS2.customBusyDialogOpen();
//                                 var currNode = oControllerS2.byId("wftree").getContextByIndex(
//                                   oControllerS2.byId("wftree").getSelectedIndex());
                                 oControllerS2.onDeleteButtonPress();
                  oControllerS2.reloadWorkflow(oControllerS2);
//            oControllerS2.byId("wftree").setSelectedIndex(-1);
         }
         else{
          oControllerS2.customBusyDialogClose();
          return;
         }
                           });
                    },

     onDeleteButtonPress : function() {
      oControllerS2.customBusyDialogOpen();
      var currNode = this.byId("wftree").getContextByIndex(
        this.byId("wftree").getSelectedIndex())
        .getObject();
      var oModel = this.getView().getModel();
      if(currNode.isSpecial=='X'){
       for(var i=currNode.nodes.length-1;i>=0;i--){
        oModel.remove("/FILE_PROUTE_ES(Posid='"
          + currNode.nodes[i].Posid + "',CaseGuid='"
          + this.caseguid + "',WitemId='" + this.wiId
          + "')", {
         success : function(oResponse) {
          oControllerS2.reloadWorkflow(oControllerS2);
//          oControllerS2.byId("wftree").setSelectedIndex(-1);
          oControllerS2.byId("idDeleteButton")
            .setEnabled(false);
          oControllerS2.byId("idAddInWorkflow").setEnabled(false);
          oControllerS2.customBusyDialogClose();
         },
         error : function(oResponse) {
          oControllerS2.customBusyDialogClose();
         },
         async : false,
        });

       }
      }else{
      oModel.remove("/FILE_PROUTE_ES(Posid='"
        + currNode.Posid + "',CaseGuid='"
        + this.caseguid + "',WitemId='" + this.wiId
        + "')", {
       success : function(oResponse) {
        oControllerS2.reloadWorkflow(oControllerS2);
//        oControllerS2.byId("wftree").setSelectedIndex(-1);
        oControllerS2.byId("idDeleteButton")
          .setEnabled(false);
        oControllerS2.byId("idAddInWorkflow").setEnabled(false);
        oControllerS2.customBusyDialogClose();
       },
       error : function(oResponse) {
        oControllerS2.customBusyDialogClose();
       },
       async : true,
      });
      }
//      oControllerS2.byId("wftree").setSelectedIndex(-1);
     },

     onWorkflowItemSelect : function(oEvent) {

      if (this.byId("wftree").getSelectedIndex() == "-1") {
       // hide the delete button
       this.byId("idDeleteButton").setEnabled(false);
       this.byId("idAddInWorkflow").setEnabled(false);
       return;
      }
      var currNode = this.byId("wftree").getContextByIndex(
        this.byId("wftree").getSelectedIndex())
        .getObject();

      // Already processed users cannot be selected for both adding and deleting
      if (currNode.Enddate != ""){
       // hide the delete button
       this.byId("idDeleteButton").setEnabled(false);
       //if special node then check for the last child node, if it has not completed processing enable add button
       if(currNode.isSpecial!='X'){
       this.byId("idAddInWorkflow").setEnabled(false);
       }else{
        if(currNode.nodes[currNode.nodes.length-1].Enddate!=""){
         this.byId("idAddInWorkflow").setEnabled(false);
        }else{
         this.byId("idAddInWorkflow").setEnabled(true);
        }
       }
       return;
      }
      // Currently processing users can add after them but not delete
      else if (currNode.Creadate != "" && currNode.Enddate == ""){
       // hide the delete button
       this.byId("idDeleteButton").setEnabled(false);

       // add button visibility
       // Special authorized person can also add

       if (oControllerS2.workflowAdminAuthorization) {
        this.byId("idAddInWorkflow").setEnabled(true);
       } else if (currNode.PosidWiid == oControllerS2.wiId) {
        /*Add button will be displayed based on wether he had already added or not*/
        if(this.byId("wftree").getContextByIndex(this.byId("wftree").getSelectedIndex()+1)){
         var nextNode = this.byId("wftree").getContextByIndex(
           this.byId("wftree").getSelectedIndex()+1)
           .getObject();
         // if next row is inserted by him then he cannot add
         if(nextNode.IsDelete){
          this.byId("idAddInWorkflow").setEnabled(false);
         }else{
          this.byId("idAddInWorkflow").setEnabled(true);
         }
        }else{
         this.byId("idAddInWorkflow").setEnabled(true);
        }

       } else {
        this.byId("idAddInWorkflow").setEnabled(false);
       }
       if(currNode.isSpecial=='X'){
       var selPath = oControllerS2.byId("wftree").getContextByIndex(oControllerS2.byId("wftree").getSelectedIndex()).getPath().split('/');
       var selNode = oControllerS2.byId("wftree").getModel().oData;
       for(var i=2;i<selPath.length-2;i+=2){
        if(i!=selPath.length-3){
         selNode=selNode.nodes[parseInt(selPath[i])];
        }else{
         selNode=selNode.nodes[parseInt(selPath[i])+1];
        }
       }
       if(!selNode || selNode.Pospast==""){
        this.byId("idAddInWorkflow").setEnabled(true);
       }else{
        this.byId("idAddInWorkflow").setEnabled(false);
       }
       }
       return;
      }

      /* 1. In future processors, authorised person can delete/add users as per his wish
       * 2. Normal processor can user can add 1(sequntial)/multiple(parallel) under him and 
       *    delete the added ones before he sends the file to next processor.
       */
      else if (currNode.Creadate == "" && currNode.Enddate == ""){
       if (oControllerS2.workflowAdminAuthorization ) {     // Super user or the processors the current users has added
        this.byId("idDeleteButton").setEnabled(true);
        this.byId("idAddInWorkflow").setEnabled(true);
       }else if (currNode.IsDelete == true){
        this.byId("idDeleteButton").setEnabled(true);
        // addition is allowed but only in parallel
        if(this.workflowParallelEnabled){
         this.byId("idAddInWorkflow").setEnabled(true);
        }else{
         this.byId("idAddInWorkflow").setEnabled(false);
        }
       }
       else {
        this.byId("idDeleteButton").setEnabled(false);
        this.byId("idAddInWorkflow").setEnabled(false);
       }
       return;
      }
     },

     reloadWorkflow : function(controller) {
      // load the service and set the model
      controller.customBusyDialogOpen();
      oWorkflowModel = new sap.ui.model.json.JSONModel();
      oWorkflowModel
        .attachRequestCompleted(
          controller,
          function(oEvent) {
           oWorkflowModel
             .detachRequestCompleted();
           controller.data.workflow = oWorkflowModel.oData.d.results;
           controller.getView().getModel(
             "global").checkUpdate();
           controller.byId("idWorkflowGrid")
             .setBusy(false);
           controller
             .initializeWorkflow(controller);
           controller.getView().getModel(
             "global").checkUpdate();
//           controller.byId("wftree").setSelectedIndex(-1);
           controller.byId("idDeleteButton")
             .setEnabled(false);
           controller.byId("idAddInWorkflow").setEnabled(false);
           controller.customBusyDialogClose();
          }, controller);
      oWorkflowModel.loadData(serviceUrl
        + "/FILE_PROUTE_ES?$filter=CaseGuid eq '"
        + controller.caseguid + +"' and TabType eq '"
        + controller.fromTab + "' and WitemId eq '"
        + controller.wiId + "'", null, true);
     },

     onInsertInWorkflow : function(oEvent) {
      // Set the busy indicator
      oControllerS2.customBusyDialogOpen();

      // Handle insertion for both sequence
      if (sap.ui.getCore().byId("idSequenceRadioButton")
        .getSelected() == true) {
       var processor = sap.ui.getCore().byId("idSelect1")
         .getSelectedItem().getText();
       var sendTo = sap.ui.getCore().byId("idUsername")
         .getValue();
       var agent = sap.ui.getCore().byId("idUsername")
         .getName();
       var activity = sap.ui.getCore().byId("idSelect2")
         .getSelectedItem().getText();
       var activityKey = sap.ui.getCore()
         .byId("idSelect2").getSelectedItem()
         .getKey();
       var processingDate = "";
       var nodeType=" ";
       if(sap.ui.getCore().byId("idDatePickerSendTo").getValue() != ""){
        processingDate = sap.ui.getCore().byId("idDatePickerSendTo").getValue();
       }

       var processingDays = 0;
       if(sap.ui.getCore().byId("idInputDays").getValue() != ""){
        processingDays = parseInt(sap.ui.getCore().byId("idInputDays").getValue());
       }

       if ((sendTo == "" || activity == "" || processor == "")) {
        sap.m.MessageToast.show(this.getView()
          .getModel("i18n").getObject(
            "MESSAGE_48"));
        return;
       }
       if (processingDate != "" && processingDays != "") {
        sap.ui.getCore().byId("idDatePickerSendTo")
          .setValue("");

        sap.ui.getCore().byId("idInputDays").setValue(
          "");

        sap.m.MessageBox.alert(this.getView().getModel(

        "i18n").getObject("MESSAGE_21"));
        return;
       }
       var wftree=oControllerS2.byId("wftree");
       if(wftree.getContextByIndex(wftree.getSelectedIndex()).getObject().isSpecial=="X"){
                             nodeType="P";
//                             oControllerS3.flatObj[i].isParallel="";
                            }
       var newObj = {
        "Actdc" : activity,
        "Activity" : activityKey,
        "Agent" : agent,
        "Nodetype" : nodeType,
        "op" : "INTRAY",
        "CaseGuid" : oControllerS2.caseguid,
        "Fullname" : sendTo,
        "PosidLed" : processingDate,
        "DueDays" : processingDays,
        "Parentid" : this.byId("wftree")
          .getContextByIndex(
            this.byId("wftree")
              .getSelectedIndex())
          .getObject().Posid,
       };

       var oWfModel = oControllerS2.getView().getModel();
       oWfModel
         .create(
           "/FILE_PROUTE_ES",
           newObj,
           {
            success : function(oResponse) {

             // Reloading the workflow
             // and closing the busy
             // indicator
             oControllerS2
               .reloadWorkflow(oControllerS2);

            },
            error : function(oResponse) {

             // through the error and
             // close the busy indicator
             oControllerS2
               .customBusyDialogClose();
             sap.m.MessageBox.alert(oControllerS2.getView()
               .getModel("i18n").getObject("MESSAGE_68"));
            },
            async : true,
           });
      } else if (sap.ui.getCore().byId("idParallelRadioButton").getSelected() == true) {
       // Parallel scenario is handled here

       var parList = sap.ui.getCore().byId(
         "idProcessorsTable").getModel("dummy")
         .getData().data;
       if (parList.length < 1) {
        // Raise an error to select two or more entries
        sap.m.MessageBox
          .alert("Select atleast one entry to insert in parallel");
        oControllerS2.customBusyDialogClose();
        return;
       }
       var oModel = oControllerS2.getView().getModel();
       // set batch use as true
       oModel.setUseBatch(true);
       oModel.clearBatch();
       var isParallel = "X";
       var nodeType = "P";
       for (var i = 0; i < parList.length; i++) {
//        var sendTo = parList[i].Name;
        var activity = parList[i].Actdc;
        var processingDate = parList[i].Date;
        var processingDays = 0;
        if(parList[i].Days != ""){
         processingDays = parseInt(parList[i].Days);
        }
        var agent = parList[i].Agent;
        var activityKey = parList[i].Activity;
        var op = " ";
        var parentid = this.byId("wftree")
         .getContextByIndex(
           this.byId("wftree")
             .getSelectedIndex()).getObject().Posid;


        if (i == parList.length - 1) {
         op = "INTRAY";  // op --> Represents that
             // this is the last record
             // sent in the create call.
             // This flag is used to
             // store data to DB
        }
        var batchOp = oModel
          .createBatchOperation(
            "/FILE_PROUTE_ES",
            'POST',
            {
             "isParallel" : isParallel,
             "Nodetype" : nodeType,
             "Actdc" : activity,
             "Activity" : activityKey,
             "CaseGuid" : oControllerS2.caseguid,
             "WitemId" : oControllerS2.wiId,
             "Agent" : agent,
             "PosidLed" : processingDate,
             "DueDays" : processingDays,
             "op" : op,
             "Parentid" : parentid,
            });

        // add batch operation
        oModel.addBatchChangeOperations([ batchOp ]);
        isParallel = 'X'; // all the rows inserted
             // after the first one need
             // to be inserted in
             // parallel to it
       }

       // submit the batch and store the results
       oModel.submitBatch(function(oResponse, oData) {
        // Success function
        // Reloading the workflow and closing the busy
        // indicator
        oControllerS2.reloadWorkflow(oControllerS2);
//        oControllerS2.customBusyDialogClose();
       }, function(oResponse) {
        // failure function
        // through the error and close the busy
        // indicator
        oControllerS2.customBusyDialogClose();
       }, true);

      }
      oControllerS2.oSequenceSend.close();
     },

     resetWorkflowPopup: function(controller, mode){
      //clearing the input fields
      sap.ui.getCore().byId("idSelect1").setSelectedKey("SPACE");
      sap.ui.getCore().byId("idSelect2").setSelectedKey("SPACE");
      sap.ui.getCore().byId("idUsername").setValue("");
      sap.ui.getCore().byId("idDatePickerSendTo").setValue("");
      sap.ui.getCore().byId("idInputDays").setValue("");
      // Condition to check wether parallel is enabled or not. Correspondingly changing UI
      if(controller.workflowParallelEnabled){
       // clearing the model
       var oTable = sap.ui.getCore().byId("idProcessorsTable");
       if(oTable.getModel("dummy")){
        oTable.getModel("dummy").destroy();
       }
       var oModel = new sap.ui.model.json.JSONModel({
        "data" : []
       });
       oTable.setModel(oModel, "dummy");
       if(mode == null){    //normal reset
        sap.ui.getCore().byId("idSequenceRadioButton").setVisible(true);
        sap.ui.getCore().byId("idParallelRadioButton").setVisible(true);
        sap.ui.getCore().byId("idSequenceRadioButton").setEnabled(true);
        sap.ui.getCore().byId("idParallelRadioButton").setEnabled(true);
        sap.ui.getCore().byId("idSequenceRadioButton").setSelected(true);
        sap.ui.getCore().byId("idParallelRadioButton").setSelected(false);
        controller.onSeqSelect();
       }else if(mode == "SEQ"){  //reset and set it for seq alone
        sap.ui.getCore().byId("idSequenceRadioButton").setVisible(true);
        sap.ui.getCore().byId("idParallelRadioButton").setVisible(true);
        sap.ui.getCore().byId("idSequenceRadioButton").setEnabled(true);
        sap.ui.getCore().byId("idParallelRadioButton").setEnabled(false);
        sap.ui.getCore().byId("idParallelRadioButton").setSelected(false);
        sap.ui.getCore().byId("idSequenceRadioButton").setSelected(true);
        controller.onSeqSelect();
       }else if(mode == "PAR"){  //reset and set it for parallel alone
        sap.ui.getCore().byId("idSequenceRadioButton").setVisible(true);
        sap.ui.getCore().byId("idParallelRadioButton").setVisible(true);
        sap.ui.getCore().byId("idSequenceRadioButton").setEnabled(false);
        sap.ui.getCore().byId("idParallelRadioButton").setEnabled(true);
        sap.ui.getCore().byId("idSequenceRadioButton").setSelected(false);
        sap.ui.getCore().byId("idParallelRadioButton").setSelected(true);
        controller.onParSelect();
       }
      }else{
       sap.ui.getCore().byId("idSequenceRadioButton").setVisible(true);
       sap.ui.getCore().byId("idParallelRadioButton").setVisible(false);
       sap.ui.getCore().byId("idSequenceRadioButton").setSelected(true);
       sap.ui.getCore().byId("idParallelRadioButton").setSelected(false);
       controller.onSeqSelect();
      }
     },

     onChangeDateTimeInDynamicUI : function(oEvent) {
      oControllerS2.saveFlag = true;
      if(oEvent.getSource().getValue()!="" && oEvent.getSource().getEditable()){
      sap.ui.getCore().byId(oEvent.getSource().getId()+"Clear").setVisible(true);
      }else{
      sap.ui.getCore().byId(oEvent.getSource().getId()+"Clear").setVisible(false);
      }

     },

    });